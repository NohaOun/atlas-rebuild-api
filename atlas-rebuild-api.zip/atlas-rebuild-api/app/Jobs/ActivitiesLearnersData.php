<?php

namespace App\Jobs;

use App\Domain\Edmentum\ActivityLearnerLibrary;
use App\Domain\Edmentum\Repository\EdmentumFetchingDataRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ActivitiesLearnersData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $classId;

    private $id;

    protected $thisedmentumFetchingDataRepo;

    protected $activityLearnerLibrary;

    public function __construct($classId, $id)
    {
        $this->classId = $classId;

        $this->id = $id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(EdmentumFetchingDataRepository $edmentumFetchingDataRepo, ActivityLearnerLibrary $activityLearnerLibrary)
    {
        $this->edmentumFetchingDataRepo = $edmentumFetchingDataRepo;

        $activities = $this->edmentumFetchingDataRepo->getClassesActivitiesScore();

        $this->activityLearnerLibrary = $activityLearnerLibrary;

        $this->activityLearnerLibrary->storeActivityLearner($activities, $this->id);
    }
}
