<?php

namespace App\Jobs;

use App\Domain\Edmentum\LearnerLibrary;
use App\Domain\Edmentum\Repository\EdmentumFetchingDataRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ClassLearnersData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $classId;

    protected $edmentumFetchingDataRepo;

    protected $learnerLibrary;

    public function __construct($classId)
    {
        $this->classId = $classId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(EdmentumFetchingDataRepository $edmentumFetchingDataRepo, LearnerLibrary $learnerLibrary)
    {
        $this->edmentumFetchingDataRepo = $edmentumFetchingDataRepo;

        $learners = $this->edmentumFetchingDataRepo->getClassLearners($this->classId);

        $this->learnerLibrary = $learnerLibrary;

        $this->learnerLibrary->UpdateClassLearner($learners);
    }
}
