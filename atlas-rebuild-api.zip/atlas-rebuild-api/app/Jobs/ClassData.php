<?php

namespace App\Jobs;

use App\Domain\Edmentum\ClassLibrary;
use App\Domain\Edmentum\Repository\EdmentumFetchingDataRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ClassData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $programId;

    private $edmentumId;

    protected $edmentumFetchingDataRepo;

    protected $classLibrary;

    public function __construct($programId, $edmentumId)
    {
        $this->programId = $programId;

        $this->edmentumId = $edmentumId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(EdmentumFetchingDataRepository $edmentumFetchingDataRepo, ClassLibrary $classLibrary)
    {
        $this->edmentumFetchingDataRepo = $edmentumFetchingDataRepo;

        $classData = $this->edmentumFetchingDataRepo->getClassesDetailsData($this->edmentumId);

        $this->classLibrary = $classLibrary;

        $this->classLibrary->storeClassData($this->programId, $classData);
    }
}
