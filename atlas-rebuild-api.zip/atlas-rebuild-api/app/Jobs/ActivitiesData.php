<?php

namespace App\Jobs;

use App\Domain\Edmentum\ActivityLibrary;
use App\Domain\Edmentum\Repository\EdmentumFetchingDataRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ActivitiesData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $classId;

    private $id;

    protected $edmentumFetchingDataRepo;

    protected $activityLibrary;

    public function __construct($classId, $id)
    {
        $this->classId = $classId;

        $this->id = $id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(EdmentumFetchingDataRepository $edmentumFetchingDataRepo, ActivityLibrary $activityLibrary)
    {
        $this->edmentumFetchingDataRepo = $edmentumFetchingDataRepo;

        $activities = $this->edmentumFetchingDataRepo->getClassesActivitiesData($this->classId);

        $this->activityLibrary = $activityLibrary;

        $this->activityLibrary->storeActivities($activities, $this->id);
    }
}
