<?php

namespace App\Jobs;

use App\Domain\Edmentum\Repository\EdmentumFetchingDataRepository;
use App\Domain\Edmentum\TimeOnTaskLibrary;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class TimeOnTaskData implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $classId;

    private $id;

    protected $edmentumFetchingDataRepos;

    protected $timeOnTaskLibrary;

    public function __construct($classId, $id)
    {
        $this->classId = $classId;

        $this->id = $id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(EdmentumFetchingDataRepository $edmentumFetchingDataRepos, TimeOnTaskLibrary $timeOnTaskLibrary)
    {
        $this->edmentumFetchingDataRepos = $edmentumFetchingDataRepos;

        $data = $this->edmentumFetchingDataRepos->getClassesTaskTimePerDay($this->classId);

        $this->timeOnTaskLibrary = $timeOnTaskLibrary;

        $this->timeOnTaskLibrary->storeTimeOnTask($data, $this->id);

    }
}

