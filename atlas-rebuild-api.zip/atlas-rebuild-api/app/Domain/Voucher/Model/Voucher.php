<?php

namespace App\Domain\Voucher\Model;

use App\Domain\Student\Model\Student;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;
use Symfony\Component\DomCrawler\Crawler;

class Voucher extends Model
{

    protected $fillable = ['student_id', 'email_body', 'subject', 'amount', 'merchant'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function extractMerchantFromSubject()
    {
        return trim(str_replace(['is Here!', 'Your', $this->amount, 'Code'], '', $this->subject));
    }

    public function extractAmountFromBody()
    {
        try {
            $crawler = new Crawler($this->email_body);
            $amount = $crawler->filter('[height=88] p:nth-child(3)')->text();
            return str_replace('.00', '', $amount);
        } catch (\Exception $exception) {
            return null;
        }
    }

    public static function boot()
    {
        static::creating(function (Voucher $model) {
            $model->fill([
                'merchant' => $model->extractMerchantFromSubject(),
                'amount' => $model->extractAmountFromBody()
            ]);
        });

        parent::boot();
    }
}
