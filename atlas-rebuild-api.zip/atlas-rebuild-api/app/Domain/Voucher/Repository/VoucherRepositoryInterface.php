<?php

namespace App\Domain\Voucher\Repository;

use App\Domain\Voucher\Filters\VoucherFilters;
use App\Domain\Voucher\Model\Voucher;

interface VoucherRepositoryInterface
{
    public function getVouchers(VoucherFilters $filterse);

    public function getVoucher($voucher): ?Voucher;


    public function saveVoucher(Voucher $redemption);

    public function deleteVoucher(Voucher $redemption);
}
