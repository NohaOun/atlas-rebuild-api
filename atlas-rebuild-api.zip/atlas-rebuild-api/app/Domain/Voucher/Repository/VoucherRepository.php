<?php

namespace App\Domain\Voucher\Repository;

use App\Domain\Voucher\Filters\VoucherFilters;
use App\Domain\Voucher\Model\Voucher;

class VoucherRepository implements VoucherRepositoryInterface
{
    public function getVouchers(VoucherFilters $filters)
    {
        $builder = Voucher::query();
        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getVouchersBuilders(VoucherFilters $filters)
    {
        $builder = Voucher::query();
        if ($filters) $filters->apply($builder);

        return $builder;
    }

    public function getVoucher($voucherId): ?Voucher
    {
        return Voucher::query()->find($voucherId);
    }

    public function saveVoucher(Voucher $voucher)
    {
        return $voucher->save();
    }

    public function deleteVoucher(Voucher $voucher)
    {
        return $voucher->delete();
    }

}
