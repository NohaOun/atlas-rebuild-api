<?php

namespace App\Domain\Voucher;

use App\Domain\Voucher\Model\Voucher;
use App\Domain\Voucher\Model\StudentPoint;
use App\Domain\Voucher\Repository\VoucherRepository;
use App\Domain\Voucher\Repository\VoucherRepositoryInterface;
use App\Domain\Status\StatusLibrary;

class VoucherLibrary
{
    protected $voucherRepo;
    /**
     * @var StatusLibrary
     */

    public function __construct(VoucherRepository $voucherRepo)
    {
        $this->voucherRepo = $voucherRepo;
    }

    public function getVouchers($filters)
    {
        $vouchers = $this->voucherRepo->getVouchers($filters);

        return $vouchers;
    }

    public function getVoucher($voucherId)
    {
        return $this->voucherRepo->getVoucher($voucherId);
    }

    public function createVoucher($input)
    {
        $voucher = new Voucher($input);

        $this->voucherRepo->saveVoucher($voucher);

        return $voucher;
    }

    public function updateVoucher(Voucher $voucher, $data)
    {
        $voucher->fill($data);

        $this->voucherRepo->saveVoucher($voucher);

        return $voucher;
    }

    public function deleteVoucher(Voucher $voucher)
    {
        return $this->voucherRepo->deleteVoucher($voucher);
    }

}
