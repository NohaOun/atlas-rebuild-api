<?php

namespace App\Domain\Voucher;


use App\Domain\Voucher\Model\Voucher;
use App\Domain\Voucher\Repository\VoucherRepository;
use App\Domain\Voucher\Repository\VoucherRepositoryInterface;
use App\Observers\VoucherObserver;
use Illuminate\Support\ServiceProvider;

class VoucherServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(VoucherRepositoryInterface::class, VoucherRepository::class);
    }

    public function boot()
    {
        Voucher::observe(VoucherObserver::class);
    }
}
