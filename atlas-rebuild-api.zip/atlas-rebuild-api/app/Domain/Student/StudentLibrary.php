<?php

namespace App\Domain\Student;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Contact\Repository\ContactRepositoryInterface;
use App\Domain\Edmentum\Model\EdmentumLearnerTask;
use App\Domain\FileUpload\FileUploadLibrary;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\Student\Exception\LegalGuardianException;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\CurrentCourse;
use App\Domain\Student\Model\RecruitmentLog;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentAssignee;
use App\Domain\Student\Model\StudentParent;
use App\Domain\Student\Model\StudentSchedule;
use App\Domain\Student\Notification\StudentParentCreated;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentPoint\StudentPointLibrary;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class StudentLibrary
{
    protected $studentRepo;
    protected $fileUploadLibrary;
    protected $contactRepo;
    protected $statusRepository;
    protected $studentPointLibrary;
    protected $challengeLibrary;

    public function __construct(
        StudentRepositoryInterface $studentRepo,
        FileUploadLibrary $fileUploadLibrary,
        ContactRepositoryInterface $contactRepo,
        StatusRepositoryInterface $statusRepository,
        StudentPointLibrary $studentPointLibrary,
        ChallengeLibrary $challengeLibrary
    )
    {
        $this->studentRepo = $studentRepo;
        $this->fileUploadLibrary = $fileUploadLibrary;
        $this->contactRepo = $contactRepo;
        $this->statusRepository = $statusRepository;
        $this->studentPointLibrary = $studentPointLibrary;
        $this->challengeLibrary = $challengeLibrary;
    }

    public function getStudents(StudentFilters $filters = null)
    {
        $paginationExists = $filters->checkFilterExists('per_page');

        return $paginationExists ? $this->studentRepo->getStudentFilter($filters) : $this->studentRepo->getStudents($filters);
    }

    public function getStudent($record)
    {
        return $this->studentRepo->getStudent($record);
    }

    public function createStudent($data)
    {
        $data['attributes']['referral_code'] = $this->createStudentReferralCode();

        return $this->saveStudent(new Student, $data);
    }

    public function updateStudentGraduation(Student $student, $input)
    {
        $student->fill($this->formatStudentInput($input['data']));
        $this->studentRepo->saveStudent($student);
        return $student;
    }

    public function updateStudent(Student $student, $data)
    {
        if (
            $student->status->phase->name == PhaseKeyRepositoryInterface::PHASE_NAME_ENROLLED_ORIENTATION
        ) {
            Log::info('we are in challenge update');
            $referral_code = $student->contact->referrer;
            $refer_challenge = $this->challengeLibrary->getChallengeByType('referral_friend');
            if ($referral_code && $refer_challenge->status) {
                $student = Student::where('referral_code', $referral_code)->first();
                Log::info('we are in challenge update 2nd if');
                switch ($refer_challenge->property["referral_friend"]["type"] ?? 2) {
                    case"1":
                        Log::info('we are in challenge update case 1');
                        $this->studentPointLibrary->multiplyPoints($student, $refer_challenge->property["referral_friend"]["value"], $refer_challenge);
                        $this->rewardNewBadge($student);
                        break;
                    case '2':
                        Log::info('we are in challenge update case 2');
                        $this->studentPointLibrary->addPoints($student, $refer_challenge->property["referral_friend"]["value"], null, $refer_challenge);
                        $this->rewardNewBadge($student);
                        break;
                }
                Log::info('after saving cases in student refer');
                $student->contact->referrer = null;
                $student->contact->save();
            }
        }

        return $this->saveStudent($student, $data);
    }

    function rewardNewBadge($student)
    {
        // $attendance_swipe_points = (float)$student->tenant->config["site_settings"]["badge_points"];
        // $challenge = new stdClass;
        // $challenge->name = "Win A New Badge";
        // $challenge->id = null;
        // $addPoints = $this->studentPointLibrary->addPoints($student, $attendance_swipe_points, null, $challenge);
    }

    public function saveStudent(Student $student, $data)
    {
        return DB::transaction(function () use ($student, $data) {
            $modelIsExist = $student->exists;
            $student->fill($this->formatStudentInput($data));

            if (
                array_key_exists('attributes', $data) &&
                !array_key_exists('pathway_descriptor', $data['attributes']) && !array_key_exists('pathway_descriptor', $data['attributes']) &&
                !array_key_exists('military_branch', $data['attributes']) && !array_key_exists('graduation_plan', $data['attributes'])
            ) {
                throw_if(
                    $modelIsExist && !$student->emergency_contact_2_legal_guardian &&
                    !$student->emergency_contact_1_legal_guardian &&
                    now()->diffInYears($student->birthdate) < 18,
                    new LegalGuardianException('At least one legal guardian is required for students under 18 years')
                );
            }

            Log::info('Request Here ' . json_encode($student));
            $this->studentRepo->saveStudent($student);
            Log::info('no error in student');

            if ($relationship = Arr::get($data, 'relationships.diseases')) {
                $this->saveStudentDiseases($student, $relationship);
            }

            if ($relationship = Arr::get($data, 'relationships.allergies')) {
                $this->saveStudentAllergies($student, $relationship);
            }

            if ($relationship = Arr::get($data, 'relationships.special_programs')) {
                $this->saveStudentSpecialPrograms($student, $relationship);
            }

            if (array_key_exists('create_parent_account_1', $data['attributes']) || array_key_exists('create_parent_account_2', $data['attributes'])) {
                $this->saveParentAccount($student, $data);
            }

            $this->saveStudentAssignees($student, $data);
            Log::info('no error in relation');

            if (Arr::has($data, 'attributes.photo')) {
                $this->saveStudentPhoto($student, Arr::get($data, 'attributes.photo'));
            }
            Log::info('no error in photo');

            return $student;
        });
    }

    protected function formatStudentInput($data)
    {
        $attributes = Arr::only(
            $data['attributes'],
            [
                'first_name', 'middle_name', 'last_name', 'street_address',
                'city', 'state', 'zip_code', 'county', 'phone_1', 'phone_2',
                'email', 'code_word', 'last_school_attended', 'district_id',
                'has_issues', 'issue', 'special_instructions', 'referred_by_code', 'referred_by_name',
                'emergency_contact_1_name', 'emergency_contact_1_phone_1',
                'emergency_contact_1_phone_2', 'emergency_contact_1_email', 'emergency_contact_1_legal_guardian',
                'emergency_contact_2_name', 'emergency_contact_2_phone_1', 'emergency_contact_2_phone_2',
                'emergency_contact_2_email', 'emergency_contact_2_legal_guardian',
                'parole_officer_name', 'parole_officer_phone', 'parole_officer_email',
                'has_wifi', 'has_device', 'has_device_loaner', 'gender', 'marital_status',
                'has_children', 'last_year_enrolled', 'last_grade_completed',
                'cohort_year', 'phone_1_type', 'phone_2_type', 'hear_about',
                'transportation', 'referral_code', 'has_medical_issues',
                'username', 'workflow_exception', 'first_date_enrolled', 'media_release', 'enrichment_participation',
                'is_district_sis', 'do_not_contact', 'pronouns', 'graduation_date', 'withdrawal_date'
                , 'nick_name', 'other_hear_about', 'can_redeem', 'pathway_descriptor', 'create_parent_account_1', 'create_parent_account_2'
            ]
        );

        if (isset($data['attributes']['password']) && !is_null($data['attributes']['password'])) {
            $attributes['password'] = $data['attributes']['password'];
        }

        if ($date = Arr::get($data['attributes'], 'birthdate')) {
            $attributes['birthdate'] = Carbon::createFromFormat('m/d/Y', $date);
        }

        if ($date = Arr::get($data['attributes'], 'first_date_enrolled')) {
            $attributes['first_date_enrolled'] = Carbon::createFromFormat('m/d/Y', $date);
        }

        if ($date = Arr::get($data['attributes'], 'graduation_date')) {
            $attributes['graduation_date'] = Carbon::createFromFormat('m/d/Y', $date);
        }

        if ($date = Arr::get($data['attributes'], 'withdrawal_date')) {
            $attributes['withdrawal_date'] = Carbon::createFromFormat('m/d/Y', $date);
        }

        if ($zipCode = Arr::get($data['attributes'], 'zip_code')) {
            $countyObject = collect(json_decode(Storage::disk('cities')->get('cities.json')))->where('zip_code', $zipCode)->first();
            $attributes['county'] = $countyObject ? $countyObject->county : null;
        }

        $submittedRelationships = Arr::get($data, 'relationships', []);
        $relationships = [
            'race', 'primary_language', 'legal_status', 'living_situation',
            'emergency_contact_1_relation', 'emergency_contact_2_relation',
            'graduate_candidate_advocate', 'site', 'status', 'referral_option', 'pathway',
        ];

        foreach ($relationships as $relationship) {
            if (array_key_exists($relationship, $submittedRelationships)) {
                $attributes["{$relationship}_id"] = Arr::get($data, "relationships.{$relationship}.data.id");
            }
        }

        $attributes["graduation_plan"] = Arr::get($data, "relationships.graduation_plan.data.id");
        $attributes["lookup_military_branch_id"] = Arr::get($data, "relationships.military_branch.data.id");

        return $attributes;
    }

    public function deleteStudent($record)
    {
        return $this->studentRepo->deleteStudent($record);
    }

    protected function saveStudentDiseases(Student $student, $relationship)
    {
        $student->diseases()->sync(
            $this->extractRelationshipIds($relationship)
        );
    }

    protected function saveStudentAllergies(Student $student, $relationship)
    {
        $student->allergies()->sync(
            $this->extractRelationshipIds($relationship)
        );
    }

    public function saveStudentSpecialPrograms(Student $student, $relationship)
    {
        $student->specialPrograms()->sync(
            $this->extractRelationshipIds($relationship)
        );
    }

    protected function saveStudentAssignees(Student $student, $data)
    {
        foreach (StudentAssignee::getAvailableGroups() as $group) {
            $relationship = Arr::get($data, "relationships.{$group}");

            if ($relationship) {
                $ids = $this->extractRelationshipIds($relationship);
                $this->studentRepo->saveStudentAssignees($student, $ids, $group);
            }
        }
    }

    protected function saveStudentPhoto(Student $student, $photo)
    {
        $student->clearMediaCollection('photo');

        $this->fileUploadLibrary->associate($student, [$photo], 'photo');
    }

    protected function extractRelationshipIds($relationship)
    {
        return array_map(function ($record) {
            return Arr::get($record, 'id');
        }, $relationship['data']);
    }

    public function createStudentReferralCode()
    {
        do {
            $code = Str::random(10);

            $exists = $this->studentRepo->studentReferralCodeExists($code);
        } while ($exists);

        return $code;
    }

    public function unarchivedStudent($studentId, $email)
    {
        $student = Student::query()->onlyTrashed()->find($studentId);
        $student = $student->fill(['email' => $email]);

        $student->restore();

        return $student;
    }

    public function updateMinorIcon($icon)
    {
        (new Student())->mediaEmptyId()->delete();
        $this->fileUploadLibrary->associateEmptyId(new Student(), [$icon], 'minor');

        return new Student();
    }

    public function addStudentSchedule($studentId, $attributes)
    {

        $studentSchedule = StudentSchedule::query()->where('student_id', $studentId)->first();

        $model = $studentSchedule ?? new StudentSchedule();
        $studentSchedule = $model->fill([
            'student_id' => $studentId,
            'sat_in' => $attributes['sat']['in'],
            'sat_out' => $attributes['sat']['out'],
            'sat_transport' => $attributes['sat']['transport'],
            'sun_in' => $attributes['sun']['in'],
            'sun_out' => $attributes['sun']['out'],
            'sun_transport' => $attributes['sun']['transport'],
            'mon_in' => $attributes['mon']['in'],
            'mon_out' => $attributes['mon']['out'],
            'mon_transport' => $attributes['mon']['transport'],
            'tue_in' => $attributes['tue']['in'],
            'tue_out' => $attributes['tue']['out'],
            'tue_transport' => $attributes['tue']['transport'],
            'wed_in' => $attributes['wed']['in'],
            'wed_out' => $attributes['wed']['out'],
            'wed_transport' => $attributes['wed']['transport'],
            'thu_in' => $attributes['thu']['in'],
            'thu_out' => $attributes['thu']['out'],
            'thu_transport' => $attributes['thu']['transport'],
            'fri_in' => $attributes['fri']['in'],
            'fri_out' => $attributes['fri']['out'],
            'fri_transport' => $attributes['fri']['transport'],
        ]);
        $model->save();
        return $studentSchedule;
    }

    public function getStudentRecruitmentLog(Student $student)
    {
        $model = new RecruitmentLog();
        if (!is_null($student->contact_id)) {
            $contact = $this->contactRepo->getContact($student->contact_id);
            $model->enrollment_coach = isset($contact->communityOutreachAdvocate) ? $contact->communityOutreachAdvocate->first_name . ' ' . $contact->communityOutreachAdvocate->last_name : null;
            $model->outreach_advocate = isset($contact->outreachResourceAdvocate) ? $contact->outreachResourceAdvocate->first_name . ' ' . $contact->outreachResourceAdvocate->last_name : null;
            $model->notes = $contact ? $contact->notes : null;
            $model->RDB_status_changed_times = $contact ? StatusHistoryEntry::query()
                ->where('status_variable_id', $contact->id)
                ->where('status_variable_type', 'Contact')->count() : null;

        }

        $model->system_status_changed_times = StatusHistoryEntry::query()
            ->where('status_variable_id', $student->id)
            ->where('status_variable_type', 'Student')->count();

        return $model;
    }

    public function studentCurrentCourses(Student $student)
    {
        $studentId = $student->id;

        $sql = "select DISTINCT `edmentum_class_learners`.`edmentum_class_id`, edmentum_classes.resource_node_name AS course_name,
                `edmentum_classes_data`.`class_no_of_activities`, `student_no_of_activities`
                from `edmentum_class_learners`
                inner join `edmentum_classes` on `edmentum_class_learners`.`edmentum_class_id` = `edmentum_classes`.`id`
                INNER JOIN
                    (
                        SELECT edmentum_class_activities.edmentum_class_id as edmentum_classes_id, COUNT(edmentum_class_activities.id) as class_no_of_activities
                        FROM edmentum_class_activities
                        GROUP BY edmentum_class_activities.edmentum_class_id
                    ) as edmentum_classes_data on (edmentum_classes_data.edmentum_classes_id=edmentum_class_learners.edmentum_class_id)
                INNER JOIN
                    (
                        SELECT edmentum_activity_learners.edmentum_learner_id as edmentum_learner_id,edmentum_activity_learners.edmentum_class_id as edmentum_class_id, COUNT(edmentum_activity_learners.id) as student_no_of_activities
                        FROM edmentum_activity_learners
                        WHERE edmentum_activity_learners.edmentum_learner_id =$studentId
                        GROUP BY edmentum_activity_learners.edmentum_learner_id,edmentum_activity_learners.edmentum_class_id
                    ) as edmentum_learner_data on (edmentum_learner_data.edmentum_class_id = edmentum_classes.id)
                WHERE edmentum_class_learners.edmentum_learner_id=$studentId";

        $result = DB::select($sql);
        $courses = [];

        if (count($result) > 0) {
            foreach ($result as $item) {
                $courses[] = ['current_course' => $item->course_name, 'progress' => ($item->class_no_of_activities == 0 || is_null($item->class_no_of_activities)) ? 0 : round((($item->student_no_of_activities / $item->class_no_of_activities) * 100), 2) . '%',
                    'current_grad' => null];
            }

        }

        return new CurrentCourse($courses);
    }

    public function onlineAttendanceLogs(Student $student)
    {
        return EdmentumLearnerTask::where('edmentum_learner_id', $student->id)->get();
    }


    public function saveParentAccount($student, $data)
    {
        $input = [];

        if (array_key_exists('create_parent_account_1', $data['attributes']) && Arr::get($data, 'attributes.create_parent_account_1') == 1) {

            $input[] = ['name' => $student->emergency_contact_1_name, 'email' => $student->emergency_contact_1_email];
        }

        if (array_key_exists('create_parent_account_2', $data['attributes']) && Arr::get($data, 'attributes.create_parent_account_2') == 1) {

            $input[] = ['name' => $student->emergency_contact_2_name, 'email' => $student->emergency_contact_2_email];
        }

        if (count($data) > 0) $this->createParentAccount($student, $input);

        if (array_key_exists('create_parent_account_1', $data['attributes']) && Arr::get($data, 'attributes.create_parent_account_1') == 0) {

            $parent = StudentParent::query()->where('email', $student->emergency_contact_1_email)->first();

            if ($parent) $student->parents()->wherePivot('parent_id', $parent->id)->detach();
        }

        if (array_key_exists('create_parent_account_2', $data['attributes']) && Arr::get($data, 'attributes.create_parent_account_2') == 0) {

            $parent = StudentParent::query()->where('email', $student->emergency_contact_2_email)->first();

            if ($parent) $student->parents()->wherePivot('parent_id', $parent->id)->detach();
        }
    }

    public function createParentAccount(Student $student, $input)
    {
        $ids = [];
        foreach ($input as $item) {
            $password = Str::random(8);

            $studentParent = StudentParent::where('email', $item['email'])->first();

            if (!$studentParent) {
                $studentParent = new StudentParent(
                    [
                        'tenant_id' => $student->tenant_id,
                        'name' => $item['name'],
                        'email' => $item['email'],
                        'should_change_password' => 1,
                        'password' => $password
                    ]
                );
                $saved = $this->studentRepo->saveStudentParent($studentParent);
                if ($saved) {
                    $this->sendWelcomeEmailForParent($studentParent, $password);
                }
            }
            $ids[] = $studentParent->id;
        }
        $student->parents()->sync($ids);

    }

    public function sendWelcomeEmailForParent($studentParent, $password)
    {
        $studentParent->notify(new StudentParentCreated($password));
    }
}
