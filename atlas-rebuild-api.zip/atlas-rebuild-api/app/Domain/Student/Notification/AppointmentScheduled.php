<?php

namespace App\Domain\Student\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class AppointmentScheduled extends Notification
{
    use Queueable;

    protected $todo;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($todo)
    {
        //
        $this->todo = $todo;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $object = $this->object;
        return (new MailMessage)
            ->greeting('Welcome! ' . $notifiable->full_name)
            ->line("<h2>New GC Appointment Scheduled</h2>")
            ->line("<p>Hello,<br />A new GC has scheduled an appointment to register.")
            ->line("Please expect on " .$object->student_full_name)
            ->line(date('m/d/Y', strtotime($object->scheduled_date))." at ".$object->site_name.".<br /><br />Thank you.</p>");
        }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
