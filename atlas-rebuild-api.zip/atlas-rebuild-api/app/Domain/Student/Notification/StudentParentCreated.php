<?php


namespace App\Domain\Student\Notification;


use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class StudentParentCreated extends Notification
{
    use Queueable;

    protected $password;

    public function __construct($password)
    {
        $this->password = $password;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }


    public function toMail($notifiable)
    {
        return (new MailMessage)->from('noreply@accelerationacademy.net')->subject('Welcome to Atlas Engagement Hub')->markdown('emails.student_parent_created', [
            'studentParent' => $notifiable,
            'tempPassword' => $this->password
        ]);
    }

}
