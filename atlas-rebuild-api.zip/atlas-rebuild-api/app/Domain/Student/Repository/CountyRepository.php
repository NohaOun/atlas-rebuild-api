<?php

namespace App\Domain\Student\Repository;

use Illuminate\Support\Facades\Storage;

class CountyRepository implements CountyRepositoryInterface
{
    public function getCounties($filter)
    {
        $countyObject = collect(json_decode(Storage::disk('cities')->get('cities.json')));

        if ($filter) $countyObject = $countyObject->where('zip_code', $filter);

        return $countyObject;
    }

}
