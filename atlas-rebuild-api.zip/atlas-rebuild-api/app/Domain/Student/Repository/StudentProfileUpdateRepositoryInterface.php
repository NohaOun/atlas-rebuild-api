<?php

namespace App\Domain\Student\Repository;

use App\Domain\Student\Model\StudentProfileUpdate;

interface StudentProfileUpdateRepositoryInterface
{
    public function getStudentProfileUpdates($studentId);

    public function saveStudentProfileUpdates(StudentProfileUpdate $studentProfileUpdate);

    public function getStudentProfileUpdate($updateId): ?StudentProfileUpdate;
}
