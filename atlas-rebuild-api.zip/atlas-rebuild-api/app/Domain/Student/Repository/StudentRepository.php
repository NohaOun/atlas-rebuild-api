<?php

namespace App\Domain\Student\Repository;

use App\Domain\Site\Model\Site;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentParent;
use App\Domain\StudentPoint\Model\StudentPoint;
use App\Domain\User\Model\Permission;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use App\Events\AddStudentToAssigneeGroup;
use Illuminate\Support\Facades\Log;

class StudentRepository implements StudentRepositoryInterface
{
    /**
     * @var StudentFilters
     */
    private $studentFilters;

    public function __construct(StudentFilters $studentFilters)
    {
        $this->studentFilters = $studentFilters;
    }

    public function getStudents(?StudentFilters $filters)
    {
        $builder = $this->getStudentBuilder();

        if ($filters) $filters->apply($builder);

        return $builder->paginate(500);
    }

    public function getStudentsByFilter(StudentFilters $filters)
    {
        $builder = $this->getStudentBuilder();

        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getStudentFilter(StudentFilters $filters)
    {
        $builder = Student::query();

        if ($filters) $filters->apply($builder);

        return $builder->first();
    }

    public function getStudent($studentId)
    {
        return $this->getStudentBuilder()->find($studentId);
    }

    public function saveStudent(Student $student)
    {
        $student->save();
    }

    public function deleteStudent(Student $student)
    {
        $student->diseases()->detach();
        $student->allergies()->detach();

        $student->delete();
    }

    public function studentReferralCodeExists($code)
    {
        return $this->getStudentBuilder()->where('referral_code', $code)->exists();
    }

    public function getActiveStudents()
    {
        $activeSiteIds = Site::query()->where('active', 1)->pluck('id')->toArray();

        return Student::with('status')->whereIn('site_id', $activeSiteIds)->get();
    }

    public function getStudentCount(StudentFilters $filters)
    {
        $builder = $this->getStudentBuilder();

        $districts = app('showing-districts-ids-in-dashboard');
        $builder->whereHas('site', function (Builder $builder) use ($districts) {
            return $builder->whereIn('sites.district_id', $districts);
        });

        if (auth()->user()->can(Permission::PERMISSION_VIEW_ASSIGNED_CASELOAD) && !auth()->user()->can(Permission::PERMISSION_VIEW_ALL)) {
            $builder->join('student_assignees', 'students.id', '=', 'student_assignees.student_id')
                ->where('student_assignees.user_id', auth()->id());
        }

        return $filters->apply($builder)->count();
    }

    private function getStudentBuilder()
    {
        return Student::query();

    }

    public function saveStudentAssignees(Student $student, $ids, $group)
    {
        $detach = $student->assignees()->where('group', $group)->pluck('users.id');

        $student->assignees()->detach($detach);

        event(new AddStudentToAssigneeGroup($student, $ids));

        $student->assignees()->attach(array_fill_keys($ids, ['group' => $group]));
    }

    public function getStudentFinishedCourses($studentId){
        return StudentFinishedCourses::where('student_id', $studentId)->where('reward', 1)->count();
    }

    public function rewardedBefore($studentId,$challengeId){
        return StudentPoint::where('student_id',$studentId)
            ->where('challenge_id',$challengeId)->exist();
    }

    public function getStudentsLatestProgress(){

        $result = DB::select(DB::raw("select *
         from
         ( select id, created_at,progress,week_number, student_id,
            @rank := IF(@group=student_id, @rank+1, 1) as ranks, @group := student_id as grp
           from weekly_progress,
              (select @rank := 0, @group := 0) as vars order by student_id asc, created_at desc ) as weekly
               left join students on students.id = weekly.student_id
               join statuses on statuses.id = students.status_id
               join phases on phases.id = statuses.phase_id and phase_key = 'Enrolled'
               where ranks <= 1"));
        return $result;
    }

    public function saveStudentParent(StudentParent $parent)
    {
        return $parent->save();
    }
}
