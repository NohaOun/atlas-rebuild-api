<?php

namespace App\Domain\Student\Repository;

use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentParent;

interface StudentRepositoryInterface
{
    public function getStudents(?StudentFilters $filters);

    public function getStudent($studentId);

    public function getStudentFilter(StudentFilters $filters);

    public function getStudentsByFilter(StudentFilters $filters);

    public function saveStudent(Student $student);

    public function deleteStudent(Student $student);

    public function studentReferralCodeExists($code);

    public function getActiveStudents();

    public function getStudentCount(StudentFilters $filters);

    public function saveStudentAssignees(Student $student, $ids, $group);

    public function saveStudentParent(StudentParent $parent);
}
