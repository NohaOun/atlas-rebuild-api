<?php

namespace App\Domain\Student\Repository;

interface CountyRepositoryInterface
{
    public function getCounties($filter);
}
