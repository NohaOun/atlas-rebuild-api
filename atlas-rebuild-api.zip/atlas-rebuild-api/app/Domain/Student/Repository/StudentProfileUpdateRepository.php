<?php

namespace App\Domain\Student\Repository;

use App\Domain\Student\Model\StudentProfileUpdate;

class StudentProfileUpdateRepository implements StudentProfileUpdateRepositoryInterface
{
    public function getStudentProfileUpdates($studentId)
    {
        return StudentProfileUpdate::query()->where('student_id', $studentId)->get();
    }

    public function getStudentProfileUpdate($updateId): ?StudentProfileUpdate
    {
        return StudentProfileUpdate::query()->find($updateId);
    }

    public function saveStudentProfileUpdates(StudentProfileUpdate $studentProfileUpdate): ?bool
    {
        return $studentProfileUpdate->save();
    }

    
}
