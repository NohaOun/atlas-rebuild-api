<?php

namespace App\Domain\Student\Exception;

class MilitaryBranchRequiredException extends \LogicException
{

}
