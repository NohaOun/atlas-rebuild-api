<?php

namespace App\Domain\Student\Exception;

class ArchivedException extends \LogicException
{

}
