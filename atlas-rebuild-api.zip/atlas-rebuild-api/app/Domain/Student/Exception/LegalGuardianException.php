<?php

namespace App\Domain\Student\Exception;

class LegalGuardianException extends \LogicException
{

}
