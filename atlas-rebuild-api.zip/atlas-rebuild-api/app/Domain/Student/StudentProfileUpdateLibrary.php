<?php

namespace App\Domain\Student;

use App\Domain\Student\Repository\StudentProfileUpdateRepositoryInterface;

class StudentProfileUpdateLibrary
{
    protected $studentProfileUpdateRepository;

    public function __construct(StudentProfileUpdateRepositoryInterface $studentProfileUpdateRepository)
    {
        $this->studentProfileUpdateRepository = $studentProfileUpdateRepository;
    }

    public function getStudentProfileUpdates($studentId)
    {
        return $this->studentProfileUpdateRepository->getStudentProfileUpdates($studentId);
    }

    public function getStudentProfileUpdate($updateId)
    {
        return $this->studentProfileUpdateRepository->getStudentProfileUpdate($updateId);
    }
}
