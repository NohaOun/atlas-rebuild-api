<?php

namespace App\Domain\Student;

use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\CountyRepository;
use App\Domain\Student\Repository\CountyRepositoryInterface;
use App\Domain\Student\Repository\StudentProfileUpdateRepository;
use App\Domain\Student\Repository\StudentProfileUpdateRepositoryInterface;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Observers\StudentObserver;
use Illuminate\Support\ServiceProvider;

class StudentServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(StudentRepositoryInterface::class, StudentRepository::class);
        $this->app->bind(StudentProfileUpdateRepositoryInterface::class, StudentProfileUpdateRepository::class);
        $this->app->bind(CountyRepositoryInterface::class, CountyRepository::class);
    }

    public function boot()
    {
        Student::observe(StudentObserver::class);
    }
}
