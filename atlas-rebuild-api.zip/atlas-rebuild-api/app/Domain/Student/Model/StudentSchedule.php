<?php


namespace App\Domain\Student\Model;

use App\Domain\Schedule\Model\StudentScheduleEntry;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentSchedule extends Model
{
    use BelongsToTenant;

    protected $table = "student_schedules";
    protected $guarded = [];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }
}
