<?php

namespace App\Domain\Student\Model;

use App\Domain\Auth\Contract\Authenticatable as AuthenticatableContract;
use App\Domain\Challenge\Model\Challenge;
use App\Domain\Chat\Model\Message;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Common\Helpers;
use App\Domain\Common\Model\MediaWithEmptyId;
use App\Domain\Contact\Model\Contact;
use App\Domain\District\Model\District;
use App\Domain\Edmentum\Model\ActivityLearner;
use App\Domain\Edmentum\Model\ClassLearner;
use App\Domain\Edmentum\Model\EdmentumClass;
use App\Domain\Edmentum\Model\EdmentumCoursewareAudit;
use App\Domain\Edmentum\Model\EdmentumCreditsCsv;
use App\Domain\Edmentum\Model\EdmentumLearnerLogin;
use App\Domain\Edmentum\Model\EdmentumLearnerTask;
use App\Domain\Lookup\Model\Allergy;
use App\Domain\Lookup\Model\Disease;
use App\Domain\Lookup\Model\EmergencyContactRelation;
use App\Domain\Lookup\Model\LegalStatus;
use App\Domain\Lookup\Model\LivingSituation;
use App\Domain\Lookup\Model\MilitaryBranch;
use App\Domain\Lookup\Model\PostGradPathway;
use App\Domain\Lookup\Model\PrimaryLanguage;
use App\Domain\Lookup\Model\Race;
use App\Domain\Lookup\Model\SpecialProgram;
use App\Domain\Note\Model\Note;
use App\Domain\Plp\Model\StudentPlan;
use App\Domain\Redemption\Model\Redemption;
use App\Domain\ReferralOption\Model\ReferralOption;
use App\Domain\Site\Model\Site;
use App\Domain\Status\Model\Status;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;
use App\Domain\StudentPoint\Model\StudentPoint;
use App\Domain\User\Model\User;
use DateTime;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Passport\HasApiTokens;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;
use Illuminate\Notifications\Notifiable;


class Student extends Authenticatable implements HasMedia
{
    use HasMediaTrait, BelongsToTenant, SoftDeletes, MediaWithEmptyId, HasApiTokens, Notifiable;

    protected $guard = 'student';

    protected $table = "students";
    protected $guarded = [];
    protected $with = ['media'];
    protected $dates = ['graduation_date', 'created_at', 'updated_at'];
    // public function findForPassport($username)
    // {
    //     return $this->where('username', $username)->first();
    // }

    public function referralOption()
    {
        return $this->belongsTo(ReferralOption::class);
    }

    public function allergies()
    {
        return $this->belongsToMany(Allergy::class);
    }

    public function diseases()
    {
        return $this->belongsToMany(Disease::class);
    }

    public function specialPrograms()
    {
        return $this->belongsToMany(SpecialProgram::class);
    }

    public function legalStatus()
    {
        return $this->belongsTo(LegalStatus::class, 'legal_status_id');
    }

    public function primaryLanguage()
    {
        return $this->belongsTo(PrimaryLanguage::class, 'primary_language_id');
    }

    public function race()
    {
        return $this->belongsTo(Race::class, 'race_id');
    }

    public function livingSituation()
    {
        return $this->belongsTo(LivingSituation::class, 'living_situation_id');
    }

    public function emergencyContact1Relation()
    {
        return $this->belongsTo(EmergencyContactRelation::class, 'emergency_contact_1_relation_id');
    }

    public function emergencyContact2Relation()
    {
        return $this->belongsTo(EmergencyContactRelation::class, 'emergency_contact_2_relation_id');
    }

    public function graduateCandidateAdvocate()
    {
        return $this->belongsTo(User::class, 'graduate_candidate_advocate_id');
    }

    public function contentCoach()
    {
        return $this->belongsTo(User::class, 'content_coach_id');
    }

    public function careerLifeCoach()
    {
        return $this->belongsTo(User::class, 'career_life_coach_id');
    }

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function status()
    {
        return $this->belongsTo(Status::class);
    }

    public function statusHistory()
    {
        return $this->morphMany(StatusHistoryEntry::class, 'status_variable');
    }

    public function assignees()
    {
        return $this->belongsToMany(User::class, 'student_assignees')->withPivot(['group'])->using(StudentAssignee::class);
    }

    public function teachers()
    {
        return $this->assignees()->wherePivot('group', StudentAssignee::GROUP_TEACHERS);
    }

    public function counselors()
    {
        return $this->assignees()->wherePivot('group', StudentAssignee::GROUP_COUNSELORS);
    }

    public function paraProfessionals()
    {
        return $this->assignees()->wherePivot('group', StudentAssignee::GROUP_PARA_PROFESSIONALS);
    }

    public function contact()
    {
        return $this->belongsTo(Contact::class, 'contact_id');
    }

    public function activity()
    {
        return $this->hasMany('App\Domain\Edmentum\Model\ActivityLearner', 'learner_id', 'id');
    }

    public function studentClasses()
    {
        return $this->belongsToMany('App\Domain\Edmentum\Model\EdmentumClass', 'edmentum_class_learners',
            'edmentum_learner_id', 'edmentum_class_id')
            ->withPivot('start_at', 'end_at')
            ->orderBy('edmentum_class_learners.start_at', 'desc');
    }

    public function studentLastClass()
    {
        return $this->hasOne(ClassLearner::class, 'edmentum_learner_id')->orderByDesc('start_at');
    }

    public function credits()
    {
        return $this->hasMany(EdmentumCreditsCsv::class, 'SISID', 'id');
    }

    public function edmentumAttendance()
    {
        return $this->hasMany(EdmentumLearnerTask::class, 'edmentum_learner_id', 'id');
    }

    public function edmentumLastAttendance()
    {
        return $this->hasOne(EdmentumLearnerTask::class, 'edmentum_learner_id', 'id')->orderByDesc('started_at');
    }

    public function edmentumAttendanceSumMinutes()
    {
        return $this->hasOne(EdmentumLearnerTask::class, 'edmentum_learner_id',
            'id')->orderByDesc('started_at')
            ->whereDate('started_at', '>=', Helpers::getPreviousDayDateByName('Sunday'));
    }

    public function studentAttendance()
    {
        return $this->hasMany(StudentAttendanceEntry::class, 'student_id', 'id');
    }

    public function studentLastAttendance()
    {
        return $this->hasOne(StudentAttendanceEntry::class, 'student_id', 'id')->orderByDesc('check_out');
    }

    public function edmentumSystemAttendance()
    {
        return $this->hasMany(EdmentumLearnerLogin::class, 'edmentum_learner_id', 'id');
    }

    public function edmentumSystemLastAttendance()
    {
        return $this->hasOne(EdmentumLearnerLogin::class, 'edmentum_learner_id', 'id')->orderByDesc('id');
    }

    public function classLearners()
    {
        return $this->hasMany(ClassLearner::class, 'edmentum_learner_id', 'id');
    }

    public function activePlpPlan()
    {
        return $this->hasOne(StudentPlan::class)->where('active', 1);
    }

    public function studentPlan()
    {
        return $this->hasOne(StudentPlan::class);
    }

    public function notes()
    {
        return $this->hasMany(Note::class, 'student_id');
    }

    public function graduationPlan()
    {
        return $this->belongsTo(Status::class, 'graduation_plan');
    }

    public function militaryBranch()
    {
        return $this->belongsTo(MilitaryBranch::class, 'lookup_military_branch_id');
    }

    public function pathway()
    {
        return $this->belongsTo(PostGradPathway::class, 'pathway_id');
    }

    public function scopeActiveStudentPlan()
    {
        $this->studentPlan()->where('status', '=', 1);
    }

    public function getPasswordStrAttribute()
    {
        return strtolower(date('Y', strtotime($this->birthdate)) . substr($this->first_name, 0, 3));
    }

    public function getAgeAttribute()
    {
        $bday = new DateTime($this->birthdate);//dd.mm.yyyy
        $today = new DateTime(); // Current date
        $diff = $today->diff($bday);
        return $diff->y . " Years, " . $diff->m . ' Months';
    }

    public function getMinorAttribute()
    {
        return $this->getAttribute('age') < 18;
    }

    public function generatUserName()
    {
        $username = strtolower(substr($this->attributes["first_name"], 0, 3) . substr($this->attributes["last_name"], 0, 3) . date('m', strtotime($this->attributes["birthdate"])));
        do {
            $username = $username . rand(0, 99);
        } while ((static::query()->where('username', $username)->exists()));
        return $username;
    }


    public function district()
    {
        return $this->belongsTo(District::class, 'district_id', 'id');
    }

    // public function setPasswordAttribute()
    // {
    //     $password_value = strtolower(date('Y', strtotime($this->attributes["birthdate"])) . substr($this->attributes["first_name"], 0, 3));
    //     $this->attributes['password'] = Hash::make($password_value);
    // }

    public function getFullNameAttribute()
    {
        return sprintf('%s %s', $this->getAttribute('first_name'), $this->getAttribute('last_name'));
    }

    protected function setPrimaryKey($key)
    {
        $this->primaryKey = $key;
    }

    public static function boot()
    {
        parent::boot();

        static::addGlobalScope('activeDistricts', function (Builder $builder) {
            $builder->whereHas('site', function (Builder $builder) {
                $builder->whereHas('district', function (Builder $builder) {
                    $builder->where('active', 1);
                });
            });
        });

        static::creating(function ($model) {
            $model->username = $model->generatUserName();
            $model->password = Hash::make($model->getPasswordStrAttribute());
            $model->referral_code = $model->generateReferralCode();
            $model->rewards_email = $model->username . '@' . config('custom.web_app_domain');
        });
    }

    public function generateReferralCode()
    {
        do {
            $code = Str::random(8);
        } while (static::query()->where('referral_code', $code)->exists());

        return $code;
    }

    public function studentPoints()
    {
        return $this->hasMany(StudentPoint::class);
    }

    public function studentPoint()
    {
        return $this->hasOne(StudentPoint::class)->orderBy('id', 'DESC')->orderBy('created_at', 'DESC');
    }

    public function redemtions()
    {
        return $this->hasMany(Redemption::class, 'student_id');
    }

    public function getAvailablePointsAttribute()
    {
        $studentPoint = $this->studentPoint()->first();

        // If no Points Then Return 0
        if (!$studentPoint)
            return 0;
        $points = $studentPoint->total_points;

        $redeemed = $this->redemtions()->sum("points");

        return $points - $redeemed;
    }

    public function getUserType()
    {
        return AuthenticatableContract::USER_TYPE_STUDENT;
    }

    public function student()
    {
        return $this->morphMany(RoomUser::class, 'user', Student::class, 'user_id', 'id');
    }

    public function messageCreator()
    {
        return $this->morphMany(Message::class, 'creator', User::class, 'creator_id', 'id');
    }

    // Retrive Badges For this Students
    public function badges()
    {
        return $this->belongsToMany(Challenge::class, "student_points", "student_id", "challenge_id");
    }

    public function parents()
    {
        return $this->belongsToMany(StudentParent::class, 'parent_student', 'student_id', 'parent_id');
    }

    public function edmentumClassLearners()
    {
        return $this->hasMany(ClassLearner::class, 'edmentum_learner_id');
    }

    public function edmentumActivityLearners()
    {
        return $this->hasMany(ActivityLearner::class, 'edmentum_learner_id');
    }

    public function edmentumCoursewareAudits()
    {
        return $this->hasMany(EdmentumCoursewareAudit::class);
    }

    public function edmentumCoursewareAuditsLatest()
    {
        return $this->hasOne(EdmentumCoursewareAudit::class)->orderBy('last_access', 'desc');
    }

}
