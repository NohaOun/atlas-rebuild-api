<?php


namespace App\Domain\Student\Model;


use App\Domain\Common\Model\Generic;

class CurrentCourse extends Generic
{
      protected $guarded= [];
}
