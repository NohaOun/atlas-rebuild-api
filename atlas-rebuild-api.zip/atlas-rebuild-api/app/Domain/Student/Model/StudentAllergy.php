<?php

namespace App\Domain\Student\Model;

use Illuminate\Database\Eloquent\Model;

class StudentAllergy extends Model
{
    public $timestamps = false;
    protected $table = "allergy_student";
    protected $fillable = ['student_id', 'allergy_id'];
}
