<?php

namespace App\Domain\Student\Model;

use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentProfileUpdate extends Model
{
    use BelongsToTenant;

    const STATUS_PENDING = 'pending';
    const STATUS_APPROVED = 'approved';

    protected $table = "student_profile_updates";
    protected $fillable = ['user_id', 'student_id', 'changes', 'status'];
    protected $casts = ['changes' => 'json'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function getFieldsAttribute()
    {
        return array_keys($this->getAttribute('changes'));
    }

    public static function getAvailableStatuses()
    {
        return [self::STATUS_PENDING, self::STATUS_APPROVED];
    }
}
