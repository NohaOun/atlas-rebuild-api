<?php


namespace App\Domain\Student\Model;


use App\Domain\Common\Model\Generic;

class RecruitmentLog extends Generic
{
      protected $fillable = ['enrollment_coach', 'outreach_advocate', 'notes', 'RDB_status_changed_times', 'system_status_changed_times'];
}
