<?php

namespace App\Domain\Student\Model;

use App\Domain\Auth\Contract\Authenticatable as AuthenticatableContract;
use App\Domain\Chat\Model\RoomUser;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentParent extends Authenticatable implements AuthenticatableContract
{
    use HasApiTokens, Notifiable, BelongsToTenant;

    protected $table = 'parents';
    protected $fillable = ['tenant_id', 'name', 'email', 'password', 'should_change_password'];
    protected $hidden = ['password'];

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    public function getUserType()
    {
        return AuthenticatableContract::USER_TYPE_PARENT;
    }

    public function students()
    {
        return $this->belongsToMany(Student::class, 'parent_student', 'parent_id', 'student_id');
    }

    public function parent()
    {
        return $this->morphMany(RoomUser::class, 'user', StudentParent::class, 'user_id', 'id');
    }
}
