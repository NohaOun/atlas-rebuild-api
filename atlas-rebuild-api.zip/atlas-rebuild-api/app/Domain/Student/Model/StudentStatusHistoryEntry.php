<?php

namespace App\Domain\Student\Model;

use App\Domain\Status\Model\Status;
use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentStatusHistoryEntry extends Model
{
    use BelongsToTenant;

    public $timestamps = false;
    protected $table = "status_history";
    protected $fillable = ['student_id', 'user_id', 'prev_status_id', 'new_status_id', 'created_at', 'exited_at'];
    protected $dates = ['exited_at'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function prevStatus()
    {
        return $this->belongsTo(Status::class, 'prev_status_id');
    }

    public function newStatus()
    {
        return $this->belongsTo(Status::class, 'new_status_id');
    }
}
