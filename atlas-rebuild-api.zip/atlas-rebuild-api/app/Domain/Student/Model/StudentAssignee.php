<?php

namespace App\Domain\Student\Model;

use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Relations\Pivot;

class StudentAssignee extends Pivot
{
    protected $table = 'student_assignees';

    const GROUP_TEACHERS = 'teachers';
    const GROUP_COUNSELORS = 'counselors';
    const GROUP_PARA_PROFESSIONALS = 'para_professionals';

    protected $fillable = ['student_id', 'user_id', 'group'];

    public static function getAvailableGroups()
    {
        return [self::GROUP_TEACHERS, self::GROUP_COUNSELORS, self::GROUP_PARA_PROFESSIONALS];
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}
