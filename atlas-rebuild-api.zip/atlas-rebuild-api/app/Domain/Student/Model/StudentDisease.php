<?php

namespace App\Domain\Student\Model;

use Illuminate\Database\Eloquent\Model;


class StudentDisease extends Model
{
    public $timestamps = false;
    protected $table = "disease_student";
    protected $fillable = ['student_id', 'disease_id'];
}
