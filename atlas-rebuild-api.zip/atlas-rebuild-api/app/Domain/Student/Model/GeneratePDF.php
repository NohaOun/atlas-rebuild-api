<?php

namespace App\Domain\Student\Model;

use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class GeneratePDF extends Model
{
     use   HasMediaTrait;
 protected $fillable = ['link'];
}
