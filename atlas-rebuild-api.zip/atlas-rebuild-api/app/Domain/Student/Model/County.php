<?php

namespace App\Domain\Student\Model;

use App\Domain\Common\Model\Generic;
use Illuminate\Support\Arr;

class County extends Generic
{
    protected $attributes;

    public function __construct($attributes)
    {
        $this->attributes = $attributes;
    }

    public function getEntityId()
    {
        return Arr::get($this->attributes, 'id');
    }

    public function getEntityType()
    {
        return Arr::get($this->attributes, 'type');
    }

    public function getName()
    {
        return Arr::get($this->attributes, 'name');
    }
}
