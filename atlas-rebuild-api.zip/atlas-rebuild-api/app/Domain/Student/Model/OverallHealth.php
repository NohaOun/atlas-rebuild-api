<?php

namespace App\Domain\Student\Model;

use Illuminate\Database\Eloquent\Model;

class OverallHealth extends Model {

    protected $attributes = [
        'last_date_attended' => '10/21/2020',
        'days_lapsed' => 0,
        'next_day_expected' => 0,
        'last_login' => '10/21/2020',
        'current_course' => 0,
        'time_online' => 0
    ];
    protected $fillable = [
        'last_date_attended', 'days_lapsed', 'next_day_expected', 'last_login', 'current_course',
        'time_online'
    ];

}
