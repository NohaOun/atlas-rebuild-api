<?php

namespace App\Domain\Student\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class StudentFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

     public function accelerationId(Builder $builder, $id)
    {
        return $builder->where('id', $id);
    }

    public function districtId(Builder $builder, $id)
    {
        return $builder->where('district_id', $id);
    }

    public function perPage(Builder $builder, $perPage)
    {
        return $builder->limit($perPage);
    }

    public function q(Builder $builder, $q)
    {
        $builder->where(function (Builder $builder) use ($q) {
            $builder->where('id', $q)
                ->orWhere('district_id', $q)
                ->orWhere(function (Builder $builder) use ($q) {
                    $builder->whereRaw('CONCAT(TRIM(first_name), " ", TRIM(last_name)) LIKE ?', "%{$q}%");
                })
                ->orWhereRaw('phone_1 LIKE ?', "%{$q}%")
                ->orWhereRaw('phone_2 LIKE ?', "%{$q}%")
                ->orWhereRaw('email LIKE ?', "%{$q}%");
        });
    }

    public function firstName(Builder $builder, $q)
    {
        return $builder->where('first_name', 'LIKE', "%{$q}%");
    }

    public function lastName(Builder $builder, $q)
    {
        return $builder->where('last_name', 'LIKE', "%{$q}%");
    }

    public function atlasId(Builder $builder, $q)
    {
        return $builder->where('id', $q);
    }

    public function createdAt(Builder $builder, $date)
    {
        return $builder->whereRaw('DATE(created_at) = ?', [$date]);
    }

    public function hasPhoto(Builder $builder)
    {
        return $builder->whereHas('media', function (Builder $builder) {
            return $builder->where('collection_name', 'photo');
        });
    }

    public function photoUploadedDate(Builder $builder, $date)
    {
        return $builder->whereHas('media', function (Builder $builder) use ($date) {
            return $builder->where('collection_name', 'image')
                ->whereRaw('DATE(created_at) = ?', $date);
        });
    }

    public function duplicate(Builder $builder, $duplicate)
    {
        return $builder->where('duplicate', $duplicate);
    }

    public function createdAtFrom(Builder $builder, $createdFrom)
    {
        return $builder->whereDate('created_at', '>=', $createdFrom);
    }

    public function createdAtTo(Builder $builder, $createdTo)
    {
        return $builder->whereDate('created_at', '<=', $createdTo);
    }

    public function status(Builder $builder, $id)
    {
        if (is_array($id)) {
            return $builder->whereIn('status_id', $id);
        } else {
            return $builder->where('status_id', $id);
        }

    }

    public function archived(Builder $builder)
    {
        return $builder->onlyTrashed();
    }

    public function photoUploadedDateFrom(Builder $builder, $date)
    {
        return $builder->whereHas('media', function (Builder $builder) use ($date) {
            return $builder->where('collection_name', 'image')
                ->whereRaw('DATE(created_at) >= ?', $date);
        });
    }

    public function photoUploadedDateTo(Builder $builder, $date)
    {
        return $builder->whereHas('media', function (Builder $builder) use ($date) {
            return $builder->where('collection_name', 'image')
                ->whereRaw('DATE(created_at) <= ?', $date);
        });
    }

    public function phase(Builder $builder, $phase)
    {
        if (is_int($phase) || is_string($phase)) {
            $phase = [(int)$phase];
        }

        $builder->whereHas('status', function (Builder $builder) use ($phase) {
            return $builder->whereIn('statuses.phase_id', $phase);
        });
    }

    public function phaseIn(Builder $builder, $phase)
    {
        if (is_int($phase) || is_string($phase)) {
            $phase = [(int)$phase];
        }

        $builder->join('statuses', function ($join) use ($phase) {
            $join->on('students.status_id', '=', 'statuses.id')
                ->whereIn('statuses.phase_id', $phase);
        })->select('students.*');
    }


    public function phaseKey(Builder $builder, $phase)
    {
        return $builder->whereDoesntHave('status.phase', function (Builder $builder) use ($phase) {
            return $builder->where('phase_key', '=', $phase);
        });
    }


    public function district(Builder $builder, $district)
    {
        $builder->whereHas('site', function (Builder $builder) use ($district) {
            return $builder->where('sites.district_id', $district);
        });
    }

    public function statusIds(Builder $builder, $statusIds)
    {
        return $builder->whereIn('status_id', $statusIds);
    }

    public function rewardsEmail(Builder $builder, $email)
    {
        return $builder->where('rewards_email', $email);
    }

    public function resetToken(Builder $builder, $email)
    {
        return $builder->where('reset_token', $email);
    }

    public function activeSite(Builder $builder)
    {
        return $builder->whereHas('site', function (Builder $builder) {
            return $builder->where('sites.active', 1);
        });
    }

    public function active(Builder $builder, $active)
    {
        return $builder->where('students.active', $active);
    }

      public function site(Builder $builder, $id)
    {
        return $builder->where('site_id', $id);
    }
      public function districtPrint(Builder $builder, $id)
    {
       $builder->whereHas('site', function (Builder $builder) use ($id) {
            return $builder->where('sites.district_id', $id);
        });
    }

    public function parent(Builder $builder, $id)
    {
        return $builder->where('parent_id', $id);
    }

}
