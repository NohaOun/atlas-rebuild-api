<?php


namespace App\Domain\Student\Filters;


use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;


class StudentScheduleFilters extends BaseFilters
{
    public function student(Builder $builder, $id)
    {
        return $builder->where('student_id', $id);
    }


    public function id(Builder $builder, $id)
    {
        return $builder->where('id', $id);
    }

}
