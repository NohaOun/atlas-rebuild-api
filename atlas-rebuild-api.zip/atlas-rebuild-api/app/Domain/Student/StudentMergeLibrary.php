<?php


namespace App\Domain\Student;

use App\Domain\Contact\Model\Contact;
use App\Domain\Contact\Model\ContactAction;
use App\Domain\Document\Model\StudentDocument;
use App\Domain\Note\Model\Note;
use App\Domain\Plp\Model\StudentPlan;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;

class StudentMergeLibrary
{
    protected $studentRepo;

    public function __construct(StudentRepositoryInterface $studentRepo)
    {
        $this->studentRepo = $studentRepo;
    }

    public function mergeStudents($data)
    {
        $masterId = $data['master_id'];
        $slaveId = $data['slave_id'];

        $this->mergeStudentPlp($masterId, $slaveId);
        $this->mergeNotes($masterId, $slaveId);
        $this->mergeAttendance($masterId, $slaveId);
        $this->mergeDocuments($masterId, $slaveId);
        $this->mergeStudentHistory($masterId, $slaveId);
        $this->mergeStudentContact($masterId, $slaveId);

        return $this->deleteSlaveStudent($slaveId);
    }

    public function mergeStudentPlp($masterId, $slaveId)
    {
        StudentPlan::where('student_id', $slaveId)->update(['student_id' => $masterId, 'active' => 0]);

    }

    public function mergeNotes($masterId, $slaveId)
    {
        Note::where('student_id', $slaveId)->update(['student_id' => $masterId]);
    }

    public function mergeAttendance($masterId, $slaveId)
    {
        StudentAttendanceEntry::where('student_id', $slaveId)->update(['student_id' => $masterId]);
    }

    public function mergeDocuments($masterId, $slaveId)
    {
        StudentDocument::where('student_id', $slaveId)->update(['student_id' => $masterId]);
    }

    public function mergeStudentHistory($masterId, $slaveId)
    {
        StatusHistoryEntry::where('status_variable_id', $slaveId)->update(['status_variable_id' => $masterId]);
    }

    public function mergeStudentContact($masterId, $slaveId)
    {
        $masterStudent = $this->studentRepo->getStudent($masterId);
        $slaveStudent = $this->studentRepo->getStudent($slaveId);

        if ((!is_null($masterStudent->contact_id ) && !is_null($slaveStudent->contact_id))) {
            ContactAction::where('contact_id', $slaveStudent->contact_id)->update(['contact_id' => $masterStudent->contact_id]);
            return $slaveStudent->contact_id;
        }
    }

    public function deleteSlaveStudent($slaveId)
    {
        StudentScheduleEntry::where('student_id', $slaveId)->delete();
        // $studentSchedule = StudentScheduleEntry::where('student_id', $slaveId)->first();
        // if($studentSchedule){
        //     $studentSchedule->appointmentCategories->delete();
        //     $studentSchedule->delete();
        // }
        $slaveStudent = $this->studentRepo->getStudent($slaveId);
        $delete = $this->studentRepo->deleteStudent($slaveStudent);
        Contact::where('id', $slaveStudent->contact_id)->delete();
        return $delete;
    }
}
