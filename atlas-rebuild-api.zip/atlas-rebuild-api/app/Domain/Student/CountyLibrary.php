<?php

namespace App\Domain\Student;

use App\Domain\Student\Model\County;
use App\Domain\Student\Repository\CountyRepositoryInterface;
use Illuminate\Support\Collection;

class CountyLibrary
{
    protected $countyRepository;

    public function __construct(CountyRepositoryInterface $countyRepository)
    {
        $this->countyRepository = $countyRepository;
    }

    public function getCounties($q)
    {
        $collection = new Collection();
        foreach ($this->countyRepository->getCounties($q) as $county) {
            $collection->push(
                new County(['type' => 'counties', 'name' => $county->county])
            );
        }

        return $collection;
    }
}
