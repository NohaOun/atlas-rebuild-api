<?php

namespace App\Domain\Student;

use App\Domain\Student\Model\Student;
use App\Domain\User\Model\User;
use App\Domain\Student\Model\GeneratePDF;
use App\Domain\User\Model\GeneratePDFUser;
use PDF;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use DB;

class GeneratePDFLibrary {

    use HasMediaTrait;

    // Generate PDF

    public function createPDF($ids) {

        if (array_key_exists("ids", $ids)) {
            $gc_ids = explode(",", $ids['ids'][0]);
        } else {
            $gc_ids = "";
        }
        if (array_key_exists("user_ids", $ids)) {
            $user_ids = explode(",", $ids['user_ids'][0]);
        } else {
            $user_ids = "";
        }

        if ($gc_ids != "" and $user_ids == "") {
            $data = Student::join('sites', 'sites.id', '=', 'students.site_id')
                    ->join('districts', 'districts.id', '=', 'sites.district_id')
                    ->select("students.*", "students.id as student_id", "sites.*", 'districts.name as district_name')
                    ->whereIn('students.id', $gc_ids)
                    ->get();

            view()->share('students', $data);
            $pdf = PDF::loadView('pdf_view', $data);
            Storage::put('public/pdf/pdf_file.pdf', $pdf->output());
            $pdf = new GeneratePDF(['link' => route('pdf.download', 'pdf_file.pdf')]);
            return $pdf;
        } elseif ($user_ids != "" and $gc_ids == "") {
            return $this->createUserPDF($user_ids);
        } elseif ($user_ids != "" and $gc_ids != "") {
            return $this->createUserAndStudentPDF($gc_ids, $user_ids);
        }
    }

    public function createUserPDF($user_ids) {

        $data = User::select('users.*', 'users.id as user_id')
                        ->whereIn('id', $user_ids)->get();
        view()->share('users', $data);
        $pdf = PDF::loadView('pdf_view_user', $data);
        Storage::put('public/pdf/pdf_file_user.pdf', $pdf->output());
        $pdf = new GeneratePDFUser(['link' => route('userPdf.download', 'user_pdf_file.pdf')]);

        return $pdf;
    }

    public function createUserAndStudentPDF($gc_ids, $user_ids) {


        $students = Student::join('sites', 'sites.id', '=', 'students.site_id')
                ->join('districts', 'districts.id', '=', 'sites.district_id')
                ->select("students.*", "students.id as student_id", "sites.*", 'districts.name as district_name')
                ->whereIn('students.id', $gc_ids)
                ->get();

        $users = User::select('users.*', 'users.id as user_id')
                        ->whereIn('id', $user_ids)->get();


        view()->share(array('users' => $users, 'students' => $students));
        $pdf = PDF::loadView('pdf_view_all', array($users, $students));
        Storage::put('public/pdf/pdf_file.pdf', $pdf->output());
        $pdf = new GeneratePDF(['link' => route('pdf.download', 'pdf_file.pdf')]);

        return $pdf;
    }

     public static function getDestrictForUser($user_id) {


        $district_name = DB::Table('tenant_user')
                          ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
                          ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
                          ->where('tenant_user.id', $user_id)->select('districts.name as district_name')->first();

        return $district_name;
    }
}
