<?php


namespace App\Domain\Zoom;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Redirect;

class ZoomService
{
    private $token;


    public function __construct()
    {
        $this->oauth();

    }


    public function oauth()
    {
        return Redirect::away('https://zoom.us/oauth/authorize?response_type=code&client_id=34dQCwRwQVGC15vfJ0IAg&redirect_uri=https://api-staging.mtcdevsite.com/getCode');

    }

    public function getToken($code)
    {
        print_r($code);
        exit;
        $response = Http::withHeaders([
            "Authorization" => "Basic MzRkUUN3UndRVkdDMTV2ZkowSUFnOjNmWkdWWktsRDVzd1ZXTDI2bTB6NDdvcGJLTzJ0N3lt"
        ])->post("https://zoom.us/oauth/token?grant_type=authorization_code&code=$code&redirect_uri=https://api-staging.mtcdevsite.com/getCode");
        $response = $response->json();
        $this->token = $response['access_token'];

    }

    public function fetchData()
    {
        print_r($this->token);
        exit;
        $response = $response = Http::withHeaders(["Authorization" => "Bearer " . $this->token])->get('https://api.zoom.us/v2/users/me');
        print_r($response->json());

    }

}
