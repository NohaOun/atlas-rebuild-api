<?php

namespace App\Domain\User;

use App\Domain\User\Filters\PermissionFilters;
use App\Domain\User\Repository\PermissionRepositoryInterface;

class PermissionLibrary
{
    protected $permissionRepo;

    public function __construct(PermissionRepositoryInterface $permissionRepo)
    {
        $this->permissionRepo = $permissionRepo;
    }

    public function getPermissions(PermissionFilters $filters = null)
    {
        return $this->permissionRepo->getPermissions($filters);
    }

    public function getPermission($recordId)
    {
        return $this->permissionRepo->getPermission($recordId);
    }

    public function getPermissionIds()
    {
        return $this->permissionRepo->getPermissions(null)->map(function ($permission) {
            return $permission->id;
        });
    }
}
