<?php

namespace App\Domain\User\Repository;

use App\Domain\Challenge\Model\StudentFinishedCourses;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Model\User;
use App\Domain\User\Model\TenantUser;
use Illuminate\Database\Eloquent\Collection;

class UserRepository implements UserRepositoryInterface
{
    public function getUsers(?UserFilters $filters = null): Collection
    {
        return $this->getFilteredBuilder($filters)->orderByDesc('first_name')->orderByDesc('last_name')->get();
    }

    public function pluckEmails($userIds): array
    {
        return User::query()->whereIn('id', $userIds)->pluck('email')->toArray();
    }

    public function getUserById($userId, UserFilters $filters = null): ?User
    {
        return $this->getFilteredBuilder($filters)->find($userId);
    }

    public function getUsersById($userIds)
    {
        return User::query()->whereIn('id', $userIds)->get();
    }
    
    public function getUserByEmail($email): ?User
    {
        return User::query()->where('email', $email)->first();
    }

    public function saveUser($user): bool
    {
        return $user->save();
    }

    public function deleteUser($user): bool
    {
        $user->districts()->detach();

        return $user->delete();
    }

    public function getTenantUser($userId, $tenantId)
    {
        return TenantUser::query()
            ->where(['user_id' => $userId, 'tenant_id' => $tenantId])
            ->first();
    }

    public function saveTenantUser(TenantUser $tenantUser)
    {
        return $tenantUser->save();
    }

    public function saveTenantUserPermissions(TenantUser $tenantUser, $permissionIds)
    {
        $tenantUser->permissions()->sync($permissionIds);
    }

    public function saveTenantUserDistricts(TenantUser $tenantUser, $districtIds)
    {
        $tenantUser->districts()->sync($districtIds);
    }

    public function getFilteredBuilder(?UserFilters $filters)
    {
        $builder = User::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}

