<?php

namespace App\Domain\User\Repository;

use App\Domain\User\Filters\PermissionFilters;
use App\Domain\User\Model\Permission;

class PermissionRepository implements PermissionRepositoryInterface
{
    public function createPermission($data)
    {
        return Permission::create($data);
    }

    public function updatePermission($record, $data)
    {
        $record->update($data);
        return $record;
    }

    public function deletePermission($record)
    {
        return $record->delete();
    }

    public function getPermissions(?PermissionFilters $filters)
    {
        $builder = Permission::query();

        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getPermission($permissionId)
    {
        return Permission::find($permissionId);
    }
}
