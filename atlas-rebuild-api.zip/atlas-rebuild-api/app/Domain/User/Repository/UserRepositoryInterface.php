<?php

namespace App\Domain\User\Repository;

use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Model\User;
use App\Domain\User\Model\TenantUser;
use Illuminate\Database\Eloquent\Collection;

interface UserRepositoryInterface
{
    public function getUsers(?UserFilters $filters = null): Collection;

    public function getUserById($userId, ?UserFilters $filters = null): ?User;

    public function getUserByEmail($email): ?User;

    public function pluckEmails($userIds): array;

    public function saveUser($user): bool;

    public function deleteUser($user): bool;

    public function getTenantUser($userId, $tenantId);

    public function saveTenantUser(TenantUser $tenantUser);

    public function saveTenantUserPermissions(TenantUser $tenantUser, $permissionIds);

    public function saveTenantUserDistricts(TenantUser $tenantUser, $districtIds);

    public function getUsersById($userIds);
}
