<?php

namespace App\Domain\User\Repository;

use App\Domain\User\Filters\RoleFilters;
use App\Domain\User\Model\Role;

interface RoleRepositoryInterface
{
    public function getRoles(?RoleFilters $filters);

    public function getRole($roleId);

    public function saveRole(Role $role);

    public function deleteRole(Role $role);

    public function saveRolePermissions(Role $role, $permissionIds);
}
