<?php

namespace App\Domain\User\Repository;

use App\Domain\User\Filters\PermissionFilters;

interface PermissionRepositoryInterface
{
    public function getPermissions(?PermissionFilters $filters);

    public function getPermission($permissionId);
}
