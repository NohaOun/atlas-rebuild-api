<?php

namespace App\Domain\User\Repository;

use App\Domain\User\Filters\RoleFilters;
use App\Domain\User\Model\Role;

class RoleRepository implements RoleRepositoryInterface
{
    public function getRoles(?RoleFilters $filters)
    {
        $builder = Role::query();

        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getRole($roleId)
    {
        return Role::query()->find($roleId);
    }

    public function saveRole(Role $role)
    {
        return $role->save();
    }

    public function deleteRole(Role $role)
    {
        $role->permissions()->detach();

        return $role->delete();
    }

    public function saveRolePermissions(Role $role, $permissionIds)
    {
        $role->permissions()->sync($permissionIds);
    }
}
