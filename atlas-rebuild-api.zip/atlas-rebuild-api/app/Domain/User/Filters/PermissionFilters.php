<?php

namespace App\Domain\User\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class PermissionFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function user(Builder $builder, $id)
    {
        return $builder->whereHas('users', function (Builder $builder) use ($id) {
            return $builder->where('users.id', $id);
        });
    }
}
