<?php

namespace App\Domain\User\Filters;

use App\Domain\Common\Filters\BaseFilters;
use App\Domain\User\Support\TenantRelationConfig;
use Illuminate\Database\Eloquent\Builder;

class UserFilters extends BaseFilters
{
    public function perPage(Builder $builder, $perPage)
    {
        return $builder->limit($perPage);
    }

    public function q(Builder $builder, $q)
    {
        $builder->where(function (Builder $builder) use ($q) {
            $builder->where('id', $q)
                ->orWhere(function (Builder $builder) use ($q) {
                    $builder->whereRaw('CONCAT(TRIM(first_name), " ", TRIM(last_name)) LIKE ?', "%{$q}%");
                })
                ->orWhereRaw('title LIKE ?', "%{$q}%")
                ->orWhereRaw('email LIKE ?', "%{$q}%")
                ->orWhereRaw('created_at LIKE ?', "%{$q}%")
                ->orWhereRaw('active LIKE ?', "%{$q}%")
                ->orWhereHas('tenantUser.permissions', function (Builder $builder) use ($q) {
                    $builder->WhereRaw('name LIKE ?', "%{$q}%");
                })
                ->orWhereHas('tenantUser.role', function (Builder $builder) use ($q) {
                    $builder->WhereRaw('name LIKE ?', "%{$q}%");
                });
        });
    }

    public function district(Builder $builder, $q)
    {
        $builder
            ->leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
            ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
            ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
            ->select('users.*', 'tenant_user.id as tenant_user_id', 'districts.id as district_id')
            ->where('district_tenant_user.district_id', $q);

    }

    public function site(Builder $builder, $q)
    {
        $builder
            ->leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
            ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')  
            ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
            ->leftJoin('sites', 'districts.id', '=', 'sites.district_id')
           ->select('users.*', 'tenant_user.id as tenant_user_id', 'districts.id as district_id')
            ->where('sites.id', $q);
    }

    public function communityOutreachAdvocate(Builder $builder)
    {
        return $builder;
    }

    public function outreachResourceAdvocate(Builder $builder)
    {
        return $builder->where(function (Builder $builder) {
            $builder->where('active', true)
                ->orWhere(function (Builder $builder) {
                    $builder->where('active', false)->has('contacts');
                });
        });
    }

    public function email(Builder $builder, $email)
    {
        return $builder->where('email', $email);
    }

    public function emails(Builder $builder, $emails)
    {
        return $builder->whereIn('email', $emails);
    }

    public function tenant(Builder $builder, $id)
    {
        return $builder->whereHas('tenants', function (Builder $builder) use ($id) {
            return $builder->where('tenants.id', $id);
        });
    }

    public function loadTenant(Builder $builder, $tenantId)
    {
        return $builder->with(
            (new TenantRelationConfig($tenantId))->compile()
        );
    }

    public function permissionGroup(Builder $builder, $config)
    {
        $group = $config['group'];
        $tenantId = $config['tenant_id'];
        $builder->whereHas('tenantUser', function (Builder $builder) use ($tenantId) {
            $builder->where('tenant_id', $tenantId);
        });

        $builder->whereHas('tenantUser.permissions', function (Builder $builder) use ($group) {
            return $builder->where('permissions.group', $group);
        });
    }

    public function active(Builder $builder, $bool)
    {
        return $builder->where('active', $bool);
    }

    public function permission(Builder $builder, $config)
    {
        $permission = $config['permission'];
        $tenantId = $config['tenant_id'];
        $builder->whereHas('tenantUser', function (Builder $builder) use ($tenantId) {
            $builder->where('tenant_id', $tenantId);
        });

        $builder->whereHas('tenantUser.permissions', function (Builder $builder) use ($permission) {
            return $builder->where('permissions.id', $permission);
        });
    }

    public function whereNotIn(Builder $builder, $ids)
    {
        return $builder->whereNotIn('users.id', $ids);
    }

    public function permissionName(Builder $builder, $permission)
    {
        if (is_string($permission)) {
            $permission = [$permission];
        }

        $builder
            ->leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
            ->leftJoin('permission_tenant_user', 'tenant_user.id', '=', 'permission_tenant_user.tenant_user_id')
            ->leftJoin('permissions', 'permissions.id', '=', 'permission_tenant_user.permission_id')
            ->whereIn('permissions.name', $permission)
            ->select('users.*');
    }
    
    public function districtPrint(Builder $builder, $q)
    {
        $builder
            ->leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
            ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
            ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
            ->select('users.*', 'tenant_user.id as tenant_user_id', 'districts.id as district_id')
            ->where('district_tenant_user.district_id', $q);

    }
    
      public function createdAtFrom(Builder $builder, $createdFrom)
    {
        return $builder->whereDate('created_at', '>=', $createdFrom);
    }

    public function createdAtTo(Builder $builder, $createdTo)
    {
        return $builder->whereDate('created_at', '<=', $createdTo);
    }
    
    public function hasPhoto(Builder $builder)
    {
        return $builder->whereHas('media', function (Builder $builder) {
            return $builder->where('collection_name', 'profile_picture');
        });
    }
    
     public function photoUploadedDate(Builder $builder, $date)
    {
        return $builder->whereHas('media', function (Builder $builder) use ($date) {
            return $builder->where('collection_name', 'profile_picture')
                ->whereRaw('DATE(created_at) = ?', $date);
        });
    }
    public function firstName(Builder $builder, $q)
    {
        return $builder->where('first_name', 'LIKE', "%{$q}%");
    }

    public function lastName(Builder $builder, $q)
    {
        return $builder->where('last_name', 'LIKE', "%{$q}%");
    }

}
