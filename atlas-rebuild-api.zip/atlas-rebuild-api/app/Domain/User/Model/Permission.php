<?php

namespace App\Domain\User\Model;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
    const GROUP_USER_TYPES = 'User Types';
    const GROUP_USER_SCOPES = 'User Scopes';
    const GROUP_ATLAS_GC_PROFILE = 'Atlas GC Profile';
    const PERMISSION_CREATE_NEW_USER = 'Create New User';
    const PERMISSION_EDIT_USER_PROFILE = 'Edit User Profile';
    const PERMISSION_CREATE_NEW_GC = 'View Create New GC';
    const PERMISSION_EDIT_GC = 'Edit Create New GC';
    const PERMISSION_VIEW_GC_PROFILE = 'View GC Profile';
    const PERMISSION_EDIT_GC_PROFILE = 'Edit GC Profile';
    const PERMISSION_EDIT_GC_PLP = 'View GC PLP';
    const PERMISSION_VIEW_GC_PLP = 'Edit GC PLP';
    const PERMISSION_VIEW_GC_ATTENDANCE = 'View GC Attendance';
    const PERMISSION_EDIT_GC_ATTENDANCE = 'Edit GC Attendance';
    const PERMISSION_EDIT_GC_SCANNER = 'Edit Scanner';
    const PERMISSION_VIEW_GC_NOTES = 'View GC Notes';
    const PERMISSION_EDIT_GC_NOTES = 'Edit GC Notes';
    const PERMISSION_VIEW_GC_DOCUMENTS = 'View GC Documents';
    const PERMISSION_EDIT_GC_DOCUMENTS = 'Edit GC Documents';
    const PERMISSION_DELETE_GC_DOCUMENTS = 'Delete GC Documents';
    const PERMISSION_VIEW_CONTACT = 'View Contacts';
    const PERMISSION_CREATE_CONTACT = 'Create New Contact';
    const PERMISSION_EDIT_CONTACT = 'Edit Contact Profile';
    const PERMISSION_VIEW_REPORT = 'View Standard Reports';
    const PERMISSION_EDIT_REPORT = 'Edit Standard Reports';
    const PERMISSION_CREATE_ROLE = 'Create New Role';
    const PERMISSION_EDIT_ROLE = 'Edit Role';
    const PERMISSION_EDIT_BULK_CONTACTS = 'Contacts Bulk Update';
    const PERMISSION_VIEW_SITE_SCHEDULE = 'View Site Schedule';
    const PERMISSION_EDIT_SITE_SCHEDULE = 'Edit Site Schedule';
    const PERMISSION_VIEW_PLP_MASTER_PLAN = 'View PLP Master Plans';
    const PERMISSION_EDIT_PLP_MASTER_PLAN = 'Edit PLP Master Plans';
    const PERMISSION_CREATE_APPOINTMENT = 'Create Appointment Category';
    const PERMISSION_VIEW_APPOINTMENT = 'View Appointment Categories';
    const PERMISSION_EDIT_APPOINTMENT = 'Edit Appointment Category';
    const PERMISSION_VIEW_STAFF = 'View Staff Schedule';
    const PERMISSION_EDIT_STAFF = 'Edit Staff Schedule';
    const PERMISSION_VIEW_REFERRAL_OPTIONS = 'View Referral Options';
    const PERMISSION_EDIT_REFERRAL_OPTIONS = 'Edit Referral Options';
    const PERMISSION_CREATE_CONTACT_ACTIONS = 'Add Contact Action Category';
    const PERMISSION_VIEW_NOTE_CATEGORY = 'View Notes Category';
    const PERMISSION_EDIT_NOTE_CATEGORY = 'Edit Notes Category';
    const PERMISSION_VIEW_DOCUMENT_TEMPLATE = 'View Documents Template';
    const PERMISSION_EDIT_DOCUMENT_TEMPLATE = 'Edit Documents Template';
    const PERMISSION_VIEW_DISTRICT = 'View District Partners';
    const PERMISSION_EDIT_DISTRICT = 'Edit District Partners';
    const PERMISSION_VIEW_ALL = 'View All';
    const PERMISSION_VIEW_ASSIGNED_CASELOAD = 'View Assigned Caseload';
    const PERMISSION_EXPORT_ALL_DISTRICTS = 'Export All Districts';
    const CAN_MANAGE_CONTACTS = [10, 9, 67, 69, 7, 6, 5, 4];
    const PERMISSION_FUND_ALL_LOCATION = 'Fund All Locations';
    const PERMISSION_FUND_ASSIGNED_LOCATION = 'Fund Assigned Locations';
    const PERMISSION_ALLOCATE_POINTS = 'Allocate Points';
    const PERMISSION_SECONED_APPROVER = 'Second Approver';
    const PERMISSION_NAME_CORPORATE = 'corporate';
    const PERMISSION_NAME_REFERRAL_POINTS = 'Referral Code Points';
    const COMMUNICATION_CASELOAD = 'Communication Caseload';
    const READ_ALL_CHATS = 'Read All Chats';
    const CHAT_IN_ALL_CHATS = 'Chat In All Chats';
    const PERMISSION_REASSIGN_SUPPORT_CHAT = 'Reassign Support Chat';
    const CAN_ACCESS_COMPASS = [56, 54, 55];
    protected $table = "permissions";
    protected $fillable = ['name', 'group'];

    public function roles()
    {
        return $this->belongsToMany(Role::class);
    }

    public function users()
    {
        return $this->belongsToMany(User::class);
    }
}
