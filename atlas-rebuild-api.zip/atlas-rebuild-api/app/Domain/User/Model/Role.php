<?php

namespace App\Domain\User\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Role extends Model
{
    use BelongsToTenant;

    protected $table = "roles";
    protected $fillable = ['name', 'tenant_id'];

    public function permissions()
    {
        return $this->belongsToMany(Permission::class);
    }

    public function scope()
    {
        return $this->hasOneThrough(
            Permission::class, PermissionRole::class, 'role_id', 'id', 'id', 'permission_id'
        )->where('group', Permission::GROUP_USER_SCOPES);
    }

    public function userTypes()
    {
        return $this->belongsToMany(Permission::class)->where('group', Permission::GROUP_USER_TYPES);
    }
}
