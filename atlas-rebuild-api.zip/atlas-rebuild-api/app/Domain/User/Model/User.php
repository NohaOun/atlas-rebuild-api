<?php

namespace App\Domain\User\Model;

use App\Domain\Auth\Contract\Authenticatable as AuthenticatableContract;
use App\Domain\Chat\Model\Message;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Contact\Model\Contact;
use App\Domain\Lookup\Model\Timezone;
use App\Domain\CallLog\Model\CallLogEntry;
use App\Domain\District\Model\District;
use App\Domain\Schedule\Model\StaffSchedule;
use App\Domain\Status\Model\Status;
use App\Domain\Tenancy\Model\Tenant;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class User extends Authenticatable implements HasMedia, AuthenticatableContract
{
    use HasApiTokens, Notifiable, HasMediaTrait, Concerns\HasTenantUser;

    protected $table = 'users';
    const CHAT_EMAILS_STATUS = ['every_message', 'day_end', 'none'];
    protected $fillable = [
        'first_name', 'chat_emails', 'last_name', 'title', 'lookup_timezone_id', 'email',
        'password', 'active', 'compass_mobile', 'should_change_password', 'nick_name'
    ];
    protected $hidden = ['password', 'remember_token'];
    protected $with = ['media', 'timezone'];

    public function timezone()
    {
        return $this->belongsTo(Timezone::class, 'lookup_timezone_id');
    }

    public function tenants()
    {
        return $this->belongsToMany(Tenant::class, 'tenant_user', 'user_id');
    }

    public function callLogEntries()
    {
        return $this->hasMany(CallLogEntry::class);
    }

    public function contacts()
    {
        return $this->hasMany(Contact::class, 'outreach_resource_advocate_id');
    }

    public function getUserType()
    {
        return AuthenticatableContract::USER_TYPE_USER;
    }

    public function getFullNameAttribute()
    {
        return sprintf('%s %s', $this->getAttribute('first_name'), $this->getAttribute('last_name'));
    }

    public function findForPassport($username)
    {
        $user = $this->where('email', $username)->first();

        if ($user !== null && $user->active == 0) {
            $user = null;
        }

        return $user;
    }

    public function hasPermission($permission)
    {
        foreach ($this->permissions as $userPermission) {
            if ($userPermission->id == optional($permission)->id ?? $permission) return true;
        }
    }

    public function staffSchedule()
    {
        return $this->hasOne(StaffSchedule::class, 'staff_id');
    }


    public function districts()
    {
        return $this->belongsToMany(District::class, 'district_tenant_user', 'tenant_user_id');
    }

    public function user()
    {
        return $this->morphMany(RoomUser::class, 'user', User::class, 'user_id', 'id');
    }

    public function messageCreator()
    {
        return $this->morphMany(Message::class, 'creator', User::class, 'creator_id', 'id');
    }
}
