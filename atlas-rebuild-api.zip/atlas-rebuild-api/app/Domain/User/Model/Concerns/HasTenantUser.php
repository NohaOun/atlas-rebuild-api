<?php

namespace App\Domain\User\Model\Concerns;

use App\Domain\User\Model\TenantUser;
use App\Domain\User\Support\TenantRelationConfig;

trait HasTenantUser
{
    public function setTenantUser(TenantUser $tenantUser)
    {
        $this->setRelation('tenantUser', $tenantUser);

        return $this;
    }

    public function getRoleAttribute()
    {
        return $this->getTenantUserAttributeValue('role');
    }

    public function getTenantAttribute()
    {
        return $this->getTenantUserAttributeValue('tenant');
    }

    public function getPermissionsAttribute()
    {
        return $this->getTenantUserAttributeValue('permissions', []);
    }

    public function hasTenant()
    {
        return $this->relationLoaded('tenantUser');
    }

    public function tenantUser()
    {
        return $this->hasOne(TenantUser::class);
    }

    public function loadTenant($tenantId)
    {
        return $this->load(
            (new TenantRelationConfig($tenantId))->compile()
        );
    }

    protected function getTenantUserAttributeValue($attribute, $default = null)
    {
        return $this->hasTenant() && $this->tenantUser
            ? $this->tenantUser->{$attribute}
            : $default;
    }

    public function getDistrictsAttribute()
    {
        return $this->getTenantUserAttributeValue('districts', []);
    }

}
