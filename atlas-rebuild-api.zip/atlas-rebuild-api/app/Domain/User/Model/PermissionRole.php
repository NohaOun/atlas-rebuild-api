<?php

namespace App\Domain\User\Model;

use Illuminate\Database\Eloquent\Relations\Pivot;

class PermissionRole extends Pivot
{
    public $timestamps = false;
    protected $table = "permission_role";
    protected $fillable = ['permission_id', 'role_id'];
}
