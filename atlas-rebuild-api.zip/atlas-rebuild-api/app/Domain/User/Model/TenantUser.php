<?php

namespace App\Domain\User\Model;

use App\Domain\District\Model\District;
use App\Domain\Tenancy\Model\Tenant;
use Illuminate\Database\Eloquent\Model;

class TenantUser extends Model
{
    protected $table = 'tenant_user';

    protected $fillable = ['user_id', 'tenant_id', 'role_id', 'is_initial'];

    public function tenant()
    {
        return $this->belongsTo(Tenant::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function role()
    {
        return $this->belongsTo(Role::class);
    }

    public function permissions()
    {
        return $this->belongsToMany(Permission::class);
    }

    public function districts()
    {
        return $this->belongsToMany(District::class);
    }
}
