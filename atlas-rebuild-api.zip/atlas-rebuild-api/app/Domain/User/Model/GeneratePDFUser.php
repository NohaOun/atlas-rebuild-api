<?php

namespace App\Domain\User\Model;

use Illuminate\Database\Eloquent\Model;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;

class GeneratePDFUser extends Model
{
     use   HasMediaTrait;
 protected $fillable = ['link'];
}
