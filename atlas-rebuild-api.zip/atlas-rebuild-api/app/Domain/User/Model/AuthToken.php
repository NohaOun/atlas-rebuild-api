<?php

namespace App\Domain\User\Model;

use App\Domain\Common\Model\Generic;
use Illuminate\Support\Arr;

class AuthToken extends Generic
{
    protected $attributes;

    public function __construct($attributes)
    {
        $this->attributes = $attributes;
    }

    public function getAccessToken()
    {
        return Arr::get($this->attributes, 'access_token');
    }

    public function getRefreshToken()
    {
        return Arr::get($this->attributes, 'refresh_token');
    }

    public function getExpiresIn()
    {
        return Arr::get($this->attributes, 'expires_in');
    }

    public function getTokenType()
    {
        return Arr::get($this->attributes, 'token_type');
    }
}
