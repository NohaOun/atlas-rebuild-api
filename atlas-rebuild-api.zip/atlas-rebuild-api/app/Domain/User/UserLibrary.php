<?php

namespace App\Domain\User;

use App\Domain\FileUpload\FileUploadLibrary;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Model\User;
use App\Domain\User\Model\TenantUser;
use App\Domain\User\Notifications\UserCreated;
use App\Domain\User\Repository\RoleRepositoryInterface;
use App\Domain\User\Repository\PermissionRepositoryInterface;
use App\Domain\User\Repository\UserRepositoryInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class UserLibrary
{
    protected $userRepo;
    private $roleRepo;
    protected $fileUploadLibrary;

    public function __construct(
        UserRepositoryInterface $userRepository,
        RoleRepositoryInterface $roleRepo,
        PermissionRepositoryInterface $permissionRepo,
        FileUploadLibrary $fileUploadLibrary
    )
    {
        $this->userRepo = $userRepository;
        $this->roleRepo = $roleRepo;
        $this->permissionRepo = $permissionRepo;
        $this->fileUploadLibrary = $fileUploadLibrary;
    }

    public function getUsers(UserFilters $filters)
    {
        return $this->userRepo->getUsers($filters);
    }

    public function getUserById($userId, UserFilters $filters = null)
    {
        return $this->userRepo->getUserById($userId, $filters);
    }

    public function getUserByEmail($email)
    {
        return $this->userRepo->getUserByEmail($email);
    }

    public function createUser($input)
    {
        $user = new User();

        $tempPassword = $this->setRandomPasswordForUser();

        $input['password'] = Hash::make($tempPassword);
        $input['should_change_password'] = 1;

        $user = $this->saveUser($user, $input);

        $this->sendWelcomeEmailForUser($user, $tempPassword);

        return $user;
    }

    public function updateUser(User $user, $input)
    {
        return $this->saveUser($user, $this->parseUserInput($input));
    }

    public function saveUser(User $user, $input)
    {
        return DB::transaction(function () use ($user, $input) {

            $user->fill($input);

            $this->userRepo->saveUser($user);

            if (Arr::has($input, 'profile_picture')) {
                $this->saveUserProfilePicture($user, Arr::get($input, 'profile_picture'));
            }

            if (Arr::has($input, 'tenant_id')) {
                $this->saveTenantUser($user, $input);
            }

            if (Arr::has($input, 'permission_ids')) {
                $this->checkUserPermissionType($user, $input['permission_ids']);
            }

            return $user;
        });
    }

    protected function saveUserProfilePicture(User $user, $profilePicture)
    {
        $user->clearMediaCollection('profile_picture');

        if ($profilePicture) {
            $this->fileUploadLibrary->associate($user, [$profilePicture], 'profile_picture');
        }
    }

    public function saveTenantUser(User $user, $input)
    {
        $tenantUser = $this->userRepo->getTenantUser($user->id, $input['tenant_id']);
        if (!$tenantUser) {
            $tenantUser = $this->createTenantUser($user->id, $input['tenant_id']);
        }

        if (Arr::has($input, 'role_id')) {
            $this->saveTenantUserRole($tenantUser, $input['role_id']);
        }

        if (Arr::has($input, 'permission_ids')) {
            $this->userRepo->saveTenantUserPermissions($tenantUser, $input['permission_ids']);
        }

        if (Arr::has($input, 'district_ids')) {
            $this->userRepo->saveTenantUserDistricts($tenantUser, $input['district_ids']);
        }

        $user->loadTenant($input['tenant_id']);

        return $user;
    }

    public function setRandomPasswordForUser()
    {
        return $this->generateRandomPassword();
    }

    public function sendWelcomeEmailForUser(User $user, $randomPassword)
    {
        $user->notify(new UserCreated($randomPassword));
    }

    protected function generateRandomPassword()
    {
        return Str::random(8);
    }

    protected function createTenantUser($userId, $tenantId)
    {
        $tenantUser = new TenantUser(['user_id' => $userId, 'tenant_id' => $tenantId]);

        $this->userRepo->saveTenantUser($tenantUser);

        return $tenantUser;
    }

    protected function parseUserInput($input)
    {
        return $input;
    }

    protected function saveTenantUserRole(TenantUser $tenantUser, $roleId)
    {
        $tenantUser->fill(['role_id' => $roleId]);

        $this->userRepo->saveTenantUser($tenantUser);

        $permissionIds = $this->roleRepo->getRole($roleId)->permissions()->pluck('id')->toArray();
        $this->userRepo->saveTenantUserPermissions($tenantUser, $permissionIds);
    }

    public function deleteUser($user)
    {
        return $this->userRepo->deleteUser($user);
    }

    protected function checkUserPermissionType($user, $permissionIds)
    {
        foreach ($permissionIds as $key => $permissionId) {
            $permission = $this->permissionRepo->getPermission($permissionId);
            if ($permission->name == "Compass Mobile?" or $permission->name == "Enrollment Coach" or $permission->name == "Outreach Resource Advocate") {
                $input['compass_mobile'] = 1;
                return $this->saveUser($user, $input);
            }
        }

    }

}
