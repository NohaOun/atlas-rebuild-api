<?php


namespace App\Domain\User;

use App\Domain\User\Filters\RoleFilters;
use App\Domain\User\Model\Role;
use App\Domain\User\Repository\PermissionRepositoryInterface;
use App\Domain\User\Repository\RoleRepositoryInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class RoleLibrary
{
    protected $roleRepo;
    protected $permissionRepo;

    public function __construct(RoleRepositoryInterface $roleRepo, PermissionRepositoryInterface $permissionRepo)
    {
        $this->roleRepo = $roleRepo;
        $this->permissionRepo = $permissionRepo;
    }

    public function getRoles(RoleFilters $filters = null)
    {
        return $this->roleRepo->getRoles($filters);
    }

    public function getRole($roleId)
    {
        return $this->roleRepo->getRole($roleId);
    }

    public function createRole($data)
    {
        return $this->saveRole(new Role, $data);
    }

    public function updateRole(Role $role, $data)
    {
        return $this->saveRole($role, $data);
    }

    protected function saveRole(Role $role, $data)
    {
        return DB::transaction(function () use ($role, $data) {
            $role->fill(Arr::only($data, ['name', 'scope', 'tenant_id']));

            $this->roleRepo->saveRole($role);

            if (Arr::has($data, 'permission_ids')) {
                $this->roleRepo->saveRolePermissions($role, $data['permission_ids']);
            }

            return $role;
        });
    }

    public function deleteRole($record)
    {
        return $this->roleRepo->deleteRole($record);
    }

    public function createTenantInitialRole($input, $tenantId)
    {
        $role = new Role();
        $role->forceFill(
            array_merge($input, ['tenant_id' => $tenantId])
        );

        $this->roleRepo->saveRole($role);

        $permissionIds = $this->permissionRepo->getPermissions(null)->map->id;
        $this->roleRepo->saveRolePermissions($role, $permissionIds);

        return $role;
    }
}
