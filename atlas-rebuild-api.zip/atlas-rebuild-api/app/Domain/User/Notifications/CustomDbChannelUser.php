<?php

namespace App\Domain\User\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;
use Illuminate\Notifications\Channels\DatabaseChannel as IlluminateDatabaseChannel;
use App\Domain\User\Model\User;

class CustomDbChannelUser  extends IlluminateDatabaseChannel
{
    use  BelongsToTenant, Queueable;

     protected $object;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->object = $object;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */

    public function send($notifiable, Notification $notification)
    {

    //    var_dump($notification);
      $user= User::leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
             ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
             ->select('tenant_user.tenant_id as tenant_id')
             ->where('users.id', $notifiable->id)->limit(1)->get();

        return $notifiable->routeNotificationFor('database')->create([
            'id'      => $notification->id,
            'type'    => get_class($notification),
            'tenant_id'=> $user[0]->tenant_id,
            'data'    => [
                'subject'=> 'Welcome meassage',
                'to'=> $notifiable->email,
                'from'=> 'noreply@accelerationacademy.net'
                          ],
            'name'    =>  $notifiable->full_name,
            'read_at' => null,
        ]);
    }

}
