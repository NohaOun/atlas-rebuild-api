<?php

namespace App\Domain\User\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class PasswordUpdated extends Notification
{
    use Queueable;

    protected $url;

    public function __construct($url = null)
    {
        $this->url = $url;
    }


    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage())
            ->from('noreply@accelerationacademy.net')
            ->greeting('Hello!: ' . $notifiable->full_name)
            ->line("<p>Your Password Was Updated Successfully</p> <br />")
            ->action('Login now', config('app.web_app_url') . $this->url)
            ->line('Thank you for using our application!');
    }
}
