<?php

namespace App\Domain\User\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use App\Domain\User\Notifications\CustomDbChannelUser;

class UserCreated extends Notification
{
    use Queueable;

    private $tempPassword;

    public function __construct($tempPassword)
    {
        $this->tempPassword = $tempPassword;
    }

    public function via($notifiable)
    {
        return ['mail', CustomDbChannelUser::class];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)->from('noreply@accelerationacademy.net')->subject('Welcome to Atlas Engagement Hub')->markdown('emails.user_created', [
            'user' => $notifiable,
            'tempPassword' => $this->tempPassword
        ]);
    }
}
