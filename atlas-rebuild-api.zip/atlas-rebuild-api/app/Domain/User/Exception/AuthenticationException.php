<?php

namespace App\Domain\User\Exception;

use Illuminate\Auth\AuthenticationException as BaseAuthenticationException;

class AuthenticationException extends BaseAuthenticationException
{

}
