<?php

namespace App\Domain\User\Exception;

class TimePeriodExceedException extends \RuntimeException
{
}
