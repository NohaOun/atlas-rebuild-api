<?php

namespace App\Domain\User\Exception;

class ALreadyChangedTempPassword extends \RuntimeException
{
}
