<?php

namespace App\Domain\User\Exception;

class CannotActivateUserException extends \RuntimeException
{
}
