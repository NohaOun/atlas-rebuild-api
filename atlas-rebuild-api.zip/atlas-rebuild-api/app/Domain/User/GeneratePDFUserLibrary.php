<?php
namespace App\Domain\User;

use App\Domain\User\Model\User;
use App\Domain\User\Model\GeneratePDFUser;
use PDF;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use DB;

class GeneratePDFUserLibrary
{
     use   HasMediaTrait;
    // Generate PDF

    public function createPDF($ids) {
          
         //  $ids = (array) $ids;
      
         $ids = explode(",",$ids['ids'][0]);
        $data = User::select('users.*', 'users.id as user_id')               
                 ->whereIn('id', $ids)->get();

         view()->share('users', $data);
        $pdf = PDF::loadView('pdf_view_user', $data);
        Storage::put('public/pdf/pdf_file_user.pdf', $pdf->output());
        $pdf = new GeneratePDFUser(['link' => route('userPdf.download', 'user_pdf_file.pdf')]);

        return $pdf;
    }

}