<?php

namespace App\Domain\User\Support;

use Illuminate\Database\Eloquent\Relations\HasOne;

class TenantRelationConfig
{
    private $tenantId;

    public function __construct($tenantId)
    {
        $this->tenantId = $tenantId;
    }

    public function compile()
    {
        return [
            'tenantUser' => function (HasOne $builder) {
                return $builder->where('tenant_id', $this->tenantId);
            },
            'tenantUser.tenant', 'tenantUser.districts', 'tenantUser.role', 'tenantUser.permissions'
        ];
    }
}
