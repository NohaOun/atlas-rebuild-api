<?php

namespace App\Domain\Status\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;
use Stancl\Tenancy\Database\TenantScope;

class StatusFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function phase(Builder $builder, $id)
    {
        if (is_array($id)) {
            return $builder->whereIn('phase_id', $id);
        } else {
            return $builder->where('phase_id', $id);
        }
    }

    public function tenant(Builder $builder, $tenantId)
    {
        $builder->withoutGlobalScope(TenantScope::class)->where('tenant_id', $tenantId);
    }

    public function statusName(Builder $builder, $name)
    {
        return $builder->where('name', $name);
    }

    public function phaseName(Builder $builder, $name)
    {
        return $builder->whereHas('phase', function (Builder $builder) use ($name) {
            return $builder->where('name', $name);
        });
    }

    public function statusKey(Builder $builder, $key)
    {
        if (is_array($key)) return $builder->whereIn('status_key', $key);

        return $builder->where('status_key', $key);
    }
}
