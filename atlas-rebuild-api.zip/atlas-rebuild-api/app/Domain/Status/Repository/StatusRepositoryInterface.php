<?php

namespace App\Domain\Status\Repository;

use App\Domain\Status\Filters\StatusFilters;
use App\Domain\Status\Model\Status;
use Illuminate\Database\Eloquent\Collection;

interface StatusRepositoryInterface
{

    const STATUS_KEY_ACTIVE = 'Active';
    const STATUS_KEY_ENGAGEMENT_PHASE_1 = 'Engagement phase 1';
    const STATUS_KEY_ENGAGEMENT_PHASE_2 = 'Engagement phase 2';
    const STATUS_KEY_ENGAGEMENT_PHASE_3 = 'Engagement phase 3';
    const STATUS_KEY_ENGAGEMENT_PHASE_4 = 'Engagement phase 4';
    const STATUS_KEY_PENDING_WITHDRAWAL = 'Pending withdrawal';
    const STATUS_KEY_WA_ONLY_HB1418 = 'WA ONLY - HB1418';
    const STATUS_KEY_DEACTIVATED_NON_RESPONSIVE = 'Deactivated - Non Responsive';
    const STATUS_KEY_DECEASED = 'Deceased';
    const STATUS_KEY_DISTRICT_REQUIREMENTS_NOT_MET = 'District Requirements Not Met';
    const STATUS_KEY_DO_NOT_CONTACT = 'Do Not Contact';
    const STATUS_KEY_GROSS_MISCONDUCT = 'Gross Misconduct';
    const STATUS_KEY_STILL_IN_DISTRICT_SIS = 'Still in District SIS';
    const STATUS_KEY_VOLUNTARY_GC_REQUEST = 'Voluntary - GC Request';
    const STATUS_KEY_COLLEGE_STUDENT = 'College Student';
    const STATUS_KEY_EMPLOYED = 'Employed';
    const STATUS_KEY_MILITARY = 'Military';
    const STATUS_KEY_TRADE_SCHOOL = 'Trade School';
    const STATUS_KEY_OTHER = 'Other';
    const STATUS_KEY_UNKNOWN = 'Unknown';
    const STATUS_KEY_NEW = 'New';
    const STATUS_KEY_INITIATED_FOLLOW_UP = 'Initiated - Follow up';
    const STATUS_KEY_PENDING_LOCAL_REVIEW = 'Pending - Local Review';
    const STATUS_KEY_PENDING_MIDDLE_SCHOOL_COMPLETION = 'Pending - Middle School Completion';
    const STATUS_KEY_PENDING_DISTRICT_APPROVAL = 'Pending - District Approval';
    const STATUS_KEY_PENDING_MISSING_ITEMS = 'Pending - Missing Items';
    const STATUS_KEY_APPROVED_WAITING_TO_BE_SCHEDULED = 'Approved - waiting to be scheduled';
    const STATUS_KEY_APPROVED_MISSING_ITEMS = 'Approved - Missing Items';
    const STATUS_KEY_APPROVED_SCHEDULED_FOR_ORIENTATION = 'Approved - scheduled for orientation';
    const STATUS_KEY_RE_ENROLLING = 'Re-Enrolling';
    const STATUS_KEY_APPOINTMENT_SCHEDULED = 'Appointment Scheduled';
    const STATUS_KEY_FIRST_ROUND = 'First Round';
    const STATUS_KEY_SECOND_ROUND = 'Second Round';
    const STATUS_KEY_THIRD_ROUND = 'Third Round';
    const STATUS_KEY_HOME_VISIT_NEEDED = 'Home Visit Needed';
    const STATUS_KEY_AGED_OUT = 'Aged Out';
    const STATUS_KEY_ALREADY_GRADUATED = 'Already Graduated';
    const STATUS_KEY_CANNOT_CONTACT_BAD_CONTACT_INFORMATION = 'Cannot Contact - Bad Contact Information';
    const STATUS_KEY_CANNOT_CONTACT_NO_RESPONSE = 'Cannot Contact - No Response';
    const STATUS_KEY_DECLINED_PROGRAM = 'Declined Program';
    const STATUS_KEY_DENIED_BY_AA = 'Denied - by AA';
    const STATUS_KEY_DENIED_BY_DISTRICT = 'Denied - by District';
    const STATUS_KEY_FUTURE_RECRUITMENT_EFFORT = 'Future Recruitment Effort';
    const STATUS_KEY_INTERESTED_NOT_READY_TO_COMMIT = 'Interested - Not Ready to Commit';
    const STATUS_KEY_UNDERAGE = 'Underage';

    public function getStatuses(StatusFilters $filters): Collection;

    public function getStatus($statusId): ?Status;

    public function getStatusByFilters(StatusFilters $filters): ?Status;

    public function saveStatus(Status $status);

    public function deleteStatus(Status $status);
}
