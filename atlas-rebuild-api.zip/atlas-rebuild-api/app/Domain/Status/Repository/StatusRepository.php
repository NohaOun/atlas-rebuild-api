<?php

namespace App\Domain\Status\Repository;

use App\Domain\Status\Model\Status;
use App\Domain\Status\Filters\StatusFilters;
use Illuminate\Database\Eloquent\Collection;

class StatusRepository implements StatusRepositoryInterface
{
    public function getStatuses(StatusFilters $filters): Collection
    {
        // TODO remove it when pagination is done
        return $this->getFilteredBuilder($filters)->take(50)->get();
    }

    public function getStatus($statusId): ?Status
    {
        return Status::query()->find($statusId);
    }

    public function getStatusByFilters(StatusFilters $filters): ?Status
    {
        return $this->getFilteredBuilder($filters)->first();
    }

    public function saveStatus(Status $status)
    {
        return $status->save();
    }

    public function deleteStatus(Status $status)
    {
        return $status->delete();
    }

    protected function getFilteredBuilder(?StatusFilters $filters)
    {
        $builder = Status::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
