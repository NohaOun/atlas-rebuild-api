<?php

namespace App\Domain\Status\Model;

use App\Domain\Phase\Model\Phase;
use App\Domain\Status\StatusLibrary;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Spatie\MediaLibrary\HasMedia\HasMedia;
use Spatie\MediaLibrary\HasMedia\HasMediaTrait;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Status extends Model implements HasMedia
{
    use BelongsToTenant, HasMediaTrait;

    protected $table = 'statuses';
    protected $fillable = ['name', 'description', 'phase_id', 'color', 'color_updated_at', 'status_key'];
    protected $with = ['phase'];
    protected $statistics;

    public function phase()
    {
        return $this->belongsTo(Phase::class);
    }

    public function getFullNameAttribute()
    {
        return sprintf('%s/%s', $this->phase->name, $this->name);
    }

    public function setStatistics($value)
    {
        $this->statistics = $value;
    }

    public function getStatistics()
    {
        if (is_null($this->statistics)) {
            $statistics = app()->make(StatusLibrary::class)->getStatisticsForStatuses([$this->id], null);

            return [
                'student_count' => Arr::get($statistics, $this->id, 0),
                'contact_count' => 0
            ];
        }

        return $this->statistics;
    }
}
