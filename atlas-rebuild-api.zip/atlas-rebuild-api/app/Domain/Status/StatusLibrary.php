<?php

namespace App\Domain\Status;

use App\Domain\Contact\Repository\ContactRepositoryInterface;
use App\Domain\FileUpload\FileUploadLibrary;
use App\Domain\Status\Filters\StatusFilters;
use App\Domain\Status\Model\Status;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Domain\StatusHistory\Repository\StatusHistoryRepositoryInterface;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\User\Model\Permission;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class StatusLibrary
{
    protected $statusRepo;
    protected $studentRepo;
    protected $fileUploadLibrary;
    protected $contactRepo;
    protected $statusHistoryRepo;

    public function __construct(
        StatusRepositoryInterface $statusRepo,
        StudentRepositoryInterface $studentRepo,
        ContactRepositoryInterface $contactRepo,
        FileUploadLibrary $fileUploadLibrary,
        StatusHistoryRepositoryInterface $statusHistoryRepo
    )
    {
        $this->statusRepo = $statusRepo;
        $this->fileUploadLibrary = $fileUploadLibrary;
        $this->studentRepo = $studentRepo;
        $this->contactRepo = $contactRepo;
        $this->statusHistoryRepo = $statusHistoryRepo;
    }

    public function getStatuses(StatusFilters $filters = null)
    {
        $statuses = $this->statusRepo->getStatuses($filters);

        $studentCounts = $this->getStatisticsForStatuses(
            $statuses->pluck('id'), $filters->get('district')
        );

        foreach ($statuses as $status) {
            $status->setStatistics([
                'student_count' => isset($studentCounts[$status->id]) ? $studentCounts[$status->id] : 0,
                'contact_count' => 0,
                'contact_count_stay_in_status_per_day' => []

            ]);
        }

        return $statuses;
    }

    public function getStatus($statusId)
    {
        return $this->statusRepo->getStatus($statusId);
    }

    public function createStatus($input)
    {
        $status = new Status($this->getStatusAttributes($input));

        $this->statusRepo->saveStatus($status);

        $this->saveStatusIcon($status, $input);

        return $status;
    }

    public function updateStatus(Status $status, $input)
    {
        $status->fill($this->getStatusAttributes($input, $status));

        $this->statusRepo->saveStatus($status);

        $this->saveStatusIcon($status, $input, true);

        return $status;
    }

    public function deleteStatus(Status $status)
    {
        return $this->statusRepo->deleteStatus($status);
    }

    protected function getStatusAttributes($input, Status $existing = null)
    {
        $attributes = Arr::get($input, 'attributes', []);

        if (
            isset($attributes['color']) &&
            (!$existing || ($attributes['color'] != $existing->color))
        ) {
            $attributes['color_updated_at'] = Carbon::now();
        }

        if (Arr::has($input, 'relationships.phase_id')) {
            $attributes['phase_id'] = $input['relationships']['phase_id'];
        }

        return $attributes;
    }

    public function getStatisticsForStatuses($statusIds, $district)
    {
        $statistics = [];

        $studentBuilder = $this->getStudentBuilder($statusIds, $district);
        $statistics['student_count'] = $studentBuilder->get()->keyBy('status_id');

        $contactBuilder = $this->getContactBuilder($statusIds, $district);
        $statistics['contact_count'] = $contactBuilder->get()->keyBy('status_id');

        $statistics['contact_status_exited'] = $this->getContactCountStatusExited($statusIds);


        return $statistics;
    }

    protected function saveStatusIcon(Status $status, $data, $update = false)
    {
        if (Arr::has($data, 'attributes.icon') && isset($data['attributes']['icon'])) {
            $status->clearMediaCollection('icon');
            $this->fileUploadLibrary->associate($status, [Arr::get($data, 'attributes.icon')], 'icon');
        } elseif ($update && Arr::has($data, 'attributes.icon') && !isset($data['attributes']['icon'])) {
            $status->clearMediaCollection('icon');
        }
    }

    public function getStudentBuilder($statusIds, $district)
    {
        $builder = DB::table('statuses')
            ->addSelect('statuses.id As status_id')
            ->selectRaw(' COUNT(DISTINCT students.id ) As student_count')
            ->leftJoin('students', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->whereIn('students.status_id', $statusIds)
            ->where('students.tenant_id', tenant()->id)
            ->whereNull('students.deleted_at')
            ->where('sites.active', 1);
        if (app()->has('assigned-district-ids')) $builder->whereIn('sites.district_id', app('assigned-district-ids'));
        if (app()->has('showing-districts-ids-in-dashboard')) $builder->whereIn('sites.district_id', app('showing-districts-ids-in-dashboard'));
        $builder->groupBy('statuses.id');
        if (Auth::guard('api')->check() && auth()->user()->can(Permission::PERMISSION_VIEW_ASSIGNED_CASELOAD) && !auth()->user()->can(Permission::PERMISSION_VIEW_ALL)) {
            $builder->join('student_assignees', 'students.id', '=', 'student_assignees.student_id')
                ->where('student_assignees.user_id', auth()->id());
        }

        if ($district) {
            $builder = $builder->where('sites.district_id', $district);
        }

        return $builder;
    }

    public function getContactBuilder($statusIds, $district)
    {
        $builder = DB::table('statuses')
            ->addSelect('statuses.id As status_id')
            ->selectRaw(' COUNT(DISTINCT contacts.id ) As contact_count')
            ->leftJoin('contacts', 'contacts.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'contacts.site_id', '=', 'sites.id')
            ->whereIn('contacts.status_id', $statusIds)
            ->where('contacts.tenant_id', tenant()->id)
            ->whereNull('contacts.deleted_at')
            ->where('sites.active', 1);
        if (app()->has('assigned-district-ids')) $builder->whereIn('sites.district_id', app('assigned-district-ids'));
        if (app()->has('showing-districts-ids-in-dashboard')) $builder->whereIn('sites.district_id', app('showing-districts-ids-in-dashboard'));
        $builder->groupBy('statuses.id');

        if ($district) {
            $builder = $builder->where('sites.district_id', $district);
        }

        return $builder;
    }

    public function getContactCountStatusExited($statusIds)
    {
        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay()->format('Y-m-d');
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay()->format('Y-m-d');
        $builder = DB::table('status_history')
            ->selectRaw('DISTINCT status_history.new_status_id')
            ->selectRaw('DAYNAME(CONCAT("1970-09-2", WEEKDAY(status_history.exited_at))) as day_of_week')
            ->selectRaw(' COUNT(status_history.status_variable_id) as contact_count')
            ->where('status_history.status_variable_type', 'Contact')
            ->where('status_history.created_at', '>=', $startDate)
            ->where('status_history.created_at', '<=', $endDate)
            ->whereIn('status_history.new_status_id', $statusIds)
            ->groupBy(['status_history.new_status_id', 'day_of_week']);

        $result = $builder->get()->groupBy('new_status_id');
        $data = [];

        foreach ($statusIds as $id) {
            if (isset($result[$id])) {
                foreach ($result[$id] as $item) {
                    $data[$id][$item->day_of_week] = $item->contact_count;
                }
            }

        }
        return $data;
    }
}
