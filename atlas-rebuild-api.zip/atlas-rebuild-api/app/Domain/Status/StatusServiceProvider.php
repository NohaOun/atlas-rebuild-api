<?php

namespace App\Domain\Status;

use App\Domain\Status\Model\Status;
use App\Domain\Status\Repository\StatusRepository;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Observers\StatusObserver;
use Illuminate\Support\ServiceProvider;

class StatusServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(StatusRepositoryInterface::class, StatusRepository::class);
    }
    public function boot(){
        Status::observe(StatusObserver::class);
    }
}
