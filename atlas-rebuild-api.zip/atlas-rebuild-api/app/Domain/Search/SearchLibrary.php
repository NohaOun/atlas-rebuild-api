<?php

namespace App\Domain\Search;

use App\Domain\Contact\Filters\ContactFilters;
use App\Domain\Contact\Repository\ContactRepositoryInterface;
use App\Domain\Lookup\Model\SpecialProgram;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Search\Model\SearchResult;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Repository\UserRepositoryInterface;
use Illuminate\Support\Collection;

class SearchLibrary
{
    protected $studentRepo;

    protected $contactRepository;

    protected $userRepository;

    public function __construct(
        StudentRepositoryInterface $studentRepository,
        ContactRepositoryInterface $contactRepository,
        UserRepositoryInterface $userRepository
    )
    {
        $this->studentRepo = $studentRepository;
        $this->contactRepository = $contactRepository;
        $this->userRepository = $userRepository;
    }

    public function getSearchResults($q)
    {

        $filters = new StudentFilters(['q' => $q, 'perPage' => 10, 'phaseKey' => PhaseKeyRepositoryInterface::PHASE_NAME_DUPLICATE]);
        $students = $this->studentRepo->getStudentsByFilter($filters)->load(['status', 'specialPrograms' => function ($q) {
            $q->where('name', '!=', 'None');
        }]);

        $collection = new Collection();
        foreach ($students as $student) {
            $icon = $student->status ? $student->status->getFirstMedia('icon') : null;
            $collection->push(
                new SearchResult([
                    'type' => 'student',
                    'id' => $student->id,
                    'label' => $student->full_name,
                    'icon' =>  $icon ? $icon->getFullUrl() : null,
                    'site' => $student->site ? $student->site->name : null,
                    'minor_icon' => $student->minor ? true : false,
                    'special_programs_icon' => $student->specialPrograms->count() > 0 ? true : false
                ])
            );
        }

        $filters = new ContactFilters(['q' => $q, 'perPage' => 10]);

        foreach ($this->contactRepository->getContacts($filters)->load('status') as $contact) {
            $icon = $contact->status ? $contact->status->getFirstMedia('icon') : null;
            $collection->push(
                new SearchResult([
                    'type' => 'contact',
                    'id' => $contact->id,
                    'label' => $contact->first_name. ' '. $contact->last_name,
                    'icon' =>  $icon ? $icon->getFullUrl() : null,
                    'site' => null,
                    'minor_icon' => false,
                    'special_programs_icon' => false
                ])
            );
        }

        $filters = new UserFilters(['q' => $q, 'perPage' => 10, 'tenant' => tenant()->id]);

        foreach ($this->userRepository->getUsers($filters) as $user) {
            $collection->push(
                new SearchResult([
                    'type' => 'user',
                    'id' => $user->id,
                    'label' => $user->full_name,
                    'icon' => null,
                    'site' => null,
                    'minor_icon' => false,
                    'special_programs_icon' => false
                ])
            );
        }

        return $collection->sortBy('label');
    }
}
