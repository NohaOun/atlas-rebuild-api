<?php

namespace App\Domain\Search\Model;

use App\Domain\Common\Model\Generic;
use Illuminate\Support\Arr;

class SearchResult extends Generic
{
    protected $attributes;

    public function __construct($attributes)
    {
        $this->attributes = $attributes;
    }

    public function getEntityId()
    {
        return Arr::get($this->attributes, 'id');
    }

    public function getEntityType()
    {
        return Arr::get($this->attributes, 'type');
    }

    public function getLabel()
    {
        return Arr::get($this->attributes, 'label');
    }

    public function getIcon()
    {
        return Arr::get($this->attributes, 'icon');
    }

    public function getMinorIcon()
    {
        return Arr::get($this->attributes, 'minor_icon');
    }

    public function getSpecialProgramsIcon()
    {
        return Arr::get($this->attributes, 'special_programs_icon');
    }

    public function getSite()
    {
        return Arr::get($this->attributes, 'site');
    }
}
