<?php


namespace App\Domain\StudentPoint\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class StudentPointFilters extends BaseFilters
{

    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function districtId(Builder $builder, $id)
    {
        return $builder->where('district_id', $id);
    }

    public function student(Builder $builder, $id)
    {
        return $builder->where('student_id', $id);
    }

    public function challengeName(Builder $builder, $challengeName)
    {
        return $builder->where('challengeName', 'like',"%$challengeName%");
    }
}
