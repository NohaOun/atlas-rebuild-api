<?php

namespace App\Domain\StudentPoint\Model;

use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\Student as Challenge;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentPoint extends Model
{
    // use BelongsToTenant;

    protected $fillable = ['student_id', 'previous_points', 'total_points', 'added_points', 'challenge_name', "challenge_id", "user_id"];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    //  PLease Chagne The Relation When It's Done
    protected function challenge()
    {
        return $this->belongsTo(Challenge::class);
    }
}
