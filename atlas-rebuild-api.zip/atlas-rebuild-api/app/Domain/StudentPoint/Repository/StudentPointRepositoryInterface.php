<?php

namespace App\Domain\StudentPoint\Repository;

use App\Domain\StudentPoint\Filters\StudentPointFilters;
use App\Domain\StudentPoint\Model\StudentPoint;

interface StudentPointRepositoryInterface
{
    public function getStudentPoints(StudentPointFilters $filterse);

    public function getStudentPoint($studentPointId): ?StudentPoint;


    public function saveStudentPoint(StudentPoint $studentPoint);

    public function deleteStudentPoint(StudentPoint $studentPoint);
}
