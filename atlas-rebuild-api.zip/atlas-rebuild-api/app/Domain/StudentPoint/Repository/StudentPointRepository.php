<?php

namespace App\Domain\StudentPoint\Repository;

use App\Domain\Student\Model\Student;
use App\Domain\StudentPoint\Filters\StudentPointFilters;
use App\Domain\StudentPoint\Model\StudentPoint;

class StudentPointRepository implements StudentPointRepositoryInterface
{
    public function getStudentPoints(StudentPointFilters $filters)
    {
        $builder = StudentPoint::query();
        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getStudentPoint($studentPointId): ?StudentPoint
    {
        return StudentPoint::query()->find($studentPointId);
    }

    public function saveStudentPoint(StudentPoint $studentPoint)
    {
        return $studentPoint->save();
    }

    public function deleteStudentPoint(StudentPoint $studentPoint)
    {
        return $studentPoint->delete();
    }

    public function addPoints(Student $student, $points, $user_id = null, $challenge = null)
    {
        // To reload relation becuase challenges can call studentpoint after making updates on the same user
        $student->load('studentPoint');
        $currentStudentPoint = $student->studentPoint;

        if (!$currentStudentPoint) {
            $currentStudentPoint = 0;
        } else {
            $currentStudentPoint = $student->studentPoint->total_points;
        }

        $newPoints = $currentStudentPoint + $points;
        $studentPoint = new StudentPoint();
        $studentPoint->student_id = $student->id;
        $studentPoint->previous_points = $currentStudentPoint;
        $studentPoint->total_points = $newPoints;
        $studentPoint->added_points = $points;
        $studentPoint->user_id = $user_id;
        if($challenge){
            $studentPoint->challenge_name = $challenge->name;
            $studentPoint->challenge_id = $challenge->id;
        }
        $this->saveStudentPoint($studentPoint);
        return $studentPoint;
    }
}
