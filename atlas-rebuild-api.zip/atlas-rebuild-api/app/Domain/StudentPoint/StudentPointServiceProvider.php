<?php

namespace App\Domain\StudentPoint;

use App\Domain\StudentPoint\Model\StudentPoint;
use App\Domain\StudentPoint\Repository\StudentPointRepository;
use App\Domain\StudentPoint\Repository\StudentPointRepositoryInterface;
use App\Observers\StudentPointObserver;
use Illuminate\Support\ServiceProvider;

class StudentPointServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(StudentPointRepositoryInterface::class, StudentPointRepository::class);
    }

    public function boot()
    {
        StudentPoint::observe(StudentPointObserver::class);
    }
}
