<?php

namespace App\Domain\StudentPoint;

use App\Domain\Challenge\Model\Challenge;
use App\Domain\Note\Model\Note;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentPoint\Model\StudentPoint;
use App\Domain\StudentPoint\Repository\StudentPointRepository;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class StudentPointLibrary
{
    protected $studentPointRepo;

    protected $phaseKeyRepo;

    public function __construct(
        StudentPointRepository $studentPointRepo)
    {
        $this->studentPointRepo = $studentPointRepo;
    }

    public function getStudentPoints($filters)
    {
        return $this->studentPointRepo->getStudentPoints($filters);
    }

    public function getStudentPoint($studentPointId)
    {
        return $this->studentPointRepo->getStudentPoint($studentPointId);
    }

    public function createStudentPoint($input)
    {
        $attributes = Arr::get($input, 'attributes', []);
        $studentPoint = new StudentPoint($attributes);
        $this->studentPointRepo->saveStudentPoint($studentPoint);
        return $studentPoint;
    }

    public function updateStudentPoint(StudentPoint $studentPoint, $data)
    {
        $attributes = Arr::get($data, 'attributes', []);
        $studentPoint->fill($attributes);

        $this->studentPointRepo->saveStudentPoint($studentPoint);

        return $studentPoint;
    }

    public function deleteStudentPoint(StudentPoint $studentPoint)
    {
        return $this->studentPointRepo->deleteStudentPoint($studentPoint);
    }


    public static function generateAndCacheRankingList()
    {
        $students = Student::Join('student_points', function($query) 
                {
                $query->on('students.id','=','student_points.student_id')
                ->whereRaw('
                student_points.id IN (
                    SELECT
                                MAX(sp2.id) 
                            FROM
                                student_points AS sp2
                            JOIN students AS stu2
                            ON
                                stu2.id = sp2.student_id
                            GROUP BY
                                sp2.student_id
                    )');
                })->join('redemptions', 'students.id', 'redemptions.student_id')
                ->groupByRaw("redemptions.student_id, 
                        student_points.total_points, concat(students.first_name, ' ', students.last_name)")
                ->selectRaw("redemptions.student_id as id, 
                    CONCAT(students.first_name, ' ', students.last_name) as name,
                student_points.total_points - SUM(redemptions.points) as current_points")
                ->orderBy('current_points', 'desc')->limit(5)->get();
       
        \Cache::put('rankingList', $students, now()->addHours(1));

        return $students;
    }

    public static function getRankingList()
    {
        return \Cache::get('rankingList', function () {
            return static::generateAndCacheRankingList();
        });
    }

    public function addPoints(Student $student, $points, $user_id = null,  $challenge = null)
    {
        return $this->studentPointRepo->addPoints($student, $points, $user_id, $challenge);
    }

    public function multiplyPoints(Student $student, $points, Challenge $challenge)
    {
        $currentStudentPoint = $student->availablePoints ?? 1;
        if (!$currentStudentPoint)
            $currentStudentPoint = 0;
        $newPoints = $currentStudentPoint * $points;
        $studentPoint = new StudentPoint();
        $studentPoint->student_id = $student->id;
        $studentPoint->previous_points = $currentStudentPoint;
        $studentPoint->total_points = $newPoints;
        $studentPoint->added_points = $points;
        $studentPoint->challenge_name = $challenge->name;
        $studentPoint->challenge_id = $challenge->id;
        $this->studentPointRepo->saveStudentPoint($studentPoint);
        return $studentPoint;
    }

    public function updateStudentPointsWithNewFactor($factor)
    {
        $sql = "SELECT student_points.id,student_id,total_points, user_id,phases.name AS phase_name, tenants.config, students.tenant_id, ssp.created_at
                FROM student_points
                INNER join (select id, created_at
                     from student_points sp
                     where id = (
                         select id
                         from student_points
                         where  sp.student_id = student_points.student_id
                         ORDER BY total_points desc, created_at desc
                         LIMIT 1
                     )
                    ) AS ssp on ssp.id = student_points.id
                INNER JOIN students ON student_points.student_id = students.id
                INNER JOIN statuses ON students.status_id = statuses.id
                INNER JOIN phases ON statuses.phase_id = phases.id
                INNER JOIN tenants ON students.tenant_id = tenants.id";

        $result = DB::select($sql);

        $studentsPoints = [];
        $noteData = [];

        if (count($result) > 0) {
            foreach ($result as $item) {
                $content = json_decode($item->config, true);
                $content = Arr::get($content, 'site_settings');
                $points_to_dollar = Arr::get($content, 'points_to_dollars_factor');
                if ($points_to_dollar == "" or $points_to_dollar == 0) {
                    $points_to_dollar = 1;
                }
                $totalPoints = 0;


                if ($item->phase_name == PhaseKeyRepositoryInterface::PHASE_NAME_ENROLLED || $item->phase_name == PhaseKeyRepositoryInterface::PHASE_NAME_ENROLLED_ORIENTATION) {
                    $totalPoints = (int)(($item->total_points / $points_to_dollar) * $factor);;
                } else {
                    $dollAmount = round($item->total_points / $points_to_dollar, 2);
                    $noteData[] = [
                        'student_id' => $item->student_id,
                        'tenant_id' => $item->tenant_id,
                        'audience' => 'Internal',
                        'type' => 'Intervention',
                        'body' => "Factor : $points_to_dollar, Number of Points : $item->total_points,Dollar Amount : $dollAmount",
                        'created_at' => '2021-01-01 00:00:00',
                        'updated_at' => '2021-01-01 00:00:00',
                    ];

                }
                $studentsPoints[] = [
                    'student_id' => $item->student_id,
                    'total_points' => $totalPoints,
                    'previous_points' => $item->total_points,
                    'added_points' => $totalPoints == 0 ? 0 : $totalPoints - $item->total_points,
                    'challenge_name' => 'Legacy Points',
                    'created_at' => '2021-01-01 00:00:00',
                    'updated_at' => '2021-01-01 00:00:00',
                ];
            }
            DB::transaction(function () use ($studentsPoints, $noteData) {
                StudentPoint::insert($studentsPoints);
                Note::insert($noteData);
            });
        }

    }
}
