<?php

namespace App\Domain\ReferralOption;

use App\Domain\ReferralOption\Repository\ReferralOptionRepositoryInterface;

class ReferralOptionLibrary
{
    protected $referralOptionRepository;

    public function __construct(ReferralOptionRepositoryInterface $referralOptionRepository)
    {
        return $this->referralOptionRepository = $referralOptionRepository;
    }

    public function createReferralOption($input)
    {
        return $this->referralOptionRepository->createReferralOption($input);
    }

    public function getReferralOption($ReferralOptionId)
    {
        return $this->referralOptionRepository->getReferralOption($ReferralOptionId);
    }

    public function getReferralOptions()
    {
        return $this->referralOptionRepository->getReferralOptions();
    }

    public function updateReferralOption($record, $data)
    {
        return $this->referralOptionRepository->updateReferralOption($record, $data);
    }

    public function deleteReferralOption($record)
    {
        return $record->delete();
    }
}

