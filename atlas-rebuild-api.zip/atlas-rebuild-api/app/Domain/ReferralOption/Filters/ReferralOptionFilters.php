<?php


namespace App\Domain\ReferralOption\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class ReferralOptionFilters extends BaseFilters
{
    public function active(Builder $builder, $active)
    {
        return $builder->where('active', $active);
    }
}
