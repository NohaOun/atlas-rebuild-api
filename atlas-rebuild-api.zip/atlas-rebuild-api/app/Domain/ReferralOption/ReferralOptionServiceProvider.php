<?php

namespace App\Domain\ReferralOption;

use App\Domain\ReferralOption\Model\ReferralOption;
use App\Domain\ReferralOption\Repository\ReferralOptionRepository;
use App\Domain\ReferralOption\Repository\ReferralOptionRepositoryInterface;
use App\Observers\ReferralOptionObserver;
use Illuminate\Support\ServiceProvider;

class ReferralOptionServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(ReferralOptionRepositoryInterface::class, ReferralOptionRepository::class);
    }

    public function boot()
    {
        ReferralOption::observe(ReferralOptionObserver::class);
    }
}
