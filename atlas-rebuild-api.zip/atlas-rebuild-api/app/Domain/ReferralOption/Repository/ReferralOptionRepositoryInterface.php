<?php

namespace App\Domain\ReferralOption\Repository;

use App\Domain\ReferralOption\Model\ReferralOption;

interface ReferralOptionRepositoryInterface
{
    public function getReferralOption($ReferralOptionId): ?ReferralOption;

    public function getReferralOptions();

    public function updateReferralOption($ReferralOptionId, $data): ReferralOption;
}

