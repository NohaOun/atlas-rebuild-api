<?php

namespace App\Domain\ReferralOption\Repository;

use App\Domain\ReferralOption\Model\ReferralOption;


class ReferralOptionRepository implements ReferralOptionRepositoryInterface
{

    public function createReferralOption($input)
    {
        return ReferralOption::query()->create($input);
    }

    public function getReferralOption($referralOptionId): ?ReferralOption
    {
        return ReferralOption::query()->find($referralOptionId);
    }

    public function getReferralOptions()
    {
        return ReferralOption::all();
    }

    public function updateReferralOption($record, $data): ReferralOption
    {
        $record->update($data);
        $record->save();

        return $record;
    }
}
