<?php

namespace App\Domain\ReferralOption\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class ReferralOption extends Model
{
    use BelongsToTenant;

    protected $fillable = ['group', 'name', 'active'];
}
