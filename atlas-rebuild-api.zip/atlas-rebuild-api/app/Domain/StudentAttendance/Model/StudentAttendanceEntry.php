<?php

namespace App\Domain\StudentAttendance\Model;

use App\Domain\Student\Model\Student;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentAttendanceEntry extends Model
{
    use BelongsToTenant;

    const TYPE_FORGET_SCAN = 'GC Forgot to Scan';
    const TYPE_SYSTEM_ISSUE = 'Atlas System Issue';
    const TYPE_OTHER = 'Other';

    protected $table = 'student_attendance_entries';
    protected $fillable = [
        'student_id', 'check_in', 'check_out', 'note', 'check_in_goals', 'check_out_goals',
        'exception', 'exception_reason', 'absence', 'next_attendance_date'
    ];
    protected $dates = ['check_in', 'check_out', 'next_attendance_date'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public static function getAvailableExceptions()
    {
        return [self::TYPE_FORGET_SCAN, self::TYPE_SYSTEM_ISSUE, self::TYPE_OTHER];
    }
}
