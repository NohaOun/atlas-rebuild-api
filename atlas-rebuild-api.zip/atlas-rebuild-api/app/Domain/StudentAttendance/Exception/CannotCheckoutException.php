<?php

namespace App\Domain\StudentAttendance\Exception;

class CannotCheckoutException extends \Exception
{

}
