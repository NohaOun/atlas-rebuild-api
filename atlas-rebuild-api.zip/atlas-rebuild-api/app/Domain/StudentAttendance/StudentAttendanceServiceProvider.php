<?php

namespace App\Domain\StudentAttendance;

use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;
use App\Domain\StudentAttendance\Repository\StudentAttendanceEntryRepository;
use App\Domain\StudentAttendance\Repository\StudentAttendanceEntryRepositoryInterface;
use App\Observers\StudentAttendanceEntryObserver;
use Illuminate\Support\ServiceProvider;

class StudentAttendanceServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(StudentAttendanceEntryRepositoryInterface::class, StudentAttendanceEntryRepository::class);
    }

    public function boot()
    {
        StudentAttendanceEntry::observe(StudentAttendanceEntryObserver::class);
    }
}
