<?php

namespace App\Domain\StudentAttendance;

use App\Domain\Status\Filters\StatusFilters;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentAttendance\Exception\CannotCheckoutException;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;
use App\Domain\StudentAttendance\Repository\StudentAttendanceEntryRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Arr;

class StudentAttendanceLibrary
{
    const CHECKOUT_THRESHOLD = 15;

    protected $studentAttendanceEntryRepository;
    protected $statusRepo;
    protected $studentRepo;

    public function __construct(StudentAttendanceEntryRepositoryInterface $studentAttendanceEntryRepository,
                                StatusRepositoryInterface $statusRepo,
                                StudentRepositoryInterface $studentRepo)
    {
        $this->studentAttendanceEntryRepository = $studentAttendanceEntryRepository;
        $this->statusRepo = $statusRepo;
        $this->studentRepo = $studentRepo;

    }

    public function addStudentAttendanceEntry($input)
    {
        $input['student_id'] = $input['relationships']['student_id'];

        $checkIn = Arr::get($input, 'attributes.check_in');
        $checkOut = Arr::get($input, 'attributes.check_out');

        if (!is_null($checkIn)) {
            $attendanceEntry = $this->createNewStudentAttendanceEntry($input['student_id'], $checkIn, $checkOut);
        } else {
            $checkIn = now();
            $attendanceEntry = $this->studentAttendanceEntryRepository->getLatestAttendanceEntryForStudent($input['student_id']);

            if (!$attendanceEntry || $attendanceEntry->check_out) {
                $attendanceEntry = $this->createNewStudentAttendanceEntry($input['student_id'], $checkIn, $checkOut);
            } else {
                if (!$checkOut) {
                    $checkOut = now();
                    $diffInMinutes = Carbon::parse($attendanceEntry->check_in)->diffInMinutes($checkOut);
                    if ($diffInMinutes < self::CHECKOUT_THRESHOLD) {
                        throw new CannotCheckoutException('Too early checkout');
                    }
                }

                $attendanceEntry->fill(['check_out' => $checkOut]);
            }
        }

        $attendanceEntryExtraAttributes = $this->getStudentAttendanceEntryExtraAttributes($input);
        $attendanceEntry->fill($attendanceEntryExtraAttributes);

        $this->studentAttendanceEntryRepository->saveStudentAttendanceEntry($attendanceEntry);

        return $attendanceEntry;
    }

    protected function createNewStudentAttendanceEntry($studentId, $checkIn, $checkOut = null)
    {
        return new StudentAttendanceEntry(['student_id' => $studentId, 'check_in' => $checkIn, 'check_out' => $checkOut]);
    }

    protected function getStudentAttendanceEntryExtraAttributes($input)
    {
        $attributes = Arr::get($input, 'attributes', []);
        if (Arr::has($input['attributes'], 'next_attendance_date')) {
            $attributes['next_attendance_date'] = Carbon::createFromFormat(
                'm/d/Y H:i:s', $input['attributes']['next_attendance_date']
            )->format('Y-m-d');
        }

        return Arr::only($attributes, [
            'note', 'check_in_goals', 'check_out_goals',
            'exception', 'exception_reason', 'absence', 'next_attendance_date'
        ]);
    }

    public function getAttendanceMeta($records, $filters)
    {
        $activeStatus = $this->statusRepo->getStatusByFilters(new StatusFilters(['status_key' => 'Active']));
        return [
            'unique_gcs' => $this->studentAttendanceEntryRepository->getUniqueAttendanceEntryCount($filters),
            'total_attendance_swipe' => $this->studentAttendanceEntryRepository->getAttendanceEntryCount($filters),
            'unique_enrolled' => $activeStatus ? $this->studentRepo->getStudentCount(new StudentFilters(['status' => $activeStatus->id])) : 0,
            'expected_attended_gc' => $this->studentAttendanceEntryRepository->scheduledToday($filters),
            'committed_gcs' => $this->studentAttendanceEntryRepository->attendTodayPercent($filters),
            'week_online_attendance' => $this->studentAttendanceEntryRepository->getDailyWeekAttendance($filters),
            'week_attendance' => $this->studentAttendanceEntryRepository->getOnsiteWeekAttendance($filters)

        ];
    }


    public function getOverallAttendanceForAsPercentage($filters)
    {
        $weeklyAttendance = $this->studentAttendanceEntryRepository->getDailyWeekAttendance($filters);

        if (!$weeklyAttendance) return 0;

        $days_attended = 0;
        foreach($weeklyAttendance as $day){
            $days_attended += $day == 1 ? 1 : 0;
        }
        
        // if ($total == 0) return 0;

        return $days_attended / 7;
    }

    public function getOverallAttendanceFor($filters)
    {
        // How many Days need to attend to schudle 
        $weeklyAttendance = $this->studentAttendanceEntryRepository->getDailyWeekAttendance($filters);

        if (!$weeklyAttendance) return '0/0';

        $days_attended = 0;
        foreach($weeklyAttendance as $day){
            $days_attended += $day == 1 ? 1 : 0;
        }
        
        if ($days_attended == 0) return 0;

        return $days_attended ."/". 7;
    }

    public function getLatestByLimitStudentAttendance($studentId, $limit){
        return $this->studentAttendanceEntryRepository->getLatestAttendanceEntryForStudent($studentId, $limit);
    }
}
