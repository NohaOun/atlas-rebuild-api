<?php

namespace App\Domain\StudentAttendance\Repository;

use App\Domain\StudentAttendance\Filters\StudentAttendanceEntryFilters;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;

interface StudentAttendanceEntryRepositoryInterface
{
    public function getLatestAttendanceEntryForStudent($studentId);

    public function saveStudentAttendanceEntry(StudentAttendanceEntry $entry): bool;

    public function getAttendanceEntryCount(StudentAttendanceEntryFilters $filters);

    public function getUniqueAttendanceEntryCount(StudentAttendanceEntryFilters $filters);

    public function getDailyWeekAttendance($filters = null);
}
