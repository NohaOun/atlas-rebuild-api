<?php

namespace App\Domain\StudentAttendance\Repository;

use App\Domain\Common\Filters\HasFilteredBuilder;
use App\Domain\Edmentum\Model\EdmentumLearnerLogin;
use App\Domain\Edmentum\Model\EdmentumLearnerTask;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use App\Domain\StudentAttendance\Filters\StudentAttendanceEntryFilters;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class StudentAttendanceEntryRepository implements StudentAttendanceEntryRepositoryInterface
{
    use HasFilteredBuilder;

    public function getLatestAttendanceEntryForStudent($studentId, $limit = null)
    {
        $filters = new StudentAttendanceEntryFilters([
            'student' => $studentId
        ]);

        if ($limit) {
            return $this->getFilteredBuilder(
                StudentAttendanceEntry::query(), $filters
            )->latest()->limit($limit)->get();
        }

        return $this->getFilteredBuilder(StudentAttendanceEntry::query(), $filters)->latest()->first();
    }

    public function saveStudentAttendanceEntry(StudentAttendanceEntry $entry): bool
    {
        return $entry->save();
    }

    public function getAttendanceEntryCount(StudentAttendanceEntryFilters $filters)
    {
        return $this->getStudentAttendanceBuilder($filters)->count();
    }

    public function getUniqueAttendanceEntryCount(StudentAttendanceEntryFilters $filters)
    {
        return $this->getStudentAttendanceBuilder($filters)->distinct('student_id')->count();
    }

    private function getStudentAttendanceBuilder($filters)
    {
        $builder = StudentAttendanceEntry::query();
        return $filters->apply($builder);
    }

    function getAttendanceStudentsForDay($start, $end)
    {
        $result = StudentAttendanceEntry::whereBetween('check_in', [
            $start->format('Y-m-d H:i:s'),
            $end->format('Y-m-d H:i:s')
        ])->orWhereBetween('check_in', [
                $start->format('Y-m-d H:i:s'),
                $end->format('Y-m-d H:i:s')]
        )->selectRaw('GROUP_CONCAT(student_id) as students_ids')
            ->first();
        $result = $result ? $result->students_ids : null;
        return $result;
    }

    public function getDailyWeekAttendance($filters = null)
    {
        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay();
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay();
        $builder = EdmentumLearnerLogin::whereBetween('login_date', [
            $startDate->format('Y-m-d'),
            $endDate->format('Y-m-d')
        ]);
        if (app()->has("showing-districts-ids-in-dashboard"))
            $builder->whereHas('learner', function (Builder $builder) {
                $builder->whereHas('student', function (Builder $builder) {
                    $builder->whereHas('site', function (Builder $builder) {
                        return $builder->whereIn('sites.district_id', app('showing-districts-ids-in-dashboard'));
                    });
                });
            });


        $district = $filters->get('district');
        if (isset($district) && !is_null($district)) {
            $builder->whereHas('learner', function (Builder $builder) use ($district) {
                $builder->whereHas('student', function (Builder $builder) use ($district) {
                    $builder->whereHas('site', function (Builder $builder) use ($district) {
                        return $builder->where('sites.district_id', $district);
                    });
                });
            });
        }

        if ($studentId = $filters->get('studentId')) {
            $builder->where("edmentum_learner_logins.edmentum_learner_id", $studentId);
        }
        $records = $builder->get(['edmentum_learner_id', 'login_date']);
        $countsPerDay = [
            'Sunday' => [],
            'Monday' => [],
            'Tuesday' => [],
            'Wednesday' => [],
            'Thursday' => [],
            'Friday' => [],
            'Saturday' => [],
        ];
        foreach ($records as $record) {

            $weekday = Carbon::createFromFormat('Y-m-d', $record->login_date)->format('l');
            if (!array_key_exists($weekday, $countsPerDay)) {
                $countsPerDay[$weekday] = [];
            }
            $countsPerDay[$weekday] [] = $record->edmentum_learner_id;
        }
        foreach ($countsPerDay as $day => $values) {
            $countsPerDay[$day] = count(array_unique($values));
        }

        return $countsPerDay;
    }

    public function getWeekAttendance($filters)
    {
        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay();
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay();
        $builder = EdmentumLearnerTask::whereBetween('started_at', [
            $startDate->format('Y-m-d H:i:s'),
            $endDate->format('Y-m-d H:i:s')
        ]);

        if ($studentId = $filters->get('studentId')) {
            $builder->where("edmentum_learner_tasks.edmentum_learner_tasks", $studentId);
        }
        $records = $builder->get(['edmentum_learner_id', 'started_at']);

    }

    public function getOnsiteWeekAttendance($filters = null)
    {

        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay();
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay();
        $builder = StudentAttendanceEntry::whereBetween('check_in', [
            $startDate->format('Y-m-d H:i:s'),
            $endDate->format('Y-m-d H:i:s')

        ]);

        if (isset($filters)) {
            $filters->apply($builder);
        }

        $records = $builder->get((['student_id', 'check_in']));
        $countsPerDay = [
            'Sunday' => [],
            'Monday' => [],
            'Tuesday' => [],
            'Wednesday' => [],
            'Thursday' => [],
            'Friday' => [],
            'Saturday' => [],
        ];
        foreach ($records as $record) {

            $weekday = Carbon::createFromFormat('Y-m-d H:i:s', $record['check_in'])->format('l');
            if (!array_key_exists($weekday, $countsPerDay)) {
                $countsPerDay[$weekday] = [];
            }
            $countsPerDay[$weekday] [] = $record['student_id'];
        }
        foreach ($countsPerDay as $day => $values) {
            $countsPerDay[$day] = count(array_unique($values));
        }

        return $countsPerDay;

    }

    public function scheduledToday($district = null)
    {

        $date = Carbon::today();

        $records = StudentScheduleEntry::where('date', $date->format('Y-m-d'))
            ->where('appointment_type', StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE)->distinct('student_id')->count();
        return $records;
    }

    public function attendTodayPercent($filters)
    {

        $startDate = Carbon::today()->startOfDay();
        $endDate = Carbon::today()->endOfDay();
        $builder = StudentAttendanceEntry::whereBetween('check_in', [
            $startDate->format('Y-m-d H:i:s'),
            $endDate->format('Y-m-d H:i:s')
        ]);

        $result = $filters->apply($builder);
        $attendTodayNum = $result->distinct('student_id')->count();
        $scheduledToday = $this->scheduledToday($filters);
        $scheduledToday = ($scheduledToday != 0) ? $scheduledToday : 1;
        $attendTodayPercent = $attendTodayNum / $scheduledToday * 100;
        return $attendTodayPercent . '%';
    }


}
