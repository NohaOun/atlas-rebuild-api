<?php

namespace App\Domain\StudentAttendance\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class StudentAttendanceEntryFilters extends BaseFilters
{
    public function student(Builder $builder, $id)
    {
        return $builder->where('student_id', $id);
    }

    public function checkInOnly(Builder $builder)
    {
        return $builder->where('check_out', null);
    }

    public function from(Builder $builder, $date)
    {
        return $builder->whereDate(
            'check_in', '>=', Carbon::createFromFormat('m/d/Y', $date)->format('Y-m-d')
        );
    }

    public function to(Builder $builder, $date)
    {
        return $builder->whereDate(
            'check_in', '<=', Carbon::createFromFormat('m/d/Y', $date)->format('Y-m-d')
        );
    }

    public function perPage(Builder $builder, $perPage)
    {
        return $builder->limit($perPage);
    }

    public function district(Builder $builder, $district)
    {
        $builder->whereHas('student', function (Builder $builder) use ($district) {
            $builder->whereHas('site', function (Builder $builder) use ($district) {
                return $builder->where('sites.district_id', $district);
            });
        });
    }

    public function site(Builder $builder, $site)
    {
        $builder->whereHas('student', function (Builder $builder) use ($site) {
            return $builder->where('students.site_id', $site);
        });
    }

    public function specificDistrict(Builder $builder)
    {
        $builder->whereHas('student', function (Builder $builder)  {
            $builder->whereHas('site', function (Builder $builder) {
                return $builder->whereIn('sites.district_id', app('showing-districts-ids-in-dashboard'));
            });
        });
    }
}
