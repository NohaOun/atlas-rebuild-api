<?php

namespace App\Domain\Phase;

use App\Domain\Phase\Model\Phase;
use App\Domain\Phase\Repository\PhaseKeyRepository;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepository;
use App\Domain\Phase\Repository\PhaseRepositoryInterface;
use App\Observers\PhaseObserver;
use Illuminate\Support\ServiceProvider;

class PhaseServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(PhaseRepositoryInterface::class, PhaseRepository::class);
        $this->app->bind(PhaseKeyRepositoryInterface::class, PhaseKeyRepository::class);
    }
    public function boot(){
        Phase::observe(PhaseObserver::class);
    }
}
