<?php


namespace App\Domain\Phase\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class PhaseFilters extends BaseFilters
{
    public function phaseKey(Builder $builder, $key)
    {
        if(is_array($key)){
            return $builder->whereIn('phase_key', $key);
        }else{
            return $builder->where('phase_key', $key);    
        }
        
    }

    public function name(Builder $builder, $name)
    {
        return $builder->whereIn('name', $name);
    }

    public function PhaseType(Builder $builder, $type)
    {
        return $builder->where('phase_type', $type);
    }
}
