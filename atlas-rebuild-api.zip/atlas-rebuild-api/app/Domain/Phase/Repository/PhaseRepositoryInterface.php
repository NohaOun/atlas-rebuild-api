<?php

namespace App\Domain\Phase\Repository;

use App\Domain\Phase\Filters\PhaseFilters;
use App\Domain\Phase\Model\Phase;

interface PhaseRepositoryInterface
{
    public function getPhases(PhaseFilters $filters, $withStatuses = false);

    public function getPhase($phaseId): ?Phase;

    public function getPhaseForClever(array $filter);

    public function savePhase(Phase $phase);

    public function deletePhase(Phase $phase);
}
