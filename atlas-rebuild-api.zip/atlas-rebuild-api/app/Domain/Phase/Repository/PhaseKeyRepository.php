<?php


namespace App\Domain\Phase\Repository;

class PhaseKeyRepository implements PhaseKeyRepositoryInterface
{
    public function getPhaseKeys()
    {
        $phaseKeys = [];
        $reflection = new \ReflectionClass($this);
        foreach ($reflection->getConstants() as $key => $value) {
            $phaseKeys[] = $value;
        }
        return $phaseKeys;
    }
}
