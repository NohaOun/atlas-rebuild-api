<?php

namespace App\Domain\Phase\Repository;

use App\Domain\Phase\Filters\PhaseFilters;
use App\Domain\Phase\Model\Phase;

class PhaseRepository implements PhaseRepositoryInterface
{
    public function getPhases(PhaseFilters $filters, $withStatuses = false)
    {
        $builder = Phase::query();
        if ($filters) $filters->apply($builder);

        if ($withStatuses) {
            $builder->with('statuses');
        }

        return $builder->get();
    }

    public function getPhase($phaseId): ?Phase
    {
        return Phase::query()->find($phaseId);
    }

    public function getPhaseForClever(array $filter)
    {
        return Phase::query()->where($filter)->get();
    }

    public function savePhase(Phase $phase)
    {
        return $phase->save();
    }

    public function deletePhase(Phase $phase)
    {
        return $phase->delete();
    }
}
