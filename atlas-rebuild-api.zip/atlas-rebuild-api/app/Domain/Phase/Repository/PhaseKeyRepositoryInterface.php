<?php


namespace App\Domain\Phase\Repository;


interface PhaseKeyRepositoryInterface
{
    const PHASE_NAME_ENROLLED = 'Enrolled'; // student phase
    const PHASE_NAME_ENROLLED_ORIENTATION = 'Enrolled orientation'; // student phase
    const PHASE_NAME_RECRUITMENT = 'Recruitment'; // contact phase
    const PHASE_NAME_REGISTRATION = 'Registration'; // contact phase
    const PHASE_NAME_CLOSE_LOST = 'Closed-Lost'; //contact phase'Closed-Lost'
    const PHASE_NAME_WITHDRAWN = 'Withdrawn';
    const PHASE_NAME_GRADUATE = 'Graduate';
    const PHASE_NAME_RE_ENGAGEMENT = 'Re-Engagement';
    const PHASE_NAME_DUPLICATE = 'Duplicate';

    public function getPhaseKeys();

}
