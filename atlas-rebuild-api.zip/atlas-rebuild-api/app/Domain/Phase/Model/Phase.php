<?php

namespace App\Domain\Phase\Model;

use App\Domain\Status\Model\Status;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Phase extends Model
{
    use BelongsToTenant;

    protected $table = 'phases';
    protected $fillable = ['name', 'phase_key', 'phase_type', 'is_in_student_clever', 'is_in_enrollment_clever',];

    public function statuses()
    {
        return $this->hasMany(Status::class);
    }
}
