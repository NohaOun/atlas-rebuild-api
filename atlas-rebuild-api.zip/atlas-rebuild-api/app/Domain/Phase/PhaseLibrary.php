<?php

namespace App\Domain\Phase;

use App\Domain\Phase\Model\Phase;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepositoryInterface;
use App\Domain\Status\StatusLibrary;

class PhaseLibrary
{
    protected $phaseRepo;

    protected $phaseKeyRepo;

    /**
     * @var StatusLibrary
     */
    private $statusLibrary;

    public function __construct(
        PhaseRepositoryInterface $phaseRepo,
        PhaseKeyRepositoryInterface $phaseKeyRepo,
        StatusLibrary $statusLibrary)
    {
        $this->phaseRepo = $phaseRepo;
        $this->phaseKeyRepo = $phaseKeyRepo;
        $this->statusLibrary = $statusLibrary;
    }

    public function getPhases($filters, $withStatuses = false, $districtId = null)
    {
        $phases = $this->phaseRepo->getPhases($filters, $withStatuses);

        if ($withStatuses) {
            $statuses = $phases->map(function ($phase) {
                return $phase->statuses;
            })->flatten()->keyBy('id');

            $statistics = $this->statusLibrary->getStatisticsForStatuses($statuses->pluck('id'), $districtId);

            foreach ($statuses->pluck('id') as $statusId) {
                $statuses->get($statusId)->setStatistics([
                    'student_count' => $statistics['student_count'][$statusId]->student_count ?? 0,
                    'contact_count' => $statistics['contact_count'][$statusId]->contact_count ?? 0,
                    'contact_count_stay_in_status_per_day' => $statistics['contact_status_exited'][$statusId] ?? []
                ]);
            }
        }

        return $phases;
    }

    public function getPhase($phaseId)
    {
        return $this->phaseRepo->getPhase($phaseId);
    }

    public function createPhase($input)
    {
        $phase = new Phase($input);

        $this->phaseRepo->savePhase($phase);

        return $phase;
    }

    public function updatePhase(Phase $phase, $data)
    {
        $phase->fill($data);

        $this->phaseRepo->savePhase($phase);

        return $phase;
    }

    public function deletePhase(Phase $phase)
    {
        return $this->phaseRepo->deletePhase($phase);
    }

    public function getPhaseKeys()
    {
        return $this->phaseKeyRepo->getPhaseKeys();
    }
}
