<?php

namespace App\Domain\Workflow\Repository;

use App\Domain\Workflow\Filters\WorkflowTriggerFilters;
use Illuminate\Database\Eloquent\Collection;

interface WorkflowTriggerRepositoryInterface
{
    public function getWorkflowTriggers(WorkflowTriggerFilters $filters): Collection;
}
