<?php

namespace App\Domain\Workflow\Repository;

use App\Domain\Workflow\Filters\WorkflowTriggerFilters;
use App\Domain\Workflow\Model\WorkflowTrigger;
use Illuminate\Database\Eloquent\Collection;

class WorkflowTriggerRepository implements WorkflowTriggerRepositoryInterface
{
    public function getWorkflowTriggers(WorkflowTriggerFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    protected function getFilteredBuilder(?WorkflowTriggerFilters $filters)
    {
        $builder = WorkflowTrigger::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
