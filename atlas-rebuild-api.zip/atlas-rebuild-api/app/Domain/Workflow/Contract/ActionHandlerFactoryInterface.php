<?php

namespace App\Domain\Workflow\Contract;

interface ActionHandlerFactoryInterface
{
    public function make($actionType): ActionHandlerInterface;
}
