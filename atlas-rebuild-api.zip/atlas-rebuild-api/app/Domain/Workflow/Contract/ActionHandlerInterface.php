<?php

namespace App\Domain\Workflow\Contract;

use App\Domain\Workflow\Model\WorkflowAction;
use App\Domain\Workflow\Model\WorkflowTrigger;

interface ActionHandlerInterface
{
    public function setTrigger(WorkflowTrigger $trigger): ActionHandlerInterface;

    public function handle(WorkflowAction $action);
}
