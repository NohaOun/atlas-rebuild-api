<?php

namespace App\Domain\Workflow;

use App\Domain\Workflow\Contract\ActionHandlerFactoryInterface;
use App\Domain\Workflow\Factory\ActionHandlerFactory;
use App\Domain\Workflow\Model\WorkflowAction;
use App\Domain\Workflow\Model\WorkflowTrigger;
use App\Domain\Workflow\Repository\WorkflowTriggerRepository;
use App\Domain\Workflow\Repository\WorkflowTriggerRepositoryInterface;
use App\Observers\WorkflowActionsObserver;
use App\Observers\WorkflowTriggersObserver;
use Illuminate\Support\ServiceProvider;

class WorkflowServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(WorkflowTriggerRepositoryInterface::class, WorkflowTriggerRepository::class);
        $this->app->bind(ActionHandlerFactoryInterface::class, ActionHandlerFactory::class);
    }

    public function boot()
    {
        WorkflowAction::observe(WorkflowActionsObserver::class);
        WorkflowTrigger::observe(WorkflowTriggersObserver::class);
    }
}
