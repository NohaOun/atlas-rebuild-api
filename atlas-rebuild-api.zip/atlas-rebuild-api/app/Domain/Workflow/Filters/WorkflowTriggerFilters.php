<?php

namespace App\Domain\Workflow\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class WorkflowTriggerFilters extends BaseFilters
{
    public function status(Builder $builder, $id)
    {
        return $builder->where('status_id', $id);
    }
}
