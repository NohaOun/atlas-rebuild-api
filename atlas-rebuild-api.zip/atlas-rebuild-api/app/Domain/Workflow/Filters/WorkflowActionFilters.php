<?php

namespace App\Domain\Workflow\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class WorkflowActionFilters extends BaseFilters
{
    public function actionType(Builder $builder, $type)
    {
        return $builder->where('type', $type);
    }
}
