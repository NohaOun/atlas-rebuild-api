<?php

namespace App\Domain\Workflow\Factory;

use App\Domain\Workflow\Contract\ActionHandlerFactoryInterface;
use App\Domain\Workflow\Contract\ActionHandlerInterface;
use App\Domain\Workflow\Handler\ChangeStatusActionHandler;
use App\Domain\Workflow\Model\WorkflowAction;
use Illuminate\Contracts\Foundation\Application;

class ActionHandlerFactory implements ActionHandlerFactoryInterface
{
    /**
     * @var Application
     */
    private $application;

    public function __construct(Application $application)
    {
        $this->application = $application;
    }

    public function make($actionType): ActionHandlerInterface
    {
        switch ($actionType) {
            case WorkflowAction::TYPE_CHANGE_STATUS:
                return $this->application->make(ChangeStatusActionHandler::class);
        }

        throw new \Exception('Invalid action type');
    }
}
