<?php

namespace App\Domain\Workflow\Handler;

use App\Domain\Edmentum\Repository\EdmentumRepository;
use App\Domain\Phase\Model\Phase;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\Workflow\Contract\ActionHandlerInterface;
use App\Domain\Workflow\Model\WorkflowAction;
use App\Domain\Workflow\Model\WorkflowTrigger;

class ChangeStatusActionHandler implements ActionHandlerInterface
{
    /**
     * @var StudentRepositoryInterface
     */
    private $studentRepo;

    /**
     * @var EdmentumRepository
     */
    private $edmentumRepository;

    /**
     * @var WorkflowTrigger
     */
    private $trigger;

    public function __construct(StudentRepositoryInterface $studentRepo, EdmentumRepository $edmentumRepository)
    {
        $this->studentRepo = $studentRepo;
        $this->edmentumRepository = $edmentumRepository;
    }

    public function setTrigger(WorkflowTrigger $trigger): ActionHandlerInterface
    {
        $this->trigger = $trigger;

        return $this;
    }

    public function handle(WorkflowAction $action)
    {
        $phase = Phase::query()->where('phase_key', PhaseKeyRepositoryInterface::PHASE_NAME_ENROLLED_ORIENTATION)->first();
        $students = $this->studentRepo->getActiveStudents();

        $phaseId = 0;
        if ($phase) $phaseId = $phase->id;

        foreach ($students as $student) {
            if ($student->workflow_exception) continue;

            $this->edmentumRepository->setStudent($student);
            if ($student->status->phase_id == $phaseId) {
                $daysLapsed = $this->edmentumRepository->studentDaysLapsedOnTask();
            } else {
                $daysLapsed = $this->edmentumRepository->studentDaysLapsed();
            }
            if (!$daysLapsed) continue;

            if ($this->withinRange($daysLapsed) && optional($student->status)->phase_id === $this->trigger->phase_id) {
                $this->updateStudent($action, $student);
            }
        }
    }

    protected function withinRange($daysLapsed)
    {
        return ($daysLapsed > $this->trigger->days_lapsed_from) && ($daysLapsed <= $this->trigger->days_lapsed_to);
    }

    protected function updateStudent(WorkflowAction $action, Student $student)
    {
        $student->fill(['status_id' => $action->status_id]);

        $this->studentRepo->saveStudent($student);
    }
}
