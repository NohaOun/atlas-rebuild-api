<?php

namespace App\Domain\Workflow\Model;

use App\Domain\District\Model\District;
use App\Domain\Site\Model\Site;
use App\Domain\Status\Model\Status;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class WorkflowTrigger extends Model
{
    use BelongsToTenant;

    protected $fillable = ['status_id', 'days_lapsed', 'system_hierarchy_level'];

    public function status()
    {
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function workflowActions()
    {
        return $this->hasMany(WorkflowAction::class);
    }

    public function sites()
    {
        return $this->belongsToMany(Site::class)->withTimestamps();
    }

    public function districts()
    {
        return $this->belongsToMany(District::class)->withTimestamps();
    }

    protected function setName()
    {
        $this->forceFill([
            'name' => sprintf('After spending %s days on %s', $this->days_lapsed, $this->status->fullName)
        ]);
    }

    public static function boot()
    {
        parent::boot();

        static::saving(function (WorkflowTrigger $trigger) {
            $trigger->setName();
        });
    }
}
