<?php

namespace App\Domain\Workflow\Model;

use App\Domain\Status\Model\Status;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class WorkflowAction extends Model
{
    use BelongsToTenant;

    const TYPE_CHANGE_STATUS = 'change-status';
    const TYPE_SEND_NOTIFICATION = 'send-notification';

    protected $fillable = ['type', 'payload', 'status_id', 'workflow_trigger_id'];

    protected $casts = [
        'payload' => 'json'
    ];

    protected $with = ['status'];

    public function workflowTrigger()
    {
        return $this->belongsTo(WorkflowTrigger::class);
    }

    public function status()
    {
        return $this->belongsTo(Status::class);
    }

    protected function setName()
    {
        if ($this->type === self::TYPE_CHANGE_STATUS) {
            $name = sprintf('Change status to: %s', $this->status->fullName);
        } else {
            $name = 'Send notification';
        }

        $this->forceFill(['name' => $name]);
    }

    public static function getAvailableTypes()
    {
        return [self::TYPE_CHANGE_STATUS, self::TYPE_SEND_NOTIFICATION];
    }

    public static function boot()
    {
        parent::boot();

        static::saving(function (WorkflowAction $action) {
            $action->setName();
        });
    }
}
