<?php

namespace App\Domain\Workflow;

use App\Domain\Workflow\Filters\WorkflowTriggerFilters;
use App\Domain\Workflow\Repository\WorkflowTriggerRepositoryInterface;

class WorkflowTriggerLibrary
{
    protected $workflowTriggerRepo;

    public function __construct(
        WorkflowTriggerRepositoryInterface $workflowTriggerRepo
    )
    {
        $this->workflowTriggerRepo = $workflowTriggerRepo;
    }

    public function getWorkflowTriggers(WorkflowTriggerFilters $filters = null)
    {
        $filters = $filters ?? new WorkflowTriggerFilters();

        return $this->workflowTriggerRepo->getWorkflowTriggers($filters);
    }
}
