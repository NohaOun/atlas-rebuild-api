<?php

namespace App\Domain\Tango;

use GuzzleHttp\RequestOptions;
use GuzzleHttp\Exception\ClientException;
class TangoLibrary
{
    /**
     * @var \GuzzleHttp\Client
     */
    protected $http;

    public function __construct()
    {
        $this->setDefaultHttpClient();
    }

    public function createOrder($student, $amount)
    {
        try{
            $response = $this->http->post('orders', [
                RequestOptions::JSON => [
                    'accountIdentifier' => $this->getConfig('account_identifier'),
                    'customerIdentifier' => $this->getConfig('customer_identifier'),
                    'sendEmail' => false,
                    'utid' => $this->getConfig('utid'),
                    'amount' => $amount,
                    'recipient' => [
                        'email' => str_replace('/','',$student->rewards_email),
                        'firstName' => str_replace('/','',$student->first_name),
                        'lastName' => str_replace('/','',$student->last_name),
                    ]
                ]
            ]);
            return json_decode($response->getBody()->getContents(), true);
        }catch (ClientException $e) {
            print_r($e);
             print_r($e->getRequest());
            echo $e->getResponse();
        }
        return json_decode($response->getBody()->getContents(), true);
    }

    public function getOrder($referenceId)
    {
        $response = $this->http->get("orders/{$referenceId}");

        return json_decode($response->getBody()->getContents(), true);
    }

    protected function getConfig($config)
    {
        return config("services.tango_card.{$config}");
    }

    protected function setDefaultHttpClient()
    {
        $token = base64_encode($this->getConfig('platform_name') . ':' . $this->getConfig('api_token'));
        $this->http = new \GuzzleHttp\Client([
            'base_uri' => $this->getConfig('api_url'),
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'Authorization' => 'Basic ' . $token
            ]
        ]);
    }
}