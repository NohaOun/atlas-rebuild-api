<?php

namespace App\Domain\ReferralCodePoint;

use App\Domain\ReferralCodePoint\Model\ReferralCodePoint;
use App\Domain\ReferralCodePoint\Model\StudentPoint;
use App\Domain\ReferralCodePoint\Repository\ReferralCodePointRepository;
use App\Domain\ReferralCodePoint\Repository\ReferralCodePointRepositoryInterface;
use App\Domain\Status\StatusLibrary;

class ReferralCodePointLibrary
{
    protected $redemptionRepo;

    public function __construct(
    ReferralCodePointRepository $redemptionRepo)
    {
        $this->redemptionRepo = $redemptionRepo;
    }

    public function getReferralCodePoint($redemptionId)
    {
        return $this->redemptionRepo->getReferralCodePoint($redemptionId);
    }

    public function createReferralCodePoint($input)
    {
        $redemption = new ReferralCodePoint($input);

        $this->redemptionRepo->saveReferralCodePoint($redemption);

        return $redemption;
    }

    public function updateReferralCodePoint(ReferralCodePoint $redemption, $data)
    {
        $redemption->fill($data);

        $this->redemptionRepo->saveReferralCodePoint($redemption);

        return $redemption;
    }

    public function deleteReferralCodePoint(ReferralCodePoint $redemption)
    {
        return $this->redemptionRepo->deleteReferralCodePoint($redemption);
    }
}
