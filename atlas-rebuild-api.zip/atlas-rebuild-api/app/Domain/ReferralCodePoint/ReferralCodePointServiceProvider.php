<?php

namespace App\Domain\ReferralCodePoint;


use App\Domain\ReferralCodePoint\Model\ReferralCodePoint;
use App\Domain\ReferralCodePoint\Repository\ReferralCodePointRepository;
use App\Domain\ReferralCodePoint\Repository\ReferralCodePointRepositoryInterface;
use App\Observers\ReferralCodePointObserver;
use Illuminate\Support\ServiceProvider;

class ReferralCodePointServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(ReferralCodePointRepositoryInterface::class, ReferralCodePointRepository::class);
    }

    public function boot()
    {
        ReferralCodePoint::observe(ReferralCodePointObserver::class);
    }
}
