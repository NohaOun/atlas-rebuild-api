<?php

namespace App\Domain\ReferralCodePoint\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class ReferralCodePoint extends Model
{
    use BelongsToTenant;


    protected $fillable = ['points'];

}
