<?php

namespace App\Domain\ReferralCodePoint\Repository;

use App\Domain\ReferralCodePoint\Filters\ReferralCodePointFilters;
use App\Domain\ReferralCodePoint\Model\ReferralCodePoint;

class ReferralCodePointRepository implements ReferralCodePointRepositoryInterface
{
    public function getReferralCodePoints(ReferralCodePointFilters $filters)
    {
        $builder = ReferralCodePoint::query();
        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getReferralCodePoint($referralCodePointId): ?ReferralCodePoint
    {
        return ReferralCodePoint::query()->find($referralCodePointId);
    }

    public function saveReferralCodePoint(ReferralCodePoint $referralCodePoint)
    {
        return $referralCodePoint->save();
    }

    public function deleteReferralCodePoint(ReferralCodePoint $referralCodePoint)
    {
        return $referralCodePoint->delete();
    }

}
