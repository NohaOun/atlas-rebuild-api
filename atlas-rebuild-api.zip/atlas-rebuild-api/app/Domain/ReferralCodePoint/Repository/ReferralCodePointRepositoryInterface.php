<?php

namespace App\Domain\ReferralCodePoint\Repository;

use App\Domain\ReferralCodePoint\Filters\ReferralCodePointFilters;
use App\Domain\ReferralCodePoint\Model\ReferralCodePoint;

interface ReferralCodePointRepositoryInterface
{
    public function getReferralCodePoints(ReferralCodePointFilters $filterse);

    public function getReferralCodePoint($referralCodePointId): ?ReferralCodePoint;


    public function saveReferralCodePoint(ReferralCodePoint $referralCodePoint);

    public function deleteReferralCodePoint(ReferralCodePoint $referralCodePoint);
}
