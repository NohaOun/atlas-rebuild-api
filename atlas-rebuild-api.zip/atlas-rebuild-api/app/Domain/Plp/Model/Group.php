<?php

namespace App\Domain\Plp\Model;

use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    protected $table = 'plp_course_groups';
    protected $fillable = ['name', 'min_credit', 'assessment'];

    public function courses()
    {
        return $this->hasMany(Course::class);
    }
}
