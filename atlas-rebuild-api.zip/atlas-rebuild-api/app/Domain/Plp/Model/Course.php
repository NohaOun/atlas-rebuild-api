<?php

namespace App\Domain\Plp\Model;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    protected $table = 'plp_courses';
    protected $fillable = ['name', 'min_score', 'tier_5', 'group_id', 'default'];
    protected $with = ['group'];

    public function group()
    {
        return $this->belongsTo(Group::class);
    }
}
