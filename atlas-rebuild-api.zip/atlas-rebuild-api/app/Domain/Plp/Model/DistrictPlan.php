<?php

namespace App\Domain\Plp\Model;

use App\Domain\District\Model\District;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class DistrictPlan extends Model
{
    use BelongsToTenant;

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DRAFT = 'draft';

    const TIER_SYSTEM_TIER_4 = 'Tier 4';
    const TIER_SYSTEM_TIER_5 = 'Tier 5';

    const CREDIT_SYSTEM_QUARTER_CREDITS = 'Quarter Credits';
    const CREDIT_SYSTEM_FRACTIONAL_CREDITS = 'Fractional Credits';

    protected $table = 'district_plp_plans';
    protected $fillable = [
        'district_id', 'name', 'credit', 'tier_system', 'credit_system',
        'status', 'content'
    ];
    protected $casts = ['content' => 'json'];

    public function district()
    {
        return $this->belongsTo(District::class);
    }

    public static function getAvailableTierSystems()
    {
        return [self::TIER_SYSTEM_TIER_4, self::TIER_SYSTEM_TIER_5];
    }

    public static function getAvailableCreditSystems()
    {
        return [self::CREDIT_SYSTEM_QUARTER_CREDITS, self::CREDIT_SYSTEM_FRACTIONAL_CREDITS];
    }

    public static function getAvailableStatuses()
    {
        return [self::STATUS_ACTIVE, self::STATUS_INACTIVE, self::STATUS_DRAFT];
    }
}
