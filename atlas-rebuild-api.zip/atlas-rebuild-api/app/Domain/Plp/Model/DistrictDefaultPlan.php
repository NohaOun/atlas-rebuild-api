<?php

namespace App\Domain\Plp\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class DistrictDefaultPlan extends Model
{
    use BelongsToTenant;

    protected $table = 'district_default_plp_plans';
    protected $fillable = ['district_id', 'content'];
    protected $casts = ['content' => 'json'];
}
