<?php

namespace App\Domain\Plp\Model;

use App\Domain\Student\Model\Student;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentPlan extends Model
{
    use BelongsToTenant;

    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const ASSESSMENT_STATUS_NOT_ATTEMPTED = 'Not Attempted';
    const ASSESSMENT_STATUS_PASSED = 'Passed';
    const ASSESSMENT_STATUS_FAILED = 'Failed';

    protected $table = 'student_plp_plans';
    protected $fillable = [
        'student_id', 'name', 'content', 'active', 'override_tier_level'
    ];
    protected $casts = ['content' => 'json'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public static function getAssessmentStatuses()
    {
        return [self::ASSESSMENT_STATUS_NOT_ATTEMPTED, self::ASSESSMENT_STATUS_PASSED, self::ASSESSMENT_STATUS_FAILED];
    }
}
