<?php

namespace App\Domain\Plp\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class TierDefinition extends Model
{
    protected $table = 'lookup_tier_definitions';
}
