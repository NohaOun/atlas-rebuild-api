<?php

namespace App\Domain\Plp\Model;

use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;

class StudentPlanChange extends Model
{
    protected $table = 'student_plp_plan_changes';
    protected $fillable = [
        'student_plp_plan_id', 'payload', 'creator_id'
    ];
    protected $casts = ['payload' => 'json'];

    public function studentPlan()
    {
        return $this->belongsTo(StudentPlan::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'creator_id');
    }
}
