<?php

namespace App\Domain\Plp;

use App\Domain\District\Model\District;
use App\Domain\Plp\Exception\InvalidDistrictPlanStatusException;
use App\Domain\Plp\Filters\DistrictPlanFilters;
use App\Domain\Plp\Filters\StudentPlanFilters;
use App\Domain\Plp\Model\DistrictDefaultPlan;
use App\Domain\Plp\Model\DistrictPlan;
use App\Domain\Plp\Model\StudentPlan;
use App\Domain\Plp\Repository\CourseRepositoryInterface;
use App\Domain\Plp\Repository\GroupRepositoryInterface;
use App\Domain\Plp\Repository\PlanRepositoryInterface;
use App\Domain\Plp\Repository\TierDefinitionRepositoryInterface;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class PlanLibrary
{
    private $planRepo;
    private $studentRepo;
    private $tierDefinitionRepo;
    private $courseRepo;
    private $groupRepo;

    public function __construct(
        PlanRepositoryInterface $planRepo,
        StudentRepositoryInterface $studentRepo,
        TierDefinitionRepositoryInterface $tierDefinitionRepo,
        CourseRepositoryInterface $courseRepo,
        GroupRepositoryInterface $groupRepo
    )
    {
        $this->planRepo = $planRepo;
        $this->studentRepo = $studentRepo;
        $this->tierDefinitionRepo = $tierDefinitionRepo;
        $this->courseRepo = $courseRepo;
        $this->groupRepo = $groupRepo;
    }

    public function getDistrictDefaultPlan($districtId)
    {
        return $this->planRepo->getDistrictDefaultPlan($districtId);
    }

    public function addInitialDistrictDefaultPlan(District $district)
    {
        $groups = $this->groupRepo->getGroups(null);

        $content = [];
        foreach ($groups as $group) {
            $groupPayload = [
                'group' => [
                    'name' => $group->name,
                    'assessment' => $group->assessment,
                    'min_credit' => $group->min_credit
                ],
                'courses' => []
            ];

            foreach ($group->courses as $course) {
                $groupPayload['courses'][] = ['name' => $course->name];
            }

            $content[] = $groupPayload;
        }

        $plan = new DistrictDefaultPlan(['district_id' => $district->id, 'content' => $content]);

        $this->planRepo->saveDistrictDefaultPlan($plan);

        return $plan;
    }

    public function saveDistrictDefaultPlan(District $district, $input)
    {
        $defaultPlan = $this->planRepo->getDistrictDefaultPlan($district->id);
        if (!$defaultPlan) {
            $defaultPlan = new DistrictDefaultPlan();
        }

        $input['district_id'] = $district->id;
        $defaultPlan->fill($input);

        $this->planRepo->saveDistrictDefaultPlan($defaultPlan);

        return $defaultPlan;
    }

    public function createDistrictPlan($attributes)
    {
        return $this->saveDistrictPlan(new DistrictPlan, $attributes);
    }

    public function updateDistrictPlan(DistrictPlan $plan, $attributes)
    {
        if ($plan->status == DistrictPlan::STATUS_ACTIVE) {
            throw new InvalidDistrictPlanStatusException('Active district plans can not be updated');
        }

        return $this->saveDistrictPlan($plan, $attributes);
    }

    protected function saveDistrictPlan($plan, $attributes)
    {
        $plan->fill($attributes);

        $this->planRepo->saveDistrictPlan($plan);

        return $plan;
    }

    public function changeDistrictPlanStatus(DistrictPlan $plan, $newStatus)
    {
        $plan->fill(['status' => $newStatus]);

        $this->planRepo->saveDistrictPlan($plan);

        return $plan;
    }

    public function getDistrictPlans(DistrictPlanFilters $filters = null)
    {
        return $this->planRepo->getDistrictPlans($filters);
    }

    public function getDistrictPlan($id)
    {
        return $this->planRepo->getDistrictPlan($id);
    }

    public function addStudentPlan($studentId, $districtPlanId, $tierLevel = null)
    {
        return DB::transaction(function () use ($studentId, $districtPlanId, $tierLevel) {
            $student = $this->studentRepo->getStudent($studentId);
            $districtPlan = $this->planRepo->getDistrictPlan($districtPlanId);

            $tierLevel = $tierLevel === null ? null : (int)filter_var($tierLevel, FILTER_SANITIZE_NUMBER_INT);

            $oldPlans = $this->planRepo->getStudentPlans(
                new StudentPlanFilters(['student' => $student->id])
            );

            foreach ($oldPlans as $oldPlan) {
                $this->planRepo->saveStudentPlan($oldPlan->fill(['active' => 0]));
            }

            $studentPlan = new StudentPlan([
                'name' => $districtPlan->name,
                'student_id' => $student->id,
                'content' => $this->createStudentPlanContent($districtPlan),
                'active' => 1,
                'override_tier_level' => $tierLevel,
            ]);

            $this->planRepo->saveStudentPlan($studentPlan);

            return $studentPlan;
        });

    }

    public function createStudentPlanContent($districtPlan)
    {
        $content = [
            'total_diploma_credit' => $districtPlan->credit,
            'tier_system' => $districtPlan->tier_system,
            'credit_system' => $districtPlan->credit_system,
            'gpa' => null,
            'post_grad_pathway' => null,
            'total_credit' => null,
            'target_graduation' => [
                'season' => null,
                'year' => null
            ],
            'groups' => []
        ];

        foreach ($districtPlan->content as $item) {
            $group = array_merge($item['group'], ['earned_credit' => 0]);

            $courses = [];
            foreach ($item['courses'] as $course) {
                $courses[] = array_merge(
                    $course, ['earned_credit' => 0, 'completed_with' => null, 'primary' => 1, 'score' => 0, 'date_taken' => null, 'status' => StudentPlan::ASSESSMENT_STATUS_NOT_ATTEMPTED]
                );
            }

            $content['groups'][] = compact('group', 'courses');
        }

        return $content;
    }

    public function addTierToPlpPlanContent($content, $plan)
    {
        $districtPlan = null;

        if ($plan) {
            $districtPlan = \Cache::remember($plan->name, 300,function() use($plan){
                return DistrictPlan::query()->where('name', $plan->name)->first();
            });
        }

        $content['diploma_credits_earned'] = 0;

        if (isset($content['groups'])) {
            foreach ($content['groups'] as $key => $item) {
                $groupEarnedCredit = 0;

                foreach ($item['courses'] as $course) {
                    $courseEarnedCredit = Arr::get($course, 'earned_credit', 0);
                    $groupEarnedCredit += (float)$courseEarnedCredit;
                }

                if ($item['group']['assessment'] === 1) {
                    $content['groups'][$key]['group']['min_credit'] = null;
                }

                $content['groups'][$key]['group']['earned_credit'] = $groupEarnedCredit;
                $content['diploma_credits_earned'] += $groupEarnedCredit;
            }
        }

        $content['total_diploma_credit'] = Arr::get($content, 'total_diploma_credit', 0);
        $content['diploma_credits_needed'] = max($content['total_diploma_credit'] - $content['diploma_credits_earned'], 0);
        $content['tier_level'] = isset($plan->override_tier_level) ? 'Tier ' . $plan->override_tier_level :
            $this->calcTierLevelForCredit($content['diploma_credits_needed'], $districtPlan);

        return $content;
    }

    protected function calcTierLevelForCredit($credit, $districtPlan)
    {
        if ($credit == 0 && isset($districtPlan['tier_system'])) {
            return $districtPlan['tier_system'];
        }

        $tiers = $this->tierDefinitionRepo->getTierDefinitions();
        foreach ($tiers as $tier) {
            if ($tier->from <= $credit && ($tier->to >= $credit || is_null($tier->to))) {
                return 'Tier ' . $tier->id;
            }
        }

        //throw new \Exception('Cannot calculate tier level');
    }

    public function activeStudentPlans(StudentPlan $plan)
    {
        $plan->update(['active' => 1]);

        StudentPlan::query()->where('id', '!=', $plan->id)
            ->where('student_id', $plan->student_id)->update(['active' => 0]);

        return $plan;
    }

    public function setTierStudentPlans(StudentPlan $plan, $tier)
    {
        $tier = $tier === null ? null : (int)filter_var($tier, FILTER_SANITIZE_NUMBER_INT);
        $plan->update(['override_tier_level' => $tier]);
        return $plan;
    }

    public function getActiveStudentPlan($studentId)
    {
        $oldPlans = $this->planRepo->getStudentPlans(
            new StudentPlanFilters(['student' => $studentId])
        )->toArray();
        return !empty($oldPlans) ? $oldPlans[0] : null;
    }

    public function getStudentPlans($studentId)
    {
        $oldPlans = $this->planRepo->getStudentPlans(
            new StudentPlanFilters(['student' => $studentId])
        );
        return $oldPlans;
    }

}

