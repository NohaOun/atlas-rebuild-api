<?php

namespace App\Domain\Plp;

use App\Domain\Plp\Filters\CourseFilters;
use App\Domain\Plp\Filters\GroupFilters;
use App\Domain\Plp\Model\Course;
use App\Domain\Plp\Repository\CourseRepositoryInterface;
use App\Domain\Plp\Repository\GroupRepositoryInterface;

class CourseLibrary
{
    private $courseRepo;
    private $groupRepo;

    public function __construct(CourseRepositoryInterface $courseRepo, GroupRepositoryInterface $groupRepo)
    {
        $this->courseRepo = $courseRepo;
        $this->groupRepo = $groupRepo;
    }

    public function getCourses(CourseFilters $filters = null)
    {
        return $this->courseRepo->getCourses($filters);
    }

    public function getCourse($courseId)
    {
        return $this->courseRepo->getCourse($courseId);
    }

    public function createCourse($input)
    {
        $course = new Course($input);

        $this->courseRepo->saveCourse($course);

        return $course;
    }

    public function updateCourse(Course $course, $input)
    {
        $course->fill($input);

        $this->courseRepo->saveCourse($course);

        return $course;
    }

    public function deleteCourse(Course $course)
    {
        return $this->courseRepo->deleteCourse($course);
    }

    public function getGroups(GroupFilters $filters = null)
    {
        return $this->groupRepo->getGroups($filters);
    }

    public function getGroup($groupId)
    {
        return $this->groupRepo->getGroup($groupId);
    }
}

