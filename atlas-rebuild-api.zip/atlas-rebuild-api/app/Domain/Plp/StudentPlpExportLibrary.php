<?php

namespace App\Domain\Plp;

use App\Domain\Common\Model\File;
use App\Domain\Plp\Export\StudentPlpExport;
use App\Domain\Student\StudentLibrary;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;

class StudentPlpExportLibrary
{
    protected $studentLibrary;

    protected $planLibrary;

    public function __construct(
        StudentLibrary $studentLibrary,
        PlanLibrary $planLibrary
    )
    {
        $this->studentLibrary = $studentLibrary;
        $this->planLibrary = $planLibrary;
    }

    public function export($student)
    {
        $student = $this->studentLibrary->getStudent($student)->load('paraProfessionals', 'studentPlan');
        $plpPlan = $this->planLibrary->addTierToPlpPlanContent($student->studentPlan->content, $student->studentPlan);
        $fileName = str_replace(' ', '', $student->full_name . '.csv');
        Excel::store(new StudentPlpExport($student, $plpPlan), $fileName, 'public');

        return new File(url(Storage::url($fileName)));
    }
}
