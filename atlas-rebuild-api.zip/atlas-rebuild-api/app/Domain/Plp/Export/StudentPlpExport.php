<?php

namespace App\Domain\Plp\Export;

use App\Domain\Student\Model\Student;
use Illuminate\Support\Arr;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithHeadings;

class StudentPlpExport implements FromArray, WithHeadings
{
    protected $student;

    protected $plpPlan;

    public function __construct(Student $student, $plpPlan)
    {
        $this->student = $student;
        $this->plpPlan = $plpPlan;
    }

    public function array(): array
    {
        $gca = '';

        $specialPrograms = '';

        $studentPlan = $this->student->studentPlan;

        $groups = [];

        foreach ($this->student->paraProfessionals as $paraProfessional) $gca .= $paraProfessional->full_name . ', ';

        foreach ($this->student->specialPrograms as $specialProgram) $specialPrograms .= $specialProgram->name . ', ';

        $groupIndex = 0;

        foreach ($studentPlan->content['groups'] as $group) {
            $groups[$groupIndex][] = [];
            $totalEarned = 0;
            foreach ($group['courses'] as $course) {
                $groups[$groupIndex][] = [Arr::get($course, 'name'), Arr::get($course, 'earned_credit'), Arr::get($course, 'completed_with')];
                $totalEarned += (float) Arr::get($course, 'earned_credit');
            }
            $groups[$groupIndex][0] = [Arr::get($group, 'group.name'), $totalEarned . ' out of ' . Arr::get($group, 'group.min_credit')];
            ++$groupIndex;
        }

        $data = [
            ['Name', $this->student->full_name, ''],
            ['Acceleration ID', $this->student->id, ''],
            ['District ID', $this->student->district_it, ''],
            ['Location', $this->student->county . ($this->student->state ? ' / ' . $this->student->state : ''), ''],
            ['GCA', $gca, ''],
            ['Diploma Name', $studentPlan ? $studentPlan->name : '', ''],
            ['Diploma Credits', $this->plpPlan['total_diploma_credit'], ''],
            ['Diploma Credits Earned', $this->plpPlan['diploma_credits_earned'], ''],
            ['Diploma Credits Needed', $this->plpPlan['diploma_credits_needed'], ''],
            ['Tier', $this->plpPlan['tier_level']],
            ['Target Graduation Date', $studentPlan && isset($studentPlan->content)
                && array_key_exists('target_graduation', $studentPlan->content)
                ? $studentPlan->content['target_graduation']['season'] . ' ' . $studentPlan->content['target_graduation']['year']
                : '', ''],
            ['GPA', $studentPlan && array_key_exists('gpa', $studentPlan->content) ? $studentPlan->content['gpa'] : '', ''],
            ['Special Programs', $specialPrograms, ''],
            ['Post Grad Pathways', $studentPlan && array_key_exists('post_grad_pathway', $studentPlan->content) ? $studentPlan->content['post_grad_pathway'] : '', ''],
        ];

        $data = array_merge($data, $groups);

        return $data;
    }

    public function headings(): array
    {
        return [
        ];
    }
}
