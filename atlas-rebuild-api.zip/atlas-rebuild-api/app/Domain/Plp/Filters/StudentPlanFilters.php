<?php

namespace App\Domain\Plp\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class StudentPlanFilters extends BaseFilters
{
    public function student(Builder $builder, $id)
    {
        return $builder->where('student_id', $id);
    }

    public function active(Builder $builder, $boolean)
    {
        return $builder->where('active', $boolean);
    }
}
