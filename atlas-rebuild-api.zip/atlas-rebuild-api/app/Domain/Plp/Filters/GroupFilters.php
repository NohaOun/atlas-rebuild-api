<?php

namespace App\Domain\Plp\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class GroupFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }
}
