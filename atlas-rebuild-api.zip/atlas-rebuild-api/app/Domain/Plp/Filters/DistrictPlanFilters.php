<?php

namespace App\Domain\Plp\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class DistrictPlanFilters extends BaseFilters
{
    public function district(Builder $builder, $id)
    {
        return $builder->where('district_id', $id);
    }
}
