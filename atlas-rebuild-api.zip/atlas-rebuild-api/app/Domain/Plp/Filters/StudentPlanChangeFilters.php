<?php

namespace App\Domain\Plp\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class StudentPlanChangeFilters extends BaseFilters
{
    public function studentPlpPlan(Builder $builder, $id)
    {
        return $builder->where('student_plp_plan_id', $id);
    }
}
