<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Plp\Filters\DistrictPlanFilters;
use App\Domain\Plp\Filters\StudentPlanFilters;
use App\Domain\Plp\Model\DistrictDefaultPlan;
use App\Domain\Plp\Model\DistrictPlan;
use App\Domain\Plp\Model\StudentPlan;
use Illuminate\Database\Eloquent\Collection;

interface PlanRepositoryInterface
{
    public function getDistrictDefaultPlan($districtId);

    public function saveDistrictDefaultPlan(DistrictDefaultPlan $record);

    public function getDistrictPlans(?DistrictPlanFilters $filters): Collection;

    public function getDistrictPlan($planId);

    public function saveDistrictPlan(DistrictPlan $districtPlan);

    public function getStudentPlans(?StudentPlanFilters $filters);

    public function saveStudentPlan(StudentPlan $studentPlan);
}
