<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Common\Filters\HasFilteredBuilder;
use App\Domain\Plp\Filters\CourseFilters;
use App\Domain\Plp\Model\Course;
use Illuminate\Database\Eloquent\Collection;

class CourseRepository implements CourseRepositoryInterface
{
    use HasFilteredBuilder;

    public function getCourses(?CourseFilters $filters): Collection
    {
        return $this->getFilteredBuilder(Course::query(), $filters)->get();
    }

    public function getCourse($recordId)
    {
        return Course::query()->find($recordId);
    }

    public function saveCourse(Course $record)
    {
        return $record->save();
    }

    public function deleteCourse(Course $record)
    {
        return $record->delete();
    }
}
