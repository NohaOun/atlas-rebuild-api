<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Common\Filters\HasFilteredBuilder;
use App\Domain\Plp\Filters\DistrictPlanFilters;
use App\Domain\Plp\Filters\StudentPlanFilters;
use App\Domain\Plp\Model\DistrictDefaultPlan;
use App\Domain\Plp\Model\DistrictPlan;
use App\Domain\Plp\Model\StudentPlan;
use Illuminate\Database\Eloquent\Collection;

class PlanRepository implements PlanRepositoryInterface
{
    use HasFilteredBuilder;

    public function getDistrictDefaultPlan($districtId)
    {
        return DistrictDefaultPlan::query()->where('district_id', $districtId)->first();
    }

    public function saveDistrictDefaultPlan(DistrictDefaultPlan $record)
    {
        return $record->save();
    }

    public function getDistrictPlans(?DistrictPlanFilters $filters): Collection
    {
        return $this->getFilteredBuilder(DistrictPlan::query(), $filters)->get();
    }

    public function getDistrictPlan($planId)
    {
        return DistrictPlan::query()->find($planId);
    }

    public function saveDistrictPlan(DistrictPlan $districtPlan)
    {
        return $districtPlan->save();
    }

    public function getStudentPlans(?StudentPlanFilters $filters)
    {
        return $this->getFilteredBuilder(StudentPlan::query(), $filters)->get();
    }

    public function saveStudentPlan(StudentPlan $studentPlan)
    {
        return $studentPlan->save();
    }


}
