<?php

namespace App\Domain\Plp\Repository;

interface TierDefinitionRepositoryInterface
{
    public function getTierDefinitions();
}
