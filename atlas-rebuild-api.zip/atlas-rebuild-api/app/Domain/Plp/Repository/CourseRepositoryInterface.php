<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Plp\Filters\CourseFilters;
use App\Domain\Plp\Model\Course;
use Illuminate\Database\Eloquent\Collection;

interface CourseRepositoryInterface
{
    public function getCourses(?CourseFilters $filters): Collection;

    public function getCourse($recordId);

    public function saveCourse(Course $record);

    public function deleteCourse(Course $record);
}
