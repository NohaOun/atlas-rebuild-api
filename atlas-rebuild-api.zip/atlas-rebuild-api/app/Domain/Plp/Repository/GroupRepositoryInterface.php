<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Plp\Filters\GroupFilters;
use Illuminate\Database\Eloquent\Collection;

interface GroupRepositoryInterface
{
    public function getGroups(?GroupFilters $filters): Collection;

    public function getGroup($recordId);
}
