<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Lookup\Model\TierDefinition;
use Illuminate\Support\Facades\Cache;

class CacheEnabledTierDefinitionRepository implements TierDefinitionRepositoryInterface
{
    const CACHE_KEY = 'tier-definitions';
    const CACHE_TTL = 600;

    public function getTierDefinitions()
    {
        return Cache::remember(self::CACHE_KEY, self::CACHE_TTL, function () {
            return TierDefinition::query()->orderBy('from')->get();
        });
    }
}
