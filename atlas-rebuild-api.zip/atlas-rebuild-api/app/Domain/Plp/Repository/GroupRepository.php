<?php

namespace App\Domain\Plp\Repository;

use App\Domain\Common\Filters\HasFilteredBuilder;
use App\Domain\Plp\Filters\GroupFilters;
use App\Domain\Plp\Model\Group;
use Illuminate\Database\Eloquent\Collection;

class GroupRepository implements GroupRepositoryInterface
{
    use HasFilteredBuilder;

    public function getGroups(?GroupFilters $filters): Collection
    {
        return $this->getFilteredBuilder(Group::query(), $filters)->get();
    }

    public function getGroup($recordId)
    {
        return Group::query()->find($recordId);
    }
}
