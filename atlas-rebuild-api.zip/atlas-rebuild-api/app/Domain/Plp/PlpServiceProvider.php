<?php

namespace App\Domain\Plp;

use App\Domain\Plp\Model\Course;
use App\Domain\Plp\Model\Group;
use App\Domain\Plp\Model\StudentPlanChange;
use App\Domain\Plp\Model\StudentPlan;
use App\Domain\Plp\Repository\CacheEnabledTierDefinitionRepository;
use App\Domain\Plp\Repository\CourseRepository;
use App\Domain\Plp\Repository\CourseRepositoryInterface;
use App\Domain\Plp\Repository\GroupRepository;
use App\Domain\Plp\Repository\GroupRepositoryInterface;
use App\Domain\Plp\Repository\PlanRepository;
use App\Domain\Plp\Repository\PlanRepositoryInterface;
use App\Domain\Plp\Repository\TierDefinitionRepositoryInterface;
use App\Observers\CourseObserver;
use App\Observers\GroupObserver;
use App\Observers\StudentPlanChangeObserver;
use App\Observers\StudentPlpObserver;
use Illuminate\Support\ServiceProvider;

class PlpServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(CourseRepositoryInterface::class, CourseRepository::class);
        $this->app->bind(GroupRepositoryInterface::class, GroupRepository::class);
        $this->app->bind(PlanRepositoryInterface::class, PlanRepository::class);
        $this->app->bind(TierDefinitionRepositoryInterface::class, CacheEnabledTierDefinitionRepository::class);
    }

    public function boot()
    {
        StudentPlan::observe(StudentPlpObserver::class);
        Course::observe(CourseObserver::class);
        Group::observe(GroupObserver::class);
        StudentPlanChange::observe(StudentPlanChangeObserver::class);
    }
}
