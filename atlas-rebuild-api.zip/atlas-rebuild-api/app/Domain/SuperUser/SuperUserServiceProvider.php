<?php

namespace App\Domain\SuperUser;

use App\Domain\SuperUser\Model\SuperUser;
use App\Domain\SuperUser\Repository\SuperUserRepository;
use App\Domain\SuperUser\Repository\SuperUserRepositoryInterface;
use App\Observers\SuperUserObserver;
use Illuminate\Support\ServiceProvider;

class SuperUserServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(SuperUserRepositoryInterface::class, SuperUserRepository::class);
    }

    public function boot()
    {
        SuperUser::observe(SuperUserObserver::class);
    }
}
