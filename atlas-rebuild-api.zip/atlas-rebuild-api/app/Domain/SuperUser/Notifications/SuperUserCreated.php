<?php

namespace App\Domain\SuperUser\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class SuperUserCreated extends Notification
{
    use Queueable;

    private $tempPassword;

    public function __construct($tempPassword)
    {
        $this->tempPassword = $tempPassword;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)->from('noreply@accelerationacademy.net')->subject('Welcome to Atlas Engagement Hub')->markdown('emails.super_user_created', [
            'superUser' => $notifiable,
            'tempPassword' => $this->tempPassword
        ]);
    }
}
