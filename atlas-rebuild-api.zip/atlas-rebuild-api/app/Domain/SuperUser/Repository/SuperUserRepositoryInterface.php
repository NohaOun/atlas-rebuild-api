<?php

namespace App\Domain\SuperUser\Repository;

use App\Domain\SuperUser\Model\SuperUser;

interface SuperUserRepositoryInterface
{
    public function getSuperUserByEmail($email): ?SuperUser;

    public function saveSuperUser(SuperUser $superUser);
}
