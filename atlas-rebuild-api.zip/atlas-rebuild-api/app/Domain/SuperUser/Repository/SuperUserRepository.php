<?php

namespace App\Domain\SuperUser\Repository;

use App\Domain\SuperUser\Model\SuperUser;

class SuperUserRepository implements SuperUserRepositoryInterface
{
    public function getSuperUserByEmail($email): ?SuperUser
    {
        return SuperUser::query()->where('email', $email)->first();
    }

    public function getSuperUserById($id): ?SuperUser
    {
        return SuperUser::find($id);
    }

    public function saveSuperUser(SuperUser $superUser)
    {
        return $superUser->save();
    }
}

