<?php

namespace App\Domain\SuperUser;

use App\Domain\SuperUser\Model\SuperUser;
use App\Domain\SuperUser\Notifications\SuperUserCreated;
use App\Domain\SuperUser\Repository\SuperUserRepository;
use Illuminate\Support\Str;

class SuperUserLibrary
{
    private $superUserRepo;

    public function __construct(SuperUserRepository $superUserRepo)
    {
        $this->superUserRepo = $superUserRepo;
    }

    public function createSuperUser($input)
    {
        $tempPassword = Str::random(6);

        $input['password'] = $tempPassword;
        $input['should_change_password'] = 1;
        $superUser = new SuperUser($input);
        $this->superUserRepo->saveSuperUser($superUser);

        $this->sendWelcomeEmailForSuperUser($superUser, $tempPassword);

        return $superUser;
    }

    public function sendWelcomeEmailForSuperUser(SuperUser $superUser, $tempPassword)
    {
        $superUser->notify(new SuperUserCreated($tempPassword));
    }
}
