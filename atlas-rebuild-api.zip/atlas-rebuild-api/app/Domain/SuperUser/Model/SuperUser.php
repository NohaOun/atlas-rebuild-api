<?php

namespace App\Domain\SuperUser\Model;

use App\Domain\Auth\Contract\Authenticatable as AuthenticatableContract;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class SuperUser extends Authenticatable implements AuthenticatableContract
{
    use HasApiTokens, Notifiable;

    protected $fillable = ['name', 'email', 'password', 'should_change_password'];
    protected $hidden = ['password'];

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    public function getUserType()
    {
        return AuthenticatableContract::USER_TYPE_SUPER_USER;
    }
}
