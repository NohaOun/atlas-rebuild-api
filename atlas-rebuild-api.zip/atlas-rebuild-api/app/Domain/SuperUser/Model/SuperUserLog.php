<?php

namespace App\Domain\SuperUser\Model;

use Illuminate\Database\Eloquent\Model;

class SuperUserLog extends Model
{
    protected $table = 'super_user_logs';
    protected $guarded = ['id'];

    public function subjectable()
    {
        return $this->morphTo();
    }
}
