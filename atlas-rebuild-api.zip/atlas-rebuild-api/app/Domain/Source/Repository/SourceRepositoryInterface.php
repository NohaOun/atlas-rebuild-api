<?php

namespace App\Domain\Source\Repository;

use App\Domain\Source\Model\Source;

interface SourceRepositoryInterface
{
    public function getSource($SourceId): ?Source;

    public function getSources();

    public function updateSource($SourceId, $data): Source;
    public function createSource($data);
}

