<?php

namespace App\Domain\Source\Repository;

use App\Domain\Source\Model\Source;


class SourceRepository implements SourceRepositoryInterface
{

    public function createSource($input)
    {
        return Source::query()->create($input);
    }

    public function getSource($sourceId): ?Source
    {
        return Source::query()->find($sourceId);
    }

    public function getSources()
    {
        return Source::all();
    }

    public function updateSource($record, $data): Source
    {
        $record->update($data);
        $record->save();
        return $record;
    }
}
