<?php

namespace App\Domain\Source\Model;

use Illuminate\Database\Eloquent\Model;

class Source extends Model
{
    
    protected $fillable = ['title', 'key'];
}
