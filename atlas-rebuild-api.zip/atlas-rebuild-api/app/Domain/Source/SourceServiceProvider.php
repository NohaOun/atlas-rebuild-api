<?php

namespace App\Domain\Source;

use App\Domain\Source\Repository\SourceRepository;
use App\Domain\Source\Repository\SourceRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class SourceServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(SourceRepositoryInterface::class, SourceRepository::class);
    }
}
