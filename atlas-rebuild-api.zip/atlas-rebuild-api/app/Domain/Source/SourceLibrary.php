<?php

namespace App\Domain\Source;

use App\Domain\Source\Repository\SourceRepositoryInterface;

class SourceLibrary
{
    protected $sourceRepository;

    public function __construct(SourceRepositoryInterface $sourceRepository)
    {
        return $this->sourceRepository = $sourceRepository;
    }

    public function createSource($input)
    {
        return $this->sourceRepository->createSource($input);
    }

    public function getSource($SourceId)
    {
        return $this->sourceRepository->getSource($SourceId);
    }

    public function getSources()
    {
        return $this->sourceRepository->getSources();
    }

    public function updateSource($record, $data)
    {
        return $this->sourceRepository->updateSource($record, $data);
    }

    public function deleteSource($record)
    {
        return $record->delete();
    }
}

