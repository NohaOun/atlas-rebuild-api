<?php

namespace App\Domain\Redemption\Model;

use App\Domain\Student\Model\Student;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Redemption extends Model
{
    use BelongsToTenant;

    const STATUS_PENDING = 'pending';
    const STATUS_NEW = 'new';
    const STATUS_SEEN = 'seen';

    protected $fillable = ['link', 'amount', 'points', 'student_id', 'status'];

    public function scopeVisible(Builder $query)
    {
        return $query->where('status', '!=', static::STATUS_PENDING);
    }

    public function student()
    {
        return $this->belongsTo(Student::class);
    }
}
