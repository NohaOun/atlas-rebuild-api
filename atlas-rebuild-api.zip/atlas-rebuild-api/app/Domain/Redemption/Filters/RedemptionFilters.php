<?php


namespace App\Domain\Redemption\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class RedemptionFilters extends BaseFilters
{

    public function student(Builder $builder, $id)
    {
        return $builder->where('student_id', $id);
    }

    public function status(Builder $builder, $status)
    {
        return $builder->where('status', $status);
    }
}
