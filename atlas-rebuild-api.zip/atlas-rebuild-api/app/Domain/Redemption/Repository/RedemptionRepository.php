<?php

namespace App\Domain\Redemption\Repository;

use App\Domain\Redemption\Filters\RedemptionFilters;
use App\Domain\Redemption\Model\Redemption;

class RedemptionRepository implements RedemptionRepositoryInterface
{
    public function getRedemptions(RedemptionFilters $filters)
    {
        $builder = Redemption::query();
        if ($filters) $filters->apply($builder);

        return $builder->get();
    }

    public function getRedemption($redemptionId): ?Redemption
    {
        return Redemption::query()->find($redemptionId);
    }

    public function saveRedemption(Redemption $redemption)
    {
        return $redemption->save();
    }

    public function deleteRedemption(Redemption $redemption)
    {
        return $redemption->delete();
    }


    public function updateStatusToSeen($stuentPoints){
        Redemption::query()->whereIn('id', $stuentPoints->pluck('id'))->update(['status' => Redemption::STATUS_SEEN]);
    }
}
