<?php

namespace App\Domain\Redemption\Repository;

use App\Domain\Redemption\Filters\RedemptionFilters;
use App\Domain\Redemption\Model\Redemption;

interface RedemptionRepositoryInterface
{
    public function getRedemptions(RedemptionFilters $filterse);

    public function getRedemption($redemptionId): ?Redemption;


    public function saveRedemption(Redemption $redemption);

    public function deleteRedemption(Redemption $redemption);
}
