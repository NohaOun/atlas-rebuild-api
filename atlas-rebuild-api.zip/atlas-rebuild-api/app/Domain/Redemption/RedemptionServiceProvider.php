<?php

namespace App\Domain\Redemption;


use App\Domain\Redemption\Model\Redemption;
use App\Domain\Redemption\Repository\RedemptionRepository;
use App\Domain\Redemption\Repository\RedemptionRepositoryInterface;
use App\Observers\RedemptionObserver;
use Illuminate\Support\ServiceProvider;

class RedemptionServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(RedemptionRepositoryInterface::class, RedemptionRepository::class);
    }

    public function boot()
    {
        Redemption::observe(RedemptionObserver::class);
    }
}
