<?php

namespace App\Domain\Redemption;

use App\Domain\Redemption\Model\Redemption;
use App\Domain\Redemption\Model\StudentPoint;
use App\Domain\Redemption\Repository\RedemptionRepository;
use App\Domain\Redemption\Repository\RedemptionRepositoryInterface;
use App\Domain\Status\StatusLibrary;

class RedemptionLibrary
{
    protected $redemptionRepo;
    /**
     * @var StatusLibrary
     */

    public function __construct(
    RedemptionRepository $redemptionRepo)
    {
        $this->redemptionRepo = $redemptionRepo;
    }

    public function getRedemptions($filters)
    {
        $redemptions = $this->redemptionRepo->getRedemptions($filters);

        return $redemptions;
    }

    public function getRedemption($redemptionId)
    {
        return $this->redemptionRepo->getRedemption($redemptionId);
    }

    public function createRedemption($input)
    {
        $redemption = new Redemption($input);

        $this->redemptionRepo->saveRedemption($redemption);

        return $redemption;
    }

    public function updateRedemption(Redemption $redemption, $data)
    {
        $redemption->fill($data);

        $this->redemptionRepo->saveRedemption($redemption);

        return $redemption;
    }

    public function deleteRedemption(Redemption $redemption)
    {
        return $this->redemptionRepo->deleteRedemption($redemption);
    }

    public function updateStatusToSeen($redemptions){
        $this->redemptionRepo->updateStatusToSeen($redemptions);
    }
}
