<?php

namespace App\Domain\Tenancy;

use App\Domain\Tenancy\Repository\FieldNameRepository;
use App\Domain\Tenancy\Repository\FieldNameRepositoryInterface;
use App\Domain\Tenancy\Repository\TenantRepository;
use App\Domain\Tenancy\Repository\TenantRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class TenancyServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(TenantRepositoryInterface::class, TenantRepository::class);
        $this->app->singleton(FieldNameRepositoryInterface::class, FieldNameRepository::class);
    }
}
