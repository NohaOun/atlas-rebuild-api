<?php

namespace App\Domain\Tenancy\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class TenantFilters extends BaseFilters
{
    public function user(Builder $builder, $id)
    {
        return $builder->whereHas('tenantUsers', function (Builder $b) use ($id) {
            return $b->where('tenant_user.user_id', $id);
        });
    }

    public function clever(Builder $builder, $clever)
    {
        return $builder->where('config->modules->courseware_integration->active', 1)
            ->where('config->modules->courseware_integration->services', 'like', '%clever%');
    }
}
