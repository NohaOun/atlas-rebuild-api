<?php

namespace App\Domain\Tenancy\Model;

use App\Domain\Tenancy\Support\TenantConfig;
use App\Domain\User\Model\Role;
use App\Domain\User\Model\TenantUser;
use Stancl\Tenancy\Database\Concerns\HasScopedValidationRules;
use Stancl\Tenancy\Database\Models\Tenant as BaseTenant;

class Tenant extends BaseTenant
{
    use HasScopedValidationRules;

    protected $casts = ['config' => 'json'];

    public static function getCustomColumns(): array
    {
        return ['id', 'name', 'config'];
    }

    public function tenantUsers()
    {
        return $this->hasMany(TenantUser::class);
    }

    public function initialTenantUser()
    {
        return $this->hasOne(TenantUser::class)->orderBy('created_at');
    }

    public function initialRole()
    {
        return $this->hasOne(Role::class)->orderBy('created_at');
    }

    public function getConfig()
    {
        return new TenantConfig($this->config);
    }
}
