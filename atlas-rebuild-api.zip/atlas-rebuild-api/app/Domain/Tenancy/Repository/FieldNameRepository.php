<?php

namespace App\Domain\Tenancy\Repository;

use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class FieldNameRepository implements FieldNameRepositoryInterface
{
    protected $fieldNames;
    protected $customFieldNames;

    public function getFieldNames()
    {
        if (!$this->fieldNames) {
            $this->cacheFieldNames();
        }

        return $this->fieldNames;
    }

    public function getFieldCustomName($fieldName)
    {
        if (!$this->customFieldNames) {
            $this->cacheCustomFieldNames();
        }

        $customName = Arr::get($this->customFieldNames, $fieldName);

        return $customName ?? $fieldName;
    }

    protected function cacheFieldNames()
    {
        $fieldNames = [];

        $reflection = new \ReflectionClass($this);
        foreach ($reflection->getConstants() as $constantName => $constantValue) {
            if (Str::startsWith($constantName, 'FIELD_NAME')) {
                $fieldNames[] = $constantValue;
            }
        }

        $this->fieldNames = $fieldNames;
    }

    protected function cacheCustomFieldNames()
    {
        $customFieldNames = [];

        $config = tenant('config');
        $fieldNames = Arr::get($config, 'fields', []);

        foreach ($fieldNames as $baseName => $customName) {
            $customFieldNames[$baseName] = $customName;
        }

        $this->customFieldNames = $customFieldNames;
    }
}

