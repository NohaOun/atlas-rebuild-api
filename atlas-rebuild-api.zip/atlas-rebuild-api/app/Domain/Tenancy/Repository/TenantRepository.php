<?php

namespace App\Domain\Tenancy\Repository;

use App\Domain\Tenancy\Filters\TenantFilters;
use App\Domain\Tenancy\Model\Tenant;
use Illuminate\Support\Arr;

class TenantRepository implements TenantRepositoryInterface
{
    public function getTenants(TenantFilters $filters = null)
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getTenant($tenantId)
    {
        return Tenant::query()->find($tenantId);
    }

    public function saveTenant(Tenant $tenant)
    {
        return $tenant->save();
    }

    public function deleteTenant(Tenant $tenant)
    {
        return $tenant->delete();
    }

    public function updateIntegration(Tenant $tenant, $integration, $attributes)
    {
        $config = $tenant->config;

        Arr::set(
            $config,
            "integrations.{$integration}",
            array_merge(Arr::get($config, "integrations.{$integration}", []), $attributes)
        );

        return $tenant->fill(['config' => $config])->save();
    }

    protected function getFilteredBuilder(?TenantFilters $filters)
    {
        $builder = Tenant::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}

