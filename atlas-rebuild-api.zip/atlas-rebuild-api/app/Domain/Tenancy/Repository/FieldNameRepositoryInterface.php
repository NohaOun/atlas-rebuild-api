<?php

namespace App\Domain\Tenancy\Repository;

interface FieldNameRepositoryInterface
{
    const FIELD_NAME_CODE_WORD = 'Code Word';
    const FIELD_NAME_DISTRICT = 'District';
    const FIELD_NAME_SITE = 'Site';
    const FIELD_NAME_DATE_ENROLLED = 'Date Enrolled';
    const FIELD_NAME_DATE_GRADUATED = 'Date Graduated';
    const FIELD_NAME_DATE_WITHDRAWN = 'Date Withdrawn';
    const FIELD_NAME_EMERGENCY_CONTACT_1_NAME = 'Emergency Contact 1 - Name';
    const FIELD_NAME_EMERGENCY_CONTACT_1_PHONE_1 = 'Emergency Contact 1 - Phone 1';
    const FIELD_NAME_EMERGENCY_CONTACT_1_PHONE_2 = 'Emergency Contact 1 - Phone 2';
    const FIELD_NAME_EMERGENCY_CONTACT_1_EMAIL = 'Emergency Contact 1 - Email';
    const FIELD_NAME_EMERGENCY_CONTACT_1_RELATIONSHIP = 'Emergency Contact 1 - Relationship';
    const FIELD_NAME_EMERGENCY_CONTACT_2_NAME = 'Emergency Contact 2 - Name';
    const FIELD_NAME_EMERGENCY_CONTACT_2_PHONE_1 = 'Emergency Contact 2 - Phone 1';
    const FIELD_NAME_EMERGENCY_CONTACT_2_PHONE_2 = 'Emergency Contact 2 - Phone 2';
    const FIELD_NAME_EMERGENCY_CONTACT_2_EMAIL = 'Emergency Contact 2 - Email';
    const FIELD_NAME_EMERGENCY_CONTACT_2_RELATIONSHIP = 'Emergency Contact 2 - Relationship';
    const FIELD_NAME_CONTENT_COACH = 'Content Coach';
    const FIELD_NAME_CAREER_LIFE_COACH = 'Career Life Coach';
    const FIELD_NAME_PARA_PROFESSIONAL = 'Para-Professional';
    const FIELD_NAME_GCA = 'GCA';
    const FIELD_NAME_ADDITIONAL_STAFF_ASSIGNMENT = 'Additional Staff Assignment';
    const FIELD_NAME_ADDITIONAL_STAFF_ASSIGNMENTS = 'Additional Staff Assignments';
    const FIELD_NAME_TRANSPORTATION = 'Transportation';
    const FIELD_NAME_ALTERNATE_ID = 'Alternate ID';
    const FIELD_NAME_PAROLE_OFFICER_NAME = 'Parole Officer Name';
    const FIELD_NAME_PAROLE_OFFICER_PHONE = 'Parole Officer Phone';
    const FIELD_NAME_PAROLE_OFFICER_EMAIL = 'Parole Officer Email';
    const FIELD_NAME_ALLERGIES = 'Allergies';
    const FIELD_NAME_LAST_DATE_ONSITE = 'Last Date Onsite';
    const FIELD_NAME_NEXT_DATE_SCHEDULED = 'Next Date Scheduled';
    const FIELD_NAME_CURRENT_COURSE = 'Current Course';
    const FIELD_NAME_TIME_ONLINE = 'Time Online';
    const FIELD_NAME_COURSE_PROGRESS = 'Course Progress';
    const FIELD_NAME_TARGET_DATE = 'Target Date';
    const FIELD_NAME_COURSEWARE_LOG = 'Courseware Log';
    const FIELD_NAME_POST_GRAD_PATHWAY = 'Post Grad Pathway';
    const FIELD_NAME_TOTAL_CREDITS = 'Total Credits';
    const FIELD_NAME_COURSE_NAME = 'Course Name';
    const FIELD_NAME_COURSE_NAMES = 'Course Name(s)';
    const FIELD_NAME_CREDIT_PER_COURSE = 'Credit per Course';
    const FIELD_NAME_COMPLETED_WITH_DISTRICT = 'Completed with District';
    const FIELD_NAME_COMPLETED_WITH_AA = 'Completed with AA';
    const FIELD_NAME_LAST_TIER_LEVEL = 'Last Tier Level';
    const FIELD_NAME_TEACHER_CONTENT_COACH = 'Teacher (Content Coach)';
    const FIELD_NAME_COUNSELOR_CAREER_LIFE_COACH = 'Counselor (Career Life Coach)';
    const FIELD_NAME_PARA_PROFESSIONAL_GCA = 'Para-Professional (GCA)';
    const FIELD_NAME_LAST_DATE_ONLINE = 'Last Date Online';
    const FIELD_NAME_COMPLETED_WITH = 'Completed With';
    const FIELD_NAME_TIER_LEVEL = 'Tier Level';
    const FIELD_NAME_AA = 'AA';
    const FIELD_NAME_STUDENT = 'Student';
    const FIELD_NAME_FIND_OUT_ABOUT_US = 'How did you find out about us?';

    public function getFieldNames();

    public function getFieldCustomName($fieldName);
}
