<?php

namespace App\Domain\Tenancy\Repository;

use App\Domain\Tenancy\Filters\TenantFilters;
use App\Domain\Tenancy\Model\Tenant;

interface TenantRepositoryInterface
{
    public function getTenants(TenantFilters $filters = null);

    public function getTenant($tenantId);

    public function saveTenant(Tenant $tenant);

    public function deleteTenant(Tenant $tenant);

    public function updateIntegration(Tenant $tenant, $integration, $attributes);
}
