<?php

namespace App\Domain\Tenancy\Support;

use Illuminate\Support\Arr;

class TenantConfig
{
    const SYSTEM_HIERARCHY_LEVEL_ROOT = 'root';
    const SYSTEM_HIERARCHY_LEVEL_LEAF = 'leaf';

    private $config;

    public function __construct($config = null)
    {
        $this->config = $config;
    }

    public function getSystemHierarchyLevels()
    {
        $levels = $this->getConfigValue('system_hierarchy.levels', []);

        usort($levels, function ($a, $b) {
            return $a['number'] <=> $b['number'];
        });

        return $levels;
    }

    public function getSystemHierarchyLevelCount()
    {
        return count($this->getSystemHierarchyLevels());
    }

    protected function getConfigValue($key, $default = null)
    {
        if (is_null($this->config)) {
            throw new \Exception('Tenant config is missing');
        }

        return Arr::get($this->config, $key, $default);
    }

    protected function getSystemHierarchyLevelName($level)
    {
        $index = $this->convertSystemHierarchyLevelToIndex($level);

        return $this->getSystemHierarchyLevels()[$index]['name'];
    }

    protected function convertSystemHierarchyLevelToIndex($level)
    {
        if ($level == self::SYSTEM_HIERARCHY_LEVEL_LEAF) {
            return $this->getSystemHierarchyLevelCount() - 1;
        } else if ($level === self::SYSTEM_HIERARCHY_LEVEL_ROOT) {
            return 0;
        } else {
            return $level - 1;
        }
    }

    public function getZoomConfig()
    {
        return array_merge(
            config('services.zoom'),
            ['refresh_token' => Arr::get($this->config, 'integrations.zoom.refresh_token')]
        );
    }
}
