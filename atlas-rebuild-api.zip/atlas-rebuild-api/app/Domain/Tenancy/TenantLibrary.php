<?php

namespace App\Domain\Tenancy;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Tenancy\Filters\TenantFilters;
use App\Domain\Tenancy\Model\Tenant;
use App\Domain\Tenancy\Repository\FieldNameRepositoryInterface;
use App\Domain\Tenancy\Repository\TenantRepositoryInterface;
use App\Domain\User\Model\Role;
use App\Domain\User\Model\User;
use App\Domain\User\PermissionLibrary;
use App\Domain\User\RoleLibrary;
use App\Domain\User\UserLibrary;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class TenantLibrary
{
    private $tenantRepo;
    private $userLibrary;
    private $roleLibrary;
    private $fieldNameRepo;
    private $permissionLibrary;
    private $challengeLibrary;

    public function __construct(
        TenantRepositoryInterface $tenantRepo,
        UserLibrary $userLibrary,
        RoleLibrary $roleLibrary,
        FieldNameRepositoryInterface $fieldNameRepo,
        PermissionLibrary $permissionLibrary,
        ChallengeLibrary $challengeLibrary
    )
    {
        $this->tenantRepo = $tenantRepo;
        $this->userLibrary = $userLibrary;
        $this->roleLibrary = $roleLibrary;
        $this->fieldNameRepo = $fieldNameRepo;
        $this->permissionLibrary = $permissionLibrary;
        $this->challengeLibrary = $challengeLibrary;

    }

    public function getTenants(TenantFilters $filters = null)
    {
        return $this->tenantRepo->getTenants($filters);
    }

    public function getTenant($tenantId)
    {
        return $this->tenantRepo->getTenant($tenantId);
    }

    public function createTenant($input)
    {
        return $this->saveTenant(new Tenant, $input);
    }

    public function updateTenant(Tenant $tenant, $input)
    {
        return $this->saveTenant($tenant, $input);
    }

    protected function saveTenant(Tenant $tenant, $input)
    {
        return DB::transaction(function () use ($tenant, $input) {
            $tenantInput = $this->parseTenantInput($input);
            $tenantInput['config'] = array_merge($tenant->config ?? [], $tenantInput['config']);
            $tenant->fill($tenantInput);

            $this->tenantRepo->saveTenant($tenant);

            if (Arr::has($input, 'config.initial_role')) {
                $initialRole = $input['config']['initial_role'];
                $role = $this->createInitialTenantRole($initialRole['name'], $tenant);

                if (Arr::has($input, 'config.initial_user')) {
                    $initialUser = array_merge($input['config']['initial_user'], ['active' => 1]);
                    $this->createInitialTenantUser($initialUser, $role, $tenant);
                }
            }
            if (!$this->challengeLibrary->getChallengesByTenant($tenant->id)->count()) {
                $standardChallenges = $this->challengeLibrary->getStandardChallenges();
                foreach ($standardChallenges as $standardChallenge) {
                    $this->challengeLibrary->addToTenant($standardChallenge, $tenant->id);
                }
            }
            return $tenant;
        });
    }

    protected function parseTenantInput($input)
    {
        $parsed = [];

        if (Arr::has($input, 'name')) {
            $parsed['name'] = $input['name'];
        }

        $inputConfig = Arr::get($input, 'config', []);
        $parsed['config'] = Arr::only($inputConfig, ['fields', 'system_hierarchy', 'modules', 'site_settings', 'limits']);

        return $parsed;
    }

    protected function createInitialTenantRole($name, Tenant $tenant)
    {
        $permissionIds = $this->permissionLibrary->getPermissionIds();

        return $this->roleLibrary->createRole(
            ['name' => $name, 'tenant_id' => $tenant->id, 'permission_ids' => $permissionIds]
        );
    }

    protected function createInitialTenantUser($input, Role $role, Tenant $tenant)
    {
        $input = array_merge($input, ['role_id' => $role->id, 'tenant_id' => $tenant->id, 'should_change_password' => 0]);
        $input['password'] = Hash::make($input['password']);
        return !($user = $this->userLibrary->getUserByEmail($input['email']))
            ? $this->userLibrary->saveUser(new User(), $input)
            : $this->userLibrary->saveTenantUser($user, $input);
    }

    public function deleteTenant(Tenant $tenant)
    {
        return $this->tenantRepo->deleteTenant($tenant);
    }

}
