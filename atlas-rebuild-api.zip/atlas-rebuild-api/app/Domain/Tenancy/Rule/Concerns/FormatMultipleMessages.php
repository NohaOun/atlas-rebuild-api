<?php

namespace App\Domain\Tenancy\Rule\Concerns;

trait FormatMultipleMessages
{
    public function formatMultipleMessages($messages)
    {
        $formattedMessages = [];

        foreach ($messages as $k => $errors) {
            foreach ($errors as $error) {
                $formattedMessages[] = sprintf('%s: %s', $k, $error);
            }
        }

        return $formattedMessages;
    }
}
