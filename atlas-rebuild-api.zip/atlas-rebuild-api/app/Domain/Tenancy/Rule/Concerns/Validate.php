<?php

namespace App\Domain\Tenancy\Rule\Concerns;

use Illuminate\Support\Facades\Validator;

trait Validate
{
    use FormatMultipleMessages;

    protected $errors = [];

    public function validate($value, $rules)
    {
        $validator = Validator::make($value, $rules);

        if ($validator->fails()) {
            $this->errors = $this->formatMultipleMessages(
                $validator->getMessageBag()->getMessages()
            );
            return false;
        }

        return true;
    }
}
