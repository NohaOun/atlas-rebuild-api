<?php

namespace App\Domain\Tenancy\Rule;

use App\Domain\Tenancy\Rule\Concerns\Validate;
use Illuminate\Contracts\Validation\Rule as RuleContract;

class ValidInitialRole implements RuleContract
{
    use Validate;

    public function passes($attribute, $value)
    {
        $rules = [
            'name' => 'required|string|min:2|max:254',
        ];

        return $this->validate($value, $rules);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid initial role.';
    }
}
