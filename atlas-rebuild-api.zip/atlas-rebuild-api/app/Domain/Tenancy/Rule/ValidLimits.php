<?php

namespace App\Domain\Tenancy\Rule;

use App\Domain\Tenancy\Rule\Concerns\Validate;
use Illuminate\Contracts\Validation\Rule;

class ValidLimits implements Rule
{
    use Validate;

    public function passes($attribute, $value)
    {
        $rules = [
            'teachers' => ['required', 'numeric', 'min:1', 'max:10'],
            'counselors' => ['required', 'numeric', 'min:1', 'max:2'],
            'para_professionals' => ['required', 'numeric', 'min:1', 'max:5'],
        ];

        return $this->validate($value, $rules);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid limits.';
    }
}
