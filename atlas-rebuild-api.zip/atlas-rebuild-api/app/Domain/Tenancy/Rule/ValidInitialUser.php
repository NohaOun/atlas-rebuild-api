<?php

namespace App\Domain\Tenancy\Rule;

use App\Domain\Tenancy\Rule\Concerns\Validate;
use Illuminate\Contracts\Validation\Rule as RuleContract;
use Illuminate\Validation\Rule;

class ValidInitialUser implements RuleContract
{
    use Validate;

    public function passes($attribute, $value)
    {
        $rules = [
            'title' => 'required|string|max:255',
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => ['required', 'email'],
            'password' => 'required',
            'lookup_timezone_id' => ['required', Rule::exists('lookup_timezones', 'id')],
        ];

        return $this->validate($value, $rules);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid initial user.';
    }
}
