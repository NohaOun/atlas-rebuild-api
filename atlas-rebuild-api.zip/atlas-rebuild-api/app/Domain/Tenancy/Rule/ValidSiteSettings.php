<?php

namespace App\Domain\Tenancy\Rule;

use App\Domain\Tenancy\Rule\Concerns\Validate;
use Illuminate\Contracts\Validation\Rule;

class ValidSiteSettings implements Rule
{
    use Validate;

    public function passes($attribute, $value)
    {
        $keys = [
            'site_name', 'email_reply', 'badge_points', 'valid_domains', 'progress_points',
            'referring_points', 'site_description', 'attendance_swipe_points',
            'points_to_dollars_factor', 'google_analytic_tracking_id',
        ];

        $rules = array_reduce($keys, function ($c, $key) {
            $c[$key] = 'present';
            return $c;
        }, []);

        $rules['status_id_to_initialize_student_from_contact'] = 'nullable';
        $rules['status_id_to_change_contact'] = 'nullable';
        $rules['dont_contact_student_status_id'] = 'nullable';
        $rules['dont_contact_compass_contact_status_id'] = 'nullable';

        return $this->validate($value, $rules);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid site settings.';
    }
}
