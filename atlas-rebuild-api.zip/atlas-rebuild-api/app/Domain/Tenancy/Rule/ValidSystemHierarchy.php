<?php

namespace App\Domain\Tenancy\Rule;

use Illuminate\Contracts\Validation\Rule as RuleContract;
use Illuminate\Support\Facades\Validator;

class ValidSystemHierarchy implements RuleContract
{
    public function passes($attribute, $value)
    {
        $validator = Validator::make($value, [
            'levels' => ['min:1', 'max:3'],
            'levels.*.number' => ['required', 'min:1', 'max:3'],
            'levels.*.name' => ['required']
        ]);

        return !$validator->fails();
    }

    public function message()
    {
        return $this->errors ?? 'Invalid system hierarchy config.';
    }
}
