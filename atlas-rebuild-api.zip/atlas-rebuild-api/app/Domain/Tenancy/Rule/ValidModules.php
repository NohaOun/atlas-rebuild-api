<?php

namespace App\Domain\Tenancy\Rule;

use Illuminate\Contracts\Validation\Rule as RuleContract;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;

class ValidModules implements RuleContract
{
    const CLEVER = 'clever';

    protected $value;
    protected $errors;

    public function passes($attribute, $value)
    {
        $this->value = $value;

        return $this->validateDashboard()
            && $this->validateReports()
            && $this->validateActive($this->getModule('student_profile_management'))
            && $this->validateCoursewareIntegration()
            && $this->validateActive($this->getModule('plp'))
            && $this->validateActive($this->getModule('graduation_calculator'))
            && $this->validateActive($this->getModule('automated_workflow'))
            && $this->validateActive($this->getModule('scheduling'))
            && $this->validateActive($this->getModule('document_storage'))
            && $this->validateActive($this->getModule('case_management_notes'));
    }

    protected function validateDashboard()
    {
        $rules = [
            'active' => 'boolean',
            'kpis' => ['required', 'array'],
            'kpis.*.name' => ['required']
        ];

        return $this->validate($this->getModule('dashboard'), $rules);
    }

    protected function validateReports()
    {
        $rules = [
            'active' => 'boolean',
            'selected' => ['required', 'array'],
            'selected.*.name' => ['required']
        ];

        return $this->validate($this->getModule('reports'), $rules);
    }

    protected function validateCoursewareIntegration()
    {
        $rules = [
            'active' => 'boolean',
            'services.*.name' => ['required'],
            'services.*.api_key' => ['required'],
        ];

        return $this->validate($this->getModule('courseware_integration'), $rules);
    }

    protected function validateActive($module)
    {
        return $this->validate($module, ['active' => 'boolean']);
    }

    protected function validate($value, $rules)
    {
        $validator = Validator::make($value, $rules);

        if ($validator->fails()) {
            $this->errors = $validator->getMessageBag()->getMessages();
            return false;
        }

        return true;
    }

    protected function getModule($module)
    {
        return Arr::get($this->value, $module);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid module config.';
    }
}
