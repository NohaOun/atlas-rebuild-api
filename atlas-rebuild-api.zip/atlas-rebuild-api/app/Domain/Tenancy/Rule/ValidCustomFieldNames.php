<?php

namespace App\Domain\Tenancy\Rule;

use App\Domain\Tenancy\Repository\FieldNameRepositoryInterface;
use App\Domain\Tenancy\Rule\Concerns\Validate;
use Illuminate\Contracts\Validation\Rule as RuleContract;
use Illuminate\Validation\Rule;

class ValidCustomFieldNames implements RuleContract
{
    use Validate;

    private $fieldNameRepo;

    public function __construct(FieldNameRepositoryInterface $fieldNameRepo)
    {
        $this->fieldNameRepo = $fieldNameRepo;
    }

    public function passes($attribute, $value)
    {
        $fieldNames = $this->fieldNameRepo->getFieldNames();

        $rules = [
            '*.base_name' => ['required', Rule::in($fieldNames)],
            '*.custom_name' => ['required']
        ];

        return $this->validate($value, $rules);
    }

    public function message()
    {
        return $this->errors ?? 'Invalid custom fields.';
    }
}
