<?php

namespace App\Domain\Site;

use App\Domain\Site\Filters\SiteFilters;
use App\Domain\Site\Model\Site;
use App\Domain\Site\Repository\SiteRepositoryInterface;
use Illuminate\Support\Arr;

class SiteLibrary
{
    protected $siteRepo;

    public function __construct(SiteRepositoryInterface $siteRepo)
    {
        return $this->siteRepo = $siteRepo;
    }

    public function getSites(SiteFilters $filters = null)
    {
        return $this->siteRepo->getSites($filters);
    }

    public function getSite($siteId)
    {
        return $this->siteRepo->getSite($siteId);
    }

    public function createSite($input)
    {
        $site = new Site($this->getSiteAttributes($input));

        $this->siteRepo->saveSite($site);

        return $site;
    }

    public function updateSite(Site $site, $input)
    {
        $site->fill($this->getSiteAttributes($input));

        $this->siteRepo->saveSite($site);

        return $site;
    }

    public function deleteSite(Site $site)
    {
        return $this->siteRepo->deleteSite($site);
    }

    protected function getSiteAttributes($input)
    {
        $attributes = Arr::get($input, 'attributes', []);

        if (Arr::has($input, 'relationships.district_id')) {
            $attributes['district_id'] = $input['relationships']['district_id'];
        }

        return $attributes;
    }
}
