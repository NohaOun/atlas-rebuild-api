<?php

namespace App\Domain\Site\Model;

use App\Domain\District\Model\District;
use App\Domain\Schedule\Model\ScheduleBlock;
use App\Domain\Student\Model\Student;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Site extends Model
{
    use BelongsToTenant;

    protected $table = 'sites';
    protected $fillable = ['name', 'district_id', 'active'];
    protected $with = ['district'];

    public function district()
    {
        return $this->belongsTo(District::class);
    }

    public function primaryScheduleBlock()
    {
        return $this->hasOne(ScheduleBlock::class)->where('primary', 1);
    }

    public function secondaryScheduleBlocks()
    {
        return $this->scheduleBlocks()->where('primary', 0);
    }

    public function scheduleBlocks()
    {
        return $this->hasMany(ScheduleBlock::class);
    }

    public function hasSecondaryScheduleBlocks()
    {
        return $this->secondaryScheduleBlocks()->exists();
    }

    public function capacity()
    {
        return $this->hasOne(SiteCapacity::class, 'site_id');
    }

    public function students()
    {
        return $this->hasMany(Student::class, 'site_id');
    }

}
