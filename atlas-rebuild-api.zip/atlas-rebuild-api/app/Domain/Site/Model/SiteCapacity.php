<?php

namespace App\Domain\Site\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class SiteCapacity extends Model
{
    use BelongsToTenant;

    protected $table = 'site_capacities';
    protected $fillable = ['people_per_site', 'gc_onsite_limit_per_week', 'site_id', 'no_capacity_restrictions'];
    protected $with = ['site'];

    public function site()
    {
        return $this->belongsTo(Site::class);
    }
}
