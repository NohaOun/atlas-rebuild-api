<?php

namespace App\Domain\Site;

use App\Domain\Site\Model\SiteCapacity;
use App\Domain\Site\Repository\SiteCapacityRepositoryInterface;

class SiteCapacityLibrary
{
    protected $siteCapacityRepo;

    public function __construct(SiteCapacityRepositoryInterface $siteCapacityRepo)
    {
        return $this->siteCapacityRepo = $siteCapacityRepo;
    }

    public function getSiteCapacities()
    {
        return $this->siteCapacityRepo->getSiteCapacities();
    }

    public function getSiteCapacity($siteCapacityId)
    {
        return $this->siteCapacityRepo->getSiteCapacity($siteCapacityId);
    }

    public function createSiteCapacity($input)
    {
        $siteCapacity = $this->siteCapacityRepo->getSiteCapacityForSite($input['site_id']);
        if (!$siteCapacity) {
            $siteCapacity = new SiteCapacity();
        }

        $siteCapacity->fill($input);

        $this->siteCapacityRepo->saveSiteCapacity($siteCapacity);

        return $siteCapacity;
    }

    public function deleteSiteCapacity($record)
    {
        return $this->siteCapacityRepo->deleteSiteCapacity($record);
    }
}
