<?php

namespace App\Domain\Site;

use App\Domain\Site\Repository\SiteRepository;
use App\Domain\Site\Repository\SiteRepositoryInterface;
use App\Domain\Site\Repository\SiteCapacityRepository;
use App\Domain\Site\Repository\SiteCapacityRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class SiteServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(SiteRepositoryInterface::class, SiteRepository::class);
        $this->app->bind(SiteCapacityRepositoryInterface::class, SiteCapacityRepository::class);
    }
}
