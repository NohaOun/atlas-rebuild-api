<?php

namespace App\Domain\Site\Repository;

use App\Domain\Site\Model\SiteCapacity;
use Illuminate\Database\Eloquent\Collection;

class SiteCapacityRepository implements SiteCapacityRepositoryInterface
{
    public function getSiteCapacities(): Collection
    {
        return SiteCapacity::all();
    }

    public function getSiteCapacity($siteCapacityId): ?SiteCapacity
    {
        return SiteCapacity::query()->find($siteCapacityId);
    }

    public function getSiteCapacityForSite($siteId): ?SiteCapacity
    {
        return SiteCapacity::query()->where('site_id', $siteId)->first();
    }

    public function saveSiteCapacity(SiteCapacity $siteCapacity)
    {
        return $siteCapacity->save();
    }

    public function deleteSiteCapacity(SiteCapacity $siteCapacity)
    {
        return $siteCapacity->delete();
    }
}
