<?php

namespace App\Domain\Site\Repository;

use App\Domain\Site\Model\SiteCapacity;
use Illuminate\Database\Eloquent\Collection;

interface SiteCapacityRepositoryInterface
{
    public function getSiteCapacities(): Collection;

    public function getSiteCapacity($siteCapacityId): ?SiteCapacity;

    public function getSiteCapacityForSite($siteId): ?SiteCapacity;

    public function saveSiteCapacity(SiteCapacity $siteCapacity);

    public function deleteSiteCapacity(SiteCapacity $siteCapacity);
}
