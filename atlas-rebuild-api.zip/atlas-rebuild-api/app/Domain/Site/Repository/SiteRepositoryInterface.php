<?php

namespace App\Domain\Site\Repository;

use App\Domain\Site\Model\Site;
use App\Domain\Site\Filters\SiteFilters;
use Illuminate\Database\Eloquent\Collection;

interface SiteRepositoryInterface
{
    public function getSites(SiteFilters $filters = null): Collection;

    public function getSite($siteId): ?Site;

    public function getSiteByFilters(SiteFilters $filters): ?Site;

    public function saveSite(Site $site);

    public function deleteSite(Site $site);
}
