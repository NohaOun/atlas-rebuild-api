<?php

namespace App\Domain\Site\Repository;

use App\Domain\Site\Model\Site;
use App\Domain\Site\Filters\SiteFilters;
use Illuminate\Database\Eloquent\Collection;

class SiteRepository implements SiteRepositoryInterface
{
    public function getSites(SiteFilters $filters = null): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getSiteByFilters(SiteFilters $filters): ?Site
    {
        return $this->getFilteredBuilder($filters)->first();
    }

    public function getSite($siteId): ?Site
    {
        return Site::query()->find($siteId);
    }

    public function saveSite(Site $site)
    {
        return $site->save();
    }

    public function deleteSite(Site $site)
    {
        return $site->delete();
    }

    protected function getFilteredBuilder(?SiteFilters $filters)
    {
        $builder = Site::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
