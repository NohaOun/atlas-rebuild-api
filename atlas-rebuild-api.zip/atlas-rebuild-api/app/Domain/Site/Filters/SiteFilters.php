<?php

namespace App\Domain\Site\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class SiteFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function district(Builder $builder, $id)
    {
        return $builder->where('district_id', $id);
    }

    public function siteName(Builder $builder, $name)
    {
        return $builder->where('name', $name);
    }

    public function districtName(Builder $builder, $name)
    {
        return $builder->whereHas('district', function (Builder $builder) use ($name) {
            return $builder->where('name', $name);
        });
    }

    public function advocate(Builder $builder, $advocate)
    {
        return $builder->has('students.paraProfessionals');
    }
    
     public function active(Builder $builder, $id)
    {
        return $builder->where('active', $id);
    }

}
