<?php


namespace App\Domain\StatusHistory;

use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\StatusHistory\Repository\StatusHistoryRepositoryInterface;
use App\Domain\User\Model\User;

class StatusHistoryLibrary
{
    protected $statusHistoryRepo;

    public function __construct(StatusHistoryRepositoryInterface $statusHistoryRepo)
    {
        return $this->statusHistoryRepo = $statusHistoryRepo;

    }

    public function trackVariableStatusChange($variable, User $user = null)
    {
        $now = now();

        $prevRecord = $this->statusHistoryRepo->getLatestVariableStatusChange($variable->id);

        if ($prevRecord) {
            $prevRecord->fill(['exited_at' => $now]);
            $this->statusHistoryRepo->saveVariableStatusChange($prevRecord);
        }

        $reflection = new \ReflectionClass($variable);
        $record = new StatusHistoryEntry([
            'status_variable_id' => $variable->id,
            'status_variable_type' => $reflection->getShortName(),
            'prev_status_id' => $variable->getOriginal('status_id'),
            'new_status_id' => $variable->status_id,
            'user_id' => $user ? $user->id : null,
            'created_at' => $now
        ]);

        $this->statusHistoryRepo->saveVariableStatusChange($record);

        return $record;
    }
}
