<?php


namespace App\Domain\StatusHistory\Repository;

use App\Domain\StatusHistory\Filters\StatusHistoryFilter;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;

class StatusHistoryRepository implements StatusHistoryRepositoryInterface
{
    public function getLatestVariableStatusChange($variableId): ?StatusHistoryEntry
    {
        return StatusHistoryEntry::query()->latest()->where('status_variable_id', $variableId)->first();
    }

    public function saveVariableStatusChange(StatusHistoryEntry $record)
    {
        return $record->save();
    }

    public function getStatusHistoryCount(StatusHistoryFilter $filters)
    {
        $builder = StatusHistoryEntry::query();

        return $filters->apply($builder)->count();
    }

    public function getStatusHistoryEntries(StatusHistoryFilter $filters)
    {
        return $filters->apply(StatusHistoryEntry::query())->get();
    }
}
