<?php


namespace App\Domain\StatusHistory\Repository;

use App\Domain\StatusHistory\Filters\StatusHistoryFilter;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;

interface StatusHistoryRepositoryInterface
{
    public function getLatestVariableStatusChange($variableId): ?StatusHistoryEntry;

    public function saveVariableStatusChange(StatusHistoryEntry $record);

    public function getStatusHistoryCount(StatusHistoryFilter $filters);

    public function getStatusHistoryEntries(StatusHistoryFilter $filters);
}
