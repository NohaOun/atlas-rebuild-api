<?php

namespace App\Domain\StatusHistory\Model;

use App\Domain\Status\Model\Status;
use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StatusHistoryEntry extends Model
{
    use BelongsToTenant;

    const STATUS_VARIABLE_TYPE_CONTACT = 'Contact';
    const STATUS_VARIABLE_TYPE_STUDENT = 'Student';

    public $timestamps = false;
    protected $table = "status_history";
    protected $fillable = ['status_variable_id', 'user_id', 'prev_status_id', 'new_status_id',
        'created_at', 'exited_at', 'status_variable_type', 'is_reentered'];
    protected $dates = ['exited_at'];

    public static function getStatusVariableType()
    {
       return [self::STATUS_VARIABLE_TYPE_STUDENT, self::STATUS_VARIABLE_TYPE_CONTACT];
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function statusVariable()
    {
        return $this->morphTo();
    }

    public function prevStatus()
    {
        return $this->belongsTo(Status::class, 'prev_status_id');
    }

    public function newStatus()
    {
        return $this->belongsTo(Status::class, 'new_status_id');
    }
}
