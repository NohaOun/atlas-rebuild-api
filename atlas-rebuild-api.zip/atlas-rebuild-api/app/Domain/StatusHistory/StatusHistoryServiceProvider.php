<?php


namespace App\Domain\StatusHistory;

use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\StatusHistory\Repository\StatusHistoryRepository;
use App\Domain\StatusHistory\Repository\StatusHistoryRepositoryInterface;
use App\Observers\StatusHistoryEntryObserver;
use Illuminate\Support\ServiceProvider;

class StatusHistoryServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(StatusHistoryRepositoryInterface::class, StatusHistoryRepository::class);
    }

    public function boot()
    {
        StatusHistoryEntry::observe(StatusHistoryEntryObserver::class);
    }
}
