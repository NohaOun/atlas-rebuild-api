<?php


namespace App\Domain\StatusHistory\Filters;


use App\Domain\Common\Filters\BaseFilters;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class StatusHistoryFilter extends BaseFilters
{
    public function district(Builder $builder, $districtId)
    {
        return $builder->whereHasMorph('statusVariable','*', function (Builder $builder) use ($districtId) {
            return $builder->whereHas('site', function (Builder $builder) use ($districtId) {
                return $builder->where('district_id', $districtId);
            });
        });
    }

    public function phase(Builder $builder, $phaseId)
    {
        return $builder->whereHas('newStatus', function (Builder $builder) use ($phaseId) {
            return $builder->where('phase_id', $phaseId);
        });
    }

    public function status(Builder $builder, $statusId)
    {
        return $builder->where('new_status_id', $statusId);
    }

    public function createdAtFrom(Builder $builder, $date)
    {
        $date = Carbon::parse($date);
        return $builder->whereDate('created_at', '>=', $date->format('Y-m-d'));
    }

    public function createdAtTo(Builder $builder, $date)
    {
        $date = Carbon::parse($date);
        return $builder->whereDate('created_at', '<=', $date->format('Y-m-d'));
    }

    public function variableType(Builder $builder, $type)
    {
        return $builder->where('status_variable_type', $type);
    }

    public function exitedAt(Builder $builder, $date)
    {
        return $builder->whereDate('exited_at', $date);
    }

    public function exitedAtFrom(Builder $builder, $date)
    {
        return $builder->where('exited_at', '>=', $date);
    }

    public function exitedAtTo(Builder $builder, $date)
    {
        return $builder->where('exited_at', '<=', $date);
    }
    
    public function q(Builder $builder, $q)
    {
        $builder->where(function (Builder $builder) use ($q) {
            $builder->where('id', $q)               
                ->orWhereHasMorph('statusVariable','*',function (Builder $builder) use ($q) {
                    $builder->WhereRaw('CONCAT(TRIM(first_name), " ", TRIM(last_name)) LIKE ?', "%{$q}%")
                  ->orWhereRaw('last_name LIKE ?', "%{$q}%");
                })
                 ->orWhereHas('newStatus',function (Builder $builder) use ($q) {
                    $builder->WhereRaw('name LIKE ?', "%{$q}%");
                })
                 ->orWhereHas('prevStatus',function (Builder $builder) use ($q) {
                    $builder->WhereRaw('name LIKE ?', "%{$q}%");
                })
                  ->orwhereHas('newStatus.phase', function (Builder $builder) use ($q) {
                  $builder->WhereRaw('name LIKE ?', "%{$q}%");
               })
                ->orwhereHas('prevStatus.phase', function (Builder $builder) use ($q) {
                  $builder->WhereRaw('name LIKE ?', "%{$q}%");
               })
                 
                ->orwhereHas('user', function (Builder $builder) use ($q) {
                  $builder->WhereRaw('CONCAT(TRIM(first_name), " ", TRIM(last_name)) LIKE ?', "%{$q}%")
                  ->orWhereRaw('last_name LIKE ?', "%{$q}%");
               })   
               ->orWhereRaw('exited_at LIKE ?', "%{$q}%") 
               ;
                
        });
    }
    
    public function perPage(Builder $builder, $perPage)
    {
        return $builder->limit($perPage);
    }
}
