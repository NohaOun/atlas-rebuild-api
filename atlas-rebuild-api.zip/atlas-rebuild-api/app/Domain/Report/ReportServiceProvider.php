<?php

namespace App\Domain\Report;

use App\Domain\Report\Repository\ReportRepository;
use App\Domain\Report\Repository\ReportRepositoryInterface;
use App\Domain\Report\Repository\ReportTypeRepository;
use App\Domain\Report\Repository\ReportTypeRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class ReportServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->mergeConfigFrom(__DIR__ . '/report-types.php', 'report-types');

        $this->app->bind(ReportTypeRepositoryInterface::class, ReportTypeRepository::class);
        $this->app->bind(ReportRepositoryInterface::class, ReportRepository::class);
    }
}
