<?php

namespace App\Domain\Report\Rule;

use Illuminate\Contracts\Validation\Rule;

class BaseRule implements Rule
{
    public function passes($attribute, $value)
    {
        return true;
    }

    public function message()
    {
        return 'Filters are not formatted correctly.';
    }
}
