<?php

namespace App\Domain\Report\Formatter;

interface FormatterInterface
{
    public function format(iterable $rows);

    public function getExtension();
}
