<?php

namespace App\Domain\Report\Formatter;

class CsvFormatter implements FormatterInterface
{
    public function format(iterable $rows)
    {
        $tmp = fopen('php://temp', 'w');

        foreach ($rows as $row) {
            fputcsv($tmp, $row);
        }

        return $tmp;
    }

    public function getExtension()
    {
        return 'csv';
    }
}
