<?php

namespace App\Domain\Report\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class Report extends Model
{
    use BelongsToTenant;

    protected $fillable = ['type', 'filename'];
}
