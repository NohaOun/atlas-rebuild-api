<?php

return [
    'contact-report' => [
        'name' => 'Contact Report'
    ],
    'gc-info-report' => [
        'name' => 'GC Info Report'
    ],
    'note-report' => [
        'name' => 'Note Report'
    ],
    'referred-report' => [
        'name' => 'Referred Report'
    ],
    'user-permission-report' => [
        'name' => 'User Permission Report'
    ],
    'gc-navigator-points-report' => [
        'name' => 'GC Navigator Points Report'
    ],
    'gc-navigator-redemption-report' => [
        'name' => 'GC Navigator Redemption Report'
    ],
    'gc-navigator-report' => [
        'name' => 'GC Navigator Report'
    ],
    'case-management-report' => [
        'name' => 'Case Management Report'
    ],
    'academic-progress-report' => [
        'name' => 'Academic Progress Report'
    ],
    'engagement-report' => [
        'name' => 'Engagement Report'
    ],
    'onsite-attendance-report' => [
        'name' => 'Onsite Attendance Report'
    ],
    'last-date-attended-report' => [
        'name' => 'Last Date Attended Report'
    ],
    'sa-dashboard-report' => [
        'name' => 'SA Dashboard Report'
    ],
    'tier-report' => [
        'name' => 'Tier Report'
    ],
    'Plp-report' => [
        'name' => 'PLP Report'
    ],
    'gc-schedule-report' => [
        'name' => 'GC Schedule Report'
    ],
    'gc-lifecycle-report' => [
        'name' => 'GC Lifecycle Report'
    ],
    'workflow-report' => [
        'name' => 'Workflow Report'
    ],
    'compass-dashboard-report' => [
        'name' => 'Compass Dashboard Report'
    ],
     'chat-report' => [
        'name' => 'Chat Report'
    ],
    'BAA-report' => [
        'name' => 'WA Requirements Tracking Report'
    ],
    'compass-canvassing-report' => [
        'name' => 'Compass Canvassing Report'
    ]
];
