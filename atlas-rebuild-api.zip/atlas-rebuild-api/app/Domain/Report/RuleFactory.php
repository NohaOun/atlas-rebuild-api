<?php

namespace App\Domain\Report;

use Illuminate\Contracts\Validation\Rule;
use Illuminate\Foundation\Application;
use Illuminate\Support\Str;

class RuleFactory
{
    private $app;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function make($reportType): Rule
    {
        $class = Str::studly($reportType);
        if (config()->has("report-types.{$reportType}.id")) {
            $class = config("report-types.{$reportType}.id");
        }

        return $this->app->make(
            sprintf('%s\%s%s', 'App\Domain\Report\Rule', $class, 'Rule')
        );
    }
}
