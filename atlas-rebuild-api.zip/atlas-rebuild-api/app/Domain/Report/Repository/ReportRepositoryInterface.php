<?php

namespace App\Domain\Report\Repository;

use App\Domain\Report\Model\Report;

interface ReportRepositoryInterface
{
    public function getReport($reportId): ?Report;

    public function saveReport(Report $report): bool;
}
