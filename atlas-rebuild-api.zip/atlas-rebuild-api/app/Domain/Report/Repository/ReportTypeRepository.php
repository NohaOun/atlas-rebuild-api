<?php

namespace App\Domain\Report\Repository;

use App\Domain\Report\Model\ReportType;
use Illuminate\Support\Collection;

class ReportTypeRepository implements ReportTypeRepositoryInterface
{
    public function getReports(): Collection
    {
        $collection = new Collection();

        foreach (config('report-types') as $id => $data) {
            $collection->push(new ReportType($id, $data['name']));
        }

        return $collection;
    }
}
