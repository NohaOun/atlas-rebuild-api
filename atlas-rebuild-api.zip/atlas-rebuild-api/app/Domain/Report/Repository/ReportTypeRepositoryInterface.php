<?php

namespace App\Domain\Report\Repository;

use Illuminate\Support\Collection;

interface ReportTypeRepositoryInterface
{
    public function getReports(): Collection;
}
