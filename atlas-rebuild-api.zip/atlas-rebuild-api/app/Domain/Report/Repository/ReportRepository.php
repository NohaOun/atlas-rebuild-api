<?php

namespace App\Domain\Report\Repository;

use App\Domain\Report\Model\Report;

class ReportRepository implements ReportRepositoryInterface
{
    public function getReport($reportId): ?Report
    {
        return Report::query()->find($reportId);
    }

    public function saveReport(Report $report): bool
    {
        return $report->save();
    }
}
