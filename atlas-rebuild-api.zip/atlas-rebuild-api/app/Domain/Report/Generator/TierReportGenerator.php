<?php

namespace App\Domain\Report\Generator;

use App\Domain\Plp\PlanLibrary;
use App\Domain\Report\Generator\Concern\StudentFilterer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;

class TierReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $planLibrary;

    public function __construct(StudentFilterer $filterer, PlanLibrary $planLibrary)
    {
        $this->filterer = $filterer;
        $this->planLibrary = $planLibrary;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As atlas_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('students.district_id AS district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('student_plp_plans.content As content')
            ->addSelect('student_plp_plans.name As name')
            ->addSelect('student_plp_plans.active as plp_active')
           ->addSelect('student_plp_plans.override_tier_level as override_tier_level')
            ->addSelect('GCA.first_name AS GCA_first_name')
            ->addSelect('GCA.last_name AS GCA_last_name')
            ->leftJoin('student_plp_plans', function ($join) {
                $join->on('student_plp_plans.student_id', '=', 'students.id')
                    ->where('student_plp_plans.active', 1)
                    ;
            })
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
             ->leftJoin('phases', function ($join) {
               $join->on('statuses.phase_id', '=', 'phases.id')
             ->where('phases.name', '!=', 'Duplicate');
                })
            ->leftJoin('users AS GCA', 'students.graduate_candidate_advocate_id', '=', 'GCA.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id' , app('assigned-district-ids'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');


        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $tiers = $builder->get();

        yield [
            'AA ID', 'District', 'School', 'District Id', 'First Name',
            'Last Name', 'Phase', 'Status', 'Tier', 'Credits Earned', 'GPA', 'GCA'
        ];

        foreach ($tiers as $tier) {

            $content = json_decode($tier->content, true);
            $content = $this->planLibrary->addTierToPlpPlanContent($content, $tier);
          
            yield [
                'AA ID' => $tier->atlas_id,
                'District' => $tier->district,
                'School' => $tier->site,
                'District Id' => $tier->district_id,
                'First Name' => $tier->first_name,
                'Last Name' => $tier->last_name ?? null,
                'Phase' => $tier->phase,
                'Status' => $tier->status,
                'Tier' =>  $tier->plp_active == 1
                && Arr::get($content, 'tier_level')                
                    ? str_replace("Tier","", Arr::get($content, 'tier_level'))
                    : 'N/A',
                'Credits Earned' => $tier->plp_active == 1
                && Arr::get($content, 'diploma_credits_earned') != 0
                    ? Arr::get($content, 'diploma_credits_earned')
                    : 'N/A',
                'GPA' => $tier->plp_active == 1
                && Arr::get($content, 'gpa') != 0 && Arr::get($content, 'gpa') != ""
                    ? Arr::get($content, 'gpa')
                    : 'N/A',
                'GCA' => $tier->GCA_first_name . ' ' . $tier->GCA_last_name,
            ];
        }
    }
}
