<?php

namespace App\Domain\Report\Generator;

use App\Domain\Plp\PlanLibrary;
use App\Domain\Report\Generator\Concern\EngagementFilterer;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class EngagementReportGenerator extends BaseGenerator implements GeneratorInterface
{
    const SEASONS =
        [0 => 'Fall', 1 => 'Spring', 2 => 'Summer', 3 => 'Winter',
            'Fall' => 'Fall',
            'Spring' => 'Spring',
            'Summer' => 'Summer',
            'Winter' => 'Winter'
        ];
    private $filterer;
    private $planLibrary;

    public function __construct(EngagementFilterer $filterer, PlanLibrary $planLibrary)
    {
        $this->filterer = $filterer;
        $this->planLibrary = $planLibrary;
    }

    public function generate($filters): iterable
    {
        $range = Arr::get($filters, 'range');

        $builder = DB::table('students')
            ->addSelect('students.id As student_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('sites.name AS site')
            ->addSelect('students.district_id')
            ->addSelect('students.created_at as first_date_enrolled')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('gca.first_name AS gca_first_name')
            ->addSelect('gca.last_name AS gca_last_name')
            ->addSelect('student_plp_plans.active as plp_active')
            ->addSelect('student_plp_plans.content as content')
            ->addSelect('student_plp_plans.name as name')
            ->addSelect('student_plp_plans.override_tier_level as override_tier_level')
            ->addSelect('tasks.minutes as total_tasks_minutes')
            ->leftJoin('student_plp_plans', function ($join) {
                $join->on('student_plp_plans.student_id', '=', 'students.id')
                    ->where('student_plp_plans.active', 1)
                    ->where('student_plp_plans.tenant_id', tenant()->id);
            })
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('student_assignees', function ($join) {
                $join->on('student_assignees.student_id', '=', 'students.id')
                    ->where('student_assignees.group', '=', 'para_professionals');
            })
            ->leftJoin('users AS gca', 'student_assignees.user_id', '=', 'gca.id')
            ->join(
                DB::raw("( " . $this->totalMinutes($range) . " ) as tasks")
                , function ($join) {
                $join->on('tasks.edmentum_learner_id', '=', 'students.id');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', true)
            ->where('sites.active', true)
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());
        $students = $builder->get();


        yield ['ATLAS', '', '', '', '', '', '', '', '', '', '', '', 'plp', '', '', '', 'Edmentum', '', '', 'Edgenuity'];

        yield [
            'Unique ID', 'Partner', 'Site', 'First Name', 'Last Name', 'Phase',
            'Status', 'First date enrolled in A.A.', 'Last Date Attended', 'Total Time On Edmentum (YTD)',
            'Atalas HRS', 'GCA', 'Target Graduation Date', 'Tier', 'Credits Earned', 'Credits Needed', 'Last Login',
            'Total Time (mins)', 'HRS', 'E Last Login', 'E Total Time (mins)', 'E HRS', '% Progress', 'Course Name'
        ];

        $edmentumData = $this->getEdmenumData($range);

        foreach ($students as $student) {
            if ($this->removeUnneeded($edmentumData, $student)) continue;

            $content = json_decode($student->content, true);
            $content = $this->planLibrary->addTierToPlpPlanContent($content, $student);

            $season = $student->plp_active == 1
            && Arr::get($content, 'target_graduation.season') !== null
                ? self::SEASONS[Arr::get($content, 'target_graduation.season')] . ' '
                : null;

            yield [
                'Unique ID' => $student->student_id,
                'Partner' => $student->district,
                'Site' => $student->site,
                'First Name' => $student->first_name,
                'Last Name' => $student->last_name ?? null,
                'Phase' => $student->phase,
                'Status' => $student->status,
                'First date enrolled in A.A.' => $student->first_date_enrolled ? Carbon::parse($student->first_date_enrolled)->format('m/d/Y') : "",
                'Last Date Attended' => isset($edmentumData[$student->student_id]) && !is_null($edmentumData[$student->student_id][0]->last_attended_in_edmentum) ? Carbon::parse($edmentumData[$student->student_id][0]->last_attended_in_edmentum)->format('m/d/Y') : "",
                'Total Time On Edmentum (YTD)' => isset($edmentumData[$student->student_id]) ? $edmentumData[$student->student_id][0]->total_time_login : "",
                'Atlas HRS' => isset($edmentumData[$student->student_id]) ? intdiv($edmentumData[$student->student_id][0]->total_time_login, 60) : '',
                'GCA' => $student->gca_first_name . ' ' . $student->gca_last_name,

                'Target Graduation Date' => $student->plp_active == 1
                && Arr::get($content, 'diploma_credits_needed') !== 0
                    ? $season . Arr::get($content, 'target_graduation.year')
                    : 'N/A',
                'Tier' => $student->plp_active == 1
                && Arr::get($content, 'tier_level')
                && Arr::get($content, 'diploma_credits_needed') !== 0
                    ? Arr::get($content, 'tier_level')
                    : 'N/A',
                'Credits Earned' => $student->plp_active == 1
                && Arr::get($content, 'diploma_credits_needed') !== 0
                    ? Arr::get($content, 'diploma_credits_earned')
                    : 'N/A',
                'Credits Needed' =>
                    $student->plp_active == 1
                    && Arr::get($content, 'diploma_credits_needed') !== 0
                    ? Arr::get($content, 'diploma_credits_needed')
                    : 'N/A',

                'Last Login' => isset($edmentumData[$student->student_id]) && !is_null($edmentumData[$student->student_id][0]->last_login) ? Carbon::parse($edmentumData[$student->student_id][0]->last_login)->format('m/d/Y') : "",
                'Total Time (mins)' => $student->total_tasks_minutes ? $student->total_tasks_minutes : "",
                'HRS' => $student->total_tasks_minutes ? intdiv($student->total_tasks_minutes, 60) : "",
                'E Last Login' => '',
                'E Total Time (mins)' => '',
                'E HRS' => '',
                '% Progress' => '',
                'Course Name' => '',
            ];
        }
    }

    public function getEdmenumData($range = null)
    {
        $sql = "SELECT `students`.`id` AS `student_id`,
                    tell.total_time_login AS total_time_login, tell.last_login AS last_login,
                  `aelt`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`
                FROM `students`

                LEFT JOIN (
                            SELECT edmentum_learner_id, SUM(`login_minutes`) AS total_time_login , Max(login_date) As last_login
                            FROM `edmentum_learner_logins` ";

        $sql .= isset($range) &&  !is_null($range['from'])? " WHERE login_date >= '{$range['from']}' AND login_date <= '{$range['to']}' " : '';

        $sql .= " GROUP BY `edmentum_learner_id`
                        ) AS tell on `students`.`id` = `tell`.`edmentum_learner_id`

                 LEFT JOIN (
                            SELECT edmentum_learner_id, MAX(`started_at`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_tasks`";

        $sql .= isset($range) &&  !is_null($range['from'])? " WHERE started_at >= '{$range['from']}' AND started_at <= '{$range['to']} 23:59:59' " : '';
        $sql .= " GROUP BY `edmentum_learner_id`
                        ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`
                        ";
        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }

    protected function totalMinutes($range)
    {
        return "SELECT SUM(minutes) as minutes, edmentum_learner_id FROM edmentum_learner_tasks GROUP BY edmentum_learner_id";
    }

    protected function removeUnneeded($edmentumData, $student, $range = null)
    {
        if (!isset($edmentumData[$student->student_id]) || is_null($edmentumData[$student->student_id][0]->last_attended_in_edmentum)) {
            return true;
        }
    }
}
