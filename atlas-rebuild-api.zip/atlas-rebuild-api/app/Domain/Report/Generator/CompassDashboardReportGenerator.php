<?php


namespace App\Domain\Report\Generator;


use App\Domain\Phase\Filters\PhaseFilters;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepositoryInterface;
use App\Domain\Report\Generator\Concern\ContactFilterer;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class CompassDashboardReportGenerator extends BaseGenerator implements GeneratorInterface
{
    protected $filterer;
    protected $phaseRepo;

    public function __construct(ContactFilterer $filterer, PhaseRepositoryInterface $phaseRepo)
    {
        $this->filterer = $filterer;
        $this->phaseRepo = $phaseRepo;
    }

    public function generate($filters): iterable
    {
        $phases = $this->phaseRepo->getPhases(new PhaseFilters(
            ['phase_key' => [PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT, PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT]]
        ));

        $phaseIds = $phases->pluck('id');
        $builder = DB::table('status_history As ssh')
            ->addSelect('contacts.id')
            ->addSelect('contacts.first_name')
            ->addSelect('contacts.last_name')
            ->addSelect('sites.name AS site')
            ->addSelect('sources.title AS source')
            ->addSelect('districts.name AS district')
            ->addSelect('contact_statuses.name As current_status')
            ->addSelect('contacts.created_at')
            ->addSelect('contact_phases.name AS current_phase')
            ->join('contacts', 'ssh.status_variable_id', '=', 'contacts.id')
            ->leftJoin('sources' ,'sources.id', '=', 'contacts.source_id')
            ->leftJoin('sites', 'contacts.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses AS contact_statuses', 'contacts.status_id', '=', 'contact_statuses.id')
            ->leftJoin('phases AS contact_phases', 'contact_statuses.phase_id', '=', 'contact_phases.id')
            ->leftJoin('statuses', 'ssh.new_status_id', '=', 'statuses.id')
            ->where('status_variable_type', StatusHistoryEntry::STATUS_VARIABLE_TYPE_CONTACT)
            ->whereNull('contacts.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('contacts.tenant_id', tenant()->id)
            ->whereIn('statuses.phase_id', $phaseIds)
            ->orderByRaw('contacts.id DESC')
            ->groupBy('contacts.id');

        if (isset($filters['phases']) && (!empty($filters['phases']))) $builder->whereIn('contact_statuses.phase_id', $filters['phases']);
        if (isset($filters['status']) && !is_null($filters['status'])) $builder->where('contact_statuses.id', $filters['status']);
        unset($filters['phases']);
        unset($filters['status']);

        if ($filters) $this->filterer->filter($builder, $filters->toArray());


        $headers = ['AEH ID', 'First Name', 'Last Name', 'District', 'Site', 'Current Phase', 'Current Status','Source', 'Date Created', 'Time Created', 'Total Days in System'];

        foreach ($phases as $phase) {

            foreach ($phase->statuses as $status) {
                $headers[] = $phase->name . '/' . $status->name . ' Enter';
                $headers[] = $phase->name . '/' . $status->name . ' Exit';
                $headers[] = $phase->name . '/' . $status->name . ' Day';
                $statusEnter = 'status' . $status->id . '_Enter';
                $statusExit = 'status' . $status->id . '_Exited';
                $builder->selectRaw("MIN(IF(ssh.new_status_id = $status->id, ssh.created_at, NULL)) AS $statusEnter");
                $builder->selectRaw("MAX(IF(ssh.new_status_id = $status->id, ssh.exited_at, NULL)) AS $statusExit");
            }

        }
        yield $headers;

        $contacts = $builder->get();

        foreach ($contacts as $contact) {
            $createdDate = Carbon::createFromDate($contact->created_at);
            $now = Carbon::now();
            $totalDays = $createdDate->diffInDays($now);
            $data = [
                'AEH ID' => $contact->id,
                'First Name' => $contact->first_name,
                'Last Name' => $contact->last_name,
                'District' => $contact->district,
                'Site' => $contact->site,
                'Current Phase' => $contact->current_phase,
                'Current Status' => $contact->current_status,
                'source' => $contact->source,
                'Date Created' => Carbon::parse($contact->created_at)->timezone(app('userTimeZone'))->format('m/d/Y'),
                'Time Created' => Carbon::parse($contact->created_at)->timezone(app('userTimeZone'))->format('h:i:s A'),
                'Total Days in System' => $totalDays
            ];
            foreach ($phases as $phase) {
                foreach ($phase->statuses as $status) {
                    $statusEnter = 'status' . $status->id . '_Enter';
                    $statusExit = 'status' . $status->id . '_Exited';
                    $statusDay = 'status' . $status->id . '_Day';
                    $data[$statusEnter] = !is_null($contact->$statusEnter) ? Carbon::parse($contact->$statusEnter)->timezone(app('userTimeZone'))->format('m/d/Y') : null;
                    $data[$statusExit] = !is_null($contact->$statusExit) ? Carbon::parse($contact->$statusExit)->timezone(app('userTimeZone'))->format('m/d/Y') : null;
                    $exit = Carbon::createFromDate($data[$statusExit]);
                    $enter = Carbon::createFromDate($data[$statusEnter]);
                    $days = (!is_null($data[$statusEnter]) && !is_null($data[$statusExit])) ? $enter->diffInDays($exit) : 0;
                    $data[$statusDay] = $days;
                }

            }
            yield $data;
        }
    }

}
