<?php

namespace App\Domain\Report\Generator;

use App\Domain\Lookup\Model\Timezone;
use App\Domain\Report\Generator\Concern\AttendanceFilterer;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LastDateAttendedReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(AttendanceFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $timezone = Auth::user()->timezone;
        $range = Arr::get($filters, 'range');

        $builder = DB::table('students')
            ->addSelect('students.id As student_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('student_attendance_entries.note')
            ->addSelect('student_attendance_entries.check_in as check_in')
            ->addSelect('student_attendance_entries.check_out as check_out')
            ->addSelect('sites.name AS site')
            ->addSelect('students.district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('GCA.first_name AS GCA_first_name')
            ->addSelect('GCA.last_name AS GCA_last_name')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('student_assignees', function ($join) {
                $join->on('student_assignees.student_id', '=', 'students.id')
                    ->where('student_assignees.group', '=', 'para_professionals')->limit(1);
            })
            ->join('student_attendance_entries', function ($join) use ($range) {
                $whereQuery = 'SELECT st_ent.id FROM student_attendance_entries AS st_ent
                         WHERE st_ent.student_id = students.id
                         AND st_ent.check_out is not null ORDER BY check_in DESC LIMIT 1';

                $join->on('students.id', '=', 'student_attendance_entries.student_id')
                    ->whereRaw('student_attendance_entries.id = (' . $whereQuery . ')');
            })
            ->leftJoin('users AS GCA', 'student_assignees.user_id', '=', 'GCA.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', 1)
            ->where('sites.active', 1)
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        $this->filterer->filter($builder, $filters->toArray());

        $attendanceEntries = $builder->get();

        yield [
            'Unique AA ID', 'District/School ID', 'District Partner', ' Site', 'GC First Name',
            'GC Last Name', 'Phase', 'Status', 'last Attend Date', 'Check-in',
            'Check-out', 'Total Time [in mins]', 'GCA'
        ];

        if (count($attendanceEntries) > 0) {
            foreach ($attendanceEntries as $entry) {
                $checkIn = Carbon::parse($entry->check_in)->timezone(
                    $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC'
                );
                $checkOut = Carbon::parse($entry->check_out)->timezone(
                    $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC'
                );
                $totalTime = $checkOut->diffInMinutes($checkIn);

                yield [
                    'Unique AA ID' => $entry->student_id,
                    'District/School ID' => $entry->district_id,
                    'District Partner' => $entry->district,
                    'Site' => $entry->site,
                    'GC First Name' => $entry->first_name,
                    'GC Last Name' => $entry->last_name,
                    'Phase' => $entry->phase,
                    'Status' => $entry->status,
                    'last Attend Date' => $checkIn->format('m/d/Y'),
                    'Check-in' => $checkIn->format('h:i a'),
                    'Check-out' => $checkOut->format('h:i a'),
                    'Total Time [in mins]' => $totalTime,
                    'GCA' => $entry->GCA_first_name . ' ' . $entry->GCA_last_name,
                ];
            }
        }
    }
}
