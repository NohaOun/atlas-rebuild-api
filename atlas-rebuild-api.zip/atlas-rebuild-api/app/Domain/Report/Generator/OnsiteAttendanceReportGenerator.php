<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\AttendanceFilterer;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class OnsiteAttendanceReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(AttendanceFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('student_attendance_entries')
            ->addSelect('students.id As atlas_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('student_attendance_entries.note')
            ->addSelect('student_attendance_entries.check_in AS check_in')
            ->addSelect('student_attendance_entries.check_out AS check_out')
            ->addSelect('sites.name AS site')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('students.district_id')
            ->addSelect('students.created_at')
            ->addSelect('students.active')
            ->addSelect('student_attendance_entries.absence')
            ->leftJoin('students', 'student_attendance_entries.student_id', '=', 'students.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        $this->filterer->filter($builder, $filters->toArray());

        $attendanceEntries = $builder->get();

        yield [
            'Acceleration ID', 'District Id', 'District', 'Site', 'First Name',
            'Last Name', 'Check-in Date', 'Check-in Time', 'Check-out Date',
            'Check-out Time', 'Absence', 'Note', 'Phase', 'status', 'Created At', 'Active'
        ];

        if (count($attendanceEntries) > 0) {
            foreach ($attendanceEntries as $entry) {
                $checkIn = strtotime($entry->check_in);
                $checkOut = strtotime($entry->check_out);
                yield [
                    'Acceleration ID' => $entry->atlas_id,
                    'District Id' => $entry->district_id,
                    'District' => $entry->district,
                    'Site' => $entry->site,
                    'First Name' => $entry->first_name,
                    'Last Name' => $entry->last_name,
                    'Check-in Date' => date('m/d/Y', $checkIn),
                    'Check-in Time' => date('h:i a', $checkIn),
                    'Check-out Date' => date('m/d/Y', $checkOut),
                    'Check-out Time' => date('h:i a', $checkOut),
                    'Absence' => $entry->absence =="" ? "0": $entry->absence ,
                    'Note' => $entry->note,
                    'phase' => $entry->phase,
                    'status' => $entry->status,
                    'Created At' => $entry->created_at ? Carbon::parse($entry->created_at)->format('m/d/Y') : "",
                    'Active' => $entry->active == 1 ? "Active" : "Not Active"
                ];
            }
        }
    }
}
