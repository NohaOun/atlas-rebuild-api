<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\WorkFlowFilterer;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class WorkflowReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(WorkFlowFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function getPhaseName($id)
    {
        return DB::table('statuses')
            ->addSelect('phases.name AS phase')
            ->leftJoin('phases', 'statuses.phase_id', '=', 'phases.id')
            ->where('statuses.id', $id)->first();
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('status_history')
            ->addSelect('students.id as student_id')
            ->addSelect('students.first_name')
            ->addSelect('status_history.prev_status_id')
            ->addSelect('sites.name as site_name')
            ->addSelect('districts.name as district_name')
            ->addSelect('students.workflow_exception')
            ->addSelect('prev_statuses.name As prev_status')
            ->addSelect('new_statuses.name As new_status')
            ->addSelect('prev_phases.name As prev_phase')
            ->addSelect('new_phases.name As new_phase')
            ->addSelect('status_history.created_at')
            ->addSelect('users.first_name As user_first_name')
            ->addSelect('users.last_name As user_last_name')
            ->addSelect('notes.created_at')
            ->addSelect('notes.body')
            ->addSelect('contact_actions.created_at As contact_created_at')
            ->addSelect('contact_actions.note As contact_note')
            ->addSelect(DB::raw("CONCAT(createdBy.first_name,' ', createdBy.last_name) as created_by_name"))
            ->addSelect(DB::raw("CONCAT(createdByContact.first_name,' ', createdByContact.last_name) as contatc_created_by_name"))
            ->join('students', 'status_history.status_variable_id', '=', 'students.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses As prev_statuses', 'status_history.prev_status_id', '=', 'prev_statuses.id')
            ->leftJoin('statuses As new_statuses', 'status_history.new_status_id', '=', 'new_statuses.id')
            ->leftJoin('phases As prev_phases', 'prev_statuses.phase_id', '=', 'prev_phases.id')
            ->leftJoin('phases As new_phases', 'new_statuses.phase_id', '=', 'new_phases.id')
            ->leftJoin('users', 'users.id', '=', 'status_history.user_id')
            ->leftJoin('notes', function ($query) {
                $query->on('status_history.status_variable_id', '=', 'notes.student_id')
                    ->where('status_history.status_variable_type', StatusHistoryEntry::STATUS_VARIABLE_TYPE_STUDENT)
                    ->whereRaw('notes.id IN (select MAX(a2.id) from notes as a2 join status_history as u2 on u2.status_variable_id = a2.student_id group by u2.status_variable_id)');
            })
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('contact_actions', function ($query) {
                $query->on('students.contact_id', '=', 'contact_actions.contact_id')
                    ->whereRaw('contact_actions.id IN (select MAX(a3.id) from contact_actions as a3 join students as u3 on u3.contact_id = a3.contact_id group by u3.contact_id)');
            })
            ->leftJoin('users As createdBy', 'notes.creator_id', '=', 'createdBy.id')
            ->leftJoin('users As createdByContact', 'contact_actions.creator_id', '=', 'createdByContact.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        yield [
            'District', 'Site', 'AA ID', 'Date Updated', 'GC Name', 'Edited By', 'Previous Phase', 'Previous Status',
            'New Phase', 'New Status', 'Workflow Exception', 'Case Management Note', 'Note created By', 'Note Date', 'Compass Action Note', 'Compass Note Created By',
            'Compass Note Date',
        ];

        $students = $builder->get();

        foreach ($students as $student) {
            $data = [
                'District' => $student->district_name,
                'Site' => $student->site_name,
                'AA ID' => $student->student_id,
                'Date Updated' => $student->created_at,
                'GC Name' => $student->first_name,
                'Edited By' => $student->user_first_name ? $student->user_first_name . ' ' . $student->user_last_name : 'system',
                'Previous Phase' => $student->prev_phase ?? "",
                'Previous Status' => $student->new_status ?? "",
                'New Phase' => $student->new_phase ?? "",
                'New Status' => $student->new_status ?? "",
                'Workflow Exception' => $student->workflow_exception == 1 ? "Yes" : "No",
                'Case Management Note' => $student->body,
                'Note created By' => $student->created_by_name,
                'Note Date' => $student->created_at ? Carbon::parse($student->created_at)->format('m/d/Y') : "",
                'Compass Action Note' => $student->contact_note,
                'Compass Note Created By' => $student->contatc_created_by_name,
                'Compass Note Date' => $student->contact_created_at ? Carbon::parse($student->contact_created_at)->format('m/d/Y') : "",
            ];
            yield $data;
        }
    }
}
