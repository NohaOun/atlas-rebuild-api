<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\StudentScheduleFilterer;
use Illuminate\Support\Facades\DB;

class GcScheduleReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(StudentScheduleFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As atlas_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('students.street_address')
            ->addSelect('students.city')
            ->addSelect('students.state')
            ->addSelect('students.zip_code')
            ->addSelect('districts.name AS district')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('student_schedules.mon_in')
            ->addSelect('student_schedules.mon_out')
            ->addSelect('student_schedules.mon_transport')
            ->addSelect('student_schedules.sat_in')
            ->addSelect('student_schedules.sat_out')
            ->addSelect('student_schedules.sat_transport')
            ->addSelect('student_schedules.sun_in')
            ->addSelect('student_schedules.sun_out')
            ->addSelect('student_schedules.sun_transport')
            ->addSelect('student_schedules.tue_in')
            ->addSelect('student_schedules.tue_out')
            ->addSelect('student_schedules.tue_transport')
            ->addSelect('student_schedules.sun_in')
            ->addSelect('student_schedules.sun_out')
            ->addSelect('student_schedules.sun_transport')
            ->addSelect('student_schedules.wed_in')
            ->addSelect('student_schedules.wed_out')
            ->addSelect('student_schedules.wed_transport')
            ->addSelect('student_schedules.thu_in')
            ->addSelect('student_schedules.thu_out')
            ->addSelect('student_schedules.thu_transport')
            ->addSelect('student_schedules.fri_in')
            ->addSelect('student_schedules.fri_out')
            ->addSelect('student_schedules.fri_transport')
            
             ->leftJoin('student_schedules', function ($query) {
                $query->on('student_schedules.student_id', '=', 'students.id')
                    ->whereRaw('student_schedules.id IN (select MAX(a3.id) from student_schedules as a3 join students as u3 on u3.id = a3.student_id group by u3.id)');
            })
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $students = $builder->get();

        yield [
            'AA ID', 'District Partner', 'First Name', 'Last Name', 'Phase', 'Status', 'Street Address',
            'City', 'State', 'Zip Code', 'Monday Time In', 'Monday Time Out', 'Monday Transportation?',
            'Tuesday Time In', 'Tuesday Time Out', 'Tuesday Transportation?',
            'Wednesday Time In', 'Wednesday Time Out', 'Wednesday Transportation?',
            'Thursday Time In', 'Thursday Time Out', 'Thursday Transportation?',
            'Friday Time In', 'Friday Time Out', 'Friday Transportation?'
        ];


        foreach ($students as $student) {
        //    echo date("g:i a", strtotime($student->mon_in));
            yield [
                'AA ID' => $student->atlas_id,
                'District Partner' => $student->district,
                'First Name' => $student->first_name,
                'Last Name' => $student->last_name,
                'Phase' => $student->phase,
                'Status' => $student->status,
                'Street Address' => $student->street_address,
                'City' => $student->city,
                'State' => $student->state,
                'Zip Code' => $student->zip_code,
                'Monday Time In' => $student->mon_in ? date("g:i a", strtotime($student->mon_in)) : "",
                'Monday Time out' =>$student->mon_out? date("g:i a", strtotime($student->mon_out)): "",
                'Monday Time Transportation?' => $student->mon_transport == 1 ? "Yes" : "No",
                'Tuesday Time In' => $student->tue_in ? date("g:i a", strtotime($student->tue_in)) : "",
                'Tuesday Time out' => $student->tue_out ? date("g:i a", strtotime($student->tue_out)) : "",
                'Tuesday Time Wednesday?' => $student->tue_transport == 1 ? "Yes" : "No",
                'Wednesday Time In' => $student->wed_in ? date("g:i a", strtotime($student->wed_in)) : "",
                'Wednesday Time out' => $student->wed_out ? date("g:i a", strtotime($student->wed_out)) : "",
                'Wednesday Time Transportation?' => $student->wed_transport == 1 ? "Yes" : "No",
                'Thursday Time In' => $student->thu_in ? date("g:i a", strtotime($student->thu_in)) : "",
                'Thursday Time out' => $student->thu_out ? date("g:i a", strtotime($student->thu_out)) : "",
                'Thursday Time Transportation?' => $student->thu_transport == 1 ? "Yes" : "No",
                'Friday Time In' => $student->fri_in ? date("g:i a", strtotime($student->fri_in)) : "",
                'Friday Time out' => $student->fri_out ? date("g:i a", strtotime($student->fri_out)) :"",
                'Friday Time Transportation?' => $student->fri_transport == 1 ? "Yes" : "No",
            ];
        }
    }
}
