<?php

namespace App\Domain\Report\Generator;

use App\Domain\Note\Model\Note;
use App\Domain\Report\Generator\Concern\CaseManagementFilterer;
use App\Domain\Report\Generator\Helper\ReportHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class CaseManagementReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $reportHelper;

    public function __construct(CaseManagementFilterer $filterer, ReportHelper $reportHelper)
    {
        $this->filterer = $filterer;
        $this->reportHelper = $reportHelper;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('notes')
            ->selectRaw(DB::raw('Max(notes.id) AS note_id'))
            ->addSelect('students.id As student_id')
            ->addSelect('students.status_id')
            ->addSelect('students.content_coach_id')
            ->addSelect('students.first_name As student_first_name')
            ->addSelect('students.last_name As student_last_name')
            ->addSelect('students.created_at As student_created_at')
            ->addSelect('districts.name AS district')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('students.phone_1')
            ->addSelect('students.street_address')
            ->addSelect('students.city')
            ->addSelect('students.state')
            ->addSelect('students.zip_code')
            ->addSelect('students.birthdate')
            ->leftJoin('students', 'notes.student_id', '=', 'students.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('student_assignees as cc', function ($join) {
                $join->on('cc.student_id', '=', 'students.id')
                    ->where('cc.group', '=', 'teachers')->limit(1);
            })
            ->leftJoin('users As contentCoach', 'cc.user_id', '=', 'contentCoach.id')
            ->leftJoin('student_assignees as sa', function ($join) {
                $join->on('sa.student_id', '=', 'students.id')
                    ->where('sa.group', '=', 'para_professionals')->limit(1);
            })
            ->leftJoin('users AS GCA', 'sa.user_id', '=', 'GCA.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('assigned-district-ids'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC')
            ->groupBy('student_id');


        $this->filterer->filter($builder, $filters->toArray());

        $studentIds = $builder->pluck('students.student_id');

        $specialPrograms = $this->reportHelper->getSpecialPrograms($studentIds);

        $notes = $builder->get();

        yield [
            'Acceleration ID', 'District', 'School', 'First Name', 'Last Name', 'Phone', 'Address',
            'City', 'State', 'Zip Code', 'BirthDate', 'Special Programs', 'GCA', 'Content Coach', 'Phase',
            'Status', 'Created Date', 'Note Category', 'Sub-Category', 'Note Details', 'Note Status',

            'Closed By', 'Closed Notes', 'Date Note Created', 'Closed Date', 'Notified',
            'Created By', 'Last Attended (Edmentum)'
        ];

        $edmentumData = $this->reportHelper->getEdmenumData();

        foreach ($notes as $note) {

            $noteSpecialPrograms = isset($specialPrograms[$note->student_id]) ? $specialPrograms[$note->student_id] : [];

            $programsName = [];
            if (count($noteSpecialPrograms) > 0) {
                foreach ($noteSpecialPrograms as $program) {
                    $programsName[] = $program->name;
                }
            }

            $programsName = implode(',', $programsName);
            $getNoteData = $this->getNoteData($note->note_id, $filters);
            $getGCAData = $this->getGCAData($note->student_id);

            yield [
                'Acceleration ID' => $note->student_id,
                'District' => $note->district,
                'School' => $note->site,
                'First Name' => $note->student_first_name,
                'Last Name' => $note->student_last_name,
                'Phone' => $note->phone_1,
                'Address' => $note->street_address,
                'City' => $note->city,
                'State' => $note->state,
                'Zip Code' => $note->zip_code,
                'Birthdate' => $note->birthdate,
                'Special Programs' => $programsName,
                'GCA' => isset($getGCAData->GCA_name) ? $getGCAData->GCA_name : "",
                'Content Coach' => isset($getGCAData->coach_name) ? $getGCAData->coach_name : "",
                'Phase' => $note->phase,
                'Status' => $note->status,
                'Created Date' => $note->student_created_at,
                'Note Category' => isset($getNoteData->category) ? $getNoteData->category : "",
                'Sub-Category' => isset($getNoteData->note_sub_category) ? $getNoteData->note_sub_category : "",
                'Note Details' => isset($getNoteData->body) ? $getNoteData->body : "",
                'Note Status' => $getNoteData->due_date && Carbon::parse($getNoteData->due_date)->format('Y-m-d') < now()->format('Y-m-d')
                && $note->status === Note::STATUS_TODO ? Note::STATUS_OVERDUE : $getNoteData->note_status,
                'Closed By' => isset($getNoteData->follower_name) ? $getNoteData->follower_name : "",
                'Closed Notes' => isset($getNoteData->note_following_note) ? $getNoteData->note_following_note : "",
                'Date Note Created' => $getNoteData->created_at ? Carbon::parse($getNoteData->created_at)->format('m/d/Y') : "",
                'Closed Date' => isset($getNoteData->note_following_date) ? $getNoteData->note_following_date : "",
                'Notified' => isset($getNoteData->assigned_to_name) ? $getNoteData->assigned_to_name : "",
                'Created By' => isset($getNoteData->created_by_name) ? $getNoteData->created_by_name : "",
                'Last Date Attended' => isset($edmentumData[$note->student_id]) && !is_null($edmentumData[$note->student_id][0]->last_attended_in_edmentum) ? Carbon::parse($edmentumData[$note->student_id][0]->last_attended_in_edmentum)->format('m/d/Y') : "",


            ];
        }
    }

    private function getNoteData($student_id, $filters)
    {
        $sql = DB::table('notes')
            ->addSelect('notes.due_date')
            ->addSelect('notes.body')
            ->addSelect('notes.created_at')
            ->addSelect('notes.audience')
            ->addSelect('notes.type As note_type')
            ->addSelect('notes.status As note_status')
            ->addSelect('notes.starting_status As note_starting_status')
            ->addSelect('notes.following_date As note_following_date')
            ->addSelect('notes.following_note As note_following_note')
            ->addSelect('category.name As category')
            ->addSelect('subCategory.name As note_sub_category')
            ->addSelect('descriptor.name As note_descriptor')
            ->addSelect('action.name As note_action')
            ->addSelect(DB::raw("CONCAT(createdBy.first_name,' ', createdBy.last_name) as created_by_name"))
            ->addSelect(DB::raw("CONCAT(follower.first_name,' ', follower.last_name) as follower_name"))
            ->addSelect(DB::raw("CONCAT(assignedTo.first_name,' ', assignedTo.last_name) as assigned_to_name"))
            ->leftJoin('users As follower', 'notes.follower_id', '=', 'follower.id')
            ->leftJoin('users As createdBy', 'notes.creator_id', '=', 'createdBy.id')
            ->leftJoin('users As assignedTo', 'notes.assignee_id', '=', 'assignedTo.id')
            ->leftJoin('note_categories As category', 'notes.note_category_id', '=', 'category.id')
            ->leftJoin('note_categories As subCategory', 'notes.note_sub_category_id', '=', 'subCategory.id')
            ->leftJoin('note_categories As descriptor', 'notes.note_descriptor_id', '=', 'descriptor.id')
            ->leftJoin('note_categories As action', 'notes.note_action_id', '=', 'action.id')
            ->where('notes.id', $student_id)
            ->orderBy('notes.id', 'desc');

        if ($filters['range']['from'] and $filters['range']['to']) {
            if (isset($filters['range']['from'])) $sql->whereDate('notes.created_at', '>=', $filters['range']['from']);
            if (isset($filters['range']['to'])) $sql->whereDate('notes.created_at', '<=', $filters['range']['to']);
        }
        return $sql->first();
    }

    private function getGCAData($student_id)
    {

        $date = DB::table('students')
            ->addSelect(DB::raw("CONCAT(contentCoach.first_name,' ', contentCoach.last_name) as coach_name"))
            ->addSelect(DB::raw("CONCAT(GCA.first_name,' ', GCA.last_name) as GCA_name"))
            ->leftJoin('student_assignees as cc', function ($join) {
                $join->on('cc.student_id', '=', 'students.id')
                    ->where('cc.group', '=', 'teachers')->limit(1);
            })
            ->leftJoin('users As contentCoach', 'cc.user_id', '=', 'contentCoach.id')
            ->leftJoin('student_assignees as sa', function ($join) {
                $join->on('sa.student_id', '=', 'students.id')
                    ->where('sa.group', '=', 'para_professionals')->limit(1);
            })
            ->leftJoin('users AS GCA', 'sa.user_id', '=', 'GCA.id')
            ->where('students.id', $student_id)
            ->first();

        return $date;
    }
}
