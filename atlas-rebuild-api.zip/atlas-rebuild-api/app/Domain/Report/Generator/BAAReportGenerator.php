<?php

namespace App\Domain\Report\Generator;

use App\Domain\Lookup\Model\Timezone;
use App\Domain\Plp\PlanLibrary;
use App\Domain\Report\Generator\Helper\ReportHelper;
use App\Domain\Student\Model\Student;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class BAAReportGenerator extends BaseGenerator implements GeneratorInterface
{
    protected $planLibrary;
    protected $reportHelper;

    public function __construct(PlanLibrary $planLibrary, ReportHelper $reportHelper)
    {
        $this->planLibrary = $planLibrary;
        $this->reportHelper = $reportHelper;
    }

    public function generate($filters): iterable
    {
        ini_set('memory_limit', '-1');
        ini_set('max_execution_time', 0);
        $timezone = Auth::user()->timezone;
        $builder = Student::query()
            ->with([
                'edmentumActivityLearners' => function ($q) {
                    $q->whereDate('score_time', '>=', now()->subDays(90)->format('Y-m-d 00:00:00'));
                },
                'edmentumCoursewareAuditsLatest',
                'notes' => function ($q) {
                    $q->whereDate('created_at', '>=', now()->subDays(90)->format('Y-m-d 00:00:00'));
                }
            ])
            ->addSelect('students.id as id')
            ->addSelect('students.id as student_id')
            ->addSelect('students.street_address as street_address')
            ->addSelect('students.phone_1 as phone_1')
            ->addSelect('students.city as city')
            ->addSelect('students.street_address as address')
            ->addSelect('students.zip_code as zip_code')
            ->addSelect('students.state as state')
            ->addSelect('students.birthdate as birthdate')
            ->addSelect('students.first_name as first_name')
            ->addSelect('students.last_name as last_name')
            ->addSelect('statuses.name as gc_status')
            ->addSelect('phases.name as phase_name')
            ->addSelect('sites.name as site_name')
            ->addSelect('districts.name as district_name')
            ->addSelect('student_plp_plans.name as name')
            ->addSelect('student_attendance_entries.check_out as check_out')
            ->addSelect('student_plp_plans.content as plp_content')
             ->addSelect(DB::raw("CONCAT(GCA.first_name,' ', GCA.last_name) as GCA_name"))
           ->leftJoin('student_plp_plans', 'student_plp_plans.student_id', '=', 'students.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('student_attendance_entries', function ($join) {
                $whereQuery = 'SELECT st_ent.id FROM student_attendance_entries AS st_ent
                         WHERE st_ent.student_id = students.id
                         AND st_ent.check_out is not null ORDER BY check_in DESC LIMIT 1';

                $join->on('students.id', '=', 'student_attendance_entries.student_id')
                    ->whereRaw('student_attendance_entries.id = (' . $whereQuery . ')');
            })
            ->leftJoin('student_assignees as cc', function ($join) {
                $join->on('cc.student_id', '=', 'students.id')
                    ->where('cc.group', '=', 'teachers')->limit(1);
            })           
            ->leftJoin('student_assignees as sa', function ($join) {
                $join->on('sa.student_id', '=', 'students.id')
                    ->where('sa.group', '=', 'para_professionals')->limit(1);
            })
           
            ->leftJoin('users AS GCA', 'sa.user_id', '=', 'GCA.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', 'districts.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->where('student_plp_plans.active', '1')
            ->whereNotNull('student_plp_plans.name')
//            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filter($builder, $filters->toArray());
        $studentIds = $builder->pluck('students.student_id');

        $specialPrograms = $this->reportHelper->getSpecialPrograms($studentIds);

        if (count($studentIds) != 0) {
            $edmentumData = $this->getEdmentumData($studentIds->toArray());
           $activityCount = $this->getCoursecount($studentIds->toArray());
            $getLastAttendance30 = $this->getLastAttendane('30', $studentIds->toArray());
            $getLastAttendance90 = $this->getLastAttendane('90', $studentIds->toArray());
            $getLastAttendance60 = $this->getLastAttendane('60', $studentIds->toArray());
        }

        $plans = $builder->distinct()->get();

        $headers = [
            'Acceleration ID', 'District', 'Site', 'First Name', 'Last Name', 'Phase',
            'Status', 'Phone 1', 'Address', 'City', 'State', 'Zipcode',
            'Birthdate', 'Special Programs', 'GCA', 'GC Meets Requirements (y/n)', 'Course Start Date', 'Course Progress Last 90-Days', 'Course Progress Last 60-Days',
            'Course Progress Last 30-Days', 'Last Date of Progress', 'Total Credits Earned Last 90-Days', 'Attendance Last 90-Days (minutes)',
            'Attendance Last 60-Days (minutes)', 'Attendance Last 30-Days (minutes)', 'Last Date Attended', 'Instructional Time Last 90-Days',
            'Instructional Time Last 60-Days', 'Instructional Time Last 30-Days', 'Last Date Contacted'
        ];

        $courseAndAssessmentGroupHeaders = [];

        $courseAndAssessmentGroupHeaders = array_keys($courseAndAssessmentGroupHeaders);

        foreach (range(1, 12) as $i) {
            $courseAndAssessmentGroupHeaders[] = $this->createAssessmentName($i, 'Status');
            $courseAndAssessmentGroupHeaders[] = $this->createAssessmentName($i, 'Date Completed');
        }

        yield array_merge($headers, $courseAndAssessmentGroupHeaders);


        
        $checkGcMeetStaff = $this->checkGcMeetStaff($studentIds->toArray());
       
        foreach ($plans as $plan) {
//            GET LAST 30 DAYs learners
            $content = json_decode($plan->plp_content, true);
            $content = $this->planLibrary->addTierToPlpPlanContent($content, $plan);
            $studentSpecialPrograms = isset($specialPrograms[$plan->student_id]) ? $specialPrograms[$plan->student_id] : [];
            $programsName = [];
            if (count($studentSpecialPrograms) > 0) {
                foreach ($studentSpecialPrograms as $program) {
                    $programsName[] = $program->name;
                }
            }
            $programsName = implode(',', $programsName);
            $lastDateEdmentum = (isset($edmentumData[$plan->student_id]) && $edmentumData[$plan->student_id][0]->last_attended_in_edmentum) ? 
                Carbon::parse($edmentumData[$plan->student_id][0]->last_attended_in_edmentum)->format('m/d/Y') : null;
            $lastCreditsGranted = (isset($edmentumData[$plan->student_id]) && $edmentumData[$plan->student_id][0]->CreditsGranted) ? $edmentumData[$plan->student_id][0]->CreditsGranted : null;
            $checkOut = $plan->check_out ? Carbon::parse($plan->check_out)->timezone(
                $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC') : null;
            $lastAttendance30 = isset($getLastAttendance30[$plan->student_id]) ? (float)$getLastAttendance30[$plan->student_id][0]->login_minutes + (float)$getLastAttendance30[$plan->student_id][0]->check_in : 0;
            $checkGCMeetsRequirements = isset($lastCreditsGranted) ? $this->checkGCMeetsRequirements($lastCreditsGranted, $lastAttendance30, $checkGcMeetStaff) : null;

            $date90Days =
                $plan->edmentumActivityLearners && $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(90)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count()
                ? $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(90)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count() : "0";

            $date30Days =
                $plan->edmentumActivityLearners &&
                 $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(30)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count()
                ? $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(30)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count() : "0";

            $date60Days =
                $plan->edmentumActivityLearners && $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(60)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count()
                ? $plan->edmentumActivityLearners->where('score_time', '>=', now()->subDays(60)->format('Y-m-d 00:00:00'))
                    ->sortByDesc('score_time')->count() : "0";

            $firstAccess = $plan->edmentumCoursewareAuditsLatest && $plan->edmentumCoursewareAuditsLatest->first_access ? Carbon::parse($plan->edmentumCoursewareAuditsLatest->first_access)->format('m/d/Y') : null;
            $lastAccess = $plan->edmentumCoursewareAuditsLatest && $plan->edmentumCoursewareAuditsLatest->last_access ? Carbon::parse($plan->edmentumCoursewareAuditsLatest->last_access)->format('m/d/Y') : null;
           
       $activityCount30=  isset($activityCount[$plan->student_id][0]->activity_count30)? $activityCount[$plan->student_id][0]->activity_count30 :0;
       $activityCount60=  isset($activityCount[$plan->student_id][0]->activity_count60)? $activityCount[$plan->student_id][0]->activity_count60 :0;
       $activityCount90=  isset($activityCount[$plan->student_id][0]->activity_count90)? $activityCount[$plan->student_id][0]->activity_count90 :0;
            $data = [
                'Acceleration ID' => $plan->student_id,
                'District' => $plan->district_name,
                'Site' => $plan->site_name,
                'First Name' => $plan->first_name,
                'Last Name' => $plan->last_name,
                'Phase' => $plan->phase_name,
                'Status' => $plan->gc_status,
                'phone_1' => $plan->phone_1,
                'ِAddress' => $plan->address,
                'City' => $plan->city,
                'state' => $plan->state,
                'zip_code' => $plan->zip_code,
                'Birthdate' => $plan->birthdate,
                'Special Programs' => $programsName,
                'GCA' => $plan->GCA_name ? $plan->GCA_name : "",
                "GC Meets Requirements (y/n)" => $checkGCMeetsRequirements,
                "Course Start Date" => $firstAccess,
                "Course Progress Last 90 Days" => ($activityCount90 != 0)? $date90Days/$activityCount90.' %': '0',
                "Course Progress Last 60 Days" => ($activityCount60 != 0)? $date60Days/$activityCount60.' %': '0',
                "Course Progress Last 30 Days" => ($activityCount30 != 0)? $date30Days/$activityCount30.' %': '0',
                "Last Date of Progress" => $lastAccess,
                'Total Credits Earned Last 90-Days' => $lastCreditsGranted,
                'Attendance Last 90-Days (minutes)' => isset($getLastAttendance90[$plan->student_id]) ? (float)$getLastAttendance90[$plan->student_id][0]->login_minutes + (float)$getLastAttendance90[$plan->student_id][0]->check_in : 0,
                'Attendance Last 60-Days (minutes)' => isset($getLastAttendance60[$plan->student_id]) ? (float)$getLastAttendance60[$plan->student_id][0]->login_minutes + (float)$getLastAttendance60[$plan->student_id][0]->check_in : 0,
                'Attendance Last 30-Days (minutes)' => $lastAttendance30,
                'Last Date Attended' => ($checkOut > $lastDateEdmentum) ? $checkOut : $lastDateEdmentum,
                'Instructional Time Last 90-Days' => $plan->notes && $plan->notes->where('created_at', '>=', now()->subDays(90))->count() ? $plan->notes->where('created_at', '>=', now()->subDays(90))->sum('time_per_action') : 0,
                'Instructional Time Last 60-Days' => $plan->notes && $plan->notes->where('created_at', '>=', now()->subDays(60))->count() ? $plan->notes->where('created_at', '>=', now()->subDays(60))->sum('time_per_action') : 0,
                'Instructional Time Last 30-Days' => $plan->notes && $plan->notes->where('created_at', '>=', now()->subDays(30))->count() ? $plan->notes->where('created_at', '>=', now()->subDays(30))->sum('time_per_action') : 0,
                'Last Date Contacted' => $plan->notes && $plan->notes->sortByDesc('id')->count() ? $plan->notes->sortByDesc('id')->first()->last_date_contacted : null,
            ];

            $courseAndAssessmentCredits = [];
            if ($plan->plp_content != "") {
                foreach ($this->getAssessmentGroups($content['groups']) as $assessmentGroup) {

                    foreach ($assessmentGroup['courses'] as $i => $assessment) {
                        $courseAndAssessmentCredits[$this->createAssessmentName($i + 1, 'Status')] = Arr::get($assessment, 'status', 0);
                        $courseAndAssessmentCredits[$this->createAssessmentName($i + 1, 'Date Completed')] = Arr::get($assessment, 'date_taken', 0);
                    }
                }
                foreach ($courseAndAssessmentGroupHeaders as $header) {
                    $data[$header] = Arr::get($courseAndAssessmentCredits, $header);
                }

                yield $data;
            }
        }
    }

    protected function getCourseGroups($groups)
    {
        return collect($groups)->filter(function ($group) {
            return !Arr::get($group['group'], 'assessment');
        });
    }

    protected function getAssessmentGroups($groups)
    {
        return collect($groups)->filter(function ($group) {
            return Arr::get($group['group'], 'assessment');
        });
    }


    protected function createAssessmentName($assessment, $suffix = null)
    {
        $name = 'Assessment ' . $assessment;

        if ($suffix) $name .= ' ' . $suffix;

        return $name;
    }


    public function getEdmentumData(array $studentIds)
    {
        $ids = implode(',', $studentIds);
        $sql = "SELECT `students`.`id` AS `student_id`,
                  `aelt`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`,edmentum_credits_csv.SISID,
                  edmentum_credits_csv.	CreditsGranted
                FROM `students`
                    LEFT JOIN (
                            SELECT edmentum_learner_id,  MAX(`login_date`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_logins`
                            GROUP BY `edmentum_learner_id`
                             ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`
                    LEFT JOIN (
                        SELECT SISID, SUM(`CreditsGranted`) AS CreditsGranted
                        FROM `edmentum_credits_csv`
                        GROUP BY `SISID`
                    ) AS edmentum_credits_csv on `students`.`id` = `edmentum_credits_csv`.`SISID`
                 WHERE students.id IN ($ids)";

        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }

    public function getLastAttendane($time, $studentIds)
    {
        $ids = implode(',', $studentIds);
        $sql = "SELECT `students`.`id` AS `student_id`,
                  `ell`.`login_minutes` AS `login_minutes`,student_attendance_entries.check_in
                FROM `students`
                  LEFT JOIN (
                           SELECT edmentum_learner_id, sum(login_minutes) AS login_minutes
                            FROM `edmentum_learner_logins`
                            WHERE  edmentum_learner_logins.login_date >= DATE_SUB(NOW(), INTERVAL $time day)
                          group by edmentum_learner_id
                        ) AS ell on `students`.`id` = `ell`.`edmentum_learner_id`
                        LEFT JOIN (
                             SELECT  SUM(TIMESTAMPDIFF(MINUTE,check_in,check_out))  AS check_in,student_id
                            FROM `student_attendance_entries`
                      WHERE  student_attendance_entries.created_at >= DATE_SUB(NOW(), INTERVAL $time day)
                       group by student_id
                ) AS student_attendance_entries on `students`.`id` = `student_attendance_entries`.`student_id`
                 WHERE students.id IN ($ids)";


        return collect(DB::select($sql))->groupBy('student_id');
    }


    public function checkGcMeetStaff(array $studentIds)
    {
        $ids = implode(',', $studentIds);
        $sql = "SELECT `students`.`id` AS `student_id`,
                  student_schedule_entries.student_id, student_schedule_entries.date
                FROM `students`
                  LEFT JOIN (
                            SELECT student_id, date
                            FROM `student_schedule_entries`
                            WHERE  date >= DATE_SUB(NOW(), INTERVAL 7 day)
                        ) AS  student_schedule_entries on `students`.`id` = `student_schedule_entries`.`student_id`
                       WHERE students.id IN ($ids)";

        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }

    private function checkGCMeetsRequirements($lastCreditsGranted, $getLastAttendance30, $checkGcMeetStaff)
    {
        if ($lastCreditsGranted != "" and $getLastAttendance30 >= 120 and $checkGcMeetStaff != "") {
            return "Yes";
        } else {
            return "No";
        }
    }

    protected function filter($builder, $filters)
    {
        if (isset($filters['district'])&& !is_null($filters['district'])) $builder->where('districts.id', $filters['district']);

        if (isset($filters['assigned_to'])){
            $assignedId = $filters['assigned_to'];
            $builder->where(function($builder) use ($assignedId){
                $builder->orWhere('students.graduate_candidate_advocate_id', $assignedId)
                    ->orWhere('students.career_life_coach_id', $assignedId)
                    ->orWhere('students.content_coach_id', $assignedId);
            });
        }
    }

   
        public function getCoursecount(array $studentIds)
    {
        $ids = implode(',', $studentIds);
         $sql =
            "SELECT `students`.`id` AS `student_id`, COUNT(edmentum_class_activities30.activity_count30) As activity_count30,
                COUNT(edmentum_class_activities90.activity_count90)As activity_count90,
                COUNT(edmentum_class_activities60.activity_count60)As activity_count60
            FROM
                `students`                  
                    LEFT JOIN
                `edmentum_activity_learners` ON `edmentum_activity_learners`.`edmentum_learner_id` = `students`.`id`
              LEFT JOIN (
                SELECT edmentum_class_id,  count(`edmentum_class_id`) AS activity_count30
                FROM `edmentum_class_activities`
                 WHERE  created_at >= DATE_SUB(NOW(), INTERVAL 30 day)
                GROUP BY `edmentum_class_id`
                    ) AS edmentum_class_activities30 on `edmentum_activity_learners`.`edmentum_class_id` =
                     `edmentum_class_activities30`.`edmentum_class_id`  
                       LEFT JOIN (
                SELECT edmentum_class_id,  count(`edmentum_class_id`) AS activity_count60
                FROM `edmentum_class_activities`
                 WHERE  created_at >= DATE_SUB(NOW(), INTERVAL 60 day)
                GROUP BY `edmentum_class_id`
                    ) AS edmentum_class_activities60 on `edmentum_activity_learners`.`edmentum_class_id` =
                     `edmentum_class_activities60`.`edmentum_class_id` 
                       LEFT JOIN (
                SELECT edmentum_class_id,  count(`edmentum_class_id`) AS activity_count90
                FROM `edmentum_class_activities`
                 WHERE  created_at >= DATE_SUB(NOW(), INTERVAL 90 day)
                GROUP BY `edmentum_class_id`
                    ) AS edmentum_class_activities90 on `edmentum_activity_learners`.`edmentum_class_id` =
                     `edmentum_class_activities90`.`edmentum_class_id` 
              where  `students`.`deleted_at` is null         
                    AND `students`.`id` in ($ids)  GROUP BY `students`.`id` order by students.id DESC";
       $results = collect(DB::select($sql));
      //  $results->groupBy('student_id');
        return $results->groupBy('student_id');
    }
}

          
