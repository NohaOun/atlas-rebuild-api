<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\StudentFilterer;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class GcNavigatorReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(StudentFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As atlas_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('students.username')
            ->addSelect('students.password')
            ->addSelect('students.can_redeem')
            ->addSelect('students.referral_code')
            ->addSelect('students.phone_1')
            ->addSelect('students.created_at')
            ->addSelect('districts.name AS district')
            ->addSelect('sites.name AS site')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('students.tenant_id  As tenant')
            ->selectRaw('Sum(redemptions.points)  As total_points_redeemed')
            ->selectRaw('Max(redemptions.created_at)  As redemption_created_at')
            ->addSelect('GCA.first_name AS GCA_first_name')
            ->addSelect('GCA.last_name AS GCA_last_name')
            ->addSelect('students.birthdate AS birthdate')
            ->addSelect(['last_attend' => function ($query) {
                $query->select('started_at')
                    ->from('edmentum_learner_tasks')
                    ->whereColumn('edmentum_learner_id', 'students.id')
                    ->orderBy('edmentum_learner_tasks.id', 'desc')
                    ->limit(1);
            }])
            ->addSelect(['config' => function ($query) {
                $query->select('config')
                    ->from('tenants')
                    ->whereColumn('id', 'students.tenant_id')
                    ->limit(1);
            }])
            ->addSelect(['total_earned' => function ($query) {
                $query->select('total_points')
                    ->from('student_points')
                    ->whereColumn('student_id', 'students.id')
                    ->orderByRaw('student_points.created_at DESC , student_points.id desc')->limit(1);
            }])
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('users AS GCA', 'students.graduate_candidate_advocate_id', '=', 'GCA.id')
            ->leftJoin('redemptions', 'students.id', '=', 'redemptions.student_id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('assigned-district-ids'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC')
            ->groupBy(['students.id']);

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $studntes = $builder->get();

        yield [
            'District Partner',
            'Acceleration ID',
            'GC First Name',
            'GC Last Name',
            'Phase',
            'Status',
            'Created Date',
            'Navigator Username',
            'Last Login',
            'Navigator Password',
            'Navigator Referral Code',
            'Total Points Earned',
            'Total $ Earned',
            'Current Points Available',
            '$ Available',
            'Total Points Redeemed',
            '$ Redeemed',
            'Last Redemption Date',
            'GCA',
            'Phone Number',
            'Can Redeem?',
        ];

        foreach ($studntes as $student) {

            $content = json_decode($student->config, true);
            $content = Arr::get($content, 'site_settings');
            $points_to_dollar = Arr::get($content, 'points_to_dollars_factor');
            if ($points_to_dollar == "" or $points_to_dollar == 0) {
                $points_to_dollar = 1;
            }
            $current = $student->total_earned - $student->total_points_redeemed ;
            yield [
                'District Partner' => $student->district,
                'Acceleration ID' => $student->atlas_id,
                'GC First Name' => $student->first_name,
                'GC Last Name' => $student->last_name,
                'Phase' => $student->phase,
                'Status' => $student->status,
                'Created Date' => $student->created_at,
                'Navigator Username' => $student->username,
                'Last Login' => $student->last_attend,
                'Navigator Password' => strtolower(date('Y', strtotime($student->birthdate)) . substr($student->first_name, 0, 3)),
                'Navigator Referral Code' => $student->referral_code,
                'Total Points Earned' => $student->total_earned ? $student->total_earned : 0,
                'Total $ Earned' => $student->total_earned ? round($student->total_earned / $points_to_dollar, 2) : 0,
                'Current Points Available' => $current,
                '$ Available' => round($current / $points_to_dollar, 2),
                'Total Points Redeemed' => $student->total_points_redeemed,
                '$ Redeemed' => round($student->total_points_redeemed / $points_to_dollar, 2),
                'Last Redemption Date' => $student->redemption_created_at,
                'GCA' => $student->GCA_first_name . ' ' . $student->GCA_last_name,
                'Phone Number' => $student->phone_1,
                'Can Redeem?' => $student->can_redeem == 1 ? "Yes" : "No",
            ];
        }
    }
}
