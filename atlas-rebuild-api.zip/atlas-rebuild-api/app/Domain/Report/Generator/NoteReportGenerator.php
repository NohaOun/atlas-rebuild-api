<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\NoteFilterer;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class NoteReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(NoteFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('notes')
            ->addSelect('students.id As student_id')
            ->addSelect('students.status_id')
            ->addSelect('students.first_name As student_first_name')
            ->addSelect('students.last_name As student_last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('notes.due_date')
            ->addSelect('notes.body')
            ->addSelect('notes.created_at')
            ->addSelect('notes.audience')
            ->addSelect('notes.following_date')
            ->addSelect('notes.type As note_type')
            ->addSelect('notes.status As note_status')
            ->addSelect('notes.following_note As following_note')
            ->addSelect('category.name As category')
            ->addSelect('sub_category.name As note_sub_category')
            ->addSelect('descriptor.name As note_descriptor')
            ->addSelect('action.name As note_action')
            ->addSelect('assignee.first_name As assignee_first_name')
            ->addSelect('assignee.last_name As assignee_last_name')
            ->addSelect('creator.first_name As creator_first_name')
            ->addSelect('creator.last_name As creator_last_name')
            ->addSelect('follower.first_name As follower_first_name')
            ->addSelect('follower.last_name As follower_last_name')
            ->addSelect('note_statuses.name As student_status_at_creation')
            ->addSelect('note_phases.name As student_phase_at_creation')
            ->leftJoin('students', 'notes.student_id', '=', 'students.id')
            ->leftJoin('note_categories As category', 'notes.note_category_id', '=', 'category.id')
            ->leftJoin('note_categories As sub_category', 'notes.note_sub_category_id', '=', 'sub_category.id')
            ->leftJoin('note_categories As descriptor', 'notes.note_descriptor_id', '=', 'descriptor.id')
            ->leftJoin('note_categories As action', 'notes.note_action_id', '=', 'action.id')
            ->leftJoin('users As assignee', 'notes.assignee_id', '=', 'assignee.id')
            ->leftJoin('users As creator', 'notes.creator_id', '=', 'creator.id')
            ->leftJoin('users As follower', 'notes.follower_id', '=', 'follower.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('statuses AS note_statuses', 'notes.student_status_id', '=', 'note_statuses.id')
            ->leftJoin('phases AS note_phases', 'note_statuses.phase_id', '=', 'note_phases.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderBy('notes.created_at', 'DESC');

        $this->filterer->filter($builder, $filters->toArray());

        yield [
            'Acceleration ID', 'First Name', 'Last Name', 'District', 'Site', 'Current Phase',
            'Current Status', 'Category', 'Sub-Category', 'Descriptor', 'Action', 'Assigned To', 'Action Date',
            'Type', 'Audience', 'Notes', 'Created By', 'Note Created Date', 'Note Status',
            'Closed Date', 'Closed by', 'Closed Notes', 'Phase at Note Creation', 'Status at Note Creation'
        ];

        foreach($builder->get() as $note) {
            yield [
                'Acceleration ID' => $note->student_id,
                'First Name' => $note->student_first_name,
                'Last Name' => $note->student_last_name,
                'District' => $note->district,
                'Site' => $note->site,
                'Current Phase' => $note->phase,
                'Current Status' => $note->status,
                'Category' => $note->category,
                'Sub-Category' => $note->note_sub_category,
                'Descriptor' => $note->note_descriptor,
                'Action' => $note->note_action,
                'Assigned To' => $note->assignee_first_name . "  " . $note->assignee_last_name,
                'Action Date' => $note->due_date,
                'Type' => $note->note_type,
                'Audience' => $note->audience,
                'Notes' => $note->body,
                'Created By' => $note->creator_first_name . "  " . $note->creator_last_name,
                'Note Created Date' => $note->created_at ? Carbon::parse($note->created_at)->format('m/d/Y') : "",
                'Note Status' => $note->note_status,
                'Closed Date' => $note->following_date,
                'Closed by' => $note->follower_first_name . "  " . $note->follower_last_name,
                'Closed Notes' => $note->following_note,
                'Phase at Note Creation' => $note->student_phase_at_creation,
                'Status at Note Creation' => $note->student_status_at_creation
            ];
        }
    }
}
