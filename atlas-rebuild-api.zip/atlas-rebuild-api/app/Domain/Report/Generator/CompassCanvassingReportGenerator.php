<?php

namespace App\Domain\Report\Generator;

use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CompassCanvassingReportGenerator extends BaseGenerator implements GeneratorInterface
{
    public function generate($filters): iterable
    {
        $builder = DB::table('contacts')
            ->addSelect('contacts.id As contact_id')
            ->addSelect('contacts.old_system_id')
            ->addSelect('contacts.first_name')
            ->addSelect('contacts.last_name')
            ->addSelect('contacts.priority')
            ->addSelect('contacts.street_address_2')
            ->addSelect('contacts.street_address_1')
            ->addSelect('contacts.phone_1_bad')
            ->addSelect('contacts.created_at')
            ->addSelect('districts.name AS district')
            ->addSelect('contacts.district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('districts.name AS district_name')
            ->addSelect('sites.name AS site_name')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('category_contacts.name AS category_contact')          
            ->addSelect('contact_actions.created_at  As action_date')
            ->addSelect('contact_actions.note AS action_note')
            ->addSelect('contact_actions.created_at AS action_created_at')
            ->addSelect('sources.title AS source')
            ->addSelect('AB.first_name AS AB_first_name')
            ->addSelect('LAB.first_name AS LAB_first_name')
            ->addSelect('CB.first_name AS CB_first_name')
            ->addSelect('CB.last_name AS CB_last_name')
            ->addSelect('LAB.last_name AS LAB_last_name')
            ->addSelect('coa.first_name AS coa_first_name')
            ->addSelect('coa.last_name AS coa_last_name')
            ->addSelect('contacts.birthdate')
            ->addSelect('contacts.city')
            ->addSelect('contacts.state')
            ->addSelect('contacts.county')
            ->addSelect('contacts.zip_code')
            ->addSelect('contacts.bad_address')
            ->leftJoin('contact_actions', function ($join) {
                $join->on('contacts.id', '=', 'contact_actions.contact_id');
            })
          
            ->join('action_contacts', function ($join) {
                $join->on('action_contacts.id', '=', 'contact_actions.contact_action_id')                   
                    ->where('action_contacts.name','Home Visit');
            })
            ->leftJoin('statuses', 'contacts.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'contacts.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('users AS coa', 'contacts.community_outreach_advocate_id', '=', 'coa.id')
            ->leftJoin('users AS ora', 'contacts.outreach_resource_advocate_id', '=', 'ora.id')
            ->leftJoin('users AS AB', 'contact_actions.action_by', '=', 'AB.id')
            ->leftJoin('users AS LAB', 'contact_actions.action_by', '=', 'LAB.id')
            ->leftJoin('users AS CB', 'contacts.created_by', '=', 'CB.id')
            ->leftJoin('category_contacts', 'contact_actions.contact_category_id', '=', 'category_contacts.id')
            ->leftJoin('sources', 'sources.id', '=', 'contacts.source')
           
             ->whereNull('contacts.deleted_at')
              ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id' , app('assigned-district-ids'))
            ->where('contacts.tenant_id', tenant()->id)->where('contacts.duplicate', 0)->orderBy('contacts.id', 'desc')
            ->latest();

        if ($filters) $this->applyFilters($builder, $filters->toArray());
          $contactIds = $builder->pluck('contacts.contact_id');
          $getLatestActionDate = $this->getLatestActionDate($contactIds->toArray());
        $contacts = $builder->get();
     
       $headers = [
           'Enrollment Coach', 'District', 'Site', 'Contact First Name', 'Contact Last Name', 'Compass ID', 'Phase', 'Status', 'Priority', 'Total Action Count', 'Home Visit Count',  
            'Address 1', 'Address 2', 'City', 'state', 'zip', 'birthdate', 'Age', 'Date of Last Action',
            'Time of Last Action', 'Last Action Completed By', 'Last Action Note', 'Contact Created Date',
            'Contact Created Time', 'Countact Source', 'Contact Created By'
            
        ];
        $actionContactGroupHeaders = [];
        foreach ($contacts as $i=>$contact) {
            $actionContactGroupHeaders[] = $this->createActionContactName($i+1, 'Status');
            $actionContactGroupHeaders[] = $this->createActionContactName($i+1, 'User');
            $actionContactGroupHeaders[] = $this->createActionContactName($i+1, 'Date');
            $actionContactGroupHeaders[] = $this->createActionContactName($i+1, 'Time');
        }

 	 yield array_merge($headers, $actionContactGroupHeaders);										
        foreach ($contacts as $contact) {
            $count = $this->actionCountR(isset($contact->contact_id) ? $contact->contact_id : null);
            $homeVisitCount = $this->homeVisitCountR(isset($contact->contact_id) ? $contact->contact_id : null);
             $data = [     
                'Enrollment Coach' => $contact->coa_first_name ." ". $contact->coa_last_name,
                'District' => $contact->district_name,
                'Site' => $contact->site_name,
                'Contact First Name' => $contact->first_name,
                'Contact last name' => $contact->last_name,
                'Compass ID' => $contact->contact_id,
                'Phase' => $contact->phase,
                'Status' => $contact->status,
                'Priority' => $contact->priority,
                'Total Action Count' => $count ? $count : 0,
                'Home Visit Count' => $homeVisitCount ? $homeVisitCount : 0,               
                'Address 1' => $contact->street_address_1,
                'Address 2' => $contact->street_address_2,
                'City' => $contact->city,
                'State' => $contact->state,
                'zip' => $contact->zip_code,
                'birthdate' => $contact->birthdate,
                'Age' => Carbon::parse($contact->birthdate)->diff(Carbon::now())->format('%y years'),
                'Date of Last Action' => (isset($getLatestActionDate[$contact->contact_id]) && $getLatestActionDate[$contact->contact_id][0]->latest_created_at) ? Carbon::parse($getLatestActionDate[$contact->contact_id][0]->latest_created_at)->format('m/d/Y') : null,
                'Time of Last Action' =>(isset($getLatestActionDate[$contact->contact_id]) && $getLatestActionDate[$contact->contact_id][0]->latest_created_at) ? Carbon::parse($getLatestActionDate[$contact->contact_id][0]->latest_created_at)->format('H:i:s') : null,
                'Last Action Completed By' => $contact->LAB_first_name ." ". $contact->LAB_last_name,
                'Last Action Note' => Carbon::parse($contact->action_date)->format('m/d/Y'),
                'Contact Created Date' => Carbon::parse($contact->created_at)->format('m/d/Y'),
                'Contact Created Time' => Carbon::parse($contact->created_at)->format('H:i:s'),
                'Countact Source' =>$contact->source,
                'Contact Created By' => $contact->CB_first_name ." ". $contact->CB_last_name,
               
            ];
             $ActionContactData = [];
             foreach ($contacts as $i => $contact) {
                        $ActionContactData[$this->createActionContactName($i + 1, 'Status')] = $contact->status;
                        $ActionContactData[$this->createActionContactName($i + 1, 'User')] = $contact->AB_first_name;
                        $ActionContactData[$this->createActionContactName($i + 1, 'Date')] = Carbon::parse($contact->action_created_at)->format('m/d/Y');
                        $ActionContactData[$this->createActionContactName($i + 1, 'Time')] = Carbon::parse($contact->action_created_at)->format('H:i:s');
                    }
                    foreach ($actionContactGroupHeaders as $header) {
                    $data[$header] = Arr::get($ActionContactData, $header);
                }
            yield $data;
        }
    }

    protected function applyFilters(Builder $builder, $filters)
    {
        if (isset($filters['district'])) $builder->where('districts.id', $filters['district']);
           if (isset($filters['site'])) $builder->where('sites.id', $filters['site']);
       
        if ($range = Arr::get($filters, 'range') and $range['from'] !="" and $range['to'] !="") {
           $range['from']= Carbon::parse($range['from'])->format('Y-m-d H:i:s');
           $range['to']= Carbon::parse($range['to'])->format('Y-m-d H:i:s');

           if (isset($range['from'])) $builder->whereDate('contact_actions.created_at', '>=', $range['from']);
           if (isset($range['to'])) $builder->whereDate('contact_actions.created_at', '<=', $range['to']);
        }
        if (isset($filters['assigned_to'])) {
            $assignedId = $filters['assigned_to'];
            $builder->where(function ($builder) use ($assignedId) {
                $builder->orWhere('students.community_outreach_advocate_id', $assignedId)
                    ->orWhere('students.outreach_resource_advocate_id', $assignedId);
            });
        }
    }

    public function actionCountR($contact_id)
    {
        return DB::table('contact_actions')
            ->where('contact_id', $contact_id)
            ->count();
    }
    public function homeVisitCountR($contact_id)
    {
        return DB::table('contact_actions')
                 ->join('action_contacts', function ($join) {
                $join->on('action_contacts.id', '=', 'contact_actions.contact_action_id')                   
                    ->where('action_contacts.name','Home Visit');
            })
            ->where('contact_id', $contact_id)
            ->count();
    }
     protected function createActionContactName($text, $suffix = null)
    {
        $name = 'Home Visit ' . $text;

        if ($suffix) $name .= ' ' . $suffix;

        return $name;
    }
     public function getLatestActionDates(array $contactIds)
    {
        $ids = implode(',', $contactIds);
        $sql = "SELECT `contacts`.`id` AS `contact_id`,
                  `contact_actions`.`created_at` AS `latest_created_at`
                FROM `contacts`                
                 LEFT JOIN (
                            SELECT  contact_id,  MAX(`created_at`) AS latest_created_at
                            FROM `contact_actions`
                            GROUP BY `contact_id`
                        )As contact_actions  on `contacts`.`id` = `contact_actions`.`contact_id`
                 WHERE  contacts.id IN ($ids)";

        $results = collect(DB::select($sql));
         print_r($results);
        return $results->groupBy('contact_id');
    }
     private function getLatestActionDate(array $contactIds)
    {
           $ids = implode(',', $contactIds);
           $sql = DB::table('contacts')
                ->addSelect('contacts.id AS contact_id')           
             ->selectRaw('Max(contact_actions.created_at)  As latest_created_at')       
             ->leftJoin('contact_actions', 'contacts.id', '=', 'contact_actions.contact_id')
             ->groupBy(['contacts.id'])
             ->get();
        return $sql->groupBy('contact_id');
    }
}