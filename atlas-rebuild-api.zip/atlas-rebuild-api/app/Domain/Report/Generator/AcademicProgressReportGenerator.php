<?php

namespace App\Domain\Report\Generator;

use App\Domain\DashBoard\DashboardLibrary;
use App\Domain\Report\Generator\Concern\AcademicFilterer;
use App\Domain\Report\Generator\Helper\ReportHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;

class AcademicProgressReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $library;
    private $reportHelper;

    public function __construct(AcademicFilterer $filterer, DashboardLibrary $library, ReportHelper $reportHelper)
    {
        $this->filterer = $filterer;
        $this->library = $library;
        $this->reportHelper = $reportHelper;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', true)
            ->where('sites.active', true)
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if (isset($filters['site']) && !is_null($filters['site'])) $builder = $builder->where('students.site_id', $filters['site']);
        if (isset($filters['district']) && !is_null($filters['district'])) $builder = $builder->where('sites.district_id', $filters['district']);

        $studentIds = $builder->pluck('id');

        $students = $this->getActivityProgress($filters, $studentIds->toArray());

        $edmentumData = $this->getEdmentumData($filters, $studentIds->toArray());

        $specialPrograms = $this->reportHelper->getSpecialPrograms($studentIds);


        yield [
            'AA ID', 'First Name', 'Last Name', 'District', 'Site', 'Phase', 'Status', 'GCA',
            'Instructor Name', 'Special Programs', 'Last Login in Edmentum', 'Date Range Time on Task', 'Total Time on Task',
            'Date Range Time Logged In', 'Total Time Logged In', 'Current Course Name', 'Progress Percentage',
            'Date Range # Activities Scored', '# Activities Scored - Last 5 Days', '# Activities Scored - Last 10 Days',
            'Course Start Date', 'Days in Course'
        ];


        foreach ($students as $student) {

            $studentSpecialPrograms = isset($specialPrograms[$student->student_id]) ? $specialPrograms[$student->student_id] : [];

            $programsName = [];
            if (count($studentSpecialPrograms) > 0) {
                foreach ($studentSpecialPrograms as $program) {
                    $programsName[] = $program->name;
                }
            }

            $programsName = implode(',', $programsName);
            yield [
                'Acceleration ID' => $student->student_id,
                'First Name' => $student->first_name,
                'Last Name' => $student->last_name,
                'District' => $student->district,
                'Site' => $student->site,
                'Phase' => $student->phase,
                'Status' => $student->status,
                'GCA' => $student->gca_first_name . ' ' . $student->gca_last_name,
                'Instructor Name' => trim($student->instructor_name, " "),
                'Special Programs' => $programsName,
                'last_attend_in_edmentum' => (isset($edmentumData[$student->student_id]) && $edmentumData[$student->student_id][0]->last_attended_in_edmentum) ? Carbon::parse($edmentumData[$student->student_id][0]->last_attended_in_edmentum)->format('m/d/Y') : null,
                'Date Range Time on Task' => isset($edmentumData[$student->student_id]) ? intdiv($edmentumData[$student->student_id][0]->date_range_total_time_on_task, 60) . ':' . ($edmentumData[$student->student_id][0]->date_range_total_time_on_task % 60) . ":" . floor(($edmentumData[$student->student_id][0]->date_range_total_time_on_task / 60)) % 60 : "00:00:00",
                'total_time_on_task' => isset($edmentumData[$student->student_id]) ? intdiv($edmentumData[$student->student_id][0]->total_time_on_task, 60) . ':' . ($edmentumData[$student->student_id][0]->total_time_on_task % 60) . ":" . floor(($edmentumData[$student->student_id][0]->total_time_on_task / 60)) % 60 : "00:00:00",
                "Date Range Time Logged In" => isset($edmentumData[$student->student_id]) ? floor($edmentumData[$student->student_id][0]->date_range_time_login / 3600) . ":" . floor(($edmentumData[$student->student_id][0]->date_range_time_login / 60) % 60) . ":" . $edmentumData[$student->student_id][0]->date_range_time_login % 60 : "00:00:00",
                "Total Time Logged In" => isset($edmentumData[$student->student_id]) ? floor($edmentumData[$student->student_id][0]->total_time_login / 3600) . ":" . floor(($edmentumData[$student->student_id][0]->total_time_login / 60) % 60) . ":" . $edmentumData[$student->student_id][0]->total_time_login % 60 : "00:00:00",
                "Current Course Name" => $student->course_name,
                "Progress Percentage" => $student->percentage_complete,
                "Date Range # Activities Scored" => $student->date_range_score ? $student->date_range_score : 0,
                "# Activities Scored - Last 5 Days" => $student->date_5days_score ? $student->date_5days_score : 0,
                "# Activities Scored - Last 10 Days" => $student->date_10days_score ? $student->date_10days_score : 0,
                "Course Start Date" => $student->first_access ? Carbon::parse($student->first_access)->format('m/d/Y') : null,
                "Days in Course" => $student->days_in_course,
            ];
        }

    }

    public function getActivityProgress($filters, array $studentIds)
    {
        $date_from = $filters['range']['from'];
        $date_to = $filters['range']['to'];

        $ids = implode(',', $studentIds);
        $sql =  
            "SELECT DISTINCT
                `edmentum_class_learners`.`edmentum_class_id`,
                `students`.`id` AS `student_id`,
                `students`.`first_name`,
                `students`.`last_name`,
                `districts`.`name` AS `district`,
                `sites`.`name` AS `site`,
                `statuses`.`name` AS `status`,
                `phases`.`name` AS `phase`,
                `gca`.`first_name` AS `gca_first_name`,
                `gca`.`last_name` AS `gca_last_name`,
                `lcc`.`first_name` AS `lcc_first_name`,
                `edmentum_classes`.`resource_node_name` AS `course_name`,
                `lcc`.`last_name` AS `lcc_last_name`,
                `date_range_score`,
                `edmentum_activity_learners_5days`.`date_5days_score`,
                `edmentum_activity_learners_10days`.`date_10days_score`,
                edmentum_class_learners.start_at AS strat_at,
                edmentum_courseware_audits.first_access,
                edmentum_courseware_audits.instructor_name,
                `edmentum_courseware_audits`.`total_activities`,
                `edmentum_courseware_audits`.`total_activities_completed`,
                edmentum_courseware_audits.percentage_complete,
                IF(edmentum_courseware_audits.recommend_for_credit = 'Yes',
                    DATEDIFF(edmentum_courseware_audits.last_access,
                            edmentum_courseware_audits.first_access),
                    DATEDIFF(NOW(),
                            edmentum_courseware_audits.first_access)) days_in_course
            FROM
                `students`
                    LEFT JOIN
                `sites` ON `students`.`site_id` = `sites`.`id`
                    LEFT JOIN
                `districts` ON `sites`.`district_id` = `districts`.`id`
                    LEFT JOIN
                `statuses` ON `students`.`status_id` = `statuses`.`id`
                    LEFT JOIN
                `phases` ON `statuses`.`phase_id` = `phases`.`id`
                    LEFT JOIN
                `student_assignees` ON `student_assignees`.`student_id` = `students`.`id`
                    AND `student_assignees`.`group` = 'para_professionals'
                    LEFT JOIN
                `users` AS `gca` ON `student_assignees`.`user_id` = `gca`.`id`
                    LEFT JOIN
                `student_assignees` AS `student_lcc` ON `student_lcc`.`student_id` = `students`.`id`
                    AND `student_lcc`.`group` = 'teachers'
                    LEFT JOIN
                `users` AS `lcc` ON `student_lcc`.`user_id` = `lcc`.`id`
                    INNER JOIN
                `edmentum_class_learners` ON `edmentum_class_learners`.`edmentum_learner_id` = `students`.`id`
                    INNER JOIN
                `edmentum_classes` ON `edmentum_class_learners`.`edmentum_class_id` = `edmentum_classes`.`id`
                    INNER JOIN
                `edmentum_courseware_audits` ON edmentum_classes.provider_id = edmentum_courseware_audits.edmentum_class_id
                    AND edmentum_class_learners.edmentum_learner_id = edmentum_courseware_audits.student_id
                    LEFT JOIN
                (SELECT 
                    edmentum_learner_id,
                        edmentum_class_id,
                        COUNT(edmentum_activity_learners.id) AS date_range_score
                FROM
                    edmentum_activity_learners
                WHERE
                    edmentum_activity_learners.score_time >= '$date_from'
                        AND edmentum_activity_learners.score_time <= '$date_to'
                GROUP BY edmentum_learner_id , edmentum_class_id) AS edmentum_activity_learners_date_range ON edmentum_activity_learners_date_range.edmentum_learner_id = edmentum_class_learners.edmentum_learner_id
                    AND edmentum_activity_learners_date_range.edmentum_class_id = edmentum_class_learners.edmentum_class_id
                    LEFT JOIN
                VIEW_ACTIVITY_LAST_5_DAYS AS edmentum_activity_learners_5days ON edmentum_activity_learners_5days.edmentum_learner_id = edmentum_class_learners.edmentum_learner_id
                    AND edmentum_activity_learners_5days.edmentum_class_id = edmentum_class_learners.edmentum_class_id
                    LEFT JOIN
                VIEW_ACTIVITY_LAST_10_DAYS AS edmentum_activity_learners_10days ON edmentum_activity_learners_10days.edmentum_learner_id = edmentum_class_learners.edmentum_learner_id
                    AND edmentum_activity_learners_10days.edmentum_class_id = edmentum_class_learners.edmentum_class_id
                    where `students`.`deleted_at` is null and `districts`.`active` = 1 and `sites`.`active` = 1 and `students`.`id` in ($ids) order by students.id DESC";
        return DB::select($sql);
    }

    public function getEdmentumData($filters, array $studentIds)
    {
        $date_from = $filters['range']['from'];
        $date_to = $filters['range']['to'];
        $ids = implode(',', $studentIds);
        $sql = "SELECT `students`.`id` AS `student_id`,
                 `elt`.`date_range_total_time_on_task` AS `date_range_total_time_on_task`,
                  ell.date_range_time_login AS date_range_time_login,
                  tell.total_time_login AS total_time_login,
                  `aelt`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`,
                  `aelt`.`total_time_on_task` AS `total_time_on_task`

                FROM `students`
                LEFT JOIN (
                            SELECT edmentum_learner_id, SUM(`minutes`) AS date_range_total_time_on_task
                            FROM `edmentum_learner_tasks`
                             WHERE edmentum_learner_tasks.started_at >= '$date_from'  and edmentum_learner_tasks.started_at <= '$date_to'
                            GROUP BY `edmentum_learner_id`
                        ) AS elt on `students`.`id` = `elt`.`edmentum_learner_id`

                LEFT JOIN (
                            SELECT edmentum_learner_id, SUM(`login_minutes`) AS total_time_login
                            FROM `edmentum_learner_logins`
                            GROUP BY `edmentum_learner_id`
                        ) AS tell on `students`.`id` = `tell`.`edmentum_learner_id`
                 LEFT JOIN (
                            SELECT edmentum_learner_id, SUM(`login_minutes`) AS date_range_time_login
                            FROM `edmentum_learner_logins`
                             WHERE edmentum_learner_logins.login_date >= '$date_from' and edmentum_learner_logins.login_date <= '$date_to'
                            GROUP BY `edmentum_learner_id`
                        ) AS ell on `students`.`id` = `ell`.`edmentum_learner_id`
                 LEFT JOIN (
                            SELECT edmentum_learner_id, SUM(`minutes`) AS total_time_on_task, MAX(`started_at`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_tasks`
                            GROUP BY `edmentum_learner_id`
                        ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`
                 WHERE students.id IN ($ids)";

        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }
}
