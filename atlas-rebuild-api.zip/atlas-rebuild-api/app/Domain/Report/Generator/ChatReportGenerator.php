<?php

namespace App\Domain\Report\Generator;

use App\Domain\Plp\PlanLibrary;
use App\Domain\Report\Generator\Concern\ChatFilterer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Arr;

class ChatReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $planLibrary;

    public function __construct(ChatFilterer $filterer, PlanLibrary $planLibrary)
    {
        $this->filterer = $filterer;
        $this->planLibrary = $planLibrary;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('messages')
            ->addSelect('students.id As atlas_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('messages.flag')
            ->addSelect('messages.body')
            ->addSelect('messages.flag_created_at')  
            ->leftJoin('students', 'students.id', '=', 'messages.creator_id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->whereNull('students.deleted_at')
            ->whereNotNull('messages.flag')
            ->where('messages.creator_type', 'App\Domain\Student\Model\Student')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id' , app('assigned-district-ids'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');


        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $messages = $builder->get();

        yield [
            'AA ID', 'GC First Name',
            'GC Last Name', 'Flag Type', 'Flag Time', 'Message'
        ];

        foreach ($messages as $message) {

           
            yield [
                'AA ID' => $message->atlas_id,               
                'GC First Name' => $message->first_name,
                'GC Last Name' => $message->last_name ?? null,
                'Flag Type' => $message->flag,
                'Flag Time' => $message->flag_created_at,
                'Message' =>  $message->body
              
            ];
        }
    }
}
