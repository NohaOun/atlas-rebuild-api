<?php

namespace App\Domain\Report\Generator;

use App\Domain\Lookup\Model\Timezone;
use App\Domain\Report\Generator\Concern\StudentFilterer;
use App\Domain\Report\Generator\Helper\ReportHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class GcInfoReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $reportHelper;

    public function __construct(StudentFilterer $filterer, ReportHelper $reportHelper)
    {
        $this->filterer = $filterer;
        $this->reportHelper = $reportHelper;
    }

    public function generate($filters): iterable
    {
        $timezone = Auth::user()->timezone;

        $builder = DB::table('students')
            ->addSelect('students.id As student_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('students.phone_1')
            ->addSelect('students.phone_2')
            ->addSelect('students.street_address')
            ->addSelect('students.city')
            ->addSelect('students.state')
            ->addSelect('students.zip_code')
            ->addSelect('students.birthdate')
            ->addSelect('students.email')
            ->addSelect('students.gender')
            ->addSelect('students.emergency_contact_1_name')
            ->addSelect('students.emergency_contact_1_phone_1')
            ->addSelect('students.emergency_contact_1_email')
            ->addSelect('districts.name AS district')
            ->addSelect('students.district_id')
            ->addSelect('students.is_district_sis')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('students.created_at')
            ->addSelect('students.workflow_exception')
            ->addSelect('lookup_races.title AS race')
            ->addSelect('lookup_emergency_contact_relations.name AS emergency_relations')
            ->addSelect('student_attendance_entries.check_in as last_attend')
            ->addSelect('students.graduation_date')
            ->addSelect('students.withdrawal_date')
            ->addSelect('students.media_release')
            ->addSelect('students.enrichment_participation')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('lookup_races', 'students.race_id', '=', 'lookup_races.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('student_attendance_entries', function ($join) {
                $join->on('students.id', '=', 'student_attendance_entries.student_id')
                    ->whereRaw('student_attendance_entries.id = (
                        SELECT st_ent.id FROM student_attendance_entries AS st_ent
                         WHERE st_ent.student_id = students.id
                         ORDER BY check_in DESC LIMIT 1
                       )
                    ');
            })
            ->leftJoin('lookup_emergency_contact_relations', 'students.emergency_contact_1_relation_id', '=', 'lookup_emergency_contact_relations.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', 1)
            ->where('sites.active', 1)
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $studentIds = $builder->pluck('students.student_id');

        $specialPrograms = $this->reportHelper->getSpecialPrograms($studentIds);
        $studentsGCAs = $this->getStuddntsGCAs($studentIds);

        $students = $builder->get();

        yield [
            'Acceleration ID', 'District', 'School', 'District ID', 'First Name', 'Last Name', 'Phone1', 'Phone2', 'Address', 'City',
            'State', 'ZipCode', 'Birthdate', 'Email', 'Gender', 'Race', 'special Programs', 'Emergency Name', 'Emergency Relationship',
            'Emergency Phone', 'Emergency  Email',
            'Active In District SIS', 'Workflow Exception', 'GCA', 'Phase', 'Status', 'Media Release', 'Enrichment Participation',
            'Graduation Date', 'Created Date', 'Last Attended (Atlas)'
        ];

        foreach ($students as $student) {
            if ($student->gender == 'Male') {
                $student->gender = 'M';
            } elseif ($student->gender == 'Female') {
                $student->gender = 'F';
            } else {
                $student->gender = 'Unknown';
            }

            $studentSpecialPrograms = isset($specialPrograms[$student->student_id]) ? $specialPrograms[$student->student_id] : [];
            $studentGCAs = isset($studentsGCAs[$student->student_id]) ? $studentsGCAs[$student->student_id] : [];

            $programsName = [];
            if (count($studentSpecialPrograms) > 0) {
                foreach ($studentSpecialPrograms as $program) {
                    $programsName[] = $program->name;
                }
            }

            $gcaName = [];
            if (count($studentGCAs) > 0) {
                foreach ($studentGCAs as $item) {
                    $gcaName[] = $item->first_name . ' ' . $item->last_name;
                }
            }

            $programsName = implode(',', $programsName);

            yield [
                'Acceleration ID' => $student->student_id,
                'District' => $student->district,
                'School' => $student->site,
                'District ID' => $student->district_id,
                'First Name' => $student->first_name,
                'Last Name' => $student->last_name,
                'Phone 1' => $student->phone_1,
                'Phone 2' => $student->phone_2,
                'Address' => $student->street_address,
                'City' => $student->city,
                'State' => $student->state,
                'ZipCode' => $student->zip_code,
                'Birthdate' => $student->birthdate,
                'Email' => $student->email,
                'Gender' => $student->gender,
                'Race' => $student->race,
                'Special Programs' => $programsName,
                'Emergency Name' => $student->emergency_contact_1_name,
                'Emergency Relationship' => $student->emergency_relations,
                'Emergency Phone' => $student->emergency_contact_1_phone_1,
                'Emergency Email' => $student->emergency_contact_1_email,
                'Active In District SIS' => $student->is_district_sis == 1 ? "Yes" : "No",
                'Workflow Exception' => $student->workflow_exception == 1 ? "Yes" : "No",
                'GCA' => implode(',', $gcaName),
                'Phase' => $student->phase,
                'Status' => $student->status,
                'Media Release' => $student->media_release == 1 ? "Yes" : "No",
                'Enrichment Participation' => $student->enrichment_participation == 1 ? "Yes" : "No",
                'Graduation Date' => $student->graduation_date,
                'Created Date' => $student->created_at
                    ? Carbon::parse($student->created_at)->timezone(
                        $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC'
                    )->format('m/d/Y')
                    : "",
                'Last Attended (Atlas)' => $student->last_attend
                    ? Carbon::parse($student->last_attend)->timezone(
                        $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC'
                    )->format('m/d/Y')
                    : ''
            ];
        }
    }

    private function getStuddntsGCAs($studentIds)
    {
        $studentGCAs = DB::table('student_assignees')
            ->addSelect('student_assignees.student_id')
            ->addSelect('student_assignees.user_id')
            ->addSelect('users.first_name')
            ->addSelect('users.last_name')
            ->join('users', 'users.id', '=', 'student_assignees.user_id')
            ->where('student_assignees.group', '=', 'para_professionals')
            ->get();
        return $studentGCAs->groupBy('student_id');
    }
}
