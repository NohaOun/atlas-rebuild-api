<?php


namespace App\Domain\Report\Generator\Helper;


use Illuminate\Support\Facades\DB;

class ReportHelper
{
    public function getSpecialPrograms($ids)
    {
        $specialPrograms = DB::table('special_program_student')
            ->addSelect('special_program_student.student_id')
            ->addSelect('lookup_special_programs.name')
            ->join('lookup_special_programs', 'lookup_special_programs.id', '=', 'special_program_student.special_program_id')
            ->whereIn('special_program_student.student_id', $ids)
            ->get();

        return $specialPrograms->groupBy('student_id');
    }

    public function getEdmenumData()
    {
        $sql = "SELECT `students`.`id` AS `student_id`,

                  `aelt`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`
                FROM `students`
                 LEFT JOIN (
                            SELECT edmentum_learner_id,  MAX(`started_at`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_tasks`
                            GROUP BY `edmentum_learner_id`
                        ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`";

        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }

}
