<?php

namespace App\Domain\Report\Generator\Concern;

use Illuminate\Database\Query\Builder;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Support\Arr;

class GcNavigatorRedemptionReportFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district']) && !is_null($filters['district'])) {
            $builder->where('districts.id', $filters['district']);
        }
        if (isset($filters['site'])) {
            $builder->where('sites.id', $filters['site']);
        }

        if ($phases = Arr::get($filters, 'phases')) {
            $builder
                ->join('statuses', 'students.status_id', '=', 'statuses.id')
                ->join('phases', function (JoinClause $join) {
                    $join->on('statuses.phase_id', '=', 'phases.id')->where('phases.name', '!=', 'Duplicate');
                })
                ->whereIn('phases.id', $phases);

            if ($status = Arr::get($filters, 'status')) {
                $builder->where('statuses.id', $status);
            }
        }

        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('vouchers.created_at', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('vouchers.created_at', '<=', $range['to']);
        }
    }
}
