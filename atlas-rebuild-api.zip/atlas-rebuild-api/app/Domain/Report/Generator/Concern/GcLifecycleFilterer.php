<?php

namespace App\Domain\Report\Generator\Concern;

use App\Domain\Phase\Model\Phase;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class GcLifecycleFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district']) && !is_null($filters['district'])) $builder->where('districts.id', $filters['district']);
        if (isset($filters['site'])) $builder->where('sites.id', $filters['site']);
        if (isset($filters['phases']) && (!empty($filters['phases']))) $builder->whereIn('current_statuses.phase_id', $filters['phases']);
        if (isset($filters['status']) && !is_null($filters['status'])) $builder->where('current_statuses.id', $filters['status']);

        if ($from = Arr::get($filters, 'range.from')) {
            if (isset($from['day'])) $builder->where(DB::raw('DAY(students.created_at)'), '>=', $from['day']);
            if (isset($from['month'])) $builder->where(DB::raw('MONTH(students.created_at)'), '>=', $from['month']);
            if (isset($from['year'])) $builder->where(DB::raw('Year(students.created_at)'), '>=', $from['year']);
        }

        if ($to = Arr::get($filters, 'range.to')) {
            if (isset($to['day'])) $builder->where(DB::raw('DAY(students.created_at)'), '<=', $to['day']);
            if (isset($to['month'])) $builder->where(DB::raw('MONTH(students.created_at)'), '<=', $to['month']);
            if (isset($to['year'])) $builder->where(DB::raw('Year(students.created_at)'), '<=', $to['year']);
        }

        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('students.created_at', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('students.created_at', '<=', $range['to']);
        }


    }
}
