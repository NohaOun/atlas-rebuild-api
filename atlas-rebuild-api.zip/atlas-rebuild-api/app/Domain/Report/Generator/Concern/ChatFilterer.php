<?php

namespace App\Domain\Report\Generator\Concern;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;

class ChatFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('messages.created_at', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('messages.created_at', '<=', $range['to']);
        }


    }
}
