<?php

namespace App\Domain\Report\Generator\Concern;

use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;

class WorkFlowFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district']) && !is_null($filters['district'])) $builder->where('sites.district_id', $filters['district']);
        if (isset($filters['site']) && !is_null($filters['site'])) $builder->where('sites.id', $filters['site']);
        if (isset($filters['phases']) && (!empty($filters['phases']))) $builder->whereIn('phases.id', $filters['phases']);
        if (isset($filters['status'])&& !is_null($filters['status'])) $builder->where('statuses.id', $filters['status']);

        if (isset($filters['assigned_to'])){
            $assignedId = $filters['assigned_to'];
            $builder->where(function($builder) use ($assignedId){
                $builder->orWhere('students.graduate_candidate_advocate_id', $assignedId)
                    ->orWhere('students.career_life_coach_id', $assignedId)
                    ->orWhere('students.content_coach_id', $assignedId);
            });
        }

        if ($range = Arr::get($filters, 'range')) {
            $from = $range['from'];
            $to = $range['to'];
            if (isset($range['from'])) $builder->where(function($query) use ($from){
                $query->orWhere('status_history.created_at', '>=', $from);
                $query->orWhere('status_history.exited_at', '>=', $from);

            });
            if (isset($range['to'])) $builder->where(function($query) use ($to){
                $query->orWhere('status_history.created_at', '<=', $to);
                $query->orWhere('status_history.exited_at', '<=', $to);

            });
        }
    }
}
