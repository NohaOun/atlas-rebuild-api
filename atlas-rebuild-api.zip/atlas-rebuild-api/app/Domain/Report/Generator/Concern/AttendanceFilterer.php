<?php

namespace App\Domain\Report\Generator\Concern;

use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class AttendanceFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district'])) $builder->where('sites.district_id', $filters['district']);

        if (isset($filters['attendance_date'])) {
            $builder->where(function (Builder $builder) use ($filters) {
                foreach ($filters['attendance_date'] as $index => $date) {
                    $date = Carbon::parse($date)->format('Y-m-d');

                    if ($index === 0) $builder->whereDate('student_attendance_entries.created_at', $date);
                    else $builder->orWhereDate('student_attendance_entries.created_at', '=', $date);
                }
            });
        }

        if (isset($filters['assigned_to'])) {
            $assignedId = $filters['assigned_to'];
            $builder->where(function ($builder) use ($assignedId) {
                $builder->orWhere('students.graduate_candidate_advocate_id', $assignedId)
                    ->orWhere('students.career_life_coach_id', $assignedId)
                    ->orWhere('students.content_coach_id', $assignedId);
            });
        }

        if ($from = Arr::get($filters, 'range.from')) {
            if (isset($from['day'])) $builder->where(DB::raw('DAY(student_attendance_entries.created_at)'), '>=', $from['day']);
            if (isset($from['month'])) $builder->where(DB::raw('MONTH(student_attendance_entries.created_at)'), '>=', $from['month']);
            if (isset($from['year'])) $builder->where(DB::raw('Year(student_attendance_entries.created_at)'), '>=', $from['year']);
        }

        if ($to = Arr::get($filters, 'range.to')) {
            if (isset($to['day'])) $builder->where(DB::raw('DAY(student_attendance_entries.created_at)'), '<=', $to['day']);
            if (isset($to['month'])) $builder->where(DB::raw('MONTH(student_attendance_entries.created_at)'), '<=', $to['month']);
            if (isset($to['year'])) $builder->where(DB::raw('Year(student_attendance_entries.created_at)'), '<=', $to['year']);
        }

        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('student_attendance_entries.check_in', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('student_attendance_entries.check_in', '<=', $range['to']);
        }

        if (isset($filters['gca'])) $builder->where('student_assignees.user_id', $filters['gca'])->where('student_assignees.group', '=', 'para_professionals');
    }
}
