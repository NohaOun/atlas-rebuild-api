<?php

namespace App\Domain\Report\Generator\Concern;

use Illuminate\Database\Query\Builder;

class StudentScheduleFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district']) && !is_null($filters['district'])) $builder->where('sites.district_id', $filters['district']);

        if (isset($filters['assigned_to'])){
            $assignedId = $filters['assigned_to'];
            $builder->where(function($builder) use ($assignedId){
                $builder->orWhere('students.graduate_candidate_advocate_id', $assignedId)
                    ->orWhere('students.career_life_coach_id', $assignedId)
                    ->orWhere('students.content_coach_id', $assignedId);
            });
        }
    }
}
