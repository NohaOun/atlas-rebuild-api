<?php

namespace App\Domain\Report\Generator\Concern;

use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class ContactFilterer
{
    public function filter(Builder $builder, $filters)
    {
        if (isset($filters['district']) && !is_null($filters['district'])) $builder->where('districts.id', $filters['district']);
        if (isset($filters['site'])) $builder->where('sites.id', $filters['site']);
        if (isset($filters['phases']) && (!empty($filters['phases']))) $builder->whereIn('statuses.phase_id', $filters['phases']);
        if (isset($filters['status']) && !is_null($filters['status'])) $builder->where('statuses.id', $filters['status']);


        if ($from = Arr::get($filters, 'range.from')) {
            if (isset($from['day'])) $builder->where(DB::raw('DAY(contacts.created_at)'), '>=', $from['day']);
            if (isset($from['month'])) $builder->where(DB::raw('MONTH(contacts.created_at)'), '>=', $from['month']);
            if (isset($from['year'])) $builder->where(DB::raw('Year(contacts.created_at)'), '>=', $from['year']);
        }

        if ($to = Arr::get($filters, 'range.to')) {
            if (isset($to['day'])) $builder->where(DB::raw('DAY(contacts.created_at)'), '<=', $to['day']);
            if (isset($to['month'])) $builder->where(DB::raw('MONTH(contacts.created_at)'), '<=', $to['month']);
            if (isset($to['year'])) $builder->where(DB::raw('Year(contacts.created_at)'), '<=', $to['year']);
        }

        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('contacts.created_at', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('contacts.created_at', '<=', $range['to']);
        }


    }
}
