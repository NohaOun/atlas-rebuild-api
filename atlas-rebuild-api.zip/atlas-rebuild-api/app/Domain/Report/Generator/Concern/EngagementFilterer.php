<?php

namespace App\Domain\Report\Generator\Concern;

use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class EngagementFilterer
{
    public function filter(Builder $builder, $filters)
    {

        if (isset($filters['district']) && !is_null($filters['district'])) $builder->where('sites.district_id', $filters['district']);

//        if ($range = Arr::get($filters, 'range') and $range['from'] !="" and $range['to'] !="") {
//           $range['from']= Carbon::parse($range['from'])->format('Y-m-d H:i:s');
//           $range['to']= Carbon::parse($range['to'])->format('Y-m-d H:i:s');
//
//            if (isset($range['from'])) $builder->where('students.created_at', '>=', $range['from']);
//            if (isset($range['to'])) $builder->where('students.created_at', '<=', $range['to']);
//        }
//

    }
}
