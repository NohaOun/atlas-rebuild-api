<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\StudentFilterer;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class GcNavigatorPointsReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(StudentFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('student_points.added_points')
            ->addSelect('student_points.challenge_name')
            ->addSelect('challenges.name')
            ->addSelect('student_points.created_at')
            ->join('student_points', 'student_points.student_id', '=', 'students.id')
            ->leftJoin('challenges', 'student_points.challenge_id', '=', 'challenges.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($range = Arr::get($filters, 'range')) {
            if (isset($range['from'])) $builder->whereDate('student_points.created_at', '>=', $range['from']);
            if (isset($range['to'])) $builder->whereDate('student_points.created_at', '<=', $range['to']);
        }

        unset($filters['range']);

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $sql = " SELECT `students`.`id`, `aelt`.`last_attend`
                        from `students`
                        INNER JOIN (
                            SELECT edmentum_learner_id,  MAX(`started_at`) AS last_attend
                            FROM `edmentum_learner_tasks`
                            GROUP BY `edmentum_learner_id`
                        ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`";
        $results = collect(DB::select($sql));

        $studentAttend = $results->groupBy('id');

        $students = $builder->get();

        yield [
            'Student ID' => 'Student ID',
            'GC First Name' => 'GC First Name',
            'GC Last Name' => 'GC Last Name',
            'Points Earned' => 'Points Earned',
            'Earned For' => 'Earned For',
            'Badge Name' => 'Badge Name',
            'Date Earned' => 'Date Earned',
            'Last Login' => 'Last Login',
        ];
        foreach ($students as $student) {
            yield [
                'Student ID' => $student->id,
                'GC First Name' => $student->first_name,
                'GC Last Name' => $student->last_name,
                'Points Earned' => $student->added_points,
                'Earned For' => $student->challenge_name,
                'Badge Name' => $student->name,
                'Date Earned' => $student->created_at,
                'Last Login' => isset($studentAttend[$student->id]) ? Carbon::parse($studentAttend[$student->id][0]->last_attend)->format('m/d/Y') : 0,
            ];
        }
    }
}
