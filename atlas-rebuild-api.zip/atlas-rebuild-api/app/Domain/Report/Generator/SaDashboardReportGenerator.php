<?php

namespace App\Domain\Report\Generator;

use App\Domain\DashBoard\DashboardLibrary;

class SaDashboardReportGenerator extends BaseGenerator implements GeneratorInterface
{
    /**
     * @var DashboardLibrary
     */
    private $library;

    public function __construct(DashboardLibrary $library)
    {
        $this->library = $library;
    }

    public function generate($filters): iterable
    {
        $records = $this->library->getCaseManagementTable($filters, null, true);

        yield [
            'AA ID', 'First Name', 'Last Name', 'Phase', 'Status', 'District',
            'Site', 'Last Day of Attendance', 'Avg. Time on Site (Weekly)', 'Last Login in Edmentum',
            'Total Time in System', 'Date of Last Contact', 'Last Point of Contact',
            'GCA', 'Content Coach'
        ];

        foreach ($records as $record) {
            yield [
                'AA ID' => $record->id,
                'First Name' => $record->first_name,
                'Last Name' => $record->last_name,
                'Phase' => $record->phase,
                'Status' => $record->status,
                'District' => $record->district,
                'Site' => $record->site,
                'Last Day of Attendance' => $record->last_attended,
                'Avg. Time on Site (Weekly)' => $record->avg_time_in_system . 'h',
                'Last Login in Edmentum' => $record->last_attended_in_edmentum,
                "Total Time in System" => $record->total_time_on_task,
                'Date of Last Contact' => $record->date_of_last_contact,
                'Last Point of Contact' => $record->last_point_of_contact_first_name
                    . ' '
                    . $record->last_point_of_contact_last_name,
                'GCA' => $record->gca_first_name . ' ' . $record->gca_last_name,
                'Content Coach' => $record->content_coach_first_name
                    . ' '
                    . $record->content_coach_last_name
            ];
        }
    }
}
