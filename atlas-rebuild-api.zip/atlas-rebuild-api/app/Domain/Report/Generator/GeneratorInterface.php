<?php

namespace App\Domain\Report\Generator;

interface GeneratorInterface
{
    public function generate($filters): iterable;
}
