<?php

namespace App\Domain\Report\Generator;

abstract class BaseGenerator
{
}
