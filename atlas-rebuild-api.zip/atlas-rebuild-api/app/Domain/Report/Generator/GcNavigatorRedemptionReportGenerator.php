<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\GcNavigatorRedemptionReportFilterer;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class GcNavigatorRedemptionReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(GcNavigatorRedemptionReportFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('vouchers')
            ->addSelect('students.id AS atlas_id')
            ->addSelect('students.first_name AS gc_first_name')
            ->addSelect('students.last_name AS gc_last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('sites.name AS site')
            ->addSelect('vouchers.created_at AS redemption_date')
            ->addSelect('vouchers.amount AS amount')
            ->addSelect('vouchers.merchant AS gift_card_merchant')
            ->addSelect(['last_login' => function ($query) {
                $query->select('started_at')
                    ->from('edmentum_learner_tasks')
                    ->whereColumn('edmentum_learner_id', 'students.id')
                    ->orderBy('edmentum_learner_tasks.id', 'desc')
                    ->limit(1);
            }])
            ->addSelect(['total_points_earned' => function ($query) {
                $query->select('total_points')
                    ->from('student_points')
                    ->whereColumn('student_id', 'students.id')
                    ->orderBy('student_points.id', 'desc')
                    ->limit(1);
            }])
            ->join('students', 'vouchers.student_id', '=', 'students.id')
            ->join('sites', 'students.site_id', '=', 'sites.id')
            ->join('districts', 'sites.district_id', '=', 'districts.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderBy('redemption_date');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $records = $builder->get();

        yield [
            'Atlas ID', 'GC First Name', 'GC Last Name', 'District', 'Site', 'Total Points Earned',
            'Redemption Date', 'Points Redeemed', '$ Amount', 'Gift Card Merchant', 'Last Login',
        ];

        foreach ($records as $record) {
            $factor = floatval(Arr::get(tenant()->config, 'site_settings.points_to_dollars_factor'));

            if (!is_numeric($factor) || $factor == 0) {
                $factor = 1;
            }

            yield [
                'Atlas ID' => $record->atlas_id,
                'GC First Name' => $record->gc_first_name,
                'GC Last Name' => $record->gc_last_name,
                'District' => $record->district,
                'Site' => $record->site,
                'Total Points Earned' => $record->total_points_earned,
                'Redemption Date' => $record->redemption_date,
                'Points Redeemed' => round((float)$record->amount * $factor, 2),
                '$ Amount' => '$' . $record->amount,
                'Gift Card Merchant' => $record->gift_card_merchant,
                'Last Login' => $record->last_login,
            ];
        }
    }
}
