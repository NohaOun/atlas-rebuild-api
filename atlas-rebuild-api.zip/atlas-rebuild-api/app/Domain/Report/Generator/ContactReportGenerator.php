<?php

namespace App\Domain\Report\Generator;

use Illuminate\Database\Query\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ContactReportGenerator extends BaseGenerator implements GeneratorInterface
{
    public function generate($filters): iterable
    {
        $builder = DB::table('contacts')
            ->addSelect('contacts.id')
            ->addSelect('contacts.old_system_id')
            ->addSelect('contacts.first_name')
            ->addSelect('contacts.last_name')
            ->addSelect('contacts.phone_1')
            ->addSelect('contacts.phone_2')
            ->addSelect('contacts.street_address_1')
            ->addSelect('contacts.phone_1_bad')
            ->addSelect('contacts.created_at')
            ->addSelect('districts.name AS district')
            ->addSelect('contacts.district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('category_contacts.name AS category_contact')

            ->addSelect('contact_actions.created_at AS action_date')
            ->addSelect('contact_actions.note AS action_note')
            ->addSelect('ora.first_name AS ora_first_name')
            ->addSelect('ora.last_name AS ora_last_name')
            ->addSelect('coa.first_name AS coa_first_name')
            ->addSelect('coa.last_name AS coa_last_name')
            ->addSelect('contacts.birthdate')
            ->addSelect('contacts.city')
            ->addSelect('contacts.state')
            ->addSelect('contacts.county')
            ->addSelect('contacts.zip_code')
            ->addSelect('contacts.bad_address')

            ->leftJoin('contact_actions', 'contacts.id', '=', 'contact_actions.contact_id')
            ->leftJoin('statuses', 'contacts.status_id', '=', 'statuses.id')
            ->leftJoin('sites', 'contacts.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('users AS coa', 'contacts.community_outreach_advocate_id', '=', 'coa.id')
            ->leftJoin('users AS ora', 'contacts.outreach_resource_advocate_id', '=', 'ora.id')
            ->leftJoin('category_contacts', 'contact_actions.contact_category_id', '=', 'category_contacts.id')

             ->whereNull('contacts.deleted_at')
              ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id' , app('assigned-district-ids'))
            ->where('contacts.tenant_id', tenant()->id)->where('contacts.duplicate', 0)->orderBy('contacts.id', 'desc')->latest();

        if ($filters) $this->applyFilters($builder, $filters->toArray());

        $contacts = $builder->get();

        yield [
           'First Name', 'last name', 'Phone Number', 'Phone Number2', 'birthdate',
            'Address', 'City', 'state', 'zip', 'ORA', 'COA', 'Compass Phase', 'Compass Status',
            'Contact Created Date', 'Action Count', 'Action Category',
            'Action Note Created Date', 'Action Note', 'Bad Number', 'Bad Address',
        ];

        foreach ($contacts as $contact) {
            $count = $this->actionCountR(isset($contact->id) ? $contact->id : null);
            yield [
                'First Name' => $contact->first_name,
                'last name' => $contact->last_name,
                'Phone Number' => $contact->phone_1,
                'Phone Number2' => $contact->phone_2,
                'birthdate' => $contact->birthdate,
                'Address' => $contact->street_address_1,
                'City' => $contact->city,
                'State' => $contact->state,
                'zip' => $contact->zip_code,
                'ORA' => $contact->ora_first_name ." ". $contact->ora_last_name,
                'COA' => $contact->coa_first_name ." ". $contact->coa_last_name,
                'Compass Phase' => $contact->phase,
                'Compass Status' => $contact->status,
                'Contact Created Date' => Carbon::parse($contact->created_at)->format('m/d/Y'),
                'Action Count' => $count ? $count : 0,
                'Action Category' => $contact->category_contact,
                'Action Note Created Date' => Carbon::parse($contact->action_date)->format('m/d/Y'),
                'Action Note' => $contact->action_note,
                'Bad Number' => $contact->phone_1_bad == 1 ? "Yes":"No" ,
                'bad address' => $contact->bad_address == 1 ? "Yes":"No" ,
            ];
        }
    }

    protected function applyFilters(Builder $builder, $filters)
    {
        if (isset($filters['district'])) $builder->where('districts.id', $filters['district']);

        if ($range = Arr::get($filters, 'range') and $range['from'] !="" and $range['to'] !="") {
           $range['from']= Carbon::parse($range['from'])->format('Y-m-d H:i:s');
           $range['to']= Carbon::parse($range['to'])->format('Y-m-d H:i:s');

           if (isset($range['from'])) $builder->whereDate('contact_actions.created_at', '>=', $range['from']);
           if (isset($range['to'])) $builder->whereDate('contact_actions.created_at', '<=', $range['to']);
        }
        if (isset($filters['assigned_to'])) {
            $assignedId = $filters['assigned_to'];
            $builder->where(function ($builder) use ($assignedId) {
                $builder->orWhere('students.community_outreach_advocate_id', $assignedId)
                    ->orWhere('students.outreach_resource_advocate_id', $assignedId);
            });
        }
    }

    public function actionCountR($contact_id)
    {
        return DB::table('contact_actions')
            ->join('category_contacts', 'category_contacts.id', 'contact_actions.contact_action_id')
            ->where('category_contacts.name', '!=', 'Internal Contact')
            ->where('contact_id', $contact_id)
            ->count();
    }
}
