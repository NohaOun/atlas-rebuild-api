<?php

namespace App\Domain\Report\Generator;

use App\Domain\User\Repository\UserRepositoryInterface;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class UserPermissionReportGenerator extends BaseGenerator implements GeneratorInterface
{
    public $userRepo;
    private $tenantId;

    public function __construct(UserRepositoryInterface $userRepo, Request $request)
    {
        $this->userRepo = $userRepo;
        $this->tenantId = $request->header('X-TENANT-ID');
    }

    public function generate($filters): iterable
    {
        $users = $this->userRepo->getUsers($filters = null);
        $permissions = $this->getPermissions();

        yield $this->getHeaders($permissions);

        foreach ($users as $user) {
            $districts = $this->getUserDistricts($user->id);
            $disrtictsName = Array();
            if (count($districts) > 0) {
                foreach ($districts as $disrtict) {
                    $disrtictsName[] = $disrtict->district_name;
                }
            }
            $disrtictsName = implode(',', $disrtictsName);

            $data = [
                'User First Name' => $user->first_name,
                'User Last Name' => $user->last_name,
                'User Email' => $user->email,
                'District' => $disrtictsName,                
                'User Role' => $user->role_name,
                'User Title' => $user->title,
                'Active' => $user->active==1 ? "Yes" : "No",
            ];

            $userPermissions = $this->getTenantUserPermissions($user);

            foreach ($permissions as $permission) {
                $data[$permission->name] = in_array($permission->name, $userPermissions) ? "Yes" : "No";
            }
            yield $data;
        }
    }

    public function getPermissions()
    {
        return DB::table('permissions')->get();
    }

    public function getHeaders($permissions)
    {
        $data = ['User First Name', 'User Last Name', 'User Email', 'District', 'User Role', 'User Title' , 'Active'];
        if (count($permissions) > 0) {
            foreach ($permissions as $permission) {
                $data[] = $permission->name;
            }
        }
        return $data;
    }

    public function getTenantUserPermissions($user)
    {
        $tenantUser = $this->userRepo->getTenantUser($user->id, $this->tenantId);

        $userPermissions = [];
        if ($tenantUser && count($tenantUser->permissions) > 0) {
            foreach ($tenantUser->permissions as $item) {
                $userPermissions[] = $item->name;
            }
        }
        return $userPermissions;
    }
    
     public function getUserDistricts($userId)
    {
        $districts = DB::table('tenant_user')
                            ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
                            ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
                            ->select('districts.name as district_name')
                            ->where('tenant_user.user_id', $userId)
                            ->where('districts.active', '1')            
                           ->get();
        return $districts;
    }
}
