<?php

namespace App\Domain\Report\Generator;

use App\Domain\Phase\Model\Phase;
use App\Domain\Report\Generator\Concern\GcLifecycleFilterer;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class GcLifecycleReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(GcLifecycleFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('status_history As ssh')
            ->addSelect('students.id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('sites.name AS site')
            ->addSelect('districts.name AS district')
            ->addSelect('current_statuses.name As current_status')
            ->addSelect('students.created_at')
            ->addSelect('students.graduation_date')
            ->addSelect('student_phases.name AS student_phase')
            ->join('students', 'ssh.status_variable_id', '=', 'students.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'ssh.new_status_id', '=', 'statuses.id')
            ->leftJoin('statuses As current_statuses', 'students.status_id', '=', 'current_statuses.id')
            ->leftJoin('statuses As prev_statuses', 'ssh.prev_status_id', '=', 'prev_statuses.id')
            ->leftJoin('phases As prev_phases', 'prev_statuses.phase_id', '=', 'prev_phases.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('statuses AS student_statuses', 'students.status_id', '=', 'student_statuses.id')
            ->leftJoin('phases AS student_phases', function ($join) {
                $join->on('student_statuses.phase_id', '=', 'student_phases.id')
                    ->where('student_phases.name', '!=', 'Duplicate');
            })
            ->where('status_variable_type', StatusHistoryEntry::STATUS_VARIABLE_TYPE_STUDENT)
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC')
            ->groupBy('students.id');
        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $phases = Phase::where('name', '!=', 'Duplicate')->get();

        $headers = ['AA ID', 'First Name', 'Last Name', 'Site', 'District', 'Current Phases', 'Current Status', 'Date Created', 'Total Days in System'];

        foreach ($phases as $phase) {
            $headers[] = $phase->name . ' Enter';
            $headers[] = $phase->name . ' Exit';
            $headers[] = $phase->name . ' Day';
            $headers[] = 'Re Entered?';

            $phaseEnter = 'phase' . $phase->id . '_Enter';
            $phaseExit = 'phase' . $phase->id . '_Exited';
            $phaseReentered = 'phase' . $phase->id . '_Reentered';

            // prev_phases.id should be phases.id in if condition1
            $builder->selectRaw("MIN(IF(phases.id = $phase->id , ssh.created_at, NULL)) AS $phaseEnter");
            $builder->selectRaw("MAX(IF(prev_phases.id = $phase->id and phases.id != prev_phases.id  , ssh.exited_at, NULL)) AS $phaseExit");
            $builder->selectRaw("MAX(IF(prev_phases.id = $phase->id and phases.id != prev_phases.id  , ssh.is_reentered, 0)) AS $phaseReentered");
        }

        yield $headers;

        $students = $builder->get();

        foreach ($students as $student) {
            $createdDate = Carbon::createFromDate($student->created_at);
            $now = Carbon::now();
            $totalDays = $createdDate->diffInDays($now);
            $data = [
                'AA ID' => $student->id,
                'First Name' => $student->first_name,
                'Last Name' => $student->last_name,
                'Site' => $student->site,
                'District' => $student->district,
                'Current Phases' => $student->student_phase,
                'Current Status' => $student->current_status,
                'Date Created' => $student->created_at ? Carbon::parse($student->created_at)->format('m/d/Y') : null,
                'Total Days in System' => $totalDays
            ];
            foreach ($phases as $phase) {

                $phaseEnter = 'phase' . $phase->id . '_Enter';
                $phaseExit = 'phase' . $phase->id . '_Exited';
                $phaseDay = 'phase' . $phase->id . '_Day';
                $phaseReentered = 'phase' . $phase->id . '_Reentered';

                $data[$phaseEnter] = $student->$phaseEnter ? Carbon::Parse($student->$phaseEnter)->format('m/d/Y') : null;
                $data[$phaseExit] = $student->$phaseExit ? Carbon::parse($student->$phaseExit)->format('m/d/Y') : null;
                $exit = Carbon::createFromDate($data[$phaseExit]);
                $enter = Carbon::createFromDate($data[$phaseEnter]);
                $days = (!is_null($data[$phaseEnter]) && !is_null($data[$phaseExit])) ? $enter->diffInDays($exit) : 0;
                $data[$phaseDay] = $days;
                $data[$phaseReentered] = $student->$phaseReentered == 0 ? 'N' : 'Y';
            }
            yield $data;
        }
    }
}
