<?php

namespace App\Domain\Report\Generator;

use App\Domain\Report\Generator\Concern\StudentFilterer;
use App\Domain\Report\Generator\Helper\ReportHelper;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class ReferredReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $reportHelper;

    public function __construct(StudentFilterer $filterer, ReportHelper $reportHelper)
    {
        $this->filterer = $filterer;
        $this->reportHelper = $reportHelper;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('students')
            ->addSelect('students.id As student_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('students.phone_1')
            ->addSelect('students.street_address')
            ->addSelect('students.city')
            ->addSelect('students.state')
            ->addSelect('students.zip_code')
            ->addSelect('students.birthdate')
            ->addSelect('students.email')
            ->addSelect('students.gender')
            ->addSelect('students.emergency_contact_1_name')
            ->addSelect('students.emergency_contact_1_phone_1')
            ->addSelect('students.emergency_contact_1_email')
            ->addSelect('students.hear_about')
            ->addSelect('students.referred_by_name')
            ->addSelect('students.other_hear_about')
            ->addSelect('students.created_at')
            ->addSelect('districts.name AS district')
            ->addSelect('students.district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('sites.name AS site')
            ->addSelect('students.created_at')
            ->addSelect('students.workflow_exception')
            ->addSelect('lookup_races.title AS race')
            ->addSelect('lookup_emergency_contact_relations.name AS emergency_relations')
            ->addSelect('GCA.first_name AS GCA_first_name')
            ->addSelect('GCA.last_name AS GCA_last_name')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('lookup_races', 'students.race_id', '=', 'lookup_races.id')
            ->leftJoin('lookup_emergency_contact_relations', 'students.emergency_contact_1_relation_id', '=', 'lookup_emergency_contact_relations.id')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('student_assignees', function ($join) {
                $join->on('student_assignees.student_id', '=', 'students.id')
                    ->where('student_assignees.group', '=', 'para_professionals');
            })
            ->leftJoin('users AS GCA', 'student_assignees.user_id', '=', 'GCA.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        $this->filterer->filter($builder, $filters->toArray());
        $studentIds = $builder->pluck('students.student_id');

        $specialPrograms = $this->reportHelper->getSpecialPrograms($studentIds);
        $students = $builder->get();

        yield [
            'System Key Pair', 'District', 'School', 'District Id', 'First Name', 'last name', 'Phone #', 'Address', 'City',
            'State', 'Zipcode', 'Birthdate', 'Email', 'Gender', 'Race', 'Special Programs', 'Emergency Name', 'Emergency Relationship',
            'Emergency Phone', 'Emergency Email', 'GCA', 'Phase', 'Status', 'Workflow Exception', 'How Did You Learn About A.A.?', 'If Other', 'Referred By Name',
            'created At'

        ];

        foreach ($students as $student) {
            $studentSpecialPrograms = isset($specialPrograms[$student->student_id]) ? $specialPrograms[$student->student_id] : [];

            $programsName = [];
            if (count($studentSpecialPrograms) > 0) {
                foreach ($studentSpecialPrograms as $program) {
                    $programsName[] = $program->name;
                }
            }

            $programsName = implode(',', $programsName);
            yield [

                'System Key Pair' => $student->student_id,
                'District' => $student->district,
                'School' => $student->site,
                'District Id' => $student->district_id,
                'First Name' => $student->first_name,
                'last name' => $student->last_name,
                'Phone #' => $student->phone_1,
                'Address' => $student->street_address,
                'City' => $student->city,
                'State' => $student->state,
                'Zipcode' => $student->zip_code,
                'Birthdate' => $student->birthdate,
                'Email' => $student->email,
                'Gender' => $student->gender,
                'Race' => $student->race,
                'Special Programs' => $programsName,
                'Emergency Name' => $student->emergency_contact_1_name,
                'Emergency Relationship' => $student->emergency_relations,
                'Emergency Phone' => $student->emergency_contact_1_phone_1,
                'Emergency Email' => $student->emergency_contact_1_email,
                'GCA' => $student->GCA_first_name . ' ' . $student->GCA_last_name,
                'Phase' => $student->phase,
                'Status' => $student->status,
                'Workflow Exception' => $student->workflow_exception == 1 ? "Yes" : "No",
                'How Did You Learn About A.A.?' => $student->hear_about,
                'If Other' => $student->other_hear_about,
                'Referred By Name' => $student->referred_by_name,
                'created At' => $student->created_at ? Carbon::parse($student->created_at)->format('m/d/Y') : "",

            ];
        }
    }
}
