<?php

namespace App\Domain\Report\Generator;

use App\Domain\Lookup\Model\Timezone;
use App\Domain\Report\Generator\Concern\AttendanceFilterer;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LastDateAttendedWithEdmentum extends BaseGenerator implements GeneratorInterface
{
    private $filterer;

    public function __construct(AttendanceFilterer $filterer)
    {
        $this->filterer = $filterer;
    }

    public function generate($filters): iterable
    {
        $timezone = Auth::user()->timezone;

        $range = Arr::get($filters, 'range');

        $builder = DB::table('students')
            ->addSelect('students.id As student_id')
            ->addSelect('students.first_name')
            ->addSelect('students.last_name')
            ->addSelect('districts.name AS district')
            ->addSelect('sites.name AS site')
            ->addSelect('students.district_id')
            ->addSelect('phases.name AS phase')
            ->addSelect('statuses.name AS status')
            ->addSelect('GCA.first_name AS GCA_first_name')
            ->addSelect('GCA.last_name AS GCA_last_name')
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('student_assignees', function ($join) {
                $join->on('student_assignees.student_id', '=', 'students.id')
                    ->where('student_assignees.group', '=', 'para_professionals')->limit(1);
            })
            ->leftJoin('users AS GCA', 'student_assignees.user_id', '=', 'GCA.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        $this->filterer->filter($builder, $filters->toArray());

        $attendanceEntries = $builder->get();

        $edmentumData = $this->getEdmenumData($range);

        yield [
            'Unique AA ID', 'District/School ID', 'District Partner', ' Site', 'GC First Name',
            'GC Last Name', 'Phase', 'Status', 'last Attend Date', 'Check-in',
            'Check-out', 'Total Time [in mins]', 'GCA'
        ];

        if (count($attendanceEntries) > 0) {
            foreach ($attendanceEntries as $entry) {
                if ($this->removeUnneeded($edmentumData, $entry)) continue;

                $checkIn = Carbon::parse($edmentumData[$entry->student_id][0]->last_attended_in_edmentum)->timezone(
                    $timezone ? Timezone::TIMEZONE_ID[$timezone->title] : 'UTC'
                );
                $totalTime = $edmentumData[$entry->student_id][0]->minutes;

                yield [
                    'Unique AA ID' => $entry->student_id,
                    'District/School ID' => $entry->district_id,
                    'District Partner' => $entry->district,
                    'Site' => $entry->site,
                    'GC First Name' => $entry->first_name,
                    'GC Last Name' => $entry->last_name,
                    'Phase' => $entry->phase,
                    'Status' => $entry->status,
                    'last Attend Date' => $checkIn->format('m/d/Y'),
                    'Check-in' => '------',
                    'Check-out' => '------',
                    'Total Time [in mins]' => $totalTime,
                    'GCA' => $entry->GCA_first_name . ' ' . $entry->GCA_last_name,
                ];
            }
        }
    }

    public function getEdmenumData($range = null)
    {
        $sql = "SELECT `students`.`id` AS `student_id`,
                  `aelt`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`,
                  `aelt`.`minutes` AS `minutes`
                FROM `students` ";
        $sql .= " LEFT JOIN (
                            SELECT edmentum_learner_id, minutes, MAX(`started_at`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_tasks`";

        $sql .= isset($range) ? " WHERE started_at >= '{$range['from']}' AND started_at <= '{$range['to']} 23:59:59' " : $sql;
        $sql .= " GROUP BY `edmentum_learner_id`, minutes
                        ) AS aelt on `students`.`id` = `aelt`.`edmentum_learner_id`
                        ";

        $results = collect(DB::select($sql));
        return $results->groupBy('student_id');
    }


    protected function removeUnneeded($edmentumData, $student, $range = null)
    {
        if (!isset($edmentumData[$student->student_id]) || is_null($edmentumData[$student->student_id][0]->last_attended_in_edmentum)) {
            return true;
        }
    }
}
