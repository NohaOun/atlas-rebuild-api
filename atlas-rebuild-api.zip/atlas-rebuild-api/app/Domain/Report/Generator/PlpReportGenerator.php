<?php

namespace App\Domain\Report\Generator;

use App\Domain\Plp\PlanLibrary;
use App\Domain\Report\Generator\Concern\PlpFilter;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PlpReportGenerator extends BaseGenerator implements GeneratorInterface
{
    private $filterer;
    private $planLibrary;

    public function __construct(PlpFilter $filterer, PlanLibrary $planLibrary)
    {
        $this->filterer = $filterer;
        $this->planLibrary = $planLibrary;
    }

    public function generate($filters): iterable
    {
        $builder = DB::table('student_plp_plans')
            ->addSelect('students.id as student_id')
            ->addSelect('students.cohort_year as cohort_year')
            ->addSelect(DB::raw("CONCAT(students.first_name,' ', students.last_name) as student_name"))
            ->addSelect('statuses.name as gc_status')
            ->addSelect('phases.name as phase_name')
            ->addSelect('sites.name as site_name')
            ->addSelect('districts.name as district_name')
            ->addSelect('student_plp_plans.name as name')
            ->addSelect('student_plp_plans.override_tier_level as override_tier_level')
            ->addSelect('students.district_id as district_id')
            ->addSelect(DB::raw("(CASE WHEN student_plp_plans.active = true THEN 'Active' ELSE 'Archived' END) as plp_status"))
            ->addSelect('student_plp_plans.content as plp_content')
            ->addSelect('student_plp_plans.updated_at as updated_at')
            ->leftJoin('students', 'student_plp_plans.student_id', '=', 'students.id')
            ->leftJoin('statuses', 'students.status_id', '=', 'statuses.id')
            ->leftJoin('phases', function ($join) {
                $join->on('statuses.phase_id', '=', 'phases.id')
                    ->where('phases.name', '!=', 'Duplicate');
            })
            ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
            ->leftJoin('districts', 'sites.district_id', 'districts.id')
            ->whereNull('students.deleted_at')
            ->where('districts.active', '1')
            ->where('sites.active', '1')
            ->whereIn('districts.id', app('showing-district-ids-in-reports'))
            ->where('students.tenant_id', tenant()->id)
            ->orderByRaw('students.id DESC');

        if ($filters) $this->filterer->filter($builder, $filters->toArray());

        $plans = $builder->get();

        $headers = [
            'Acceleration ID', 'District', 'Site', 'District ID', 'GC Name', 'GC Phase',
            'GC Status', 'Cohort Year', 'PLP Status', 'Tier', 'Target Graduation', 'Post Grad Pathway',
            'Credits Earned', 'Credits Needed', 'Update Date', 'Update By'
        ];

        $courseAndAssessmentGroupHeaders = [];

        foreach ($plans as $plan) {
            $content = json_decode($plan->plp_content, true);

            $this->getCourseGroups($content['groups'])->each(function ($group) use (&$courseAndAssessmentGroupHeaders) {
                $courseAndAssessmentGroupHeaders[$this->createCourseGroupName($group, 'AA')] = true;
                $courseAndAssessmentGroupHeaders[$this->createCourseGroupName($group, 'District')] = true;
            });
        }

        $courseAndAssessmentGroupHeaders = array_keys($courseAndAssessmentGroupHeaders);

        foreach (range(1, 12) as $i) {
            $courseAndAssessmentGroupHeaders[] = $this->createAssessmentName($i, 'Name');
            $courseAndAssessmentGroupHeaders[] = $this->createAssessmentName($i, 'Score');
        }

        yield array_merge($headers, $courseAndAssessmentGroupHeaders);

        foreach ($plans as $plan) {
            $content = json_decode($plan->plp_content, true);

            $content = $this->planLibrary->addTierToPlpPlanContent($content, $plan);
            $data = [
                'Acceleration ID' => $plan->student_id,
                'District' => $plan->district_name,
                'Site' => $plan->site_name,
                'District ID' => $plan->district_id,
                'GC Name' => $plan->student_name,
                'GC Phase' => $plan->phase_name,
                'GC Status' => $plan->gc_status,
                'Cohort Year' => $plan->cohort_year,
                'PLP Status' => $plan->plp_status,
                'Tier' => $content['tier_level'],
                'Target Graduation' => $this->parseSeason(Arr::get($content, 'target_graduation.season'))
                    . '/'
                    . Arr::get($content, 'target_graduation.year'),
                'Post Grad Pathway' => Arr::get($content, 'post_grad_pathway'),
                'Credits Earned' => $content['diploma_credits_earned'],
                'Credits Needed' => $content['diploma_credits_needed'],
                'Update Date' => Carbon::parse($plan->updated_at)->format('m/d/Y'),
                'Update By' => "",
            ];

            $courseAndAssessmentCredits = [];

            foreach ($this->getCourseGroups($content['groups']) as $group) {
                $credits = $this->parseGroupCredits($group);

                $courseAndAssessmentCredits[$this->createCourseGroupName($group, 'AA')] = $credits[0];
                $courseAndAssessmentCredits[$this->createCourseGroupName($group, 'District')] = $credits[1];
            }

            foreach ($this->getAssessmentGroups($content['groups']) as $assessmentGroup) {
                foreach ($assessmentGroup['courses'] as $i => $assessment) {
                    $courseAndAssessmentCredits[$this->createAssessmentName($i + 1, 'Name')] = Arr::get($assessment, 'name', 0);
                    $courseAndAssessmentCredits[$this->createAssessmentName($i + 1, 'Score')] = $this->parseAssessmentScore($assessment);
                }
            }

            foreach ($courseAndAssessmentGroupHeaders as $header) {
                $data[$header] = Arr::get($courseAndAssessmentCredits, $header);
            }

            yield $data;
        }
    }

    protected function getCourseGroups($groups)
    {
        return collect($groups)->filter(function ($group) {
            return !Arr::get($group['group'], 'assessment');
        });
    }

    protected function getAssessmentGroups($groups)
    {
        return collect($groups)->filter(function ($group) {
            return Arr::get($group['group'], 'assessment');
        });
    }

    protected function createCourseGroupName($group, $completedWith)
    {
        return Arr::get($group['group'], 'name', 0) . " Credits " . $completedWith;
    }

    protected function createAssessmentName($assessment, $suffix = null)
    {
        $name = 'Assessment ' . $assessment;

        if ($suffix) $name .= ' ' . $suffix;

        return $name;
    }

    protected function parseGroupCredits($group)
    {
        $aaCredits = $districtCredits = 0;

        foreach ($group['courses'] as $course) {
            if (Arr::get($course, 'completed_with') == "District") {
                $districtCredits += (float) Arr::get($course, 'earned_credit', 0);
            } else {
                $aaCredits += (float) Arr::get($course, 'earned_credit', 0);
            }
        }

        return [$aaCredits, $districtCredits];
    }

    protected function parseSeason($season)
    {
        switch ($season) {
            case 0:
                return 'Fall';
            case 1:
                return 'Spring';
            case 2:
                return 'Summer';
            case 3:
                return 'Winter';
        }

        return $season;
    }

    protected function parseAssessmentScore($assessment)
    {
        if (isset($assessment['score']) && $assessment['score'] === "") {
            return "Not Attempted";
        }

        return (isset($assessment['passed']) && $assessment['passed']) ? "Passed" : "Failed";
    }
}
