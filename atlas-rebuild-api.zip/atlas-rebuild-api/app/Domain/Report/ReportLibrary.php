<?php

namespace App\Domain\Report;

use App\Domain\Report\Formatter\FormatterInterface;
use App\Domain\Report\Generator\SaDashboardReportGenerator;
use App\Domain\Report\Model\Report;
use App\Domain\Report\Model\ReportType;
use App\Domain\Report\Repository\ReportRepositoryInterface;
use App\Domain\Report\Repository\ReportTypeRepositoryInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

class ReportLibrary
{
    private $reportTypeRepo;
    private $reportGeneratorFactory;
    private $ruleFactory;
    private $reportRepo;

    public function __construct(
        ReportTypeRepositoryInterface $reportTypeRepo,
        ReportRepositoryInterface $reportRepo,
        ReportGeneratorFactory $reportGeneratorFactory,
        RuleFactory $ruleFactory
    )
    {
        $this->reportTypeRepo = $reportTypeRepo;
        $this->reportGeneratorFactory = $reportGeneratorFactory;
        $this->ruleFactory = $ruleFactory;
        $this->reportRepo = $reportRepo;
    }

    public function getReportTypes()
    {
        return $this->reportTypeRepo->getReports();
    }

    public function getReportTypeList(): Collection
    {
        return $this->reportTypeRepo->getReports()->map(function (ReportType $reportType) {
            return $reportType->getId();
        });
    }

    public function getReport($reportId)
    {
        return $this->reportRepo->getReport($reportId);
    }

    public function createReport($type, $filters, FormatterInterface $formatter)
    {
        $generator = $this->reportGeneratorFactory->make($type);

        $formatted = $formatter->format($generator->generate($filters));

        $filename = $this->saveReportToDisk($formatted, $type, $formatter->getExtension());

        $report = new Report(['type' => $type, 'filename' => $filename]);

        $this->reportRepo->saveReport($report);

        return $report;
    }

    protected function saveReportToDisk($content, $type, $extension)
    {
        $filename = sprintf('%s-%s.%s', $type, time(), $extension);

        Storage::disk('reports')->put($filename, $content);

        return $filename;
    }

    public function getRuleForReportType($reportType)
    {
        return $this->ruleFactory->make($reportType);
    }
}
