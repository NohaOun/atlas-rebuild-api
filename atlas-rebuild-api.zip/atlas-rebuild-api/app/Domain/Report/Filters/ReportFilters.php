<?php

namespace App\Domain\Report\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class ReportFilters extends BaseFilters
{
    public function type(Builder $builder, $type)
    {
        return $builder->where('type', $type);
    }
}
