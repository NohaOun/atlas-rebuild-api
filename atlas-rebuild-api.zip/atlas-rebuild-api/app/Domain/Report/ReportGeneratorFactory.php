<?php

namespace App\Domain\Report;

use App\Domain\Report\Generator\GeneratorInterface;
use Illuminate\Foundation\Application;
use Illuminate\Support\Str;

class ReportGeneratorFactory
{
    private $app;

    public function __construct(Application $app)
    {
        $this->app = $app;
    }

    public function make($reportType): GeneratorInterface
    {
        if (config()->has("report-types.{$reportType}.generator")) {
            return $this->app->make(
                config("report-types.{$reportType}.generator")
            );
        }

        $class = Str::studly($reportType);
        return $this->app->make(
            sprintf('%s\%s%s', 'App\Domain\Report\Generator', $class, 'Generator')
        );
    }
}
