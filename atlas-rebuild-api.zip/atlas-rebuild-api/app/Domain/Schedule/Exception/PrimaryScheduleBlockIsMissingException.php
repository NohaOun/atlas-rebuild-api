<?php

namespace App\Domain\Schedule\Exception;

class PrimaryScheduleBlockIsMissingException extends \LogicException
{
}
