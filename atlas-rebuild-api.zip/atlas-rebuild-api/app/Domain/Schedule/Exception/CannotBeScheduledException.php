<?php

namespace App\Domain\Schedule\Exception;

class CannotBeScheduledException extends \LogicException
{
}
