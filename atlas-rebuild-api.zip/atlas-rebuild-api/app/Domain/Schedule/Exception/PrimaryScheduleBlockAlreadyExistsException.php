<?php

namespace App\Domain\Schedule\Exception;

class PrimaryScheduleBlockAlreadyExistsException extends \LogicException
{
}
