<?php

namespace App\Domain\Schedule;

use App\Domain\Schedule\Repository\ScheduleBlockRepository;
use App\Domain\Schedule\Repository\ScheduleBlockRepositoryInterface;
use App\Domain\Schedule\Repository\StaffScheduleEntryRepository;
use App\Domain\Schedule\Repository\StaffScheduleEntryRepositoryInterface;
use App\Domain\Schedule\Repository\AppointmentCategoryRepository;
use App\Domain\Schedule\Repository\AppointmentCategoryRepositoryInterface;
use App\Domain\Schedule\Repository\StaffScheduleRepository;
use App\Domain\Schedule\Repository\StaffScheduleRepositoryInterface;

use App\Domain\Schedule\Repository\StudentScheduleEntryRepository;
use App\Domain\Schedule\Repository\StudentScheduleEntryRepositoryInterface;
use Illuminate\Support\ServiceProvider;

class ScheduleServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->bind(AppointmentCategoryRepositoryInterface::class, AppointmentCategoryRepository::class);
        $this->app->bind(StaffScheduleRepositoryInterface::class, StaffScheduleRepository::class);
        $this->app->bind(StaffScheduleEntryRepositoryInterface::class, StaffScheduleEntryRepository::class);
        $this->app->bind(StudentScheduleEntryRepositoryInterface::class, StudentScheduleEntryRepository::class);
        $this->app->bind(ScheduleBlockRepositoryInterface::class, ScheduleBlockRepository::class);
    }
}
