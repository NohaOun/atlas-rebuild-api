<?php

namespace App\Domain\Schedule;

use App\Domain\Schedule\Model\StaffSchedule;
use App\Domain\Schedule\Filters\StaffScheduleFilters;
use App\Domain\Schedule\Repository\StaffScheduleRepositoryInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class StaffScheduleLibrary
{
    protected $staffScheduleRepo;

    public function __construct(StaffScheduleRepositoryInterface $staffScheduleRepo)
    {
        $this->staffScheduleRepo = $staffScheduleRepo;
    }

    public function getStaffSchedules(StaffScheduleFilters $filters = null)
    {
        return $this->staffScheduleRepo->getStaffSchedules($filters);
    }

    public function getStaffSchedule($resourceId)
    {
        return $this->staffScheduleRepo->getstaffSchedule($resourceId);
    }

    public function createStaffSchedule(array $data)
    {
        return $this->saveStaffSchedule(new StaffSchedule, $data);
    }

    public function updateStaffSchedule(StaffSchedule $schedule, $data)
    {
        return $this->saveStaffSchedule($schedule, $data);
    }

    protected function saveStaffSchedule(StaffSchedule $schedule, $data)
    {
        return DB::transaction(function () use ($schedule, $data) {
            $schedule->fill(
                $this->getStaffScheduleAttributes($data)
            );
            $this->staffScheduleRepo->saveStaffSchedule($schedule);

            return $schedule;
        });
    }

    protected function getStaffScheduleAttributes($data)
    {
        $attributes = Arr::get($data, 'attributes', []);

        if (Arr::has($data, 'relationships.site_id')) {
            $attributes['site_id'] = $data['relationships']['site_id'];
        }

        if (Arr::has($data, 'relationships.staff_id')) {
            $attributes['staff_id'] = $data['relationships']['staff_id'];
        }

        return $attributes;
    }

    public function deleteStaffSchedule($record)
    {
        return $this->staffScheduleRepo->deleteStaffSchedule($record);
    }
}
