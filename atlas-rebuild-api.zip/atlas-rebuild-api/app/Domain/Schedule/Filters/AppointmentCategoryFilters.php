<?php

namespace App\Domain\Schedule\Filters;

use App\Domain\Common\Filters\BaseFilters;
use App\Domain\Schedule\Model\AppointmentCategory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class AppointmentCategoryFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function gcCanSelect(Builder $builder, $gcCanSelect)
    {
        return $builder->where('gc_can_select', $gcCanSelect);
    }

    public function durationTypes(Builder $builder, $types)
    {
        return $builder->where(function (Builder $builder) use ($types) {
            foreach ($types as $type) {
                $builder->orWhere('duration->type', $type);
            }

            return $builder;
        });
    }

    public function name(Builder $builder, $name)
    {
        return $builder->where('name', 'LIKE', "%{$name}%");
    }

    public function active(Builder $builder, $active)
    {
        return $builder->where('active', $active);
    }

    public function sites(Builder $builder, $ids)
    {
        $builder->whereHas('sites', function (Builder $builder) use ($ids) {
            return $builder->whereIn('sites.id', $ids);
        });
    }

    public function date(Builder $builder, $date)
    {
        return $builder->where(function (Builder $builder) use ($date) {
            return $builder
                ->where('duration->type', AppointmentCategory::DURATION_TYPE_IN_MINUTES)
                ->orWhere(function (Builder $builder) use ($date) {
                    return $builder
                        ->where('duration->type', AppointmentCategory::DURATION_TYPE_SET_TIME)
                        ->where('duration->payload->date', $date);
                })
                ->orWhere(function (Builder $builder) use ($date) {
                    $day = strtolower(Carbon::createFromFormat('m/d/Y', $date)->format('D'));

                    return $builder
                        ->where('duration->type', AppointmentCategory::DURATION_TYPE_RECURRING)
                        ->where('duration->payload->day', $day);
                });
        });
    }

    public function staff(Builder $builder, $staffId)
    {
        $builder->whereHas('staffScheduleEntries', function (Builder $builder) use ($staffId) {
            $builder->whereHas('staffSchedule', function (Builder $builder) use ($staffId) {
                return $builder->where('staff_id', $staffId);
            });
        });
    }

    public function schedulable(Builder $builder)
    {
        $builder->where(function ($appointment) {
            $appointment->where('duration->type', '!=', AppointmentCategory::DURATION_TYPE_SET_TIME)
                ->orWhere('duration->payload->date', '>', now()->format('Y-m-d'));
        })->whereHas('staffScheduleEntries', function (Builder $builder) {
            $builder->where('date', '>', now()->format('Y-m-d'));
        });
    }
}
