<?php

namespace App\Domain\Schedule\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Illuminate\Database\Eloquent\Builder;

class ScheduleBlockFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function site(Builder $builder, $id)
    {
        return $builder->where('site_id', $id);
    }

    public function primary(Builder $builder, $primary)
    {
        return $builder->where('primary', $primary);
    }

    public function ignore(Builder $builder, $id)
    {
        return $builder->where('id', '!=', $id);
    }
}
