<?php

namespace App\Domain\Schedule\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class StaffScheduleEntryFilters extends BaseFilters
{
    public function ids(Builder $builder, $ids)
    {
        return $builder->whereIn('id', $ids);
    }

    public function staffSchedule(Builder $builder, $id)
    {
        return $builder->where('staff_schedule_id', $id);
    }

    public function appointmentCategory(Builder $builder, $categoryId)
    {
        $builder->whereHas('appointmentCategories', function (Builder $builder) use ($categoryId) {
            return $builder->where('appointment_categories.id', $categoryId);
        });
    }

    public function appointmentCategories(Builder $builder, $categoryIds)
    {
        $builder->whereHas('appointmentCategories', function (Builder $builder) use ($categoryIds) {
            return $builder->whereIn('appointment_categories.id', $categoryIds);
        });
    }

    public function appointmentCategoryType(Builder $builder, $type)
    {
        $builder->whereHas('appointmentCategories', function (Builder $builder) use ($type) {
            return $builder->where('appointment_categories.duration->type', $type);
        });
    }

    public function staff(Builder $builder, $StaffId)
    {
        return $builder->whereHas('staff', function (Builder $builder) use($StaffId){
            return $builder->where('staff_id', $StaffId);

        });
    }

    public function fromDate(Builder $builder, $fromDate)
    {
        return $builder->where('date', '>=', Carbon::createFromFormat('m/d/Y', $fromDate)->format('Y-m-d'));
    }

    public function toDate(Builder $builder, $toDate)
    {
        return $builder->where('date', '<=', Carbon::createFromFormat('m/d/Y', $toDate)->format('Y-m-d'));
    }
}
