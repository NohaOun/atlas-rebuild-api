<?php

namespace App\Domain\Schedule\Filters;

use App\Domain\Common\Filters\BaseFilters;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class StudentScheduleEntryFilters extends BaseFilters
{
    public function student(Builder $builder, $studentId)
    {
        return $builder->where('student_id', $studentId);
    }

    public function appointmentType(Builder $builder, $typ)
    {
        return $builder->where('appointment_type', $typ);
    }

    public function sameWeekAs(Builder $builder, $date)
    {
        return $builder->where('date', '>=', Carbon::createFromFormat('m/d/Y', $date)->startOf('week'));
    }

    public function date(Builder $builder, $date)
    {
        return $builder->where('date', '>=', Carbon::createFromFormat('m/d/Y', $date)->format('Y-m-d'));
    }

    public function fromDate(Builder $builder, $fromDate)
    {
        return $builder->where('date', '>=', Carbon::createFromFormat('m/d/Y', $fromDate)->format('Y-m-d'));
    }

    public function toDate(Builder $builder, $toDate)
    {
        return $builder->where('date', '<=', Carbon::createFromFormat('m/d/Y', $toDate)->format('Y-m-d'));
    }

    public function startTime(Builder $builder, $from)
    {
        return $builder->where('from', '>=', Carbon::createFromFormat('H:i', $from)->format('H:i:s'));
    }

    public function endTime(Builder $builder, $to)
    {
        return $builder->where('to', '<=', Carbon::createFromFormat('H:i', $to)->format('H:i:s'));
    }

    public function staff(Builder $builder, $staff)
    {
        return $builder->where('staff_id', $staff);
    }

    public function slot(Builder $builder, $slot)
    {
        return $builder->where(function ($builder) use ($slot) {
            return $builder->where('from', '<=', $slot['to'])
                ->where('to' , '>=' , $slot['from']);
        });
    }

    public function id(Builder $builder, $id)
    {
        return $builder->where('id', $id);
    }
    
    public function appointmentCategory(Builder $builder, $categoryId)
    {
        return $builder->whereHas('appointmentCategories', function (Builder $builder) use ($categoryId) {
            return $builder->where('appointment_categories.id', $categoryId);
        });
    }

    public function site(Builder $builder, $siteId)
    {
        return $builder->whereHas('student', function (Builder $builder) use($siteId) {
            $builder->whereHas('site', function (Builder $builder) use ($siteId) {
                $builder->where('id', $siteId);
            });
        });
    }
}
