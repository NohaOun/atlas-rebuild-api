<?php

namespace App\Domain\Schedule;

use App\Domain\Schedule\Model\AppointmentCategory;
use App\Domain\Schedule\Filters\AppointmentCategoryFilters;
use App\Domain\Schedule\Repository\AppointmentCategoryRepositoryInterface;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class AppointmentCategoryLibrary
{
    protected $appointmentCategoryRepository;

    public function __construct(AppointmentCategoryRepositoryInterface $appointmentCategoryRepository)
    {
        $this->appointmentCategoryRepository = $appointmentCategoryRepository;
    }

    public function getAppointmentCategories(AppointmentCategoryFilters $filters = null)
    {
        return $this->appointmentCategoryRepository->getAppointmentCategories($filters);
    }

    public function getAppointmentCategoriesBuilder(AppointmentCategoryFilters $filters = null)
    {
        return $this->appointmentCategoryRepository->getFilteredBuilder($filters);
    }

    public function getAppointmentCategory($resourceId)
    {
        return $this->appointmentCategoryRepository->getAppointmentCategory($resourceId);
    }

    public function createAppointmentCategory(array $data)
    {
        return $this->saveAppointmentCategory(new AppointmentCategory, $data);
    }

    public function updateAppointmentCategory(AppointmentCategory $category, $data)
    {
        return $this->saveAppointmentCategory($category, $data);
    }

    protected function saveAppointmentCategory(AppointmentCategory $category, $data)
    {
        return DB::transaction(function () use ($category, $data) {
            $attributes = $this->getAppointmentCategoryAttributes($data);

            $category->fill($attributes);

            $this->appointmentCategoryRepository->saveAppointmentCategory($category);

            $this->saveAppointmentCategorySites($category, $data);

            return $category;
        });
    }

    protected function getAppointmentCategoryAttributes($data)
    {
        $attributes = Arr::only($data['attributes'], ['name', 'active', 'gc_can_select', 'duration']);

        foreach (['active', 'gc_can_select'] as $k) {
            if (Arr::has($data, "attributes.{$k}")) {
                $attributes[$k] = Arr::get($data, "attributes.{$k}");
            }
        }

        return Arr::only($data['attributes'], ['name', 'active', 'gc_can_select', 'duration']);
    }

    protected function saveAppointmentCategorySites(AppointmentCategory $category, $data)
    {
        if (Arr::has($data, 'relationships.site_ids')) {
            $category->sites()->sync(Arr::get($data, 'relationships.site_ids', []));
        }
    }

    public function deleteAppointmentCategory($record)
    {
        return $this->appointmentCategoryRepository->deleteAppointmentCategory($record);
    }
}
