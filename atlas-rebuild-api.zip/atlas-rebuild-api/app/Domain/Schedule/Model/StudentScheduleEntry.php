<?php

namespace App\Domain\Schedule\Model;

use App\Domain\Student\Model\Student;
use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StudentScheduleEntry extends Model
{
    use BelongsToTenant;

    protected $table = 'student_schedule_entries';
    protected $fillable = ['student_id', 'staff_id', 'appointment_type', 'date', 'from', 'to', 'looking_for'];

    const APPOINTMENT_TYPE_ON_SITE = 'on-site';
    const APPOINTMENT_TYPE_VIRTUAL = 'virtual';

    const LOOKING_FOR_MEET_WITH = 'meet-with';
    const LOOKING_FOR_COME_IN_ON = 'come-in-on';
    const LOOKING_FOR_WORK_ON = 'work-on';

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function staff()
    {
        return $this->belongsTo(User::class);
    }

    public function appointmentCategories()
    {
        return $this->belongsToMany(AppointmentCategory::class);
    }

    public static function getAvailableAppointmentTypes()
    {
        return [self::APPOINTMENT_TYPE_ON_SITE, self::APPOINTMENT_TYPE_VIRTUAL];
    }

    public static function getAvailableLookingFor()
    {
        return [self::LOOKING_FOR_WORK_ON, self::LOOKING_FOR_MEET_WITH, self::LOOKING_FOR_COME_IN_ON];
    }

    public static function getFormattedNameAttribute($key)
    {
        $name = '';

        switch ($key){
            case self::LOOKING_FOR_MEET_WITH:
                $name = 'I need to meet with someone specific';
                break;
            case self::LOOKING_FOR_COME_IN_ON:
                $name = 'I want to come in on ...';
                break;
            case self::LOOKING_FOR_WORK_ON:
                $name = 'I need to work on ...';
                break;
            default:
                $name = '';
        }

        return $name;
    }
}
