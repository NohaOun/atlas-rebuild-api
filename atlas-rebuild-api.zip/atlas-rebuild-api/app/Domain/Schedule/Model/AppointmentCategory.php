<?php

namespace App\Domain\Schedule\Model;

use App\Domain\Site\Model\Site;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class AppointmentCategory extends Model
{
    use BelongsToTenant;

    const DURATION_TYPE_IN_MINUTES = 'in-minutes';
    const DURATION_TYPE_SET_TIME = 'set-time';
    const DURATION_TYPE_RECURRING = 'recurring';

    protected $table = 'appointment_categories';
    protected $fillable = [
        'name', 'gc_can_select', 'active', 'duration'
    ];
    protected $casts = ['duration' => 'json'];

    public function sites()
    {
        return $this->belongsToMany(Site::class);
    }

    public static function getAvailableDurationTypes()
    {
        return [self::DURATION_TYPE_IN_MINUTES, self::DURATION_TYPE_SET_TIME, self::DURATION_TYPE_RECURRING];
    }

    public function staffScheduleEntries()
    {
        return $this->belongsToMany(StaffScheduleEntry::class, 'appointment_category_staff_schedule_entry');
    }

    public function getIsRecurringAttribute()
    {
        return $this->duration["type"] == self::DURATION_TYPE_RECURRING;
    }

    // public function getFormattedFromTimeAttribute()
    // {
    //     return !empty($this->duration["payload"]["from"]) ? Carbon::createFromFormat('H:i', $this->duration["payload"]["from"])->format('H:i') : '';
    // }

    // public function getFormattedToTimeAttribute()
    // {
    //     return !empty($this->duration["payload"]["to"]) ? Carbon::createFromFormat('H:i', $this->duration["payload"]["to"])->format('H:i') : '';
    // }

}
