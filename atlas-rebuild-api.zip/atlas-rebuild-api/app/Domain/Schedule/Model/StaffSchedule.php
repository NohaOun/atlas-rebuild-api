<?php

namespace App\Domain\Schedule\Model;

use App\Domain\Site\Model\Site;
use App\Domain\User\Model\User;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StaffSchedule extends Model
{
    use BelongsToTenant;

    protected $table = 'staff_schedules';
    protected $fillable = ['site_id', 'staff_id', 'keep_schedule'];

    public function site()
    {
        return $this->belongsTo(Site::class);
    }

    public function staff()
    {
        return $this->belongsTo(User::class, 'staff_id');
    }

    public function entries()
    {
        return $this->hasMany(StaffScheduleEntry::class);
    }
}
