<?php

namespace App\Domain\Schedule\Model;

use App\Domain\Site\Model\Site;
use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class ScheduleBlock extends Model
{
    use BelongsToTenant;

    protected $table = 'schedule_blocks';
    protected $fillable = [
        'primary', 'days', 'site_id'
    ];
    protected $casts = ['days' => 'json'];

    public function site()
    {
        return $this->belongsTo(Site::class);
    }
}
