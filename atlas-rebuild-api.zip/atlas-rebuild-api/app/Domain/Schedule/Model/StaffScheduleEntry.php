<?php

namespace App\Domain\Schedule\Model;

use Illuminate\Database\Eloquent\Model;
use Stancl\Tenancy\Database\Concerns\BelongsToTenant;

class StaffScheduleEntry extends Model
{
    use BelongsToTenant;

    protected $table = 'staff_schedule_entries';
    protected $fillable = [
        'schedule_block_id', 'staff_schedule_id', 'date', 'schedule_type', 'from', 'to'
    ];

    public function scheduleBlock()
    {
        return $this->belongsTo(ScheduleBlock::class);
    }

    public function appointmentCategories()
    {
        return $this->belongsToMany(AppointmentCategory::class);
    }

    public function staffSchedule()
    {
        return $this->belongsTo(StaffSchedule::class);
    }
}
