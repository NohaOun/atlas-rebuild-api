<?php

namespace App\Domain\Schedule;

use App\Domain\AcademyClosure\Filters\AcademyClosureFilters;
use App\Domain\AcademyClosure\Repository\AcademyClosureRepositoryInterface;
use App\Domain\Schedule\Exception\CannotBeScheduledException;
use App\Domain\Schedule\Filters\StudentScheduleEntryFilters;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use App\Domain\Schedule\Repository\StudentScheduleEntryRepositoryInterface;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class StudentScheduleEntryLibrary
{
    protected $studentScheduleEntryRepo;

    protected $academyClosureRepository;

    protected $studentRepository;

    public function __construct(
        StudentScheduleEntryRepositoryInterface $studentScheduleEntryRepo,
        AcademyClosureRepositoryInterface $academyClosureRepository,
        StudentRepositoryInterface $studentRepository
    )
    {
        $this->academyClosureRepository = $academyClosureRepository;
        $this->studentScheduleEntryRepo = $studentScheduleEntryRepo;
        $this->studentRepository = $studentRepository;
    }

    public function createStudentScheduleEntry($data)
    {
        $student = $this->studentRepository->getStudent($data['student_id'])->load('site.capacity');

        $this->checkAcademyClosureValidation($data, $student);
        $this->checkStaffHaseSameTimeSlot($data);
        $this->checkSiteCapacityValidation($data, $student);


        return $this->saveStudentScheduleEntry(new StudentScheduleEntry, $data);
    }

    public function updateStudentScheduleEntry($entry, $data)
    {
        return $this->saveStudentScheduleEntry($entry, $data);
    }

    public function deleteStudentScheduleEntry(StudentScheduleEntry $entry)
    {
        $this->studentScheduleEntryRepo->deleteStudentScheduleEntry($entry);
    }

    public function saveStudentScheduleEntry(StudentScheduleEntry $entry, $data)
    {
        return DB::transaction(function () use ($entry, $data) {
            $data['date'] = Carbon::createFromFormat('m/d/Y', $data['date'])->format('Y-m-d');
            $entry->fill($data);

            $this->studentScheduleEntryRepo->saveStudentScheduleEntry($entry);

            $this->saveStudentScheduleEntryAppointmentCategories($entry, $data);

            return $entry;
        });
    }

    protected function saveStudentScheduleEntryAppointmentCategories(StudentScheduleEntry $entry, $data)
    {
        if (Arr::has($data, 'appointment_category_ids')) {
            $entry->appointmentCategories()->sync(Arr::get($data, 'appointment_category_ids', []));
        }
    }

    public function checkAcademyClosureValidation($data, $student)
    {
        $availability = $data['appointment_type'] === 'virtual' ? ['availableVirtually' => false] : ['availableOnSite' => false];

        $academyClosures = $this->academyClosureRepository->getAcademyClosures(
            new AcademyClosureFilters(
                array_merge([
                    'betweenDates' => $data['date'],
                    'betweenTimes' => ['from' => $data['from'], 'to' => $data['to']],
                    'active' => true,
                    'sites' => [$student->site->id],
                ], $availability))
        );

        throw_if($academyClosures->count(),
            new CannotBeScheduledException('Cannot schedule because there is an academy closure')
        );
    }

    public function checkStaffHaseSameTimeSlot($data)
    {
        $studentScheduleEntry = $this->studentScheduleEntryRepo->getStudentScheduleEntries(new StudentScheduleEntryFilters([
            'staff' => $data['staff_id'],
            'date' => $data['date'],
            'slot' => ['from' => $data['from'], 'to' => $data['to']],
        ]));

        throw_if($studentScheduleEntry->count(),
            new CannotBeScheduledException('Cannot schedule because this staff was schedule for the same time slot')
        );
    }

    public function getStudentScheduleEntries($filters)
    {
        return $this->studentScheduleEntryRepo->getStudentScheduleEntries($filters);
    }

    public function getStudentScheduleEntriesBuilder($filters)
    {
        return $this->studentScheduleEntryRepo->getStudentScheduleEntriesBuilder($filters);
    }
    
    public function checkSiteCapacityValidation($data, $student)
    {
        $booked = $this->studentScheduleEntryRepo->getStudentScheduleEntries(new StudentScheduleEntryFilters([
            'student' => $data['student_id'],
            'sameWeekAs' => $data['date'],
            'appointmentType' => StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE
        ]));

        $theChosenDay = $this->studentScheduleEntryRepo->getStudentScheduleEntries(new StudentScheduleEntryFilters([
            'date' => $data['date'],
            'startTime' => $data['from'],
            'endTime' => $data['to'],
        ]));

        if(isset($student->site->capacity) && $student->site->capacity->no_capacity_restrictions == 0){
            // 2 * $theChosenDay->count() ----> 2 is for GC + Staff Member
            throw_if($student->site->capacity->people_per_site <= (2 * $theChosenDay->count()),
                new CannotBeScheduledException('Cannot schedule because the limit for people per site')
            );

            throw_if($student->site->capacity->gc_onsite_limit_per_week <= $booked->count(),
                new CannotBeScheduledException('Cannot schedule because gc on site limit')
            );
        }
    }
}
