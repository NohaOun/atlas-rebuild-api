<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\StaffScheduleEntryFilters;
use App\Domain\Schedule\Model\StaffScheduleEntry;
use Illuminate\Database\Eloquent\Collection;

class StaffScheduleEntryRepository implements StaffScheduleEntryRepositoryInterface
{
    public function saveStaffScheduleEntry(StaffScheduleEntry $record)
    {
        return $record->save();
    }

    public function deleteStaffScheduleEntry(StaffScheduleEntry $record)
    {
        $record->appointmentCategories()->detach();

        return $record->delete();
    }

    public function syncStaffScheduleEntryAppointmentCategories(StaffScheduleEntry $record, $categoryIds)
    {
        $record->appointmentCategories()->sync($categoryIds);
    }

    public function getStaffScheduleEntries(StaffScheduleEntryFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    protected function getFilteredBuilder(?StaffScheduleEntryFilters $filters)
    {
        $builder = StaffScheduleEntry::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}