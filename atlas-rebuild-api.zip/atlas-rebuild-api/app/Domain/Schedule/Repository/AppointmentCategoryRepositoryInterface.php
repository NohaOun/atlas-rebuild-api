<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\AppointmentCategoryFilters;
use App\Domain\Schedule\Model\AppointmentCategory;
use Illuminate\Database\Eloquent\Collection;

interface AppointmentCategoryRepositoryInterface
{
    public function getAppointmentCategories(AppointmentCategoryFilters $filters): Collection;

    public function getAppointmentCategory($resourceId);

    public function saveAppointmentCategory(AppointmentCategory $record);

    public function deleteAppointmentCategory(AppointmentCategory $record);

    public function getFilteredBuilder(AppointmentCategoryFilters $filters);
}
