<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Student\Filters\StudentScheduleFilters;
use App\Domain\Student\Model\StudentSchedule;
use Illuminate\Database\Eloquent\Collection;

interface StudentScheduleRepositoryInterface
{
    public function getStudentSchedules(StudentScheduleFilters $filters): Collection;

    public function getStudentSchedule($resourceId);

    public function saveStudentSchedule(StudentSchedule $record);

    public function deleteStudentSchedule(StudentSchedule $record);
}
