<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\ScheduleBlockFilters;
use App\Domain\Schedule\Model\ScheduleBlock;

class ScheduleBlockRepository implements ScheduleBlockRepositoryInterface
{
    public function getScheduleBlock($scheduleBlockId): ?ScheduleBlock
    {
        return ScheduleBlock::query()->find($scheduleBlockId);
    }

    public function getPrimaryScheduleBlock($siteId, ScheduleBlockFilters $filters = null): ?ScheduleBlock
    {
        $builder = ScheduleBlock::query()->where('site_id', $siteId)->where('primary', true);

        if ($filters) {
            $filters->apply($builder);
        }

        return $builder->first();
    }
}
