<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\StudentScheduleEntryFilters;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use Illuminate\Database\Eloquent\Collection;

interface StudentScheduleEntryRepositoryInterface
{
    public function getStudentScheduleEntries(StudentScheduleEntryFilters $filters): Collection;
    
    public function getStudentScheduleEntriesBuilder(StudentScheduleEntryFilters $filters);

    public function saveStudentScheduleEntry(StudentScheduleEntry $record);

    public function deleteStudentScheduleEntry(StudentScheduleEntry $record);

    public function syncStudentScheduleEntryAppointmentCategories(StudentScheduleEntry $entry, $categoryIds);
}
