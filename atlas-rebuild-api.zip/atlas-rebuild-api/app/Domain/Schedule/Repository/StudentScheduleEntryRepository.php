<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\StudentScheduleEntryFilters;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use Illuminate\Database\Eloquent\Collection;

class StudentScheduleEntryRepository implements StudentScheduleEntryRepositoryInterface
{
    public function getStudentScheduleEntries(StudentScheduleEntryFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getStudentScheduleEntriesBuilder(StudentScheduleEntryFilters $filters)
    {
        return $this->getFilteredBuilder($filters);
    }
    
    public function saveStudentScheduleEntry(StudentScheduleEntry $record)
    {
        return $record->save();
    }

    public function deleteStudentScheduleEntry(StudentScheduleEntry $record)
    {
        $record->appointmentCategories()->detach();

        return $record->delete();
    }

    public function syncStudentScheduleEntryAppointmentCategories(StudentScheduleEntry $entry, $categoryIds)
    {
        $entry->appointmentCategories()->sync($categoryIds);
    }

    protected function getFilteredBuilder(?StudentScheduleEntryFilters $filters)
    {
        $builder = StudentScheduleEntry::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
