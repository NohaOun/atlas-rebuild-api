<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\AppointmentCategoryFilters;
use App\Domain\Schedule\Model\AppointmentCategory;
use Illuminate\Database\Eloquent\Collection;

class AppointmentCategoryRepository implements AppointmentCategoryRepositoryInterface
{
    public function getAppointmentCategories(AppointmentCategoryFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getAppointmentCategory($resourceId)
    {
        return AppointmentCategory::query()->find($resourceId);
    }

    public function saveAppointmentCategory(AppointmentCategory $record)
    {
        return $record->save();
    }

    public function deleteAppointmentCategory(AppointmentCategory $record)
    {
        $record->sites()->detach();

        return $record->delete();
    }

    public function getFilteredBuilder(AppointmentCategoryFilters $filters)
    {
        $builder = AppointmentCategory::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
