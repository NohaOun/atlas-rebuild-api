<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\StaffScheduleFilters;
use App\Domain\Schedule\Model\StaffSchedule;
use Illuminate\Database\Eloquent\Collection;

class StaffScheduleRepository implements StaffScheduleRepositoryInterface
{
    public function getStaffSchedules(StaffScheduleFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getStaffSchedule($resourceId)
    {
        return StaffSchedule::query()->find($resourceId);
    }

    public function saveStaffSchedule(StaffSchedule $record)
    {
        return $record->save();
    }

    public function deleteStaffSchedule(StaffSchedule $record)
    {
        $record->entries->each(function ($entry) {
            $entry->delete();
        });

        return $record->delete();
    }

    protected function getFilteredBuilder(?StaffScheduleFilters $filters)
    {
        $builder = StaffSchedule::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
