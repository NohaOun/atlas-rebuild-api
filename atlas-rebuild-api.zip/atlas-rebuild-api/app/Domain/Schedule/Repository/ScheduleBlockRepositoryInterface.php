<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\ScheduleBlockFilters;
use App\Domain\Schedule\Model\ScheduleBlock;

interface ScheduleBlockRepositoryInterface
{
    public function getScheduleBlock($scheduleBlockId): ?ScheduleBlock;

    public function getPrimaryScheduleBlock($siteId, ScheduleBlockFilters $filters = null): ?ScheduleBlock;
}
