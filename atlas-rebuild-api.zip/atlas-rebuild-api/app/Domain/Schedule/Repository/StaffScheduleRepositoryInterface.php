<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Filters\StaffScheduleFilters;
use App\Domain\Schedule\Model\StaffSchedule;
use Illuminate\Database\Eloquent\Collection;

interface StaffScheduleRepositoryInterface
{
    public function getStaffSchedules(StaffScheduleFilters $filters): Collection;

    public function getStaffSchedule($resourceId);

    public function saveStaffSchedule(StaffSchedule $record);

    public function deleteStaffSchedule(StaffSchedule $record);
}
