<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Schedule\Model\StaffScheduleEntry;

interface StaffScheduleEntryRepositoryInterface
{
    public function saveStaffScheduleEntry(StaffScheduleEntry $record);

    public function deleteStaffScheduleEntry(StaffScheduleEntry $record);

    public function syncStaffScheduleEntryAppointmentCategories(StaffScheduleEntry $record, $categoryIds);
}
