<?php

namespace App\Domain\Schedule\Repository;

use App\Domain\Student\Filters\StudentScheduleFilters;
use App\Domain\Student\Model\StudentSchedule;
use Illuminate\Database\Eloquent\Collection;

class StudentScheduleRepository implements StudentScheduleRepositoryInterface
{
    public function getStudentSchedules(StudentScheduleFilters $filters): Collection
    {
        return $this->getFilteredBuilder($filters)->get();
    }

    public function getStudentSchedule($resourceId)
    {
        return StudentSchedule::query()->find($resourceId);
    }

    public function saveStudentSchedule(StudentSchedule $record)
    {
        return $record->save();
    }

    public function deleteStudentSchedule(StudentSchedule $record)
    {
        $record->entries->each(function ($entry) {
            $entry->delete();
        });

        return $record->delete();
    }

    protected function getFilteredBuilder(?StudentScheduleFilters $filters)
    {
        $builder = StudentSchedule::query();

        if ($filters) $filters->apply($builder);

        return $builder;
    }
}
