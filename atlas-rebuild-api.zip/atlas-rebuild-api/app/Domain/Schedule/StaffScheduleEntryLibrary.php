<?php

namespace App\Domain\Schedule;

use App\Domain\Common\Helpers;
use App\Domain\Schedule\Model\StaffScheduleEntry;
use App\Domain\Schedule\Repository\ScheduleBlockRepositoryInterface;
use App\Domain\Schedule\Repository\StaffScheduleEntryRepositoryInterface;
use App\Domain\Schedule\Repository\StaffScheduleRepositoryInterface;
use App\Domain\Site\Model\Site;
use Carbon\Carbon;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class StaffScheduleEntryLibrary
{
    protected $stuffScheduleEntryRepo;
    protected $staffScheduleRepo;
    protected $scheduleBlockRepo;

    public function __construct(
        StaffScheduleEntryRepositoryInterface $staffScheduleEntryRepo,
        StaffScheduleRepositoryInterface $staffScheduleRepo,
        ScheduleBlockRepositoryInterface $scheduleBlockRepo
    )
    {
        $this->stuffScheduleEntryRepo = $staffScheduleEntryRepo;
        $this->staffScheduleRepo = $staffScheduleRepo;
        $this->scheduleBlockRepo = $scheduleBlockRepo;
    }

    public function createStaffScheduleEntry(array $data)
    {
        return $this->saveStaffScheduleEntry(new StaffScheduleEntry, $data);
    }

    public function updateStaffScheduleEntry(StaffScheduleEntry $category, $data)
    {
        return $this->saveStaffScheduleEntry($category, $data);
    }

    protected function saveStaffScheduleEntry(StaffScheduleEntry $entry, $data)
    {
        return DB::transaction(function () use ($entry, $data) {
            $attributes = $this->parseStaffScheduleEntryAttributes($data);

            $entry->fill($attributes);

            $this->stuffScheduleEntryRepo->saveStaffScheduleEntry($entry);

            $this->saveStaffScheduleEntryAppointmentCategories($entry, $data);

            return $entry;
        });
    }

    protected function parseStaffScheduleEntryAttributes($attributes)
    {
        if (Arr::has($attributes, ['staff_schedule_id', 'schedule_block_id'])) {
            $staffSchedule = $this->staffScheduleRepo->getStaffSchedule($attributes['staff_schedule_id']);
            /** @var Site $site */
            $site = $staffSchedule->site;
            if ($site->hasSecondaryScheduleBlocks()) {
                $day = Helpers::getDay($attributes['date']);
                $scheduleBlock = $this->scheduleBlockRepo->getScheduleBlock($attributes['schedule_block_id']);
                $attributes['from'] = $scheduleBlock->days[$day]['from'];
                $attributes['to'] = $scheduleBlock->days[$day]['to'];
            }
        }

        if (Arr::has($attributes, 'date')) {
            $attributes['date'] = Carbon::createFromFormat('m/d/Y', $attributes['date'])->format('Y-m-d');
        }

        return $attributes;
    }

    protected function saveStaffScheduleEntryAppointmentCategories(StaffScheduleEntry $entry, $attributes)
    {
        if (Arr::has($attributes, 'appointment_category_ids')) {
            $this->stuffScheduleEntryRepo->syncStaffScheduleEntryAppointmentCategories(
                $entry, $attributes['appointment_category_ids']
            );
        }
    }

    public function deleteStaffScheduleEntry($record)
    {
        return $this->stuffScheduleEntryRepo->deleteStaffScheduleEntry($record);
    }
}
