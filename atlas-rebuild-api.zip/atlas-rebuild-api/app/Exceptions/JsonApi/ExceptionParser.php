<?php

namespace App\Exceptions\JsonApi;

use App\Domain\Auth\Exception\CurrentTenantIsNotDefinedException;
use App\Domain\Bank\Exception\DistrictAlreadyAssignedException;
use App\Domain\Bank\Exception\NoRemainingException;
use App\Domain\Bank\Exception\NotFoundBankSiteException;
use App\Domain\Bank\Exception\SiteAlreadyAssignedException;
use App\Domain\Bank\Exception\UnavailablePointsException;
use App\Domain\Chat\Exception\UnauthorizedActionException;
use App\Domain\Contact\Exception\SiteRequiredException;
use App\Domain\Schedule\Exception\CannotBeScheduledException;
use App\Domain\Auth\Exception\ShouldChangePasswordException;
use App\Domain\Schedule\Exception\PrimaryScheduleBlockAlreadyExistsException;
use App\Domain\Schedule\Exception\PrimaryScheduleBlockIsMissingException;
use App\Domain\Student\Exception\ArchivedException;
use App\Domain\Student\Exception\LegalGuardianException;
use App\Domain\Note\Exception\NotValidDueDateException;
use App\Domain\Student\Exception\MilitaryBranchRequiredException;
use App\Domain\StudentAttendance\Exception\CannotCheckoutException;
use App\Domain\User\Exception\ALreadyChangedTempPassword;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Http\Response;
use Neomerx\JsonApi\Document\Error;
use App\Domain\Contact\Exception\InvalidContactFileException;
use App\Domain\FileUpload\Exception\InvalidUploadedFileException;
use CloudCreativity\LaravelJsonApi\Exceptions\ExceptionParser as BaseExceptionParser;

class ExceptionParser extends BaseExceptionParser
{
    protected function getErrors(\Throwable $e): array
    {
        if ($e instanceof InvalidUploadedFileException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof DistrictAlreadyAssignedException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof DistrictAlreadyAssignedException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof UnavailablePointsException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof NotFoundBankSiteException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof ArchivedException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof SiteAlreadyAssignedException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof MilitaryBranchRequiredException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof SiteRequiredException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof NoRemainingException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof CannotCheckoutException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof CannotCheckoutException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof LegalGuardianException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof NotValidDueDateException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof PrimaryScheduleBlockIsMissingException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof PrimaryScheduleBlockAlreadyExistsException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof InvalidContactFileException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof CurrentTenantIsNotDefinedException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof CannotBeScheduledException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof AuthenticationException) {
            return [new Error(null, null, 401, null, $e->getMessage())];
        }

        if ($e instanceof ShouldChangePasswordException) {
            return [new Error(null, null, 401, null, $e->getMessage())];
        }

        if ($e instanceof UnauthorizedActionException) {
            return [$this->createValidationError($e)];
        }

        if ($e instanceof ALreadyChangedTempPassword) {
            return [$this->createValidationError($e)];
        }

        return parent::getErrors($e);
    }

    protected function createValidationError(\Exception $e, $message = null, $status = Response::HTTP_UNPROCESSABLE_ENTITY)
    {
        return $this->createError($message ?? $e->getMessage(), $status);
    }

    protected function createError($title, $status = Response::HTTP_INTERNAL_SERVER_ERROR)
    {
        return new Error(null, null, $status, null, $title);
    }
}
