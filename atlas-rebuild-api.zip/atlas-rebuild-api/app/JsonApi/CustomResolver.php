<?php

namespace App\JsonApi;

use CloudCreativity\LaravelJsonApi\Resolver\NamespaceResolver;

class CustomResolver extends NamespaceResolver
{
    protected function resolve($unit, $resourceType)
    {
        if ($this->isResourceOfType($resourceType, 'student-status-history', $unit)) {
            return $this->resolveCustomPath('StudentStatusHistory', $unit);
        }

        if ($this->isResourceOfType($resourceType, 'completed-with', $unit)) {
            return $this->resolveCustomPath('CompletedWith', $unit);
        }

        return parent::resolve($unit, $resourceType);
    }

    protected function isResourceOfType($requestedType, $comparedWith, $unit, $availableUnits = null)
    {
        if (is_null($availableUnits)) {
            $availableUnits = ['Adapter', 'Schema', 'Validators'];
        }

        return $requestedType === $comparedWith && in_array($unit, $availableUnits);
    }

    protected function resolveCustomPath($path, $unit)
    {
        return $this->append(sprintf('%s\%s', $path, $unit));
    }
}
