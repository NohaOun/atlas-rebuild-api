<?php

namespace App\JsonApi;

use CloudCreativity\LaravelJsonApi\Exceptions\RuntimeException;

class CreateCustomResolver
{
    public function __invoke($apiName, array $config)
    {
        $byResource = $config['by-resource'];

        if ('false-0.x' === $byResource) {
            throw new RuntimeException("The 'false-0.x' resolver option is no longer supported.");
        }

        return new CustomResolver(
            $config['namespace'],
            (array)$config['resources'],
            (bool)$byResource
        );
    }
}
