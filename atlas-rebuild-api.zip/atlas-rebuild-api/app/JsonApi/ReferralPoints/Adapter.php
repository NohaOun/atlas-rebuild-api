<?php

namespace App\JsonApi\ReferralCodePoints;

use App\Domain\User\Filters\ReferralCodePointFilters;
use App\Domain\User\ReferralCodePointLibrary;
use CloudCreativity\LaravelJsonApi\Contracts\Adapter\RelationshipAdapterInterface;
use CloudCreativity\LaravelJsonApi\Contracts\Adapter\ResourceAdapterInterface;
use Illuminate\Support\Arr;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;

class Adapter implements ResourceAdapterInterface
{
    protected $referralCodePoint;

    public function __construct(ReferralCodePointLibrary $referralCodePoint)
    {
        $this->referralCodePoint = $referralCodePoint;
    }

    public function create(array $document, EncodingParametersInterface $parameters)
    {
        return $this->referralCodePoint->createReferralCodePoint($this->parseDocument($document));
    }

    public function read($record, EncodingParametersInterface $parameters)
    {
        return $this->referralCodePoint->getReferralCodePoint($record->id);
    }

    public function update($record, array $document, EncodingParametersInterface $params)
    {
        return $this->referralCodePoint->updateReferralCodePoint($record, $this->parseDocument($document));
    }

    public function delete($record, EncodingParametersInterface $params)
    {
        return $this->referralCodePoint->deleteReferralCodePoint($record);
    }

    public function getRelated(string $field): RelationshipAdapterInterface
    {
        // TODO: Implement getRelated() method.
    }

    public function query(EncodingParametersInterface $parameters)
    {
        return $this->referralCodePoint->getReferralCodePoints();
    }

    public function exists(string $resourceId): bool
    {
        return (bool)$this->find($resourceId);
    }

    public function find(string $resourceId)
    {
        return $this->referralCodePoint->getReferralCodePoint($resourceId);
    }

    public function findMany(iterable $resourceIds): iterable
    {
        return $this->referralCodePoint->getReferralCodePoints(new ReferralCodePointFilters(['ids' => $resourceIds]));
    }

    protected function parseDocument($document)
    {
        $attributes = Arr::only(
            Arr::get($document, 'data.attributes', []), ['name']
        );

        if (Arr::has($document, 'data.relationships.permissions')) {
            $attributes['permission_ids'] = array_map(function ($permission) {
                return $permission['id'];
            }, Arr::get($document, 'data.relationships.permissions.data'));
        }

        return $attributes;
    }
}
