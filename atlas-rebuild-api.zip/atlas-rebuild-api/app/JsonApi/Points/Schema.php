<?php

namespace App\JsonApi\Points;

use App\JsonApi\Lookup\Schema as LookupSchema;

class Schema extends LookupSchema
{
    protected $resourceType = 'points';

}
