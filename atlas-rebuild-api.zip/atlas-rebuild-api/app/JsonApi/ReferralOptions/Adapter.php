<?php

namespace App\JsonApi\ReferralOptions;

use App\Domain\ReferralOption\Filters\ReferralOptionFilters;
use App\Domain\ReferralOption\Model\ReferralOption;
use App\Domain\ReferralOption\ReferralOptionLibrary;
use CloudCreativity\LaravelJsonApi\Contracts\Adapter\RelationshipAdapterInterface;
use CloudCreativity\LaravelJsonApi\Eloquent\AbstractAdapter;
use CloudCreativity\LaravelJsonApi\Pagination\StandardStrategy;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;

class Adapter extends AbstractAdapter
{
    protected $referralOptionLibrary;

    public function __construct(ReferralOptionLibrary $referralOptionLibrary, StandardStrategy $paging = null)
    {
        parent::__construct(new ReferralOption(), $paging);
        $this->referralOptionLibrary = $referralOptionLibrary;
    }

    protected function filter($query, Collection $filters)
    {
        $filters = new ReferralOptionFilters($filters->toArray());
        return $filters->apply($query);
    }

    /**
     * @inheritDoc
     */
    public function create(array $document, EncodingParametersInterface $parameters)
    {
        return $this->referralOptionLibrary->createReferralOption(Arr::get($document, 'data.attributes'));
    }

    /**
     * @inheritDoc
     */
    public function read($record, EncodingParametersInterface $parameters)
    {
        return $record;
    }

    /**
     * @inheritDoc
     */
    public function update($record, array $document, EncodingParametersInterface $params)
    {
        return $this->referralOptionLibrary->updateReferralOption($record, Arr::get($document, 'data.attributes'));
    }

    /**
     * @inheritDoc
     */
    public function delete($record, EncodingParametersInterface $params)
    {
        return $this->referralOptionLibrary->deleteReferralOption($record);
    }

    /**
     * @inheritDoc
     */
    public function getRelated(string $field): RelationshipAdapterInterface
    {
        // TODO: Implement getRelated() method.
    }

    /**
     * @inheritDoc
     */
    public function exists(string $resourceId): bool
    {
        return (boolean)$this->referralOptionLibrary->getReferralOption($resourceId)->count();
    }

    /**
     * @inheritDoc
     */
    public function find(string $resourceId)
    {
        return $this->referralOptionLibrary->getReferralOption($resourceId);
    }

    /**
     * @inheritDoc
     */
    public function findMany(iterable $resourceIds): iterable
    {

    }
}
