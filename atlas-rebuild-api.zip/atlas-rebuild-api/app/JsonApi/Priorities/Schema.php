<?php

namespace App\JsonApi\Priorities;

use App\JsonApi\Lookup\Schema as LookupSchema;

class Schema extends LookupSchema
{
    protected $resourceType = 'priorities';
}
