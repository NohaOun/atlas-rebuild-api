<?php

namespace App\JsonApi\Priorities;

use App\Domain\Lookup\Model\Priority;
use App\JsonApi\Lookup\Adapter as BaseAdapter;

class Adapter extends BaseAdapter
{
    protected function getModel()
    {
        return new Priority();
    }
}
