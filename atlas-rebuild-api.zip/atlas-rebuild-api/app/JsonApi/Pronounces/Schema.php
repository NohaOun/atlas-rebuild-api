<?php

namespace App\JsonApi\Pronounces;

use App\JsonApi\Lookup\Schema as LookupSchema;

class Schema extends LookupSchema
{
    protected $resourceType = 'pronounces';
}
