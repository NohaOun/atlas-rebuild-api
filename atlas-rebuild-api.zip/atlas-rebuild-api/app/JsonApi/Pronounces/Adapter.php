<?php

namespace App\JsonApi\Pronounces;

use App\Domain\Lookup\Model\Pronouns;
use App\JsonApi\Lookup\Adapter as BaseAdapter;

class Adapter extends BaseAdapter
{
    protected function getModel()
    {
        return new Pronouns();
    }
}
