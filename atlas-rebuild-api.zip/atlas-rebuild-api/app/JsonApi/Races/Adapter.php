<?php

namespace App\JsonApi\Races;

use App\Domain\Lookup\Model\Race;
use App\JsonApi\Lookup\Adapter as BaseAdapter;

class Adapter extends BaseAdapter
{
    protected function getModel()
    {
        return new Race();
    }
}
