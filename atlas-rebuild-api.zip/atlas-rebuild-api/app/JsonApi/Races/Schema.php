<?php

namespace App\JsonApi\Races;

use App\JsonApi\Lookup\Schema as LookupSchema;

class Schema extends LookupSchema
{
    protected $resourceType = 'races';
}
