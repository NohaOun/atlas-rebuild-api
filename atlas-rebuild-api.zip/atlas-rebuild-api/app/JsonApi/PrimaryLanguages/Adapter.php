<?php

namespace App\JsonApi\PrimaryLanguages;

use App\Domain\Lookup\Model\PrimaryLanguage;
use App\JsonApi\Lookup\Adapter as BaseAdapter;

class Adapter extends BaseAdapter
{
    protected function getModel()
    {
        return new PrimaryLanguage();
    }
}
