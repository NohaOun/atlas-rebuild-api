<?php

namespace App\JsonApi\PlpCourses;

use App\Domain\Plp\CourseLibrary;
use App\Domain\Plp\Filters\CourseFilters;
use CloudCreativity\LaravelJsonApi\Contracts\Adapter\RelationshipAdapterInterface;
use CloudCreativity\LaravelJsonApi\Contracts\Adapter\ResourceAdapterInterface;
use Illuminate\Support\Arr;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;

class Adapter implements ResourceAdapterInterface
{
    protected $courseLibrary;

    public function __construct(CourseLibrary $courseLibrary)
    {
        $this->courseLibrary = $courseLibrary;
    }

    public function create(array $document, EncodingParametersInterface $parameters)
    {
        return $this->courseLibrary->createCourse(
            $this->parseDocument($document)
        );
    }

    public function read($record, EncodingParametersInterface $parameters)
    {
        return $record;
    }

    public function update($record, array $document, EncodingParametersInterface $params)
    {
        return $this->courseLibrary->updateCourse(
            $record, $this->parseDocument($document)
        );
    }

    public function delete($record, EncodingParametersInterface $params)
    {
        return $this->courseLibrary->deleteCourse($record);
    }

    public function getRelated(string $field): RelationshipAdapterInterface
    {
        // TODO: Implement getRelated() method.
    }

    public function query(EncodingParametersInterface $parameters)
    {
        return $this->courseLibrary->getCourses(
            new CourseFilters($parameters->getFilteringParameters() ?? [])
        );
    }

    public function exists(string $resourceId): bool
    {
        return (bool)$this->find($resourceId);
    }

    public function find(string $resourceId)
    {
        return $this->courseLibrary->getCourse($resourceId);
    }

    public function findMany(iterable $resourceIds): iterable
    {
        return $this->courseLibrary->getCourses(
            new CourseFilters(['ids' => $resourceIds])
        );
    }

    protected function parseDocument(array $document)
    {
        $attributes = Arr::only(
            Arr::get($document, 'data.attributes'), ['name', 'min_score', 'tier_5']
        );

        $documentRelationships = Arr::get($document, 'data.relationships', []);

        if (isset($documentRelationships['group'])) {
            $attributes['group_id'] = $documentRelationships['group']['data']['id'];
        }

        return $attributes;
    }
}
