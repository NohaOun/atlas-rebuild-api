<?php

namespace App\JsonApi\PlpCourses;

use App\Rules\PositiveNumber;
use CloudCreativity\LaravelJsonApi\Rules\HasOne;
use CloudCreativity\LaravelJsonApi\Validation\AbstractValidators;

class Validators extends AbstractValidators
{
    protected $allowedIncludePaths = ['group'];

    protected $allowedFilteringParameters = [];

    protected function existingAttributes($record): iterable
    {
        return [];
    }

    protected function rules($record = null): array
    {
        $filling = $record === null ? 'required' : 'filled';

        return [
            'name' => [$filling, 'string', 'max:255'],
            'min_score' => ['filled', new PositiveNumber],
            'tier_5' => ['filled'],
            'group' => [$filling, new HasOne('plp-course-groups')]
        ];
    }

    protected function queryRules(): array
    {
        return [];
    }
}
