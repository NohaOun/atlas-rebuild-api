<?php

namespace App\JsonApi\PlpCourses;

use Neomerx\JsonApi\Schema\SchemaProvider;

class Schema extends SchemaProvider
{
    protected $resourceType = 'plp-courses';

    public function getId($resource)
    {
        return (string)$resource->getRouteKey();
    }

    public function getAttributes($resource)
    {
        return [
            'name' => $resource->name,
            'min_score' => $resource->min_score,
            'tier_5' => $resource->tier_5,
            'default' => (int)$resource->default,
        ];
    }

    public function getRelationships($course, $isPrimary, array $includeRelationships)
    {
        $relations = [];

        if (isset($includeRelationships['group'])) {
            $relations['group'] = [
                self::DATA => function () use ($course) {
                    return $course->group;
                },
            ];
        }

        return $relations;
    }
}
