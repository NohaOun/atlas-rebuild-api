<?php

namespace App\JsonApi;

use CloudCreativity\LaravelJsonApi\Contracts\Decoder\DecoderInterface;

class MultipartFormDataDecoder implements DecoderInterface
{
    public function decode($request): array
    {
        return $request->allFiles();
    }
}
