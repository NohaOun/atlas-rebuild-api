<?php

namespace App\JsonApi;

use CloudCreativity\LaravelJsonApi\Eloquent\AbstractAdapter;
use Illuminate\Support\Collection;

class Paging extends AbstractAdapter
{
    protected $defaultPagination = ['number' => 1, 'size' => 20];

    /**
     * @inheritDoc
     */
    protected function filter($query, Collection $filters)
    {
        // TODO: Implement filter() method.
    }
}
