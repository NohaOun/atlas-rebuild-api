Json API has three main parts

- Adapters
- Schemas
- Validators

### Schema
is our resource, where php objects' are converted to JSON API representations. 
Defining the resources is in the config file 
```
'resources' => [
    'posts' => App\Post::class,
    'comments' => App\Comment::class,
]
```
posts here is called resource type, we create the type by terminal with ``` php artisan make:json-api:schema <resource-type>```.

Method <b>getAttributes</b> is where we write what keys return.
Method <b>getRelationships</b> is where we define resource's relations and its meta like.
```
'posts' => [
    self::SHOW_SELF => false,
    self::SHOW_RELATED => true,
    self::SHOW_DATA => isset($includeRelationships['posts']),
    self::DATA => function () use ($user) {
        return $user->posts;
    },
]
```


### Adapters

is where we define, how to read/write on database. 
In construct we should define the model we use.

```$attributes``` property where we write what request's key mapped to in our model
like if the request has key called 'published-at' and our model has 'published_at'. 


We can protect JSON API from filling any attribute by ```$guarded / $fillable``` property even it is not our model.


### Validations

is where we write our validations on read/write operations, we generate the file by ```php artisan make:json-api:validators <resource-type> ```.

There are two methods we write our validation login ```queryRules``` and ```rules```.


### Sorting

We can write how we sort in property called ```$allowedSortParameters``` in Validators.

We can write the default sort in property called ```$defaultSort``` in Adaptors and - is for desc order.

We can also map what is sent to our columns in property called ```$sortColumns``` in Adapters.


### Pagination

In validators we can specify the allowed keys for pagination in ```allowedPagingParameters```, and 
we can specify the query rules for example:
```
protected $queryRules = [
        'page.number' => 'filled|numeric|min:1',
        'page.size' => 'filled|numeric|between:1,100',
    ];
```

In Adapters we can specify the default values like:
```
    protected $defaultPagination = ['number' => 1, 'size' => 5];
```
the number is the page and the size is the total data per each page.


### Filters

We can add what user can filter with in Validators in property called ```$allowedFilteringParameters```.
We can also validate its rules in method called queryRules.



