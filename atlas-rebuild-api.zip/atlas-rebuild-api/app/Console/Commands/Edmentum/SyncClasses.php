<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ClassLibrary;
use Illuminate\Console\Command;

class SyncClasses extends Command
{
    protected $signature = 'Edmentum:SyncClasses';

    protected $classLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(ClassLibrary $classLibrary)
    {
        ini_set('memory_limit', -1);
        $this->classLibrary = $classLibrary;

        //$this->classLibrary->fetchClasses();
        $this->classLibrary->storeClassData();
    }
}
