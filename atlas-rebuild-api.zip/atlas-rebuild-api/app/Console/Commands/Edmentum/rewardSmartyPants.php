<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use stdClass;

class rewardSmartyPants extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $studentPointsLib;
    private $challengeLibrary;
    private $studentRepository;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-smarty-pants {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward SmartyPants';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary, 
                ChallengeLibrary $challengeLibrary,
                StudentPointLibrary $studentPointsLib,
                StudentRepository $studentRepository)
    {
        parent::__construct();
        $this->studentPointsLib = $studentPointsLib;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        $this->studentRepository = $studentRepository;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Not finished Edugenty Based !
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            echo "PLase Add Tenant ID";
            exit;
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get orientation Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('smarty_pants');
         
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong> SmartyPants Challenge was deactivated</strong>';
 			exit(); 
 			return false;	
         } 
        $startDate = now()->startOfMonth();
        $endDate = now()->endOfDay();
        $studentWith_finished_activity = DB::table('edmentum_activity_learners AS eal_1')
                        ->selectRaw("edmentum_learner_id, count(*) completedChallenges")
                        ->join("edmentum_class_activities AS eca_1","eca_1.provider_id" , "eal_1.resource_node_id")
                        ->join("students", function($join){
                            $join->where("students.tenant_id", $this->tenant->id);
                            $join->on("students.id", "edmentum_learner_id");
                        })
                        ->whereRaw("eca_1.grade_category_name like '%Assessment%'  
                        AND ((eal_1.score / eca_1.grade_category_score) * 100) >= ".$this->challenge->property["assessment_attempt1_bonus"]["percentage"]."
                        AND `eal_1`.`score_time` between '$startDate' and '$endDate'
                        AND eal_1.score_time = (select min(eal_2.score_time)  from edmentum_activity_learners eal_2 
                            join edmentum_class_activities eca_2 on eca_2.provider_id = eal_2.resource_node_id
                            where eca_2.id = eca_1.id  and `eal_2`.`score_time` between '$startDate' and '$endDate'
                        )")->groupBy("edmentum_learner_id")->get();

        $student_Points = Student::join('student_points',function($query)use($startDate, $endDate){
            $query->on('student_points.student_id', 'students.id');
            $query->where('challenge_id', $this->challenge->id);
            $query->whereBetween('student_points.created_at', [$startDate, $endDate]);
        })->selectRaw('students.id, count(students.id) completedChallenges')
        ->groupBy('students.id')
        ->get()->pluck("completedChallenges", "id")->toArray();
        foreach($studentWith_finished_activity as $studentActivity){
            $count = $student_Points[$studentActivity->edmentum_learner_id] ?? 0;
            if($count <  $studentActivity->completedChallenges){
                $rest = $studentActivity->completedChallenges - $count;
                $student = $this->studentRepository->getStudent($studentActivity->edmentum_learner_id);
                for ($i=0; $i < $rest; $i++) { 
                    switch($this->challenge->property["assessment_attempt1_bonus"]["type"] ?? 2){
                        case"1":
                            $this->studentPointsLib->multiplyPoints($student , $this->challenge->property["assessment_attempt1_bonus"]["value"], $this->challenge);
                            $this->rewardNewBadge($student );
                    
                        break;
                        case '2':
                            $this->studentPointsLib->addPoints( $student , $this->challenge->property["assessment_attempt1_bonus"]["value"], null, $this->challenge);
                            $this->rewardNewBadge($student );
                        break;
                    }
                }
            }
        }
 		
        echo "Done";
        return 0;
    }
    
    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
