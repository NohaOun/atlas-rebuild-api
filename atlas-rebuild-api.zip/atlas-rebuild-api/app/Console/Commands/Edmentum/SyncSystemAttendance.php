<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\SystemAttendanceLibrary;
use Illuminate\Console\Command;

class SyncSystemAttendance extends Command
{
    protected $signature = 'Edmentum:SyncSystemAttendance';

    protected $systemAttendanceLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(SystemAttendanceLibrary $systemAttendanceLibrary)
    {
        ini_set('memory_limit', -1);
        $this->systemAttendanceLibrary = $systemAttendanceLibrary;

        $this->systemAttendanceLibrary->storeSystemAttendance();
    }
}
