<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\TimeOnTaskLibrary;
use Illuminate\Console\Command;

class SyncTimeOnTasks extends Command
{
    protected $signature = 'Edmentum:SyncTimeOnTask';

    protected $timeOnTaskLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(TimeOnTaskLibrary $timeOnTaskLibrary)
    {
        ini_set('memory_limit', -1);
        $this->timeOnTaskLibrary = $timeOnTaskLibrary;

        $this->timeOnTaskLibrary->storeTimeOnTask();
    }
}
