<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;

class ChallengeSchedular extends Command
{
    private $tenantLibrary;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:run-challenges';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Edmentum Run Challenges';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary)
    {
        parent::__construct();
        $this->tenantLibrary = $tenantLibrary;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // // Get Tenant From Comman Option
        // $this->getTenant();
        // if(!$this->tenant){
        //     echo "PLase Add Tenant ID";
        //     exit;
        // }
        // // initialize the Tenant
        // tenancy()->initialize($this->tenant);
        // We Cannot use this now becuase inside challenges exit();
        $tenants = $this->tenantLibrary->getTenants();
        foreach ($tenants as $key => $tenant) {
          \Artisan::call("Edmentum:reward-activity-goal --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-course-completion --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-first-course-completion --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-graduation-Hopper  --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-orientation --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-over-time-warrior  --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-smarty-pants  --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-tier-Hopper  --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-weekly-dash  --tenant=$tenant->id");
          \Artisan::call("Edmentum:reward-weekly-progress  --tenant=$tenant->id");
        }

    }
}
