<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ClassLibrary;
use App\Domain\Edmentum\CoursewareAuditLiberary;
use Illuminate\Console\Command;

class SyncCoursewareAudit extends Command
{
    protected $signature = 'Edmentum:SyncCoursewareAudit';

    protected $coursewareAuditLiberary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(CoursewareAuditLiberary $coursewareAuditLiberary)
    {
        ini_set('memory_limit', -1);
        $this->coursewareAuditLiberary = $coursewareAuditLiberary;
        $this->coursewareAuditLiberary->storeCoursewareAuditLiberaryData();
    }
}
