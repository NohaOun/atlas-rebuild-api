<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use stdClass;

class rewardWeeklyDash extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $challengeLibrary;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-weekly-dash {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward-tier-Hopper';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary,
                                    ChallengeLibrary $challengeLibrary)
    {
        parent::__construct();
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get Tier Hopper Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('weekly_dash');
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong>weekly_dash Challenge was deactivated</strong>';
 			exit();
 			return false;	
         } 	
         
 		$studentWeekInfo = $this->getStudentsWithWeekAttendenceProgress();

        foreach($studentWeekInfo as $id=> $student){
            
            $bonus_type = null;
            switch($this->checkPreviousWeeks($student)){
                case '1':
                    $bonus_type = $this->challenge->property["week1_bonus_points"]["type"] ?? 2;
                    $bonus_value = $this->challenge->property["week1_bonus_points"]["value"];
                break;
                case '2':
                    $bonus_type = $this->challenge->property["week2_bonus_points"]["type"] ?? 2;
                    $bonus_value = $this->challenge->property["week2_bonus_points"]["value"];
                break;
                case '3':
                    $bonus_type = $this->challenge->property["week3_bonus_points"]["type"] ?? 2;
                    $bonus_value = $this->challenge->property["week3_bonus_points"]["value"];
                break; 	
                case '4':
                    $bonus_type = $this->challenge->property["week4_bonus_points"]["type"] ?? 2;
                    $bonus_value = $this->challenge->property["week4_bonus_points"]["value"];
                break; 	
            }
            // Reward Points to student  and Badge 
            switch($bonus_type){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $student, $bonus_value, $this->challenge);
                    $this->rewardNewBadge($student);
            
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $student, $bonus_value, null, $this->challenge);
                    $this->rewardNewBadge($student);
                break;
            }
            
        }
        return 0;
    }

    public function getStudentsWithWeekAttendenceProgress(){
          $attendence_table = 'weekly_attendence';
          $result = DB::select(DB::raw("select * from 
      ( select
             ".$attendence_table.".created_at,".$attendence_table.".total_minutes,".$attendence_table.".week_number, ".$attendence_table.".student_id, weekly_progress.progress,
             @rank := IF(@group=".$attendence_table.".student_id, @rank+1, 1) as rank,
             @group := ".$attendence_table.".student_id as grp 
           from 
              ".$attendence_table." 
              JOIN students on ".$attendence_table.".student_id  = `students`.`id`  and students.tenant_id = $this->tenant->id
              left join 
              weekly_progress on ".$attendence_table.".student_id = weekly_progress.student_id 
              and 
              ".$attendence_table.".week_number = weekly_progress.week_number 
      
          ,
             (
                  select @rank := 0, @group := 0) as vars order by ".$attendence_table.".student_id asc, ".$attendence_table.".week_number desc ) 
                  as weekly 
                   left join students on students.id = weekly.student_id 
                   where rank <= 4 and students.phase = 'Enrolled'
                   order by weekly.student_id, weekly.week_number desc"));
        
          $studentsWithWeekInfoArray = [];
          $counter = 0;
          foreach ($result as $row ) {
            $counter++;
             $id = $row->grp;
             if($id !== $prevId){
               $student = [];
               $counter = 1;
             }
             if($counter > 4) continue;
             
             $student[$id]['weeks'][$row->week_number]['progress'] = $row->progress;
             $student[$id]['weeks'][$row->week_number]['attendance'] = $row->total_minutes;
             $studentsWithWeekInfoArray[$id] = $student[$id];
             $prevId = $id;
          }
          return ($studentsWithWeekInfoArray);
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
    }
    
    function attendenceChallenge($attendenceMinutes){
        if($attendenceMinutes >= $this->challenge->property["attendance_goal"]["value"] ){
            return true;
        }else{
            return false;
        }
    }
    function progressChallenge($progressPercentage){
        if($progressPercentage >= $this->challenge->property["progress_goal"]["value"] ){
            return true;
        }else{
            return false;
        }
    }

    function checkPreviousWeeks($student){
        $i = 0;
        //var_dump($student['weeks']);
        foreach($student['weeks'] as $key => $value ){
            if(
                !$this->attendenceChallenge($value['attendance']) || 
                !$this->progressChallenge($value['progress'])
            ){ // add class progress values
                return $i;
            }
            $i++;
        }	
        return $i;
    }
}
