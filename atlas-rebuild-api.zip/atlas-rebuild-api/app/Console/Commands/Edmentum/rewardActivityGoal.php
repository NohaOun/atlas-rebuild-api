<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use stdClass;

class rewardActivityGoal extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $studentPointsLib;
    private $challengeLibrary;
    private $studentRepository;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-activity-goal {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward ActivityGoal';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary, 
                ChallengeLibrary $challengeLibrary,
                StudentPointLibrary $studentPointsLib,
                StudentRepository $studentRepository)
    {
        parent::__construct();
        $this->studentPointsLib = $studentPointsLib;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        $this->studentRepository = $studentRepository;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            echo "PLase Add Tenant ID";
            exit;
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get orientation Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('activity_goal');
         
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong> Activity Goal Challenge was deactivated</strong>';
 			exit();
 			return false;	
         } 
        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay(); // 3-1-2021 
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay();// 10-1-2021
        // $startDate = '2021-01-010 00:00:00.0';
        // $endDate = '2021-01-16 00:00:00.0';
        // Get Student that Finished Courses 
        $studentsOrientation = Student::
            join('edmentum_activity_learners', 'edmentum_activity_learners.edmentum_learner_id', 'students.id')->
            join('edmentum_class_activities', 'edmentum_class_activities.provider_id', 
            'edmentum_activity_learners.resource_node_id')
            ->leftJoin('student_points',function($query)use($startDate, $endDate){
                    $query->on('student_points.student_id', 'students.id');
                    $query->where('challenge_id', $this->challenge->id);
                    $query->whereBetween('student_points.created_at', [$startDate, $endDate]);
            })
            ->selectRaw('students.id, count(edmentum_class_activities.id)')
            ->groupBy('students.id')->having(DB::raw('count(edmentum_class_activities.id)'), '>', $this->challenge->property["activity_goal"]["numberOfChallengesNeedToFinish"])
            ->whereRaw('edmentum_class_activities.grade_category_score = edmentum_activity_learners.score')
            ->whereNull('student_points.id')
            ->whereBetween('score_time', [$startDate, $endDate])
            ->get();

        foreach($studentsOrientation as $studentOrientation){
            $studnet = $this->studentRepository->getStudent($studentOrientation->id);
            switch($this->challenge->property["activity_goal"]["type"] ?? 2){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $studnet, $this->challenge->property["activity_goal"]["value"], $this->challenge);
                    $this->rewardNewBadge($studnet);
            
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $studnet, $this->challenge->property["activity_goal"]["value"], null, $this->challenge);
                    $this->rewardNewBadge($studnet);
                break;
            }
        }
        echo "Done";
        return 0;
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;
        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
