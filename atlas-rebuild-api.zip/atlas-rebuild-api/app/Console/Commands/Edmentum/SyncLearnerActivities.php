<?php


namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ActivityLearnerLibrary;
use Illuminate\Console\Command;

class SyncLearnerActivities extends Command
{
    protected $signature = 'Edmentum:SyncActivitiesLearner';

    protected $activityLearnerLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(ActivityLearnerLibrary $activityLearnerLibrary)
    {
        ini_set('memory_limit', -1);
        $this->activityLearnerLibrary = $activityLearnerLibrary;

        $this->activityLearnerLibrary->storeActivityLearner();
    }
}
