<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\CoursesCreditsLibrary;
use Illuminate\Console\Command;

class SyncCourseCredits extends Command
{
    protected $signature = 'Edmentum:SyncCourseCredits';

    protected $coursesCreditsLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(CoursesCreditsLibrary $coursesCreditsLibrary)
    {
        ini_set('memory_limit', -1);
        $this->coursesCreditsLibrary = $coursesCreditsLibrary;

        $this->coursesCreditsLibrary->storeCoursesCredits();
    }
}
