<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Challenge\Model\StudentFinishedCourses;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentAttendance\Repository\StudentAttendanceEntryRepository;
use App\Domain\Tenancy\TenantLibrary;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use stdClass;

class rewardWeeklyProgress extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $challengeLibrary;
    private $studentAttendanceEntryRepository;
    private $studentRepository;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-weekly-progress {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward Weekly Progress';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary,
                                ChallengeLibrary $challengeLibrary,
                                StudentAttendanceEntryRepository $studentAttendanceEntryRepository,
                                StudentRepository $studentRepository)
    {
        parent::__construct();
        $this->tenantLibrary = $tenantLibrary;
        $this->studentAttendanceEntryRepository = $studentAttendanceEntryRepository;
        $this->challengeLibrary = $challengeLibrary;
        $this->studentRepository = $studentRepository;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get Tier Hopper Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('weekly_progress');
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong>weekly_dash Challenge was deactivated</strong>';
 			exit();
 			return false;	
         } 	
         
        $startDate = Carbon::today()->startOfDay();
        $endDate = Carbon::tomorrow()->startOfDay();
 		$studentsAttendedIds = $this->getAttendees($startDate, $endDate);
 		$studentsAttendedIdsArrays = explode(',',$studentsAttendedIds);
 		$allStudentsWithProgress = $this->getAllStudentWithLatestProgress();
        if(!$allStudentsWithProgress){
            echo '<strong> no students</strong>';
            return false;
        }
        if(!$studentsAttendedIds || $studentsAttendedIds == ''){
            echo '<strong> no attendees that day</strong>';
            return false;
        }
        $i = 1;
        $topStudent = null;
        foreach($allStudentsWithProgress as $student){
            if(!in_array($student->id,$studentsAttendedIdsArrays)){continue;}
 			if($i == 1){ $topStudent = $student; }

 			if( $student->progress > $topStudent->progress  ){
 				$topStudent = $student;
 			}
 			$i++;
        }
        switch($this->challenge->property["weekly_progress_bonus"]["type"] ?? 2){
            case"1":
                $this->studentPointsLib->multiplyPoints($topStudent->id,$this->challenge->property["weekly_progress_bonus"]["value"], $this->challenge);
                $this->rewardNewBadge($topStudent);
            break;
            case '2':
                $this->studentPointsLib->addPoints($topStudent->id,$this->challenge->property["weekly_progress_bonus"]["value"], null ,$this->challenge);
                $this->rewardNewBadge($topStudent);
            break;
       }
        return 0;
    }

    public function getStudentsWithWeekAttendenceProgress(){
          $attendence_table = 'weekly_attendence';
          $result = DB::select(DB::raw("select * from 
      ( select
             ".$attendence_table.".created_at,".$attendence_table.".total_minutes,".$attendence_table.".week_number, ".$attendence_table.".student_id, weekly_progress.progress,
             @rank := IF(@group=".$attendence_table.".student_id, @rank+1, 1) as rank,
             @group := ".$attendence_table.".student_id as grp 
           from 
              ".$attendence_table." 
           left join 
              weekly_progress on ".$attendence_table.".student_id = weekly_progress.student_id 
              and 
              ".$attendence_table.".week_number = weekly_progress.week_number 
      
          ,
             (
                  select @rank := 0, @group := 0) as vars order by ".$attendence_table.".student_id asc, ".$attendence_table.".week_number desc ) 
                  as weekly 
                   left join students on students.id = weekly.student_id 
                   where rank <= 4 and students.phase = 'Enrolled'
                   order by weekly.student_id, weekly.week_number desc"));
        
          $studentsWithWeekInfoArray = [];
          $counter = 0;
          foreach ($result as $row ) {
            $counter++;
             $id = $row->grp;
             if($id !== $prevId){
               $student = [];
               $counter = 1;
             }
             if($counter > 4) continue;
             
             $student[$id]['weeks'][$row->week_number]['progress'] = $row->progress;
             $student[$id]['weeks'][$row->week_number]['attendance'] = $row->total_minutes;
             $studentsWithWeekInfoArray[$id] = $student[$id];
             $prevId = $id;
          }
          return ($studentsWithWeekInfoArray);
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
    }

    public function getAttendees($from,$to){
        return $this->studentAttendanceEntryRepository->getAttendanceStudentsForDay($from,$to);
    }
     function getAllStudentWithLatestProgress(){
        return $this->studentRepository->getStudentsLatestProgress();
    }

}
