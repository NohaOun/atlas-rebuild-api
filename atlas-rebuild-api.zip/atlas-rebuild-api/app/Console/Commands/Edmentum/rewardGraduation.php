<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use stdClass;

class rewardGraduation extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $studentPointsLib;
    private $challengeLibrary;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-graduation-Hopper {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward-tier-Hopper';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary, 
                ChallengeLibrary $challengeLibrary,
                StudentPointLibrary $studentPointsLib)
    {
        parent::__construct();
        $this->studentPointsLib = $studentPointsLib;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get graduate Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('graduate');
         
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong> graduate Challenge was deactivated</strong>';
 			exit();
 			return false;	
        } 
         
        // Get Finished Courses But not Handeled yet 
        $studentsFinished = Student::select("students.*")->
                            join('statuses', 'statuses.id', 'students.status_id')->
                            join('phases', function($query){
                                $query->on('phases.id', 'statuses.phase_id');
                                $query->where('phase_key', 'Graduate');
                            })->leftJoin('student_points',function($query){
                                $query->on('student_points.student_id', 'students.id');
                                $query->where('challenge_id', $this->challenge->id);
                            })->whereNull('student_points.id')->where('graduation_date', '>=', now()->startOfMonth())->get();

        // For loop for every course and reward its student
        foreach($studentsFinished as $studentFinished){
            switch($this->challenge->property["graduate_bonus"]["type"] ?? 2){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $studentFinished, $this->challenge->property["graduate_bonus"]["value"], $this->challenge);
                    $this->rewardNewBadge($studentFinished);
            
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $studentFinished, 5000, null, $this->challenge);
                    $this->rewardNewBadge($studentFinished);
                break;
            }
        }
        return 0;
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
