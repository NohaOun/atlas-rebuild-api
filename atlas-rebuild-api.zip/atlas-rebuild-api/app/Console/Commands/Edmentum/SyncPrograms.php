<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ProgramLibrary;
use Illuminate\Console\Command;

class SyncPrograms extends Command
{
    protected $signature = 'Edmentum:SyncPrograms';

    protected $program;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(ProgramLibrary $program)
    {
        ini_set('memory_limit', -1);
        $this->program = $program;

        $this->program->storeProgramData();
    }
}
