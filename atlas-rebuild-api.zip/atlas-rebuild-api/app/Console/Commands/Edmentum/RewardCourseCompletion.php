<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Edmentum\Model\EdmentumCreditsCsv;
use App\Domain\Student\Model\Student;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use stdClass;

class RewardCourseCompletion extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-course-completion {--tenant=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Reward-course-Completion';

    private $studentPointsLib;
    private $challengeLibrary;
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
            TenantLibrary $tenantLibrary, 
            ChallengeLibrary $challengeLibrary,
            StudentPointLibrary $studentPointsLib)
    {
        parent::__construct();
        $this->challengeLibrary = $challengeLibrary;
        $this->tenantLibrary = $tenantLibrary;
        $this->studentPointsLib = $studentPointsLib;
    }

    protected function getTenant()
	{
		return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
	}

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //  Didnt Complete in new system its customed and in old system they using apis call (rewardEdmentumCompletionChallenge)
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get graduate Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('course_completion');

        if(!$this->challenge || $this->challenge->status != 1){
            echo '<strong>Challenge was deactivated</strong>';
            return false;	
        }

        $student_classesFinished = Student::
                            join('edmentum_credits_csv', 'edmentum_credits_csv.SISID', 'students.id')
                            ->select("students.*")->whereNotNull('edmentum_credits_csv.GrantedDate')
                            ->select("students.*", "edmentum_credits_csv.id as credits_id")
                            ->where('edmentum_credits_csv.GrantedDate', ">=" , now()->startOfMonth())
                            ->whereNull("awarded")->distinct()->get();
        //loop through students and 
        $bonus_value = $this->challenge->property["course_completion"]["value"];
        foreach ($student_classesFinished as $key => $student) {
            # code...
            switch($this->challenge->property["course_completion"]["type"] ?? 2){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $student, $bonus_value, $this->challenge);
                    $this->rewardNewBadge($student);
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $student, $bonus_value, null, $this->challenge);
                    $this->rewardNewBadge($student);
                break;
            }
            EdmentumCreditsCsv::where('id', $student->credits_id)->update(["awarded"=>1]);
        }
        echo "Done";
        return 0;
    }


    function rewardNewBadge($student){        
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;
        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
