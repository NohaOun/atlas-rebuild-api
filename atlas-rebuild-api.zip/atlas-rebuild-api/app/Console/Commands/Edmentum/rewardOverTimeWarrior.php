<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Carbon\Carbon;
use Illuminate\Console\Command;
use stdClass;

class rewardOverTimeWarrior extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $studentPointsLib;
    private $challengeLibrary;
    private $studentRepository;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-over-time-warrior {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward Over Time Warrior OR weekend challenge';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary, 
                ChallengeLibrary $challengeLibrary,
                StudentPointLibrary $studentPointsLib,
                StudentRepository $studentRepository)
    {
        parent::__construct();
        $this->studentPointsLib = $studentPointsLib;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        $this->studentRepository = $studentRepository;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Not finished Edugenty Based !
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            echo "PLase Add Tenant ID";
            exit;
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get orientation Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('weekend_challenge');
         
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong> Overtime Challenge was deactivated</strong>';
 			exit();
 			return false;	
         } 
         
        // Get Finished Courses But not Handeled yet
        $startSaturdayDate = now()->endOfWeek(Carbon::SATURDAY)->startOfDay();
        $endSaturdayDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay();
        $startSundayDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay();

        // $startSaturdayDate = '2021-01-09 00:00:00.0';
        // $endSaturdayDate = '2021-01-09 23:59:59.999999';
        // $startSundayDate = '2021-01-10 00:00:00.0';

        // Get Student that Finished Courses 
        $student_Points = Student::join('student_points',function($query)use($startSundayDate, $endSaturdayDate){
                $query->on('student_points.student_id', 'students.id');
                $query->where('challenge_id', $this->challenge->id);
                $query->whereBetween('student_points.created_at', [$startSundayDate, $endSaturdayDate]);
            })
            ->selectRaw('students.id, count(students.id) completedChallenges')
            ->groupBy('students.id')
            ->get()->pluck("completedChallenges", "id")->toArray();
        
        $studentsActivityFinished = Student::
            join('edmentum_activity_learners', 'edmentum_activity_learners.edmentum_learner_id', 'students.id')->
            join('edmentum_class_activities', 'edmentum_class_activities.provider_id', 
            'edmentum_activity_learners.resource_node_id')
            ->groupBy('students.id')
            ->whereRaw('edmentum_class_activities.grade_category_score = edmentum_activity_learners.score')
            ->Where(function($query)use($startSaturdayDate, $startSundayDate) {
                $query->whereDate('score_time', $startSaturdayDate)
                      ->orwhereDate('score_time', $startSundayDate);
            })->selectRaw("students.id, Count(students.id) AS completedChallenges")->get();

        foreach($studentsActivityFinished as $studentActivity){
            $count = $student_Points[$studentActivity->id] ?? 0;
            if($count <  $studentActivity->completedChallenges){
                $rest = $studentActivity->completedChallenges - $count;
                $student = $this->studentRepository->getStudent($studentActivity->id);
                for ($i=0; $i < $rest; $i++) { 
                    switch($this->challenge->property["weekend_challenge"]["type"] ?? 2){
                        case"1":
                            $this->studentPointsLib->multiplyPoints($student , $this->challenge->property["weekend_challenge"]["value"], $this->challenge);
                            $this->rewardNewBadge($student );
                    
                        break;
                        case '2':
                            $this->studentPointsLib->addPoints( $student , $this->challenge->property["weekend_challenge"]["value"], null, $this->challenge);
                            $this->rewardNewBadge($student );
                        break;
                    }
                }
            }
        }
        echo "Done";
        return 0;
    }

    function getAllStudentWithLatestProgress(){
        return $this->studentRepository->getStudentsLatestProgress();
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
