<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\LearnerLibrary;
use Illuminate\Console\Command;

class SyncLearners extends Command
{
    protected $signature = 'Edmentum:SyncLearners';

    protected $learnerLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(LearnerLibrary $learnerLibrary)
    {
        ini_set('memory_limit', -1);
        $this->learnerLibrary = $learnerLibrary;

        $learnerLibrary->storeLearnerData();
    }
}
