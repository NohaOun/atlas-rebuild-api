<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\Repository\WeeklyAttendanceRepository;
use Illuminate\Console\Command;

class MigrateAttendanceWeeksToEdmentum extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:migrate-attendance-weeks-to-edmentum';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Migrate-Attendance-Weeks-To-Edmentum';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    private $weeklyAttendanceRepository;
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->weeklyAttendanceRepository = new WeeklyAttendanceRepository('EDMENTUM');
        
		$students =  $this->weeklyAttendanceRepository->getStudentsWithLatestWeek('site_attendance');
			foreach ($students as $student) {
			    $this->weeklyAttendanceRepository->addNewWeek($student->id,null,null,null,$student->weekly_num);
			}
    }
}
