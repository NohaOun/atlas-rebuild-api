<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Edmentum\Repository\WeeklyAttendanceRepository;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use stdClass;

class RewardCustomChallenges extends Command
{
    use ChallengeTriat;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:custom-challenges {--tenant=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Custom Challeng';

    protected $studentPointLibrary;
    protected $studentRepo;
    protected $weeklyAttendanceRepository;
	protected $challenge_type = 'custom';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo,
            StudentPointLibrary $studentPointLibrary,
            TenantLibrary $tenantLibrary,
            ChallengeLibrary $challengeLibrary)
    {
        parent::__construct();
        $this->studentPointLibrary = $studentPointLibrary;
        $this->studentRepo = $studentRepo;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
    }

    protected function getTenant()
	{
		return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->challengeGuard();
 		$studentWithAttendenceProgress = $this->getStudentsWithWeekAttendenceProgressLatest();
 		foreach ($studentWithAttendenceProgress as $student_id => $record) {
             $student = $this->studentRepo->getStudent($student_id);
            if($this->challenge->property["course_progress"] ){
                if($record['progress'] >= $this->challenge->property["progress_success_percentage"]){
                    switch($this->challenge->property["course_progress"]["value"]){
                        case"Multiplier":
                            $this->studentPointLibrary->multiplyPoints( $student, $this->challenge->property["progress_success_percentage"]["value"], $this->challenge);
                        break;
                        case 'Fixed Points':
                            $this->studentPointLibrary->addPoints( $student, $this->challenge->property["course_progress_bonus"]["value"], null, $this->challenge);
                        break;
                    }
                }
                
            } 
            if($this->challenge->property["attendence"]){
                if($record['attendance'] >= $this->challenge->property["attendace_success_number"]["value"]){
                    switch($this->challenge->attendence_bonus_type){
                        case"1":
                            $this->studentPointLibrary->multiplyPoints( $student, $this->challenge->property["attendance_bonus"]["value"], $this->challenge);
                            $this->rewardNewBadge($student);
                        break;
                        case '2':
                            $this->studentPointLibrary->addPoints( $student, $this->challenge->property["attendance_bonus"]["value"], null, $this->challenge);
                            $this->rewardNewBadge($student);
                        break;
                    }
                }
            }
 		}
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
    }

    public function getStudentsWithWeekAttendenceProgressLatest(){
        $result = DB::select(
            DB::raw("SELECT 
                        *
                    FROM
                        (SELECT 
                            edmentum_weekly_attendance.created_at,
                                edmentum_weekly_attendance.total_minutes,
                                edmentum_weekly_attendance.week_number,
                                edmentum_weekly_attendance.student_id,
                                edmentum_weekly_progress.progress,
                                @rank:=IF(@group = edmentum_weekly_attendance.student_id, @rank + 1, 1) AS rank,
                                @group:=edmentum_weekly_attendance.student_id AS grp
                        FROM
                            edmentum_weekly_attendance
                        LEFT JOIN edmentum_weekly_progress ON edmentum_weekly_attendance.student_id = edmentum_weekly_progress.student_id
                            AND edmentum_weekly_attendance.week_number = edmentum_weekly_progress.week_number, (SELECT @rank:=0, @group:=0) AS vars
                        ORDER BY edmentum_weekly_attendance.student_id ASC , created_at DESC) AS weekly
                            LEFT JOIN
                        students ON students.id = weekly.student_id
                    WHERE
                        rank <= 1
                    ORDER BY weekly.student_id , weekly.week_number DESC"
            )
        );
      
        $studentsWithWeekInfoArray = [];
        $counter = 0;$i = 1;
        $prevId=0;
        foreach ($result as $row ) {
          $counter++;
           $id = $row->grp;
           if($id != $prevId){
            $student = [];
            $counter = 1;
           }
           if($counter > 1) continue;
           $student[$id]['progress'] = $row->progress;
           $student[$id]['attendance'] = $row->total_minutes;
           $studentsWithWeekInfoArray[$id] = $student[$id];
           $prevId = $id;
           $i++;
        }
        return ($studentsWithWeekInfoArray);
     }	
}
