<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ClassLibrary;
use Illuminate\Console\Command;

class SyncLearnerGrades extends Command
{
    protected $signature = 'Edmentum:SyncGrads';

    protected $classLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(ClassLibrary $classLibrary)
    {
        ini_set('memory_limit', -1);
        $this->classLibrary = $classLibrary;

        $this->classLibrary->fetchClassGrads();
    }
}
