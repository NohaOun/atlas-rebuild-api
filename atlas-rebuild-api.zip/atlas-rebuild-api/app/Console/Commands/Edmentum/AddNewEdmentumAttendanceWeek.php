<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\Repository\WeeklyAttendanceRepository;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use Illuminate\Console\Command;

class AddNewEdmentumAttendanceWeek extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:add-new-edmentum-atendance-week {tenant}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add new Edmentum Attendance week';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo)
    {
        parent::__construct();
        $this->studentRepo = $studentRepo;
        $this->weeklyAttendanceRepository = new WeeklyAttendanceRepository('EDMENTUM');
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        ini_set('memory_limit', '-1');
		ini_set('max_execution_time', 0);
        $allStudents = $this->studentRepo->getStudents(new StudentFilters(['phaseKey' => 'Enrolled']));
		$counter = 1;
		foreach($allStudents as $student){
			$this->weeklyAttendanceRepository->addNewWeek($student['id']);
			if($counter > 50 ){
				$counter = 1;
				sleep(1);
			}
		}
    }
}
