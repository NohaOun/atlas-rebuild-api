<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\ActivityLibrary;
use Illuminate\Console\Command;

class SyncActivities extends Command
{
    protected $signature = 'Edmentum:SyncActivities';

    protected $activityLibrary;

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle(ActivityLibrary $activityLibrary)
    {
        ini_set('memory_limit', -1);
        $this->activityLibrary = $activityLibrary;

        $this->activityLibrary->storeActivities($this);
    }
}
