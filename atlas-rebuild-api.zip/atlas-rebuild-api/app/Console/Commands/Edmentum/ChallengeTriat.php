<?php 
namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Tenancy\TenantLibrary;

Trait ChallengeTriat {

    protected $challengeLibrary;
    protected $tenantLibrary;
    protected $tenant;



    protected function getTenant()
	{
		return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }


    protected function challengeGuard()
    {
        //  Didnt Complete in new system its customed and in old system they using apis call (rewardEdmentumCompletionChallenge)
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get graduate Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType($this->challenge_type);

        if(!$this->challenge || $this->challenge->status != 1){
            echo '<strong>Challenge was deactivated</strong>';
            exit;	
        }
    }

    function getPreviousStaurday(){
		if(date('l', time()) == "Saturday"){
			return date( 'Y-m-d', strtotime( ' today' ) ).' 00:00:00'; 
		}else{
			return date( 'Y-m-d', strtotime( ' previous  saturday' ) ).' 00:00:00';
		}
		
	}
}
?>