<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Edmentum\Repository\WeeklyAttendanceRepository;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use stdClass;

class RewardEdmentumAttendancePoints extends Command
{
    use ChallengeTriat;

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:add-attendance-points {--tenant=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add Attendance Points To Edmentum';

    protected $studentPointLibrary;
    protected $studentRepo;
    protected $weeklyAttendanceRepository;
	protected $challenge_type = 'edmentum_attendance_points';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo,
            StudentPointLibrary $studentPointLibrary,
            TenantLibrary $tenantLibrary,
            ChallengeLibrary $challengeLibrary)
    {
        parent::__construct();
        $this->studentPointLibrary = $studentPointLibrary;
        $this->studentRepo = $studentRepo;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        $this->weeklyAttendanceRepository = new WeeklyAttendanceRepository('EDMENTUM');
    }

    protected function getTenant()
	{
		return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        
        $this->challengeGuard();
        $students = $this->getNewAttendance();
 		foreach ($students as $student ) {
            foreach ($student->edmentumAttendance as $key => $edmentumAttendance) {
                # code...
                $this->rewardEdmentumAttendanceSwipe($student);
                $this->updateEdmentumWeeklyAttendance($edmentumAttendance->minutes, $student->id);
                (new WeeklyAttendanceRepository('EDMENTUM'))->updateStudentAttendanceDay($student->id,true,null);
                $this->flagAsAwarded($edmentumAttendance);
            }
 		}
    }

    public function getNewAttendance(){
        return Student::whereHas('edmentumAttendance', function($query){
             $query->whereNull('edmentum_learner_tasks.awarded');
             return $query->where('created_at', ">=", now()->startOfMonth());
        })->with(['edmentumAttendance' => function($query){
            $query->whereNull('edmentum_learner_tasks.awarded');
            return $query->where('created_at', ">=", now()->startOfMonth());
       }])->limit(250)->get();
    }

    public function flagAsAwarded($attendance){
        $attendance->awarded = 1;
        $attendance->save();
    }

    function updateEdmentumWeeklyAttendance($attendance_minutes,$student_id,$new_row=true){
       $weeklyAttendance = $this->weeklyAttendanceRepository->
            getWeeklyAttendance($student_id, ['created_at' => $this->getPreviousStaurday()]);
       if($weeklyAttendance){
            $weeklyAttendance->total_minutes +=$attendance_minutes;
            $weeklyAttendance->save();
       }else{
            $this->weeklyAttendanceRepository->addNewWeek($student_id, $attendance_minutes,$this->getPreviousStaurday());
            sleep(1);
        }
    }	
    
    function rewardEdmentumAttendanceSwipe($student){
        $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["attendance_swipe_points"];
		$challenge = new stdClass;
		$challenge->name = "Edmentum Attendance Swipe";
        $challenge->id = null;
        $addPoints = $this->studentPointLibrary->addPoints( $student, $attendance_swipe_points, null, $challenge);
		return $addPoints;
    }
    
}
