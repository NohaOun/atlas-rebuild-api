<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Edmentum\Model\ClassLearner;
use App\Domain\Edmentum\Repository\EdmentumProgressRepository;
use App\Domain\Edmentum\Repository\WeeklyProgressRepository;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use GPBMetadata\Google\Iam\Credentials\V1\Common;
use Illuminate\Console\Command;
use stdClass;

class RewardProgressPoints extends Command
{
	use ChallengeTriat;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:add-progress-points {--tenant=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add progress points';

    private $studentRepo;
    private $studentPointsLib;
	private $weeklyProgressRepository;
	protected $challenge_type = 'progress_point';
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo, 
                                StudentPointLibrary $studentPointsLib,
								WeeklyProgressRepository $weeklyProgressRepository,
								EdmentumProgressRepository $edmentumProgressRepository,
								TenantLibrary $tenantLibrary,
            					ChallengeLibrary $challengeLibrary)
    {
		parent::__construct();
        $this->progressRepo = $edmentumProgressRepository;
        $this->studentRepo = $studentRepo;
        $this->studentPointsLib = $studentPointsLib;
		$this->weeklyProgressRepository = $weeklyProgressRepository;
		$this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
		$this->challengeGuard();
        // get new 250 record of edmentum progress
 		ini_set("display_errors", "1");
		$students = $this->getNewStudentProgres();
 		foreach ($students as $student ) {
			 // process of counting progress and adding points
			foreach($student->classLearners as $progress){
				$this->award($progress, $student);
				// flag the record as done
				$this->flagAsAwarded($progress);
			}
 			
 		}
    }

    public function award($progress, $student){
		if(config('custom.challenges_attendance_method') == 'EDMENTUM'){
		 	if((float)$progress->percent_by_count > 0){ 
 				//get the previous progress on the same course to get the difference
 				$current_progress =  $this->currentProgress($progress);
 				if($current_progress && $student){
					$this->rewardProgressPointSwipe($student, $current_progress);
	 				$this->weeklyProgressRepository->updateEdmentumWeeklyProgress($current_progress, $student->id);
	 				$this->flagAsAwarded($progress);
	 				return true;
	 			}
 			}
 		}
         return false;
    }


 	public function currentProgress($progress){
 		if(config('custom.challenges_attendance_method') == 'EDMENTUM'){
 			//get the previous progress on the same course to get the difference
	 		$previous_progress = $this->progressRepo->getCoursePreviousProgress($progress->id,$progress->edmentum_learner_id,$progress->edmentum_class_id);
	 		if($previous_progress){
	 			$current_progress = (float) $progress->percent_by_count - (float) $previous_progress->percent_by_count;
	 		}else{
	 			$current_progress = $progress->percent_by_count;
	 		}
	 		echo 'current_progress:'.$current_progress.'<br/>';
 		}
 		return $current_progress;
	 }
	 
	function getCoursePreviousProgress($recordId,$student_edmentum_id,$class_id){
		return ClassLearner::with('student')->where([
			["edmentum_learner_id","=",$student_edmentum_id],
			["edmentum_class_id","=",$class_id],
			["id","<",$recordId]
			])->OrderBy('edmentum_class_learners.id','DESC')->first();
	}
	 
	function getNewStudentProgres(){
		//use Student to get by tenants
		return Student::whereHas('classLearners', function($query){
			$query->whereNull('edmentum_class_learners.awarded');
			$query->whereNotNull('edmentum_class_learners.percent_by_count');
			return $query->where('created_at', ">=", now()->startOfMonth());
	   })->with(['classLearners' => function($query){
		   $query->whereNull('edmentum_class_learners.awarded');
		   $query->whereNotNull('edmentum_class_learners.percent_by_count');
		   return $query->where('created_at', ">=", now()->startOfMonth());
	  }])->limit(250)->get();
		// return ClassLearner::whereHas('student')->with('student')->whereNull('edmentum_class_learners.awarded')
		// ->whereNull('edmentum_class_learners.percent_by_count')->limit(250)->get();
	}
	 
 	public function flagAsAwarded($progress){
 		$progress = $this->progressRepo->get($progress->id);
 		$progress->awarded = 1;
 		$this->progressRepo->updateByID($progress->id,$progress);
	 }
	 
	 function rewardProgressPointSwipe($student, $current_progress){
		$progress_deserved_points = (float) tenant()->config["site_settings"]["progress_points"];
		$total_points =(float)($current_progress * $progress_deserved_points);
		$challenge = new stdClass;
		$challenge->name = "New Edmentum Progress";
        $challenge->id = null;
        $addPoints = $this->studentPointsLib->addPoints( $student, $total_points, null, $challenge);
		return $addPoints;
    }
}
