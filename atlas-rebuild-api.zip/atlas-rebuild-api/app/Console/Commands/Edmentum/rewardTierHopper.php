<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Challenge\Model\StudentFinishedCourses;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use stdClass;

class rewardTierHopper extends Command
{
    private $totalCreditCourses = 18;
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $challengeLibrary;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-tier-Hopper {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward-tier-Hopper';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary,
                                    ChallengeLibrary $challengeLibrary)
    {
        parent::__construct();
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
        
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            return "PLase Add Tenant ID";
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get Tier Hopper Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('tier_hopper');
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong>Challenge was deactivated</strong>';
 			exit();
 			return false;	
        } 	
         
        // Get Finished Courses But not Handeled yet
        $studentsFinished = StudentFinishedCourses::where("reward", 0)->orWhereNull('reward')->get();
        $sutdentRepository = new StudentRepository(new StudentFilters());
        // For loop for every course and reward its student
        foreach($studentsFinished as $studentFinished){
            // Get Finished courses's Number 
            $finishedCoursesNumber = $sutdentRepository->getStudentFinishedCourses($studentFinished->student_id);
            // Get Lefted Courses on this tair
            $leftCourses = $this->totalCreditCourses - $finishedCoursesNumber;
            // Get Previous Tair number
            $previousTier = $this->getStudentTier(($leftCourses - 1),$studentFinished->student_id);
            // get Current Tair Number
            $tier = $this->getStudentTier($leftCourses,$studentFinished->student_id);
            //  if user in the same tair then do nothing
            if($tier == $previousTier){
                echo "<strong>same tier </strong><br/>";
                return false;
            }

            switch($this->tier){
                case '1':
                    $tier_bonus_type = $this->challenge->property["tier1_bonus_points"]["type"] ?? 2;
                    $tier_bonus_value = $this->challenge->property["tier1_bonus_points"]["value"];
                break;
                case '2':
                    $tier_bonus_type = $this->challenge->property["tier2_bonus_points"]["type"] ?? 2;
                    $tier_bonus_value = $this->challenge->property["tier1_bonus_points"]["value"];
                break;
                case '3':
                    $tier_bonus_type = $this->challenge->property["tier1_bonus_points"]["type"] ?? 2;
                    $tier_bonus_value = $this->challenge->property["tier1_bonus_points"]["value"];
                break; 	
                case '4':
                    $tier_bonus_type = $this->challenge->property["tier1_bonus_points"]["type"] ?? 2;
                    $tier_bonus_value = $this->challenge->property["tier1_bonus_points"]["value"];
                break; 	
                case '5':
                    $tier_bonus_type = $this->challenge->property["tier1_bonus_points"]["type"] ?? 2;
                    $tier_bonus_value = $this->challenge->property["tier1_bonus_points"]["value"];
                break;  				
            }
            // Reward Points to student  and Badge 
            switch($tier_bonus_type){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $studentFinished->student, $tier_bonus_value, $this->challenge);
                    $this->rewardNewBadge($studentFinished->student);
            
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $studentFinished->student, $tier_bonus_value, null, $this->challenge);
                    $this->rewardNewBadge($studentFinished->student);
                break;
            }
            // Save Student Finished record as rewared
            $studentsFinished->reward = 1;
            $studentsFinished->save();
        }
        return 0;
    }

    function getStudentTier($leftCourses,$studentId){
        echo 'leftCourses : '.$leftCourses;
        switch (true) {
            case ($leftCourses == 0):
                $tier = 5;
                (new addEvent(new EventRepository()))->add('graduate',$studentId);
            break;
            case ($leftCourses <=5):
                $tier = 4;
            break; 
            case ($leftCourses <= 10):
                $tier = 3;
            break; 
            case ($leftCourses <= 15):
                $tier = 2;
            break; 
            case ($leftCourses > 15):
                $tier = 1;
            break;  		 						
        }
        return $tier;
        //$this->studentId;
        //return 4;	

    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
