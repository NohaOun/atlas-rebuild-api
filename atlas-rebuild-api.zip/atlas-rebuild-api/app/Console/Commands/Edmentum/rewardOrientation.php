<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;
use stdClass;

class rewardOrientation extends Command
{
    private $challenge;
    private $tenantLibrary;
    private $tenant;
    private $studentPointsLib;
    private $challengeLibrary;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:reward-orientation {--tenant=}';
    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'reward orientation';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(TenantLibrary $tenantLibrary, 
                ChallengeLibrary $challengeLibrary,
                StudentPointLibrary $studentPointsLib)
    {
        parent::__construct();
        $this->studentPointsLib = $studentPointsLib;
        $this->tenantLibrary = $tenantLibrary;
        $this->challengeLibrary = $challengeLibrary;
    }

    protected function getTenant()
    {
        return $this->tenant = ($tenantId = $this->option('tenant')) ? $this->tenantLibrary->getTenant($tenantId) : null;
    }
    
    
    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Get Tenant From Comman Option
        $this->getTenant();
        if(!$this->tenant){
            echo "PLase Add Tenant ID";
            exit;
        }
        // initialize the Tenant
        tenancy()->initialize($this->tenant);
        // Get orientation Challenge
        $this->challenge = $this->challengeLibrary->getChallengeByType('orientation');
         
        if(!$this->challenge || $this->challenge->status != 1){
 			echo '<strong> orientation Challenge was deactivated</strong>';
 			exit();
 			return false;	
         } 
         
        // Get Finished Courses But not Handeled yet
        /**
         * select st.id from students st
            join statuses s on s.id = st.status_id
            join phases p on p.id = s.phase_id and phase_key = 'Enrolled - Orientation'
            left join student_points sp on sp.student_id = st.id and challenge_id = 3
            where sp.id is null;

            select * 
            
            from `students` 
            join `statuses` on `statuses`.`id` = `students`.`status_id` 
            join `phases` on `phases`.`id` = `statuses`.`phase_id` and `phase_key` = `Enrolled - Orientation` 
            left join `student_points` on `student_points`.`student_id` = `students`.`id` and `challenge_id` = `1`
             where `student_points`.`id` is null
              and `students`.`tenant_id` = ? 
              and `students`.`deleted_at` is null 
              and exists 
              (select * 
                    from `sites` 
                    where `students`.`site_id` = `sites`.`id` 
                    and exists (select * from `districts`
                         where `sites`.`district_id` = `districts`.`id` and `active` = ? 
                         and `districts`.`tenant_id` = ?) and `sites`.`tenant_id` = ?)
         */
        $studentsOrientation = Student::
            join('statuses', 'statuses.id', 'students.status_id')->
            join('phases', function($query){
                $query->on('phases.id', 'statuses.phase_id');
                $query->where('phase_key', 'Enrolled Orientation');
            })
            ->leftJoin('student_points',function($query){
                $query->on('student_points.student_id', 'students.id');
                $query->where('challenge_id', 0);
            })->whereNull('student_points.id')->select("students.*")->get();
        // For loop for every course and reward its student
        foreach($studentsOrientation as $studentOrientation){
            switch($this->challenge->property["orientation_bonus"]["type"] ?? 1){
                case"1":
                    $this->studentPointsLib->multiplyPoints( $studentOrientation, $this->challenge->property["orientation_bonus"]["value"], $this->challenge);
                    $this->rewardNewBadge($studentOrientation);
            
                break;
                case '2':
                    $this->studentPointsLib->addPoints( $studentOrientation, $this->challenge->property["orientation_bonus"]["value"], null, $this->challenge);
                    $this->rewardNewBadge($studentOrientation);
                break;
            }
        }
        echo "Done";
        return 0;
    }

    function rewardNewBadge($student){
        // $attendance_swipe_points = (float) $student->tenant->config["site_settings"]["badge_points"];
		// $challenge = new stdClass;
		// $challenge->name ="Win A New Badge";
        // $challenge->id = null;

        // $addPoints = $this->studentPointsLib->addPoints( $student, $attendance_swipe_points, null, $challenge);
	}
}
