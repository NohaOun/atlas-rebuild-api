<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\Repository\WeeklyProgressRepository;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use Illuminate\Console\Command;

class UpdateProgresseWeek extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:update-progress-week {tenant}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add new progress week';

    private  $studentRepo;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo, WeeklyProgressRepository $weeklyAttendanceRepository)
    {
        parent::__construct();
        $this->studentRepo = $studentRepo;
        $this->weeklyAttendanceRepository = $weeklyAttendanceRepository;

    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $allStudents = $this->studentRepo->getStudents(new StudentFilters(['phaseKey' => 'Enrolled']));
        $counter = 1;
        
		foreach($allStudents as $student){
			$this->weeklyProgressRepository->addNewWeek($student['id']);
			$counter++;
			if($counter > 50 ){
				$counter = 1;
				sleep(1);
			}
		}
    }
}
