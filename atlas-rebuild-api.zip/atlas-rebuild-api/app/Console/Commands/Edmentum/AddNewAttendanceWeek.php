<?php

namespace App\Console\Commands\Edmentum;

use App\Domain\Edmentum\Repository\WeeklyAttendanceRepository;
use App\Domain\Phase\Repository\PhaseRepository;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use Illuminate\Console\Command;

class AddNewAttendanceWeek extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'Edmentum:add-new-atendance-week {tenant}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add new Attendance week';
    protected $studentRepo;
    protected $weeklyAttendanceRepository;
    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepositoryInterface $studentRepo, WeeklyAttendanceRepository $weeklyAttendanceRepository)
    {
        parent::__construct();
        $this->studentRepo = $studentRepo;
        $this->weeklyAttendanceRepository = $weeklyAttendanceRepository;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $allStudents = $this->studentRepo->getStudents(new StudentFilters(['phaseKey' => 'Enrolled']));
		$counter = 1;
		foreach($allStudents as $student){
			$this->weeklyAttendanceRepository->addNewWeek($student['id']);
			if($counter > 50 ){
				$counter = 1;
				sleep(1);
			}
		}
    }
}
