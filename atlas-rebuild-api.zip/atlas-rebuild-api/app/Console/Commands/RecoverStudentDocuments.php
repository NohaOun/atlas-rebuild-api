<?php

namespace App\Console\Commands;

use App\Domain\Document\Model\DocumentType;
use App\Domain\Document\Model\StudentDocument;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RecoverStudentDocuments extends Command
{
    protected $signature = 'app:recover-student-documents {--tenant=} {--disk=public}';

    protected $description = 'Recover student documents';

    public function handle()
    {
        $errors = [];

        $documents = $this->getDocumentsDatabaseConnection()
            ->table('media')
            ->selectRaw('
                media.id, media.model_id, media.file_name, media.collection_name, 
                student_documents.student_id, 
                document_types.group AS document_type_group, document_types.name AS document_type_name
            ')
            ->join('student_documents', 'media.model_id', '=', 'student_documents.id')
            ->leftJoin('document_types', 'student_documents.document_type_id', '=', 'document_types.id')
            ->where('model_type', 'student-document')
            ->get();

        $this->output->newLine();
        $bar = $this->output->createProgressBar($documents->count());

        foreach ($documents as $document) {
            try {
                $this->recoverDocument($document);
            } catch (\Exception $exception) {
                $errors[] = $exception->getMessage();
            }

            $bar->advance();
        }

        $this->output->newLine();

        foreach ($errors as $error) {
            $this->error($error);
        }
    }

    protected function getModelTypes()
    {
        return array_map('trim', explode(',', $this->option('types'))) ?? [];
    }

    protected function recoverDocument($document)
    {
        $documentTypeId = null;

        if ($this->hasDocumentType($document)) {
            $documentType = DocumentType::query()
                ->where('group', $this->parseDocumentTypeGroup($document->document_type_group))
                ->where('name', $document->document_type_name)
                ->first();

            if (!$documentType) {
                throw new \Exception(
                    sprintf(
                        'Missed document type %s/%s',
                        $this->parseDocumentTypeGroup($document->document_type_group),
                        $document->document_type_name
                    )
                );
            }

            $documentTypeId = $documentType->id;
        }

        DB::transaction(function () use ($document, $documentTypeId) {
            /** @var StudentDocument $recovered */
            $recovered = StudentDocument::query()->forceCreate([
                'tenant_id' => $this->option('tenant'),
                'document_type_id' => $documentTypeId,
                'student_id' => $document->student_id
            ]);

            $media = $recovered
                ->addMedia($this->getFilePath($document))
                ->preservingOriginal()
                ->toMediaCollection($document->collection_name, $this->option('disk'));

            $media->forceFill(['tenant_id' => $this->option('tenant')])->save();
        });
    }

    protected function hasDocumentType($document)
    {
        return $document->document_type_group && $document->document_type_name;
    }

    protected function parseDocumentTypeGroup($group)
    {
        return str_replace('-', ' ', $group);
    }

    protected function getFilePath($document)
    {
        return sprintf('%s/%s/%s', env('RECOVER_STUDENT_DOCUMENTS_BACKUP_PATH'), $document->id, $document->file_name);
    }

    protected function getDocumentsDatabaseConnection()
    {
        return DB::connection('recover_student_documents');
    }
}
