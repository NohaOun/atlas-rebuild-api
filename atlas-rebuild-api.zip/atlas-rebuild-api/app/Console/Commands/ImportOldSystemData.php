<?php

namespace App\Console\Commands;

use App\Domain\Common\OldSystemLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;

class ImportOldSystemData extends Command
{
    protected $signature = 'app:import-old-system-data {--districts=} {--students=} {--tenant=} {--only=} {--except=} {--options=}';
    protected $description = 'Import old system data.';

    /**
     * @var OldSystemLibrary
     */
    private $oldSystemLibrary;

    /**
     * @var TenantLibrary
     */
    private $tenantLibrary;

    public function __construct(OldSystemLibrary $oldSystemLibrary, TenantLibrary $tenantLibrary)
    {
        parent::__construct();

        $this->oldSystemLibrary = $oldSystemLibrary;
        $this->tenantLibrary = $tenantLibrary;
    }

    public function handle()
    {
        $filters = $this->getFilters();
        $tenant = $this->getTenant();

        $this->oldSystemLibrary->setOutput($this);

        $selected = ($only = $this->option('only')) ? array_map('trim', explode(',', $only)) : '*';
        $except = ($except = $this->option('except')) ? array_map('trim', explode(',', $except)) : [];

        $this->oldSystemLibrary->import($selected, $except, $filters, $tenant, $this->parseOptions());
    }

    protected function getTenant()
    {
        return ($tenantId = $this->option('tenant'))
            ? $this->tenantLibrary->getTenant($tenantId)
            : null;
    }

    protected function parseOptions()
    {
        return collect(
            array_filter(explode(',', $this->option('options'))) ?? []
        )->reduce(function ($carry, $item) {
            list ($k, $v) = array_map('trim', explode(':', $item));
            $carry[$k] = $v;

            return $carry;
        });
    }

    protected function getFilters()
    {
        $filters = [];

        if ($studentIds = $this->option('students')) {
            $filters['students'] = array_map('trim', explode(',', $studentIds));
        }

        if ($districtIds = $this->option('districts')) {
            $filters['districts'] = array_map('trim', explode(',', $districtIds));
        }

        return $filters;
    }
}
