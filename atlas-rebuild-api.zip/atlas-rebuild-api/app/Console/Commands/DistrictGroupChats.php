<?php

namespace App\Console\Commands;

use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Student\Model\Student;
use App\Domain\Tenancy\Model\Tenant;
use App\Domain\User\Model\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class DistrictGroupChats extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'district:group-chat';


    protected $description = 'create group chat for each district and add all user and students to it';


    public function __construct()
    {
        parent::__construct();
    }


    public function handle()
    {
        $tenants = Tenant::all();
        foreach ($tenants as $tenant) {
            $builderStudents[] = DB::table('students')
                ->leftJoin('sites', 'students.site_id', '=', 'sites.id')
                ->leftJoin('districts', 'sites.district_id', '=', 'districts.id')
                ->whereNull('students.deleted_at')
                ->where('districts.tenant_id', $tenant->id)
                ->addSelect('students.*', 'districts.name as district_name')
                ->get();
            $builderUsers[] = DB::table('users')
                ->leftJoin('tenant_user', 'users.id', '=', 'tenant_user.user_id')
                ->leftJoin('district_tenant_user', 'tenant_user.id', '=', 'district_tenant_user.tenant_user_id')
                ->leftJoin('districts', 'districts.id', '=', 'district_tenant_user.district_id')
                ->select('users.*', 'districts.name as district_name')
                ->where('districts.tenant_id', $tenant->id)
                ->get();
            foreach ($builderUsers as $users) {
                foreach ($users as $user) {
                    $chatRoom = DB::table('chat_rooms')
                        ->where('name', $user->district_name)
                        ->where('room_type', ChatRoom::$chatRoomType['DISTRICT_GROUP'])
                        ->where('tenant_id', $tenant->id)->first();
                    if (!$chatRoom)
                        $chatRoomId = DB::table('chat_rooms')->insertGetId([
                            'name' => $user->district_name,
                            'room_type' => ChatRoom::$chatRoomType['DISTRICT_GROUP'],
                            'tenant_id' => $tenant->id,
                        ]);
                    else
                        $chatRoomId = $chatRoom->id;

                    $chatRoomUser = DB::table('room_users')
                        ->where('room_id', $chatRoomId)
                        ->where('user_id', $user->id)
                        ->where('tenant_id', $tenant->id)
                        ->where('user_type', '=', User::class)->first();
                    if (!$chatRoomUser)
                        DB::table('room_users')->insert([
                            'room_id' => $chatRoom ? $chatRoom->id : $chatRoomId,
                            'user_id' => $user->id,
                            'user_type' => User::class,
                            'tenant_id' => $tenant->id,
                        ]);
                }

            }
            foreach ($builderStudents as $students) {
                foreach ($students as $student) {
                    $chatRoom = DB::table('chat_rooms')
                        ->where('name', $student->district_name)
                        ->where('room_type', ChatRoom::$chatRoomType['DISTRICT_GROUP'])
                        ->where('tenant_id', $tenant->id)->first();

                    if (!$chatRoom)
                        $chatRoomId = DB::table('chat_rooms')->insertGetId([
                            'name' => $user->district_name,
                            'room_type' => ChatRoom::$chatRoomType['DISTRICT_GROUP'],
                            'tenant_id' => $tenant->id,
                        ]);
                    else
                        $chatRoomId = $chatRoom->id;
                    $chatRoomUser = DB::table('room_users')
                        ->where('room_id', $chatRoomId)
                        ->where('user_id', $user->id)
                        ->where('tenant_id', $tenant->id)
                        ->where('user_type', '=', User::class)->first();
                    if (!$chatRoomUser)
                        DB::table('room_users')->insert([
                            'room_id' => $chatRoom ? $chatRoom->id : $chatRoomId,
                            'user_id' => $student->id,
                            'user_type' => Student::class,
                            'tenant_id' => $tenant->id,
                        ]);
                }
            }
        }
    }
}
