<?php

namespace App\Console\Commands\OnSiteAttendance;

use App\Domain\Student\Model\Student;
use App\Domain\StudentPoint\StudentPointLibrary;
use Illuminate\Console\Command;

class AddPointsToStudent extends Command
{

    protected $signature = 'onsite:add-progress-points {--tenant=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Add progress points';

    protected $studentPointLibrary;

    const CHALLENGE_TYPE = 'Edmentum Attendance Swipe';

    public function __construct(StudentPointLibrary $studentPointLibrary)
    {
        parent::__construct();
        $this->studentPointLibrary = $studentPointLibrary;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        tenancy()->initialize($this->option('tenant'));
        $points = (float) tenant()->config['site_settings']['attendance_swipe_points'];

        $students = $this->getStudentsAttendedToday();
        $challenge = new \stdClass();
        $challenge->name = self::CHALLENGE_TYPE;
        $challenge->id = null;

        foreach ($students as $student) {
            try {
                $this->studentPointLibrary->addPoints($student, $points, null, $challenge);
            } catch (\Exception $exception) {}
        }
    }

    public function getStudentsAttendedToday()
    {
        return Student::query()->whereHas(
            'studentAttendance', function ($builder) {
                $builder->whereDate('check_in', '=', now()->subDay()->format('Y-m-d'));
            }
        )->with('studentPoint')->get();
    }
}
