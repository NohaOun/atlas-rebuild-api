<?php

namespace App\Console\Commands;

use App\Domain\User\Filters\UserFilters;
use App\Domain\User\UserLibrary;
use Illuminate\Console\Command;

class SendWelcomeEmailToExistingUsers extends Command
{
    protected $signature = 'app:send-welcome-email-to-existing-users {--emails=}';
    protected $description = 'Send welcome email to existing users.';
    /**
     * @var UserLibrary
     */
    private $userLibrary;

    public function __construct(UserLibrary $userLibrary)
    {
        parent::__construct();

        $this->userLibrary = $userLibrary;
    }

    public function handle()
    {
        $filters = [];
        if ($emails = $this->option('emails')) {
            $filters['emails'] = array_map('trim', explode(',', $emails));
        }

        $users = $this->userLibrary->getUsers(new UserFilters($filters));

        $progressBar = $this->getOutput()->createProgressBar(count($users));

        foreach ($users as $user) {
            $randomPassword = $this->userLibrary->setRandomPasswordForUser($user);

            $this->userLibrary->sendWelcomeEmailForUser($user, $randomPassword);

            $progressBar->advance();
        }

        $this->output->newLine();
    }
}
