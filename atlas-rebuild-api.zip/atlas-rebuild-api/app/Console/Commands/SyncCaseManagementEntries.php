<?php

namespace App\Console\Commands;

use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SyncCaseManagementEntries extends Command
{
    protected $signature = 'app:sync-case-management-entries';
    protected $description = 'Sync case management entry cache';

    public function handle()
    {
        DB::statement('TRUNCATE cache_case_management_entries');

        $startDate = now()->startOfWeek(Carbon::SUNDAY)->startOfDay()->format('Y-m-d H:i:s');
        $endDate = now()->endOfWeek(Carbon::SATURDAY)->endOfDay()->format('Y-m-d H:i:s');

        DB::statement(
            "INSERT INTO cache_case_management_entries
                (student_id,
                 tenant_id,
                 student_district_id,
                 site_id,
                 status_id,
                 content_coach_id,
                 gca_id,
                 graduation_date,
                 withdrawal_date,
                 last_contact_id,
                 last_attended,
                 avg_time_in_system,
                 total_time_in_system,
                 last_attended_in_edmentum,
                 total_time_on_task,
                 created_at,
                 updated_at
                )
                SELECT `students`.`id` AS `student_id`,
                       `students`.`tenant_id` AS `tenant_id`,
                       `students`.`district_id` AS `student_district_id`,
                       `sites`.`id` AS `site_id`,
                       `statuses`.`id` AS `status_id`,
                       `content_coach`.`id` AS `content_coach_id`,
                       `gca`.`id` AS `gca_id`,
                       `students`.`graduation_date` AS `graduation_date`,
                       `students`.`withdrawal_date` AS `withdrawal_date`,
                       `lc`.`id` AS `last_contact_id`,
                       `la`.`last_attended` AS `last_attended`,
                       `la`.`avg_time_in_system` AS `avg_time_in_system`,
                       `la`.`total_time_in_system` AS `total_time_in_system`,
                       `ell`.`last_attended_in_edmentum` AS `last_attended_in_edmentum`,
                       `elt`.`total_time_on_task` AS `total_time_on_task`,
                       NOW() AS `created_at`,
                       NOW() AS `updated_at`
                FROM `students`
                         LEFT JOIN `sites` on `students`.`site_id` = `sites`.`id`
                         LEFT JOIN `statuses` on `students`.`status_id` = `statuses`.`id`
                         LEFT JOIN `users` as `content_coach` on `students`.`content_coach_id` = `content_coach`.`id`
                         LEFT JOIN `users` as `gca` on `students`.`graduate_candidate_advocate_id` = `gca`.`id`
                         LEFT JOIN (
                            SELECT edmentum_learner_id, CONCAT(FLOOR(SUM(minutes)/60),'.',MOD(SUM(minutes),60))   AS total_time_on_task
                            FROM `edmentum_learner_tasks`
                            WHERE (`started_at` BETWEEN '$startDate' AND '$endDate')
                            GROUP BY `edmentum_learner_id`
                        ) AS elt on `students`.`id` = `elt`.`edmentum_learner_id`
                        LEFT JOIN (
                            SELECT edmentum_learner_id, MAX(`login_date`) AS last_attended_in_edmentum
                            FROM `edmentum_learner_logins`
                            GROUP BY `edmentum_learner_id`
                        ) AS ell on `students`.`id` = `ell`.`edmentum_learner_id`
                        LEFT JOIN (
                            SELECT student_id,
                                   MAX(`check_out`)                                  AS last_attended,
                                   AVG(TIMESTAMPDIFF(hour, `check_in`, `check_out`)) AS avg_time_in_system,
                                   SUM(TIMESTAMPDIFF(hour, `check_in`, `check_out`)) as total_time_in_system
                            FROM `student_attendance_entries`
                            GROUP BY `student_id`
                        ) AS la on `students`.`id` = `la`.`student_id`
                        LEFT JOIN (
                            SELECT  student_id, MAX(`notes`.`id`) AS id
                            FROM `users`
                            JOIN `notes` ON `users`.`id` = `notes`.`creator_id`
                            GROUP BY student_id
                        ) AS lc on `students`.`id` = `lc`.`student_id`;"
        );
    }
}
