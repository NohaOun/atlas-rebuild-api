<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class RemoveDuplicatedStatuses extends Command
{
    protected $signature = 'app:remove-duplicated-statuses';
    protected $description = 'Remove duplicated statuses.';

    public function handle()
    {
        $statusGroups = DB::table('statuses')
            ->get()
            ->groupBy(function ($item) {
                return sprintf('%s-%s', $item->phase_id, $item->name);
            });

        DB::statement('SET FOREIGN_KEY_CHECKS = 0;');

        foreach ($statusGroups as $statuses) {
            $ids = $statuses->pluck('id')->toArray();

            if (count($ids) == 1) continue; // No duplication, no need to update any records

            DB::table('students')->whereIn('status_id', $ids)->update(['status_id' => $ids[0]]);
            DB::table('contacts')->whereIn('status_id', $ids)->update(['status_id' => $ids[0]]);
            DB::table('contact_actions')->whereIn('status_id', $ids)->update(['status_id' => $ids[0]]);
            DB::table('notes')->whereIn('student_status_id', $ids)->update(['student_status_id' => $ids[0]]);
            DB::table('status_history')->whereIn('prev_status_id', $ids)->update(['prev_status_id' => $ids[0]]);
            DB::table('status_history')->whereIn('new_status_id', $ids)->update(['new_status_id' => $ids[0]]);

            DB::table('statuses')->whereIn('id', Arr::except($ids, [0]))->delete(); // Delete all duplicate statuses
        }

        DB::statement('SET FOREIGN_KEY_CHECKS = 1;');
    }
}
