<?php

namespace App\Console\Commands;

use App\Domain\District\DistrictLibrary;
use App\Domain\Plp\PlanLibrary;
use Illuminate\Console\Command;

class AddInitialDefaultPlpPlan extends Command
{
    protected $signature = 'app:add-initial-default-plp-plan {district}';
    protected $description = 'Add initial default plan for a district.';

    private $planLibrary;
    private $districtLibrary;

    public function __construct(PlanLibrary $planLibrary, DistrictLibrary $districtLibrary)
    {
        parent::__construct();

        $this->planLibrary = $planLibrary;
        $this->districtLibrary = $districtLibrary;
    }

    public function handle()
    {
        $districtId = $this->argument('district');
        $district = $this->districtLibrary->getDistrict($districtId);

        tenancy()->initialize($district->tenant);

        $this->planLibrary->addInitialDistrictDefaultPlan($district);
    }
}
