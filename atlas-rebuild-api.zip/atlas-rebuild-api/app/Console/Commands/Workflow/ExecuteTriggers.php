<?php

namespace App\Console\Commands\Workflow;

use App\Domain\Tenancy\Repository\TenantRepositoryInterface;
use App\Domain\Workflow\Contract\ActionHandlerFactoryInterface;
use App\Domain\Workflow\Model\WorkflowTrigger;
use App\Domain\Workflow\WorkflowTriggerLibrary;
use Illuminate\Console\Command;

class ExecuteTriggers extends Command
{
    protected $signature = 'workflow:execute-triggers';
    protected $description = 'Execute workflow triggers';

    private $tenantRepo;
    private $workflowTriggerLibrary;
    private $actionHandlerFactory;

    public function __construct(
        TenantRepositoryInterface $tenantRepo,
        WorkflowTriggerLibrary $workflowTriggerLibrary,
        ActionHandlerFactoryInterface $actionHandlerFactory
    )
    {
        parent::__construct();

        $this->tenantRepo = $tenantRepo;
        $this->workflowTriggerLibrary = $workflowTriggerLibrary;
        $this->actionHandlerFactory = $actionHandlerFactory;
    }

    public function handle()
    {
        $tenants = $this->getTenants();

        foreach ($tenants as $tenant) {
            tenancy()->initialize($tenant);

            $triggers = $this->workflowTriggerLibrary->getWorkflowTriggers();

            foreach ($triggers as $trigger) {
                $this->executeTrigger($trigger);
            }
        }
    }

    protected function executeTrigger(WorkflowTrigger $trigger)
    {
        foreach ($trigger->workflowActions as $action) {
            $handler = $this->actionHandlerFactory->make($action->type);

            $handler->setTrigger($trigger)->handle($action);
        }
    }

    protected function getTenants()
    {
        return $this->tenantRepo->getTenants();
    }
}
