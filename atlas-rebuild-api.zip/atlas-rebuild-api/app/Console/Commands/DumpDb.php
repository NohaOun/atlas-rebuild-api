<?php

namespace App\Console\Commands;

use App\Domain\Common\DumpDbLibrary;
use Illuminate\Console\Command;

class DumpDb extends Command
{
    protected $signature = 'app:dump-db {--username=} {--password=} {--host=} {--database=}';
    protected $description = 'Dump database.';

    /**
     * @var DumpDbLibrary
     */
    private $dumpDbLibrary;

    public function __construct(DumpDbLibrary $dumpDbLibrary)
    {
        parent::__construct();
        $this->dumpDbLibrary = $dumpDbLibrary;
    }

    public function handle()
    {
        $config = [];
        foreach (['username', 'password', 'host', 'database'] as $configItem) {
            $config[$configItem] = $this->option($configItem) ?? $this->getDefaultDbConfigItem($configItem);
        }

        $this->dumpDbLibrary->dumpDb($config);
    }

    protected function getDefaultDbConfigItem($item)
    {
        $defaultConnection = config('database.default');

        return config("database.connections.{$defaultConnection}.{$item}");
    }
}
