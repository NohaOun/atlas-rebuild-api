<?php

namespace App\Console\Commands;

use App\Domain\CallLog\CallLogLibrary;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Command;

class ImportCallLogs extends Command
{
    protected $signature = 'app:import-call-logs {provider}';
    protected $description = 'Import call logs.';

    /**
     * @var TenantLibrary
     */
    private $tenantLibrary;

    /**
     * @var CallLogLibrary
     */
    private $callLogLibrary;

    public function __construct(TenantLibrary $tenantLibrary, CallLogLibrary $callLogLibrary)
    {
        parent::__construct();

        $this->tenantLibrary = $tenantLibrary;
        $this->callLogLibrary = $callLogLibrary;
    }

    public function handle()
    {
        $providerName = $this->argument('provider');

        foreach ($this->tenantLibrary->getTenants() as $tenant) {
            $this->callLogLibrary->importCallLogsForTenant($providerName, $tenant);
        }
    }
}
