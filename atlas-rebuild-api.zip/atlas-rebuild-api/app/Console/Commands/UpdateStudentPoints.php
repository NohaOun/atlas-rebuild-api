<?php

namespace App\Console\Commands;

use App\Domain\StudentPoint\StudentPointLibrary;
use Illuminate\Console\Command;

class UpdateStudentPoints extends Command
{
    protected $signature = 'app:update-student-points';
    protected $description = 'Update Student points with new dollar factory';
    protected $studentPointLibrary;

    public function handle(StudentPointLibrary $studentPointLibrary)
    {
        $this->studentPointLibrary = $studentPointLibrary;

        $this->studentPointLibrary->updateStudentPointsWithNewFactor(100);
    }
}
