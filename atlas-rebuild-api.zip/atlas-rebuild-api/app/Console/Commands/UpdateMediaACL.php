<?php

namespace App\Console\Commands;

use App\Domain\FileUpload\Model\Media;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\PathGenerator\PathGeneratorFactory;

class UpdateMediaACL extends Command
{
    protected $signature = 'app:update-media-acl {acl} {--types=} {--disk=s3}';
    protected $description = 'Update media ACL.';

    public function handle()
    {
        $diskName = $this->option('disk');

        $diskConfig = config("filesystems.disks.{$diskName}");
        if ($diskConfig['driver'] != 's3') {
            throw new \Exception('Only s3 disks are supported');
        }

        $disk = Storage::disk($diskName);

        /** @var \Aws\S3\S3Client $client */
        $client = $disk->getDriver()->getAdapter()->getClient();

        $this->getMedia()->each(function ($mediaItem) use ($client, $disk, $diskConfig) {
            try {
                $mediaPath = PathGeneratorFactory::create()->getPath($mediaItem);

                $files = $disk->allFiles($mediaPath);

                foreach ($files as $file) {
                    $client->putObjectAcl([
                        'ACL' => $this->argument('acl'),
                        'Bucket' => $diskConfig['bucket'],
                        'Key' => $file
                    ]);

                    $this->info('File processed: ' . $file);
                }

                $mediaItem->setCustomHeaders(['ACL' => $this->argument('acl')])->save();

                $this->info('Media item processed: ' . $mediaItem->id);
            } catch (\Exception $exception) {
                $this->error($exception->getMessage());
            }
        });
    }

    protected function getMedia()
    {
        $builder = Media::query();

        $mediaTypes = array_filter(explode(',', $this->option('types')));
        if (count($mediaTypes)) {
            $builder->whereIn('model_type', $mediaTypes);
        }

        return $builder->get();
    }
}
