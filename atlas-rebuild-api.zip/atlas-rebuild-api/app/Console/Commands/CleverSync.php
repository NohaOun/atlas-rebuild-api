<?php

namespace App\Console\Commands;

use App\Domain\Phase\Repository\PhaseRepositoryInterface;
use App\Domain\Site\Filters\SiteFilters;
use App\Domain\Site\SiteLibrary;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\Tenancy\Filters\TenantFilters;
use App\Domain\Tenancy\TenantLibrary;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\UserLibrary;
use Illuminate\Console\Command;
use phpseclib\Net\SFTP;

class CleverSync extends Command
{
    protected $signature = 'clever:sync';
    protected $description = 'This command to sync gc with clever';

    protected $siteLibrary;

    protected $userLibrary;

    protected $studentRepository;

    protected $tenantLibrary;

    protected $phaseRepository;

    public function __construct(
        SiteLibrary $siteLibrary,
        UserLibrary $userLibrary,
        StudentRepositoryInterface $studentRepository,
        TenantLibrary $tenantLibrary,
        PhaseRepositoryInterface $phaseRepository
    )
    {
        parent::__construct();
        $this->siteLibrary = $siteLibrary;
        $this->userLibrary = $userLibrary;
        $this->studentRepository = $studentRepository;
        $this->tenantLibrary = $tenantLibrary;
        $this->phaseRepository = $phaseRepository;
    }

    public function handle()
    {
        $pathToExport = config('clever.path_to_export');
        $tenantsHaveClever = $this->tenantLibrary->getTenants(new TenantFilters(['clever' => true]));
        foreach ($tenantsHaveClever as $tenant) {
            ### Set Tenant
            tenancy()->initialize($tenant);
            $enrollmentPhase = $this->phaseRepository->getPhaseForClever([
                'is_in_enrollment_clever' => true
            ]);
            $studentPhase = $this->phaseRepository->getPhaseForClever([
                'is_in_student_clever' => true
            ]);

            try {
                ### Connect To Clever
                $sftp = $this->checkCleverConnection($tenant);

                ### School CSV
                $sites = $this->siteLibrary->getSites(new SiteFilters(['active' => true]))->load('district');
                $this->schoolExport($pathToExport['schools'], $sites);

                ## Teacher CSV

                $teachers = $this->userLibrary->getUsers(new UserFilters([
                    'permissionName' => 'Educator in Clever',
                    'active' => true,
                ]))->load('tenants.tenantUsers.districts.sites');

                $this->teacherExport($pathToExport['teachers'], $teachers);

                ## Staff CSV
                $staffs = $this->userLibrary->getUsers(new UserFilters([
                    'permissionName' => 'Ed Admin',
                    'active' => true,
                ]))->load('tenants.tenantUsers.districts.sites');
                $this->staffExport($pathToExport['staffs'], $staffs);

                ## Section CSV
                $allSections = $this->sectionExport($pathToExport['sections']);

                ## Enrollment CSV
                $studentEnrollments = $this->studentRepository->getStudentsByFilter(new StudentFilters([
                    'phaseIn' => $enrollmentPhase->pluck('id')->toArray() !== [] ? $enrollmentPhase->pluck('id')->toArray() : 0,
                    'active' => true,
                    'activeSite'
                ]))->load('site');

                $this->enrollmentExport($pathToExport['enrollments'], $studentEnrollments, $allSections);

                $students = $this->studentRepository->getStudentsByFilter(new StudentFilters([
                    'phaseIn' => $studentPhase->pluck('id')->toArray() !== [] ? $studentPhase->pluck('id')->toArray() : 0,
                    'active' => true,
                    'activeSite'
                ]))->load('emergencyContact1Relation', 'site');

                $this->studentExport($pathToExport['students'], $students);

                ### Upload to Clever
                foreach ($pathToExport as $file) {
                    $sftp->put(basename($file), $file, SFTP::SOURCE_LOCAL_FILE);
                }

            } catch (\Exception $exception) {
                throw $exception;
            }
        }
    }

    protected function checkCleverConnection($tenant)
    {
        $sftp = (new SFTP('sftp.clever.com'));
        $services = $tenant['config']['modules']['courseware_integration']['services'];
        $cleverConfig = collect($services)->where('name', 'clever')->first();

        throw_if(!$cleverConfig || !$sftp->login($cleverConfig['username'], $cleverConfig['password']),
            new \InvalidArgumentException('Invalid clever auth')
        );

        return $sftp;
    }

    protected function schoolExport($pathToExport, $schools)
    {
        $data['School_id'] = 'School_id';
        $data['School_name'] = 'School_name';
        $data['School_number'] = 'School_number';
        $data['Low_Grade'] = 'Low_Grade';
        $data['High_Grade'] = 'High_Grade';

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);

        foreach ($schools as $school) {
            $data['School_id'] = $school->old_system_id ?? $school->id;
            $data['School_name'] = $school->district && $school->district->abbreviation
                ? $school->district->abbreviation . '-' . $school->name : $school->name;
            $data['School_number'] = $school->old_system_id ?? $school->id;
            if ($school->old_system_id === 35) {
                $data['Low_Grade'] = 12;
                $data['High_Grade'] = 12;
            }
            if ($school->old_system_id === 25) {
                $data['Low_Grade'] = 11;
                $data['High_Grade'] = 11;
            }
            fputcsv($pathToExport, $data);
        }
    }

    protected function teacherExport($pathToExport, $teachers)
    {
        $data['School_id'] = 'School_id';
        $data['Teacher_id'] = 'Teacher_id';
        $data['Teacher_email'] = 'Teacher_email';
        $data['First_name'] = 'First_name';
        $data['Last_name'] = 'Last_name';

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);

        foreach ($teachers as $teacher) {
            $data = [];
            $district = $teacher->tenants->where('id', tenant()->id)
                ->first()->tenantUsers->where('user_id', $teacher->id)->first()
                ->districts->where('active', true)->random();

            $school = $district && $district->sites->where('active', true)->count()
                ? $district->sites->where('active', true)->random()
                : null;

            $school = $school
                ? ($school->old_system_id ?? $school->id)
                : '99999';

            $data['School_id'] = $school;
            $data['Teacher_id'] = $teacher->old_system_id ?? $teacher->id;
            $data['Teacher_email'] = $teacher->email;
            $data['First_name'] = html_entity_decode($teacher->first_name, ENT_QUOTES);
            $data['Last_name'] = html_entity_decode($teacher->last_name, ENT_QUOTES);
            fputcsv($pathToExport, $data);
        }
    }

    public function staffExport($pathToExport, $staffs)
    {
        $data = [];
        $data['School_id'] = 'School_id';
        $data['Staff_id'] = 'Staff_id';
        $data['Staff_email'] = 'Staff_email';
        $data['First_name'] = 'First_name';
        $data['Last_name'] = 'Last_name';

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);

        foreach ($staffs as $staff) {
            $data = [];

            $districts = $staff->tenants->where('id', tenant()->id)->first()
                ->tenantUsers->where('user_id', $staff->id)->first()
                ->districts->where('active', true);

            foreach ($districts as $district) {
                foreach ($district->sites->where('active', true) as $site) {
                    $data['School_id'] = ($site->old_system_id ?? $site->id);
                    $data['Staff_id'] = $staff->old_system_id ?? $staff->id;
                    $data['Staff_email'] = $staff->email;
                    $data['First_name'] = html_entity_decode($staff->first_name, ENT_QUOTES);
                    $data['Last_name'] = html_entity_decode($staff->last_name, ENT_QUOTES);
                    fputcsv($pathToExport, $data);
                }
            }
        }
    }

    public function sectionExport($pathToExport)
    {
        $data = [];
        $data['School_id'] = 'School_id';
        $data['Section_id'] = 'Section_id';
        $data['Teacher_id'] = 'Teacher_id';
        $data['Teacher_2_id'] = 'Teacher_2_id';
        $data['Teacher_3_id'] = 'Teacher_3_id';
        $data['Teacher_4_id'] = 'Teacher_4_id';
        $data['Teacher_5_id'] = 'Teacher_5_id';
        $data['Teacher_6_id'] = 'Teacher_6_id';
        $data['Teacher_7_id'] = 'Teacher_7_id';
        $data['Teacher_8_id'] = 'Teacher_8_id';
        $data['Teacher_9_id'] = 'Teacher_9_id';
        $data['Teacher_10_id'] = 'Teacher_10_id';
        $data['Name'] = 'Name';
        $schools = collect();

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);
//
//        $schoolWithAdvocate = $this->siteLibrary->getSites(new SiteFilters([
//            'advocate' => true
//        ]))->load('students.paraProfessionals.tenants.tenantUsers.permissions', 'district');

//        $allTeachers = collect();
//
//        foreach ($schoolWithAdvocate as $school) {
//            $schoolTeachers = collect();
//
//            foreach ($school->students as $student) {
//                if (isset($student->paraProfessionals)) {
//                    foreach ($student->paraProfessionals as $advocate) {
//                        $isPrimary = $advocate->tenants->where('id', tenant()->id)->first()
//                            ->tenantUsers->where('user_id', $advocate->id)->first()
//                            ->permissions->where('name', 'Primary Teacher')->count();
//
//                        $schoolTeachers->push([
//                            'teacher_id' => $advocate->old_system_id ?? $advocate->id,
//                            'is_primary_teacher' => (boolean)$isPrimary
//                        ]);
//                        $allTeachers->push($advocate->id);
//                    }
//                }
//            }
//            $schools->push([
//                'school_id' => ($school->old_system_id ?? $school->id),
//                'school_name' => $school->name,
//                'district' => $school->district->abbreviation,
//                'teachers' => $schoolTeachers
//            ]);
//        }
//
//        $allTeachers = $allTeachers->unique();

        $otherTeachers = $this->userLibrary->getUsers(new UserFilters([
//            'whereNotIn' => $allTeachers->toArray(),
            'permissionName' => ['Ed Admin', 'Educator in Clever'],
            'active' => true,
        ]))->load('tenants.tenantUsers.districts.sites', 'tenants.tenantUsers.permissions');

        foreach ($otherTeachers as $otherTeacher) {
            $districts = $otherTeacher->tenants->where('id', tenant()->id)->first()
                ->tenantUsers->where('user_id', $otherTeacher->id)->first()
                ->districts->where('active', true);
            $isPrimary = $otherTeacher->tenants->where('id', tenant()->id)->first()
                ->tenantUsers->where('user_id', $otherTeacher->id)
                ->first()->permissions->where('name', 'Primary Teacher')->count();

            foreach ($districts as $district) {
                foreach ($district->sites->where('active', true) as $school) {
                    $ifSchoolPushed = $schools->where('school_id', ($school->old_system_id ?? $school->id))->first();
                    if (!isset($ifSchoolPushed)) {
                        $schools->push([
                            'school_id' => ($school->old_system_id ?? $school->id),
                            'district' => $district->abbreviation,
                            'school_name' => $school->name,
                            'teachers' => collect()->push(
                                [
                                    'teacher_id' => $otherTeacher->old_system_id ?? $otherTeacher->id,
                                    'is_primary_teacher' => (boolean)$isPrimary,
                                ]
                            ),
                        ]);
                    } else {
                        $ifSchoolPushed['teachers']->push([
                            'teacher_id' => $otherTeacher->old_system_id ?? $otherTeacher->id,
                            'is_primary_teacher' => (boolean)$isPrimary,
                        ]);

                    }
                }
            }
        }

        $sectionNumber = 1;
        $allSections = [];
        foreach ($schools as &$school) {
            $schoolSections = [];
            $school['teachers'] = $school['teachers']->unique();
            $countableTeachers = ceil($school['teachers']->count() / 10);
            $howManyAvailSection =  ceil(($school['teachers']->count() + $countableTeachers - 1) / 10 ) ;
            $primaryTeachersExists = [];
            while ($howManyAvailSection) {
                $primaryTeacher = $school['teachers']->where('is_primary_teacher', true)->first();

                $section = [];
                $section['School_id'] = $school['school_id'];
                $section['Section_id'] = $school['school_id'] . $sectionNumber;
                $section['Teacher_id'] = '';

                if (!$primaryTeacher) {
                    $firstTeacher = $school['teachers']->first();
                    $index = array_search($firstTeacher['teacher_id'], array_column($school['teachers']->toArray(), 'teacher_id'));
                    unset($school['teachers'][$index]);
                    $section['Teacher_id'] = $firstTeacher['teacher_id'];
                } else {
                    $section['Teacher_id'] = $primaryTeacher['teacher_id'];
                    $primaryTeachersExists[$section['Section_id']] = $primaryTeacher['teacher_id'];
                }

                $section['Teacher_2_id'] = '';
                $section['Teacher_3_id'] = '';
                $section['Teacher_4_id'] = '';
                $section['Teacher_5_id'] = '';
                $section['Teacher_6_id'] = '';
                $section['Teacher_7_id'] = '';
                $section['Teacher_8_id'] = '';
                $section['Teacher_9_id'] = '';
                $section['Teacher_10_id'] = '';
                $section['Name'] = $school['district'] . '-' . $school['school_name'] . ' Section' . $sectionNumber;
                $schoolSections[] = $section;
                $sectionNumber++;
                $howManyAvailSection--;
            }

            foreach ($schoolSections as &$schoolSection) {
                foreach ($schoolSection as $key => &$item) {
                    if ($item === '') {
                        $exists = array_key_exists($schoolSection['Section_id'], $primaryTeachersExists)
                            ? $school['teachers']->whereNotIn('teacher_id', $primaryTeachersExists[$schoolSection['Section_id']])->first()
                            : $school['teachers']->first();

                        if (is_array($exists)) {
                            $item = $exists['teacher_id'];
                            $index = array_search($item, array_column($school['teachers']->toArray(), 'teacher_id'));
                            $school['teachers'] = collect(array_values($school['teachers']->toArray()));
                            unset($school['teachers'][$index]);
                        }
                    }
                }
                fputcsv($pathToExport, $schoolSection);
                $allSections[$school['school_id']][] = $schoolSection;
            }
        }
        return $allSections;
    }

    public function enrollmentExport($pathToExport, $students, $allSections)
    {
        $data = [];
        $data['School_id'] = 'School_id';
        $data['Section_id'] = 'Section_id';
        $data['Student_id'] = 'Student_id';

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);

        foreach ($students as $student) {
            $data['Student_id'] = $student->id;
            $data['School_id'] = $student->site ? ($student->site->old_system_id ?? $student->site->id) : '9999';
            foreach ($allSections[$student->site->old_system_id ?? $student->site->id] as $section) {
                $data['Section_id'] = $section['Section_id'];
                fputcsv($pathToExport, $data);
            }
        }
    }

    public function studentExport($pathToExport, $students)
    {
        $data = [];
        $data['School_id'] = 'School_id';
        $data['Student_id'] = 'Student_id';
        $data['First_name'] = 'First_name';
        $data['Last_name'] = 'Last_name';
        $data['Gender'] = 'Gender';
        $data['Grade'] = 'Grade';
        $data['DOB'] = 'DOB';
        $data['IEP'] = 'IEP_status';
        $data['ELL/ESOL'] = 'Ell_status';
        $data['Contact_relationship'] = 'Contact_relationship';
        $data['Contact_name'] = 'Contact_name';
        $data['Contact_phone'] = 'Contact_phone';
        $data['Contact_email'] = 'Contact_email';

        $pathToExport = fopen($pathToExport, 'w');
        fputcsv($pathToExport, $data);

        foreach ($students as $student) {
            $data = [];
            $data['School_id'] = $student->site ? ($student->site->old_system_id ?? $student->site->id) : '9999';
            $data['Student_id'] = $student->id;
            $data['First_name'] = html_entity_decode($student->first_name, ENT_QUOTES);
            $data['Last_name'] = html_entity_decode($student->last_name, ENT_QUOTES);
            $data['Gender'] = $student->gender;

            $data['Grade'] = !isset($student->last_grade_completed) || $student->last_grade_completed === 'Not Sure'
                ? '12'
                : preg_replace('~\D~', '', $student->last_grade_completed);

            $data['DOB'] = !isset($student->birthdate) || $student->birthdate !== '0000-00-00'
                ? date('m/d/Y', strtotime($student->birthdate))
                : '';

            $data['IEP'] =
                $student->specialPrograms->where('name', '504 Plan')->count() || $student->specialPrograms->where('name', 'IEP')->count()
                    ? 'Y' : 'N';

            $data['ELL/ESOL'] = $student->specialPrograms->where('name', 'ELL/ESOL')->count()
                ? 'Y' : 'N';

            $data['Contact_relationship'] = $student->emergencyContact1Relation ? $student->emergencyContact1Relation->name : '';
            $data['Contact_name'] = $student->emergency_contact_1_name ? html_entity_decode($student->emergency_contact_1_name, ENT_QUOTES) : '';
            $data['Contact_phone'] = $student->emergency_contact_1_phone_1 ?? '';
            $data['Contact_email'] = $student->emergency_contact_1_email ?? '';

            fputcsv($pathToExport, $data);
        }
    }
}
