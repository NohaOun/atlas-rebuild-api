<?php

namespace App\Console\Commands;

use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Repository\StudentRepository;
use App\Models\Student;
use Illuminate\Console\Command;

class CacheRanking extends Command
{
    protected $signature = 'app:cache-ranking';
    protected $description = 'Cache ranking.';

    public function handle()
    {
        $this->cacheRankingList();
        $this->cacheTopStudents();
    }

    protected function cacheRankingList()
    {
        $studentRepository = new StudentRepository(new StudentFilters());
        $students = $studentRepository->
                    getStudentsByFilter(new StudentFilters())->load('studentPoint')->sortByDesc(function ($record) {
                        return $record->current_points;
                    });

        $rankingList = [];
        $previousPoints = 0;
        $ranking = 0;
        $students->map(function ($student) use (&$previousPoints, &$ranking, &$rankingList) {
            if ($student->current_points != $previousPoints) {
                ++$ranking;
            }

            $rankingList[$student->id] = ($ranking != 0 ? $ranking : 1);

            $previousPoints = $student->current_points;
        });

        \Cache::put('rankingList', $rankingList, now()->addHours(24));
    }

    protected function cacheTopStudents()
    {
        $studentRepository = new StudentRepository(new StudentFilters());
        $topStudents = $studentRepository->
                    getStudentsByFilter(new StudentFilters())->load('studentPoint')->sortByDesc(function ($record) {
                        return $record->current_points;
                    })->take(5);

        \Cache::put('topStudents', $topStudents, now()->addHours(24));
    }
}
