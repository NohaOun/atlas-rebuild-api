<?php

namespace App\Console\Commands;

use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentAssignee;
use App\Domain\User\Model\Permission;
use App\Domain\User\Model\TenantUser;
use App\Domain\User\Model\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class CreateUsersMainGroupCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user-main-group:create';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'create main group to users have permission Communication Caseload';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('create main group to users have permission Communication Caseload');
        $users = User::all();
        foreach ($users as $user) {
            $tenantUser = TenantUser::query()->where('user_id', $user->id)->first();
            $user->setTenantUser($tenantUser);
            Log::alert($user->id);
            Log::alert($user->can(Permission::COMMUNICATION_CASELOAD));
            if ($user->can(Permission::COMMUNICATION_CASELOAD)) {
                $studentsIds = StudentAssignee::query()->where('user_id', $user->id)->pluck('student_id');
                Log::debug($studentsIds);
                foreach ($studentsIds as $studentsId) {
                    Log::alert($studentsId);
                    $room = ChatRoom::query()->firstOrCreate([
                        'admin_id' => $user->id,
                        'room_type' => ChatRoom::$chatRoomType['MAIN_GROUP'],
                        'name' => "Main Group",
                    ]);
                    Log::alert($room);
                    RoomUser::query()->firstOrCreate([
                        'user_id' => $studentsId,
                        'room_id' => $room->id,
                        'user_type' => Student::class,
                    ]);
                    RoomUser::query()->firstOrCreate([
                        'user_id' => $user->id,
                        'room_id' => $room->id,
                        'user_type' => User::class,
                        'reassign_ability' => true,
                    ]);
                }
            }
        }

    }
}
