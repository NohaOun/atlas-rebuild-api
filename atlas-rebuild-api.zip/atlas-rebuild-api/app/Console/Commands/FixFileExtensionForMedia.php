<?php

namespace App\Console\Commands;

use App\Domain\FileUpload\Model\Media;
use Illuminate\Console\Command;

class FixFileExtensionForMedia extends Command
{
    protected $signature = 'app:fix-file-extension-for-media';
    protected $description = 'Fix file extension for media.';

    public function handle()
    {
        $media = Media::query()->get();

        foreach ($media as $record) {
            if ($record->extension) continue;

            if ($extension = $this->guessExtension($record->mime_type)) {
                $record->fill(['file_name' => $record->file_name . '.' . $extension])->save();
            }
        }
    }

    protected function guessExtension($mimeType)
    {
        if ($mimeType === 'image/png') {
            return 'png';
        }

        return null;
    }
}
