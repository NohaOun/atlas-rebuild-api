<?php

namespace App\Console\Commands;

use App\Domain\FileUpload\Model\Media;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\PathGenerator\PathGeneratorFactory;

class MoveMedia extends Command
{
    protected $signature = 'app:move-media {from} {to}';
    protected $description = 'Move media from disk to another.';

    public function handle()
    {
        $from = $this->argument('from');
        $to = $this->argument('to');

        Media::query()->where('disk', $from)->chunk(1000, function ($media) use ($from, $to) {
            foreach ($media as $mediaItem) {
                $this->moveMediaItem($mediaItem, $from, $to);
            }
        });
    }

    protected function moveMediaItem(Media $mediaItem, $from, $to)
    {
        $mediaPath = PathGeneratorFactory::create()->getPath($mediaItem);

        $fromDisk = Storage::disk($from);
        $toDisk = Storage::disk($to);

        $filesInDirectory = $fromDisk->allFiles($mediaPath);

        foreach ($filesInDirectory as $fileInDirectory) {
            $toDisk->put(
                $fileInDirectory,
                $fromDisk->readStream($fileInDirectory)
            );
        }

        $fromDisk->deleteDirectory($mediaPath);

        $mediaItem->fill(['disk' => $to])->save();
    }
}
