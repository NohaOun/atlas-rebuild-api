<?php

namespace App\Console;

use App\Console\Commands\OnSiteAttendance\AddPointsToStudent;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\Workflow\ExecuteTriggers::class,
        Commands\AddInitialDefaultPlpPlan::class,
        Commands\CleverSync::class,
//        AddPointsToStudent::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param \Illuminate\Console\Scheduling\Schedule $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('workflow:execute-triggers')->daily();
        $schedule->command('workflow:execute-triggers')->dailyAt('06:00');

        $schedule->command('clever:sync')->hourly();

        $schedule->command('app:import-call-logs zoom')->hourly();

        $schedule->command('app:sync-case-management-entries')->everyFifteenMinutes();

        if (config('edmentum-cronjobs.enabled')) {
            $schedule->command('Edmentum:SyncPrograms')->cron(config('edmentum-cronjobs.syncProgramsTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncLearners')->cron(config('edmentum-cronjobs.syncLearnersTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncClasses')->cron(config('edmentum-cronjobs.syncClassesTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncClassLearners')->cron(config('edmentum-cronjobs.syncClassLearnersTime'))->withoutOverlapping();
            // $schedule->command('Edmentum:SyncLearnerGrads')->cron(config('edmentum-cronjobs.syncLearnerGradsTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncTimeOnTask')->cron(config('edmentum-cronjobs.syncTimeOnTaskTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncActivities')->cron(config('edmentum-cronjobs.syncActivitiesTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncActivitiesLearner')->cron(config('edmentum-cronjobs.syncActivitiesLearnersTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncSystemAttendance')->cron(config('edmentum-cronjobs.syncSystemAttendanceTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncCourseCredits')->cron(config('edmentum-cronjobs.syncCourseCreditsTime'))->withoutOverlapping();
            $schedule->command('Edmentum:SyncCoursewareAudit')->cron(config('edmentum-cronjobs.syncCoursewareAuditsTime'))->withoutOverlapping();
        }

        /** @var TenantLibrary $tenantLibrary */
        $tenantLibrary = app()->make(TenantLibrary::class);
        $tenants = $tenantLibrary->getTenants();
        ini_set('memory_limit', -1);
        foreach ($tenants as $key => $tenant) {
            $schedule->command("onsite:add-progress-points --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-activity-goal --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-course-completion --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-first-course-completion --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-graduation-Hopper  --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-orientation --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-over-time-warrior  --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-smarty-pants  --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-tier-Hopper  --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-weekly-dash  --tenant=$tenant->id")->daily();
            $schedule->command("Edmentum:reward-weekly-progress  --tenant=$tenant->id")->daily();
            // $schedule->command("Edmentum:add-attendance-points  --tenant=$tenant->id")->daily();
//            $schedule->command("Edmentum:add-progress-points  --tenant=$tenant->id")->daily();
        }

        $schedule->command('telescope:prune')->daily();

        $schedule->command('app:dump-db')->at("08:00");
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
