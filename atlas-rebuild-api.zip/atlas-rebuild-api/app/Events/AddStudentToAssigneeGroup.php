<?php

namespace App\Events;

use App\Domain\Student\Model\Student;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class AddStudentToAssigneeGroup
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $student, $userIds;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Student $student, $userIds)
    {
        $this->student = $student;
        $this->userIds = $userIds;
    }
}
