<?php

namespace App\Events;

use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Chat\Model\Message;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\User\Model\User;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class MessageFlagged
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message, $chatRoom, $user;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Message $message, ChatRoom $chatRoom, User $user)
    {
        $this->user = $user;
        $this->message = $message;
        $this->chatRoom = $chatRoom;
    }


}
