<?php

namespace App\Events;

use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Student\Model\Student;
use App\Domain\User\Model\User;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ChatUpdates implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $chatRoom, $receiver, $eventType;

    public function __construct($chatRoom, $receiver, $eventType)
    {
        $this->chatRoom = $chatRoom;
        $this->receiver = $receiver;
        $this->eventType = $eventType;
    }

    public function broadcastWith()
    {
        return ['chatRoom' => $this->chatRoom];
    }

    public function broadcastAs()
    {
        if ($this->eventType === 'create')
            return 'new';
        else if ($this->eventType === 'delete')
            return 'deleted';
    }

    public function broadcastOn()
    {
        if ($this->receiver->user_type === Student::class)
            return new PrivateChannel('student-room' . $this->receiver->user_id);
        return new PrivateChannel('room' . $this->receiver->user_id);
    }
}
