<?php

namespace App\Events;

use App\Domain\Chat\Model\ChatMediaStatus;
use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Chat\Model\Message;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Common\Helpers;
use App\Domain\User\Model\User;
use App\Exceptions\Handler;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class MessageSent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $message, $roomMessagesCount, $receiver, $eventType;


    public function __construct($message, $receiver, $messagesCount, $eventType = 'new-message')
    {
        $this->message = $message;
        $this->receiver = $receiver;
        $this->roomMessagesCout = $messagesCount;
        $this->eventType = $eventType;
    }

    public function broadcastWith()
    {
        return ['message' => $this->message];
    }

    public function broadcastAs()
    {
        if ($this->eventType != 'new-message')
            return 'new-flag';
        return 'message';
    }

    public function broadcastOn()
    {
        if ($this->receiver->user_type === User::class)
            return new PrivateChannel('user-message-receiver' . $this->receiver->user_id);
        return new PrivateChannel('student-message-receiver' . $this->receiver->user_id);
    }
}
