<?php

namespace App\Http\Middleware;

use App\Domain\Auth\Exception\ShouldChangePasswordException;
use Closure;
use Illuminate\Support\Str;

class CheckTempPassword
{
    public function handle($request, Closure $next)
    {
        $user = auth()->user();

        if ($user && $user->should_change_password
            && !Str::endsWith(\Route::currentRouteAction(), 'AuthController@logout')
            && !Str::endsWith(\Route::currentRouteAction(), 'AuthController@changePassword')
            && !Str::endsWith(\Route::currentRouteAction(), 'AuthController@superUserChangePassword')
            && !Str::endsWith(\Route::currentRouteAction(), 'AuthController@parentChangePassword')) {
            throw new ShouldChangePasswordException();
        }


        return $next($request);
    }
}
