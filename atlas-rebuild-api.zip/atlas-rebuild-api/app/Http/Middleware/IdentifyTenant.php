<?php

namespace App\Http\Middleware;

use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentParent;
use App\Domain\Tenancy\Repository\TenantRepositoryInterface;
use App\Domain\User\Exception\AuthenticationException;
use App\Domain\User\Repository\UserRepositoryInterface;
use Closure;

class IdentifyTenant
{
    /**
     * @var TenantRepositoryInterface
     */
    private $tenantRepo;

    /**
     * @var UserRepositoryInterface
     */
    private $userRepo;

    public function __construct(
        TenantRepositoryInterface $tenantRepo,
        UserRepositoryInterface $userRepo
    )
    {
        $this->tenantRepo = $tenantRepo;
        $this->userRepo = $userRepo;
    }

    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @param mixed $required
     *
     * @return mixed
     *
     * @throws AuthenticationException
     */
    public function handle($request, Closure $next, $required = true)
    {
        if ($required === '0' || $required === 'false' || $required === 'optional') {
            $required = false;
        }

        $user = $request->user();

        $tenantId = $request->header('X-TENANT-ID');
        if (!$tenantId && $required) {
            $this->throwCannotIdentifyTenantException();
        }

        $tenant = $this->tenantRepo->getTenant($tenantId);
        if (!$tenant && ($tenantId || $required)) {
            $this->throwCannotIdentifyTenantException();
        }

        if ($tenant) {
            tenancy()->initialize($tenant);
            if(!(auth()->user() instanceof Student) && !(auth()->user() instanceof StudentParent)){
                $tenantUser = $this->userRepo->getTenantUser($user->id, $tenantId);
                if (!$tenantUser) {
                    $this->throwCannotFindTenantUserException();
                }

                $user->setTenantUser($tenantUser);
            }
        }

        return $next($request);
    }

    protected function throwCannotIdentifyTenantException()
    {
        throw new AuthenticationException('Cannot identify tenant');
    }

    protected function throwCannotFindTenantUserException()
    {
        throw new AuthenticationException('Cannot find tenant user');
    }
}
