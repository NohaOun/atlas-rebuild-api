<?php

namespace App\Http\Middleware;

use App\Domain\AcademyClosure\Model\AcademyClosure;
use App\Domain\Contact\Model\Contact;
use App\Domain\District\Repository\DistrictRepositoryInterface;
use App\Domain\Lookup\Model\Timezone;
use App\Domain\Note\Model\Note;
use App\Domain\Plp\Model\DistrictPlan;
use App\Domain\Schedule\Model\AppointmentCategory;
use App\Domain\Schedule\Model\ScheduleBlock;
use App\Domain\Schedule\Model\StaffSchedule;
use App\Domain\Site\Model\SiteCapacity;
use App\Domain\StatusHistory\Model\StatusHistoryEntry;
use App\Domain\Student\Model\Student;
use App\Domain\StudentAttendance\Model\StudentAttendanceEntry;
use App\Domain\User\Model\Permission;
use Closure;
use Illuminate\Database\Eloquent\Builder;

class ApplyDistrict
{
    protected $studentRepo;
    protected $contactRepo;
    protected $districtRepo;

    public function __construct(DistrictRepositoryInterface $districtRepo)
    {
        $this->districtRepo = $districtRepo;
    }

    public function handle($request, Closure $next)
    {
        $districts = $request->user()->districts;
        $districtIds = $districts->pluck('id');
        $showingInDashboard = $districts->where('show_in_dashboard', true)->pluck('id');
        $showingInReports = $districts->where('show_in_reports', true)->pluck('id');

        if ($request->user()->can(Permission::PERMISSION_NAME_CORPORATE)) {
            $districtIds = $this->districtRepo->getDistricts()->pluck('id');
        }

        Student::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        Contact::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->where(function (Builder $builder) use ($districtIds) {
                $builder->whereIn('district', $districtIds);
                $builder->orWhereHas('site', function (Builder $builder) use ($districtIds) {
                    $builder->whereIn('sites.district_id', $districtIds);
                });
            });
        });

        StudentAttendanceEntry::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('student', function (Builder $builder) use ($districtIds) {
                $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                    $builder->whereIn('sites.district_id', $districtIds);
                });
            });
        });

        Note::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('student', function (Builder $builder) use ($districtIds) {
                $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                    $builder->whereIn('sites.district_id', $districtIds);
                });
            });
        });

        AcademyClosure::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('sites', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        AppointmentCategory::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('sites', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        SiteCapacity::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        ScheduleBlock::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        StaffSchedule::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                $builder->whereIn('sites.district_id', $districtIds);
            });
        });

        StatusHistoryEntry::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereHasMorph('statusVariable','*', function (Builder $builder) use ($districtIds) {
                $builder->whereHas('site', function (Builder $builder) use ($districtIds) {
                    $builder->whereIn('sites.district_id', $districtIds);
                });
            });

        });

        DistrictPlan::addGlobalScope('assigned-districts', function (Builder $builder) use ($districtIds) {
            $builder->whereIn('district_id', $districtIds);
        });

        app()->instance('assigned-district-ids', $districtIds);
        app()->instance('showing-districts-ids-in-dashboard', $showingInDashboard);
        app()->instance('showing-district-ids-in-reports', $showingInReports);
        $timeZone = $request->user()->timeZone ?  Timezone::TIMEZONE_ID[$request->user()->timeZone->title] : 'UTC';
        app()->instance('userTimeZone', $timeZone);

        return $next($request);
    }
}
