<?php

namespace App\Http\Middleware;

use App\Domain\User\Model\Permission;
use Closure;
use Illuminate\Http\Response;

class IsRecruitment
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if(auth()->check()){
            foreach(auth()->user()->permissions as $permission){
                if(in_array($permission->id,Permission::CAN_ACCESS_COMPASS)){
                    return $next($request);
                }
            }
        }
        $arr["error"] = "You do not have access to Compass Mobile App";
        $arr['status'] = Response::HTTP_UNAUTHORIZED;
        return response($arr, Response::HTTP_UNAUTHORIZED);

    }
}
