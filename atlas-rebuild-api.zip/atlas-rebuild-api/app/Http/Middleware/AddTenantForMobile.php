<?php

namespace App\Http\Middleware;

use App\Domain\Student\Model\Student;
use Closure;

class AddTenantForMobile
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!$request->headers->has("X-TENANT-ID") && auth()->user()) {
            if (auth()->user() instanceof Student) {
                $request->headers->add(["X-TENANT-ID" => auth()->user()->tenant_id]);
            } else {
                $request->headers->add(["X-TENANT-ID" => auth()->user()->tenants()->first()->id]);
            }
        }
        return $next($request);
    }
}
