<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ContactResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $pinColor = $this->status->color?? '#31a1c0';
        return [
            'id' => $this->id,
            'pin_type' => $this->pin_type,
            'priority' => (int) $this->priority,
            'statusChangesNumber' => $this->status_changes_number ?? 0,
            'pinColor' =>  $pinColor,
            'business' => $this->business_id ?
                [
                    'id' => $this->business->id,
                    'establishmentName' => $this->business->establishment_name,
                ] : (object) null,
            'overview' => [
                'firstName' => $this->first_name,
                'middleName' => $this->middle_name,
                'lastName' => $this->last_name,
                'district' => $this->district,
                'site' => [
                    'id' => $this->site? $this->site->id: '',
                    'name' => $this->site ? $this->site->name : ''
                ],
                'phase' => $this->status->phase->name,
                'status' => $this->status->name,
            ],
            'contactInformation' => [
                'street1' => $this->street_address_1,
                'street2' => $this->street_address_2,
                'city' => $this->city,
                'state' => $this->state,
                'zipCode' => $this->zip_code,
                'phone1' => $this->phone_1,
                'phone2' => $this->phone_2,
                'email' => $this->email
            ],
            'eeoc' => [
                'DOB' => $this->birthdate? $this->birthdate->format('m/d/Y') : ''
            ],
            'pastSchoolAttended' => [
                'pastSchool' => $this->past_school_attended,
                'withdrawalCode' => $this->withdrawal_code,
                'withdrawalDate' => $this->withdrawal_date
            ],
            'referrer' => [
                'referrer' => $this->referrer,
                'referralOption' => $this->referral_option,
                'referralOptionOther' => $this->referral_option_other
            ],
            'staff' => [
                'enrollment_coach' => [
                    'id' => optional($this->communityOutreachAdvocate)->id,
                    'name' => optional($this->communityOutreachAdvocate)->full_name
                ],
                'outreachAdvocate' => [
                    'id' => optional($this->outreachResourceAdvocate)->id,
                    'name' => optional($this->outreachResourceAdvocate)->full_name
                ]
            ],
            'notes' => $this->notes,
            'updatedAt' => date('M d, Y \a\t h:i A', strtotime($this->updated_at))
        ];
    }
}
