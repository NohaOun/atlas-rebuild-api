<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AssignedUserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            "id" => $this->id,
            "district_id" => $this->district_id??"[0]",
            "school_id" =>  $this->site->id ?? 0,
            "attendance_only"=> null,
            "gca" => null,
            "first_name" => $this->first_name,
            "last_name"=> $this->last_name,
            "email"=> $this->email,
            "title"=> $this->title,
            "password"=> null,
            "api_token"=> null,
            "reporting_api_token"=> null,
            "salt"=> null,
            "bootstrap"=> null,
            "timezone"=> $this->timezone->id,
            "date_created"=> $this->created_at,
            "active"=>  $this->active,
            "user_group"=> null,
            "is_local"=> 0,
            "compass_mobile"=> $this->compass_mobile,
            "profile_image"=> null,
            "image_upload_date"=> null
        ];
    }
}
