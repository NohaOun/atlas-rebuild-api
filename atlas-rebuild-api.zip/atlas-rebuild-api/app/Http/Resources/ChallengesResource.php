<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ChallengesResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'activeChallenges' => $this->resource['activeChallenges'],
            'points' => intval($this->resource['studentPoints']),
            'amount' => floatval(round($this->resource['amount'], 2)),
            'canRedeem' => (boolean) (auth()->user()->can_redeem && intval($this->resource['studentPoints']))
        ];
    }
}
