<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class HomeResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'graduation' => $this->resource['toGoal'],
            'attendance' => $this->resource['attendance'],
            'coursework' => $this->resource['coursework'],
        ];
    }
}
