<?php

namespace App\Http\Resources;

use App\Domain\Schedule\Model\StudentScheduleEntry;
use Illuminate\Http\Resources\Json\JsonResource;

class ScheduleReasonResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource,
            'name' => StudentScheduleEntry::getFormattedNameAttribute($this->resource)
        ];
    }
}
