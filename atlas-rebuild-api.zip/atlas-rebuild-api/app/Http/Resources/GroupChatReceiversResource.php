<?php

namespace App\Http\Resources;

use App\Domain\Chat\Model\Message;
use Illuminate\Http\Resources\Json\JsonResource;

class GroupChatReceiversResource extends JsonResource
{
    public function toArray($request)
    {

        $redCount = $this->resource->room->messages
            ->where('creator_id', $this->resource->user_id)
            ->where('creator_type', $this->resource->user_type)
            ->where('flag', Message::$messageFlagTypes['RED'])->count();
        $yellowCount = $this->resource->room->messages
            ->where('creator_id', $this->resource->user_id)
            ->where('creator_type', $this->resource->user_type)
            ->where('flag', Message::$messageFlagTypes['YELLOW'])->count();
        if ($this->resource->user) {
            $name = $this->resource->user->nick_name != null ? $this->resource->user->nick_name : $this->resource->user->first_name . ' ' . $this->resource->user->last_name;
        } else {
            $name = null;
        }
        return [
            'name' => $name,
            'user_type' => $this->resource->user_type,
            'user_id' => $this->resource->user_id,
            'view_only' => $this->resource->view_only,
            'room_id' => $this->resource->room_id,
            'id' => $this->resource->id,
            'reassign_ability' => $this->resource->reassign_ability,
            'flags' => ['red' => $redCount, 'yellow' => $yellowCount],
        ];
    }
}
