<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class ChatMediaResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'file_url' => $this->message()->first()->getFirstMedia('message_file')->getTemporaryUrl(now()->addMinutes(10)),
            'creator' => $this->message()->first()->creator()->first()->full_name,
            'room_name' => $this->room()->first()->name
        ];
    }
}
