<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Str;

class VoucherResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->resource->id,
            'student' => new StudentResource($this->whenLoaded('student')),
            'subject' => $this->resource->subject,
            'merchant' => $this->resource->merchant,
            'amount' => $this->resource->amount,
            'emailBody' => $this->when($this->resource->email_body, $this->resource->email_body),
            'createdAt' => $this->resource->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
