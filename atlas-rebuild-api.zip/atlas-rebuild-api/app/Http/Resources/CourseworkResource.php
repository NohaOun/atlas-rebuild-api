<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CourseworkResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'remaining' => $this->resource['coursework'],
            'currentCourse' => $this->resource['currentCourse']
        ];
    }
}
