<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class RedemptionResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'student' => new StudentResource($this->whenLoaded('student')),
            'link' => $this->resource->link,
            'points' => intval($this->resource->points),
            'amount' => intval($this->resource->amount),
            'status' => $this->resource->status,
            'createdAt' => $this->resource->created_at->format('Y-m-d H:i:s'),
        ];
    }
}
