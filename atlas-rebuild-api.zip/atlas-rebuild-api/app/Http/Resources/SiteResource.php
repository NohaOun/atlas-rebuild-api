<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class SiteResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'districtId' => $this->district_id,
            'label' => $this->name
        ];
    }
}
