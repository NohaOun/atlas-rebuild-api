<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Psy\Util\Str;

class StudentScheduleResource extends JsonResource
{

    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource->id,
            'name' => Carbon::createFromFormat('Y-m-d', $this->resource->date)->format('D n/j'),
            'staff' => [
                'id' => $this->resource->staff->id,
                'name' => $this->resource->staff->full_name
            ],
            'date' => Carbon::createFromFormat('Y-m-d', $this->resource->date)->format('m/d/Y'),
            'from' => Carbon::createFromFormat('H:i:s', $this->resource->from)->format('h:iA'),
            'to' => Carbon::createFromFormat('H:i:s', $this->resource->to)->format('h:iA'),
            'reason' => new ScheduleReasonResource($this->looking_for),
            'type' => $this->resource->appointment_type,
            'location' => \Illuminate\Support\Str::title($this->resource->appointment_type),
            'categories' => AppointmentCategoryResource::collection($this->resource->appointmentCategories)
        ];
    }
}
