<?php

namespace App\Http\Resources;
use Illuminate\Http\Resources\Json\JsonResource;
// use DNS1D;

class ProfileResource extends JsonResource
{
    public function toArray($request)
    {
        $photo = $this->getFirstMedia('photo');
        
        return [
            'name' => $this->full_name,
            'profilePicture' => $photo ? $photo->getUrl() : null,
            'accelerationId' => "#{$this->id}",
            'districtId' => $this->district_id ? : null,
            'location' => $this->site->district->name.' / '.$this->site->name,
            'barcodeImage' => \DNS1D::getBarcodePNG($this->id, 'C39+',2,100),
            'ranking' => $this->ranking,
            'points' => intval($this->availablePoints),
            'referral_code' => $this->referral_code
        ];
    }
}
