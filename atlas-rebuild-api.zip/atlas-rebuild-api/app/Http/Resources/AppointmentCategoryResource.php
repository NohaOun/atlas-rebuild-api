<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AppointmentCategoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->resource->id,
            'name' => $this->resource->name,
            'type' => $this->resource->duration["type"],
            'isRecurring' => $this->resource->isRecurring,
            'fromTime' => $this->resource->duration["payload"]["from"]?? null,
            'toTime' => $this->resource->duration["payload"]["to"]?? null,
            'minutes' => $this->resource->duration["payload"]["minutes"]?? null,
            'day' => $this->resource->duration["payload"]["day"]?? null,
            'date' =>   $this->resource->duration["payload"]["date"] ?? null
        ];
    }
}
