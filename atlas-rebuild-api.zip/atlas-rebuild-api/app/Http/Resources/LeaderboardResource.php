<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class LeaderboardResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'name' => $this->name,
            'profile_picture' => optional($this->getFirstMedia('photo'))->getUrl(),
            'ranking' => $this->ranking,
            'points' => intval($this->current_points),
            'progress' => optional($this->edmentumCoursewareAuditsLatest)->percentage_complete . '%'
        ];
    }
}
