<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class CategoryContactsResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'action_title' => $this->name,
            'type' => 'category',
            "created_at" => $this->created_at,
            "updated_at" => $this->updated_at
        ];
    }
}
