<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PhaseLabelResource extends JsonResource
{

    public function toArray($request)
    {
        $statuses = [];
        foreach($this->statuses as $status)
            $statuses[]  = $status->name;
        return [
                "label" => $this->name,
                "statuses" => $statuses
        ];
    }
        
}
