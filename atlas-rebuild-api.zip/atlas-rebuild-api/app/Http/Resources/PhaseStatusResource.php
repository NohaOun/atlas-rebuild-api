<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PhaseStatusResource extends JsonResource
{

    public function toArray($request)
    {
        $statuses = [];
        foreach($this->statuses as $status)
            $statuses[]  = $status->name;

        return [$this->name => $statuses];
    }
}
