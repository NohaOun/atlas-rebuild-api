<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class GraduationResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'credits' => $this->resource['credits'],
            'toGoal' => $this->resource['toGoal'],
            'courses' => $this->resource['courses']
        ];
    }
}
