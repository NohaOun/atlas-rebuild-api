<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class ContactActionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'phase' => $this->status->phase->name,
            'status' => $this->status->name,
            'date' => Carbon::createFromFormat('Y-m-d H:i:s', $this->created_at)->format('m/d/Y'),
            'createdBy' => [
                'id' => $this->creator->id,
                'name' => $this->creator->full_name
            ],
            'category' => [
                'id' => $this->category->id,
                'name' => $this->category->name
            ],
            'notes' => $this->note,
            'sentTo' => implode(',', $this->usersMentioned??[]),
            'mentions' => $this->usersMentioned?  $this->usersMentioned : [],
            'action' => [
                'id' => $this->action->id?? null,
                'name' => $this->action->name?? null
            ],
            'assignee' =>[
                'id' => $this->assignee->id?? null,
                'name' =>  $this->assignee->full_name?? null,
            ],
            'creator' => [
                'id' => $this->creator->id?? null,
                'name' =>  $this->creator->full_name?? null,
            ],
            'action_by' => [
                'id' => $this->creator->id?? null,
                'name' =>  $this->creator->full_name?? null,
            ],
            'action_note' => $this->following_note,
            'due_date' =>  $this->due_date ? $this->due_date->format('m/d/Y'): null,
            'action_date' =>  $this->following_date ? $this->following_date->format('m/d/Y'): null,
            'due_date_time' =>  $this->due_date ? $this->due_date->format('m/d/Y'): null,
            // 'status' => $this->action_type,
            'user_time_zone' =>$this->user_time_zone
        ];
    }

    
}
