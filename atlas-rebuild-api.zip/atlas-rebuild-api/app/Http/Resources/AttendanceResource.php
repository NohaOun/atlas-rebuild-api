<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AttendanceResource extends JsonResource
{

    public function toArray($request)
    {
        return [
           'attendance' => $this->resource['attendance'],
            'toGoal' => $this->resource['toGoal'],
            'recentAttendance' => $this->resource['recentAttendance']
        ];
    }
}
