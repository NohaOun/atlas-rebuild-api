<?php

namespace App\Http\Requests\DocuSign;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SendDocuSignEnvelope extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:docusign-envelope',
            'data.relationships.student-documents.data.id' => ['required', 'exists:App\Domain\Document\Model\StudentDocument,id'],
        ];
    }
}
