<?php

namespace App\Http\Requests\Contacts;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateBulkContacts extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.relationships.site.data.id' => ['filled', Rule::exists('sites', 'id')],
            'data.relationships.status.data.id' => ['filled', Rule::exists('statuses', 'id')],
            'data.attributes.priority' => ['filled'],
            'data.attributes.phone_1' => ['filled'],
            'data.attributes.city' => ['filled'],
            'data.attributes.state' => ['filled'],
            'data.attributes.zip_code' => ['filled'],
            'data.relationships.category_contact.data.id' => ['filled', Rule::exists('category_contacts', 'id')],
            'data.relationships.community_outreach_advocate.data.id' => ['filled', Rule::exists('users', 'id')],
            'data.relationships.outreach_resource_advocate.data.id' => ['filled', Rule::exists('users', 'id')],
            'data.relationships.contacts' => ['nullable'],
            'data.relationships.contacts.data.*.id' => ['nullable', Rule::exists('contacts', 'id')]
        ];
    }
}
