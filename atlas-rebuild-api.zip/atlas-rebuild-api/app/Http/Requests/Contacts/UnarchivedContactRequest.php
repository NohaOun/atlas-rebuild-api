<?php


namespace App\Http\Requests\Contacts;


use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UnarchivedContactRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:contacts',
            'data.attributes.email' => ['required', 'max:100', 'email', Rule::unique('contacts', 'email')->whereNull('deleted_at')]
        ];
    }

}
