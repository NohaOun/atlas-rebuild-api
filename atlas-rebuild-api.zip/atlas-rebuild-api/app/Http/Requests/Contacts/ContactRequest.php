<?php


namespace App\Http\Requests\Contacts;


use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ContactRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:contacts',
            'data.relationships.master' => 'required',
            'data.relationships.master.data.type' => 'in:contacts',
            'data.relationships.master.data.id' => ['required', 'integer', Rule::exists('contacts', 'id')->whereNull('deleted_at')],
            'data.relationships.slave.data.type' => 'in:contacts',
            'data.relationships.slave' => 'required',
            'data.relationships.slave.data.id' => ['required', 'integer', Rule::exists('contacts', 'id')->whereNull('deleted_at')],
        ];
    }

}
