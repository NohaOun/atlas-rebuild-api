<?php

namespace App\Http\Requests\Student;

use Illuminate\Foundation\Http\FormRequest;

class UpdateSpecialProgram extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:students',
            'data.id' => 'required|exists:students,id,tenant_id,' . tenant()->id,
            'data.attributes.cohort_year' => ['sometimes'],
            'data.relationships.special_programs' => ['sometimes', 'array'],
            'data.relationships.relationships.*.data' => ['array'],
            'data.relationships.relationships.*.data.*.type' => ['in:special-programs'],
            'data.relationships.relationships.*.data.*.id' => ['exists:lookup_special_programs'],
        ];
    }
}
