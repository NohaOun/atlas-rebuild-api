<?php

namespace App\Http\Requests\Student;

use App\Domain\Lookup\Model\PhoneType;
use Illuminate\Foundation\Http\FormRequest;

class UpdateProfileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $phone_type_list =implode(',',(new PhoneType())->getValues());

        return [
            'zipcode' => 'numeric',
            'state' => 'in:'.implode(',', config('states')),
            'phone' => 'required|unique:students,phone_1,'.$this->request->get('id').'|numeric|digits:10',
            'phone_type' => 'in:'.$phone_type_list,
            'phone_secondary' => 'sometimes|numeric|digits:10',
            'phone_secondary_type' => 'sometimes|in:'.$phone_type_list,
            'email' => 'required|unique:students,email,'.$this->request->get('id'),
        ];
    }

    /**
     * @return array
     */
    public function attributes()
    {
        $phone_type_list =implode(',',(new PhoneType())->getValues());
        return [

            'zipcode' => 'Please, insert valid zip code!',
            'state' => 'Please, insert valid state value!',
            //'phone' => 'Please, insert valid state value!',
            'phone_type' => 'Phone type should be in:'.$phone_type_list,
            'phone_secondary' => 'Please insert a valid secondery phone !',
            'phone_secondary_type' => 'Phone type should be in:'.$phone_type_list,
            'email' => 'Please insert a valid email !',
        ];
    }
}


