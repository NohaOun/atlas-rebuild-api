<?php


namespace App\Http\Requests\Student;


use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UnarchivedStudentRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:students',
            'data.attributes.email' => ['required', 'max:100', 'email', Rule::unique('students', 'email')->whereNull('deleted_at')]
        ];
    }
}
