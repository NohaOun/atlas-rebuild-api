<?php


namespace App\Http\Requests\Student;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateStudentGraduationRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:students',
            'data.id' => [Rule::exists('students', 'id')->whereNull('deleted_at')],
            'data.attributes' => ['sometimes', 'array'],
            'data.attributes.pathway_descriptor' => ['sometimes', 'nullable', 'max:2000'],

            'data.relationships' => ['sometimes', 'array'],

            'data.relationships.graduation_plan' => ['sometimes', 'nullable', 'array'],
            'data.relationships.graduation_plan.data' => ['sometimes', 'array'],
            'data.relationships.graduation_plan.data.type' => ['in:statuses'],
            'data.relationships.graduation_plan.data.id' => [Rule::exists('statuses', 'id')],

            'data.relationships.military_branch' => ['sometimes', 'nullable', 'array'],
            'data.relationships.military_branch.data' => ['sometimes', 'array'],
            'data.relationships.military_branch.data.type' => ['in:military-branches'],
            'data.relationships.military_branch.data.id' => [Rule::exists('lookup_military_branches', 'id')],

            'data.relationships.pathway' => ['sometimes', 'nullable', 'array'],
            'data.relationships.pathway.data' => ['sometimes', 'array'],
            'data.relationships.pathway.data.type' => ['in:post-grad-pathways'],
            'data.relationships.pathway.data.id' => [Rule::exists('lookup_post_grad_pathways', 'id')],
        ];
    }
}
