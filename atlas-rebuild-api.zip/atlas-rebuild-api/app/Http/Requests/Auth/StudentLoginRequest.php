<?php

namespace App\Http\Requests\Auth;
use Illuminate\Foundation\Http\FormRequest;

class StudentLoginRequest extends LoginRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.attributes.email' => 'required',
            'data.attributes.password' => 'required',
        ];
    }
}
