<?php

namespace App\Http\Requests\Auth;

class ChangePasswordRequest extends LoginRequest
{
    public function rules()
    {
        return [
            'data.attributes.password' => ['required', 'min:6'],
        ];
    }

}
