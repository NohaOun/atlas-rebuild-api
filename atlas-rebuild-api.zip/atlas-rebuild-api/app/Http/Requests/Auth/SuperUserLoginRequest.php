<?php

namespace App\Http\Requests\Auth;

class SuperUserLoginRequest extends LoginRequest
{
}
