<?php


namespace App\Http\Requests\Auth;


use Illuminate\Validation\Rule;

class ForgotPasswordRequest extends LoginRequest
{
    public function rules()
    {
        return [
            'data.attributes.email' => ['required', 'email',Rule::exists('parents', 'email')],
            'data.attributes.new_password' => 'required',
        ];
    }

}
