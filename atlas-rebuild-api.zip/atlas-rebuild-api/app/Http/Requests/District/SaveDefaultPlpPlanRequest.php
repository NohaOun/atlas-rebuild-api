<?php

namespace App\Http\Requests\District;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SaveDefaultPlpPlanRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.type' => 'in:district-default-plp-plans',
            'data.attributes.content' => ['required', 'array'],
            'data.attributes.content.*.group' => ['required', 'array'],
            'data.attributes.content.*.group.name' => ['required', 'string', Rule::exists('plp_course_groups', 'name')],
            'data.attributes.content.*.group.min_credit' => ['nullable', 'numeric'],
            'data.attributes.content.*.group.assessment' => ['required', 'boolean'],
            'data.attributes.content.*.courses' => ['array'],
            'data.attributes.content.*.courses.*.min_score' => ['nullable'],
            'data.attributes.content.*.courses.*.tier_5' => ['filled', 'boolean'],
        ];
    }
}
