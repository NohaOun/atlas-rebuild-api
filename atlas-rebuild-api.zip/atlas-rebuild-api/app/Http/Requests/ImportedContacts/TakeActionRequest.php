<?php

namespace App\Http\Requests\ImportedContacts;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class TakeActionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'data.attributes.file_id' => ['required', 'exists:media,id,is_valid,1'],
            'data.attributes.action_on' => ['nullable', 'array'],
            'data.attributes.action_on.*.action' => ['required', Rule::in(['override', 'add'])],
            'data.attributes.action_on.*.contacts' => ['nullable', 'array'],
            'data.attributes.action_on.*.contacts.*' => [
                'exists:imported_contacts,id,taken_action,0,file_id,' . $this->data['attributes']['file_id']
            ]
        ];
    }
}
