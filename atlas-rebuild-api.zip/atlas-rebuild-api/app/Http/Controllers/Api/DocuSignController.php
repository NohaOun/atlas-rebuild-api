<?php

namespace App\Http\Controllers\Api;

use App\Domain\Document\DocumentLibrary;
use App\Domain\DocuSign\Model\StudentDocusignEnvelope;
use App\Domain\FileUpload\Factory\FromJwtTokenFactory;
use LaravelDocusign\Facades\DocuSign;
use DocuSign\eSign\Model\EnvelopeDefinition;
use DocuSign\eSign\Model\TemplateRole;
use DocuSign\eSign\Client\ApiException;

use App\Http\Controllers\Controller;
use App\Http\Requests\DocuSign\SendDocuSignEnvelope;
use Carbon\Carbon;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;
use stdClass;

use function CloudCreativity\LaravelJsonApi\json_decode;

class DocuSignController extends Controller
{
    //
    use CreatesResponses;

    private $documentLibrary;
    
    function __construct(DocumentLibrary $documentLibrary)
    {
        $this->documentLibrary = $documentLibrary;
    }

    public function getTemplates()
    {
        $JSONTemplates = DocuSign::get('templates')->ListTemplates(config('docusign.DOCUSIGN_ACCOUNT_ID'));
        $doc_templates = json_decode($JSONTemplates);
        $templates = [];
        foreach ($doc_templates->envelopeTemplates as $key => $template) {
            $templates[$key]["template_id"] = $template->templateId;
            $templates[$key]["template_name"] = $template->name;
        }
        $data = ["data" => $templates];
        return  $data;
    }


    public function SentEnvlope(SendDocuSignEnvelope $request)
    {
       
        $studentDocuments_id = Arr::get($request->all(), 'data.relationships.student-documents.data.id');
        $student_Document = $this->documentLibrary->getStudentDocument($studentDocuments_id);
        $student = $student_Document->student;
        $birthdate = $student->birthdate;
        // if student under 18 then legal guardian
        if(Carbon::parse($birthdate)->age < 18){
            $args["signer_email"] = $student->emergency_contact_1_email ?? $student->emergency_contact_2_email;
        }else{
            $args["signer_email"] = $student->email;
        }
        $args["signer_name"]= $student->full_name;
        $args['template_id'] = $student_Document->documentType->docusign_template_id;
        
        $signer = new TemplateRole([
            'email' => $args['signer_email'], 
            'name' => $args['signer_name'],
            'role_name' => 'signer',
            'routing_order' => "1"
            // 'client_user_id' => $student->id # change the signer to be embedded
        ]);
        $senders = [];
        // Commented CC added to Envelope till we know how we can get it completed
        // if($student->graduateCandidateAdvocate){
        //     $args['cc_email'] =  $student->graduateCandidateAdvocate->email;
        //     $args['cc_name'] = $student->graduateCandidateAdvocate->full_name;
        //     $cc = new TemplateRole([
        //         'email' => $args['cc_email'], 
        //         'name' => $args['cc_name'],
        //         'role_name' => 'cc',
        //         'routing_order' => "1"
        //     ]);
        //     $senders[] = $cc;
        // }
        $senders[] = $signer;

        $envelope_definition = new EnvelopeDefinition([
            'status' => 'sent', 
            'template_id' => $args['template_id']
        ]);
       
        # Add the TemplateRole objects to the envelope object
        $envelope_definition->setTemplateRoles($senders);
        
        $document_template = DocuSign::get('envelopes')->createEnvelope($envelope_definition);

        $studentDocusign = StudentDocusignEnvelope::create([
            "envelope_id" => $document_template->getEnvelopeId(),
            "student_document_id" => $student_Document->id,
            "status" => $document_template->getStatus(),
            "uri" =>  $document_template->getUri()
        ]);

        return ["data" => $studentDocusign];

    }

    public function HandleWebHook(Request $request){
        $xml_data = simplexml_load_string($request->getContent());
        $envelopeId = $xml_data->EnvelopeStatus->EnvelopeID;
        $studentDocusignEnvelope =  StudentDocusignEnvelope::where('envelope_id', $envelopeId)->firstOrFail();
        $studentDocusignEnvelope->status = strtolower($xml_data->EnvelopeStatus->Status);
        $studentDocusignEnvelope->download_links = json_encode($this->DownloadDocs($envelopeId));
        $studentDocusignEnvelope->save();
    }

    public function DownloadDocs($envelopeId){
        try 
        {
            $envelopeJson =  DocuSign::get('envelopes')->listDocuments($envelopeId);
            $envelope = json_decode($envelopeJson);
            $download_links = [];
            foreach ($envelope->envelopeDocuments as $key => $docuemnt) {
                //An SplFileObject is returned. See http://php.net/manual/en/class.splfileobject.php
                $temp_file =  DocuSign::get('envelopes')->getDocument($docuemnt->documentId, $envelopeId);
                
                $has_pdf_suffix = strtoupper(substr($docuemnt->name, -4)) == '.PDF';
                
                $extensions = '';
                
                # Add ".pdf" if it's a content or summary doc and doesn't already end in .pdf
                if ($docuemnt->type == "content" || ($docuemnt->type == "summary" && ! $has_pdf_suffix)) {
                    $extensions .= ".pdf";
                }
                
                # Add .zip as appropriate
                if ($docuemnt->type == "zip") {
                    $extensions .= ".zip";
                }
                // Generate Unique File name
                $filename = sprintf('%s-%s-%s-%s', $docuemnt->documentIdGuid,time(),$docuemnt->name, $extensions);
                # Save Document to local storage    
                Storage::disk('docuSignDocuments')->put( $filename, file_get_contents($temp_file->getRealPath()));
                # Store URL 
                $download_links[$key]['file_name'] = $docuemnt->name . $extensions;
                $download_links[$key]['url'] =    Storage::disk('docuSignDocuments')->url( $filename);
            }
            return  $download_links;
        } catch (ApiException $e) {
            DocuSign::get('ApiException')->showErrorTemplate($e);
            exit;
        }
    }
}
