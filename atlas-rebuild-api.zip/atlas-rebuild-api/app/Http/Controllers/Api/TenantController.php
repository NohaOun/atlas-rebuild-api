<?php

namespace App\Http\Controllers\Api;

use App\Domain\User\Filters\UserFilters;
use App\Domain\User\UserLibrary;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;

class TenantController extends Controller
{
    use CreatesResponses;

    /**
     * @var UserLibrary
     */
    private $userLibrary;

    public function __construct(UserLibrary $userLibrary)
    {
        $this->userLibrary = $userLibrary;
    }

    public function users($tenant)
    {
        return $this->reply()->content(
            $this->userLibrary->getUsers(new UserFilters(['tenant' => $tenant->id]))
        );
    }
}
