<?php

namespace App\Http\Controllers\Api;

use App\Domain\Contact\ContactLibrary;
use App\Domain\Contact\Filters\ContactFilters;
use App\Domain\Contact\Repository\ContactRepositoryInterface;
use App\Http\Requests\Contacts\UpdateBulkContacts;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Support\Arr;

class BulkUpdateContactControllers extends JsonApiController
{
    use CreatesResponses;

    public $contactLibrary;
    public $contactRepo;

    public function __construct(ContactLibrary $contactLibrary, ContactRepositoryInterface $contactRepo)
    {
        $this->contactLibrary = $contactLibrary;
        $this->contactRepo = $contactRepo;
    }

    public function updateBulkContacts(UpdateBulkContacts $request)
    {
        $model = $this->contactLibrary->updateBulkContacts(
            $this->parseRequest($request->all())
        );

        return $this->reply()->created($model);
    }

    protected function parseRequest(array $document)
    {
        $attributes = Arr::get($document, 'data.attributes');
        $filters = Arr::get($document, 'filter');

        $documentRelationships = Arr::get($document, 'data.relationships', []);

        $relationships = [];

        if (isset($documentRelationships['community_outreach_advocate'])) {
            $relationships['community_outreach_advocate_id'] = Arr::get($documentRelationships, 'community_outreach_advocate.data.id');
        }

        if (isset($documentRelationships['outreach_resource_advocate'])) {
            $relationships['outreach_resource_advocate_id'] = Arr::get($documentRelationships, 'outreach_resource_advocate.data.id');
        }

        if (isset($documentRelationships['site'])) {
            $relationships['site_id'] = Arr::get($documentRelationships, 'site.data.id');
        }

        if (isset($documentRelationships['status'])) {
            $relationships['status_id'] = Arr::get($documentRelationships, 'status.data.id');
        }

        if (isset($documentRelationships['category_contact'])) {
            $relationships['category_contact_id'] = Arr::get($documentRelationships, 'category_contact.data.id');
        }

        if (isset($documentRelationships['contacts']) && $documentRelationships['contacts']['data']) {
            $relationships['contact_ids'] = array_map(function ($record) {
                return $record['id'];
            }, $documentRelationships['contacts']['data']);

        }

        if(isset($filters)){
            $contacts = $this->contactRepo->getContacts(new ContactFilters($filters));
            $contactsIds = $contacts->pluck('id');
            $relationships['contact_ids'] = $contactsIds->toArray();
        }

        if (isset($documentRelationships['district'])) {
            $relationships['district'] = Arr::get($documentRelationships, 'district.data.id');
        }

        return compact('attributes', 'relationships');

    }
}
