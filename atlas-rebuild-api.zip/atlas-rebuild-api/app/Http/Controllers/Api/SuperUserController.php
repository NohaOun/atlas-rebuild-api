<?php

namespace App\Http\Controllers\Api;

use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResource;
use Illuminate\Support\Facades\Auth;

class SuperUserController extends JsonApiController
{
    public function me(FetchResource $request)
    {
        $user = Auth::user();

        return $this->reply()->content($user);
    }
}
