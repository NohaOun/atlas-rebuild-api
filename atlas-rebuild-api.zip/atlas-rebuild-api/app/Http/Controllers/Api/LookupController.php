<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

class LookupController extends Controller
{
    private $lookupLibrary;

    public function __construct(LookupLibrary $lookupLibrary)
    {

        $this->lookupLibrary = $lookupLibrary;
    }
}
