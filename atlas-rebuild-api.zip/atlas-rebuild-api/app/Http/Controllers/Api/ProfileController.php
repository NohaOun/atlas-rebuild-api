<?php

namespace App\Http\Controllers\Api;

use App\Domain\Auth\Exception\CurrentTenantIsNotDefinedException;
use App\Domain\CallLog\CallLogLibrary;
use Carbon\Carbon;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResource;
use Illuminate\Support\Facades\Auth;

class ProfileController extends JsonApiController
{
    use CreatesResponses;
    public function me(FetchResource $request)
    {
        if (
            !Auth::user()->hasTenant() &&
            in_array('current_tenant', $request->getEncodingParameters()->getIncludePaths())
        ) {
            throw new CurrentTenantIsNotDefinedException();
        }

        $user = Auth::user();

        return $this->reply()->content($user);
    }

    public function callLogStats(CallLogLibrary $callLogLibrary)
    {
        return $this->reply()->content($callLogLibrary->getCallLogStats());
    }

    public function superUserMe()
    {
        $user = Auth::guard('api_super_users')->user();

        return $this->reply()->content($user);
    }
}
