<?php

namespace App\Http\Controllers\Api;

use App\Domain\Log\Filters\LogFilters;
use App\Domain\Log\LogLibrary;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;

class LogController extends Controller
{
    use CreatesResponses;

    /**
     * @var LogLibrary
     */
    private $logLibrary;

    public function __construct(LogLibrary $logLibrary)
    {
        $this->logLibrary = $logLibrary;
    }

    public function index(EncodingParametersInterface $parameters)
    {
        $filters = $parameters->getFilteringParameters() ?? [];

        if (array_key_exists('contact', $filters)) {
            $filters['subject'] = $filters['contact'];
            $filters['subjectType'] = 'Contact';
        }

        $filters = new LogFilters($filters);

        return $this->reply()->content(
            $this->logLibrary->getLogEntries($filters)
        );
    }

    public function show($id)
    {
        return $this->reply()->content(
            $this->logLibrary->getLogEntry($id)
        );
    }
}
