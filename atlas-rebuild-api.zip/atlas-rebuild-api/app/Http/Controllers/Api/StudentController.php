<?php

namespace App\Http\Controllers\Api;

use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Notifications\PasswordUpdated;
use App\Domain\Student\Notifications\ResetPassword;
use App\Domain\Student\Repository\StudentRepositoryInterface;
use App\Domain\Student\StudentLibrary;
use App\Domain\Student\StudentMergeLibrary;
use App\Http\Requests\Student\StudentRequest;
use App\Http\Requests\Student\UnarchivedStudentRequest;
use App\Http\Requests\Student\UpdateSpecialProgram;
use App\Http\Requests\Student\UpdateStudentGraduationRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class StudentController extends JsonApiController
{
    use CreatesResponses;

    protected $mergeStudentLibrary;

    protected $studentLibrary;

    protected $studentRepo;


    public function __construct(
        StudentMergeLibrary $mergeStudentLibrary,
        StudentLibrary $studentLibrary,
        StudentRepositoryInterface $studentRepo
    )
    {
        $this->mergeStudentLibrary = $mergeStudentLibrary;
        $this->studentLibrary = $studentLibrary;
        $this->studentRepo = $studentRepo;
    }

    public function mergeStudents(StudentRequest $request)
    {
        $model = $this->mergeStudentLibrary->mergeStudents(
            $this->parseRequest($request->all())
        );

        return $this->reply()->created($model);
    }

    protected function parseRequest(array $document)
    {
        $documentRelationships = Arr::get($document, 'data.relationships', []);

        $relationships = [];

        if (isset($documentRelationships['master'])) {
            $relationships['master_id'] = Arr::get($documentRelationships, 'master.data.id');
        }

        if (isset($documentRelationships['slave'])) {
            $relationships['slave_id'] = Arr::get($documentRelationships, 'slave.data.id');
        }

        return $relationships;
    }

    public function updateSpecialProgram(UpdateSpecialProgram $request)
    {
        $student = $this->studentLibrary->getStudent(Arr::get($request->all(), 'data.id'));

        if ($relationship = Arr::get($request->all(), 'data.relationships.special_programs')) {
            $this->studentLibrary->saveStudentSpecialPrograms($student, $relationship);
        }

        if ($cohort = Arr::get($request->all(), 'data.attributes.cohort_year')) {
            $student->fill(['cohort_year' => $cohort]);
            $this->studentRepo->saveStudent($student);
        }

        return $this->reply()->content(
            $student
        );
    }

    public function unarchivedStudent($student, UnarchivedStudentRequest $request)
    {
        $email = Arr::get($request->all(), 'data.attributes.email');

        $model = $this->studentLibrary->unarchivedStudent($student, $email);

        return $this->reply()->created($model);
    }

    public function updateMinorIcon(Request $request)
    {
        return $this->reply()->content(
            $this->studentLibrary->updateMinorIcon($request->get('data')['attributes']['icon'])
        );
    }

    public function recruitmentLog(Student $student)
    {
        return $this->reply()->created($this->studentLibrary->getStudentRecruitmentLog($student));
    }

    public function studentCurrentCourses(Student $student)
    {
        return $this->reply()->created($this->studentLibrary->studentCurrentCourses($student));
    }

    public function updateStudentGraduation(Student $student, UpdateStudentGraduationRequest $graduationRequest)
    {
        return $this->reply()->content(
            $this->studentLibrary->updateStudentGraduation($student, $graduationRequest->all())
        );
    }

    public function onlineAttendanceLogs(Student $student)
    {
        return $this->reply()->content($this->studentLibrary->onlineAttendanceLogs($student));
    }
    public function resetPasswordLink(Request $request, Student $student)
    {
        $email = Arr::get($request->all(), 'data.attributes.email');
        if($email){
            $student->email = $email;
        }
        $student->reset_token = Str::random(20);
        $this->studentRepo->saveStudent($student);
        $student->notify(new ResetPassword());
        return response()->json("Reset Email Sent Successfully to $student->email");
    }

    public function changePassword(Request $request )
    {
        $resetToken = Arr::get($request->all(), 'data.attributes.reset-token');
        $password = Arr::get($request->all(), 'data.attributes.password');
        
        if(!$resetToken || !$password){
            return response()->json("Please Send All Required paramters" , 401);
        }
        $student = $this->studentRepo->getStudentFilter(new StudentFilters(["reset-token"=> $resetToken?? "Fail"]));
        if($student){
            if($password){
                $student->password = Hash::make($password);
                $student->reset_token = null;
                $this->studentRepo->saveStudent($student);
            }
            $student->notify(new PasswordUpdated());
            return response()->json("Password Updated Successfully");
        }
        return response()->json("Password can not updated", 401);
    }
}
