<?php

namespace App\Http\Controllers\Api;

use App\Domain\Contact\ContactImportLibrary;
use App\Http\Requests\ImportedContacts\TakeActionRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Support\Arr;

class ImportedContactController extends JsonApiController
{
    use CreatesResponses;

    protected $contactImportLibrary;

    public function __construct(ContactImportLibrary $contactImportLibrary)
    {
        $this->contactImportLibrary = $contactImportLibrary;
    }

    public function takeAction(TakeActionRequest $request)
    {
        return $this->reply()->content(
            $this->contactImportLibrary->updateImportedContacts(
                Arr::get($request->all(), 'data.attributes'),
                Arr::get($request->all(), 'filter')
            )
        );
    }
}
