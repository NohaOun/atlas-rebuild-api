<?php


namespace App\Http\Controllers\Api;


use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResource;
use Illuminate\Support\Facades\Auth;

class ParentController extends JsonApiController
{
    public function me(FetchResource $request)
    {
        $parent = Auth::user();
        return $this->reply()->content($parent);
    }

    public function students(FetchResource $request)
    {
        $parent = Auth::user();
        return $this->reply()->content($parent->students);
    }
}
