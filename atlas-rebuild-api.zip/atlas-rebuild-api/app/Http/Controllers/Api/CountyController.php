<?php

namespace App\Http\Controllers\Api;

use App\Domain\Student\CountyLibrary;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Http\Request;

class CountyController extends Controller
{
    use CreatesResponses;

    /**
     * @var CountyLibrary
     */
    private $countyLibrary;

    public function __construct(CountyLibrary $countyLibrary)
    {
        $this->countyLibrary = $countyLibrary;
    }

    public function search(Request $request)
    {
        return $this->reply()->content(
            $this->countyLibrary->getCounties($request->get('filter')['q'])
        );
    }
}
