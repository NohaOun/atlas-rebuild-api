<?php

namespace App\Http\Controllers\Api;

use App\Domain\Lookup\Library\SpecialProgramLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;

class SpecialProgramsController extends JsonApiController
{
    use CreatesResponses;

    protected $specialProgramLibrary;

    public function __construct(SpecialProgramLibrary $specialProgramLibrary)
    {
        $this->specialProgramLibrary = $specialProgramLibrary;
    }

    public function updateIcon(Request $request)
    {
        return $this->reply()->content(
            $this->specialProgramLibrary->updateIcon($request->get('data')['attributes']['icon'])
        );
    }
}
