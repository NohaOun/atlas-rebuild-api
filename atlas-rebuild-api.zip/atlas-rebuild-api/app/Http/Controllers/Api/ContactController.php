<?php

namespace App\Http\Controllers\Api;

use App\Domain\Contact\ContactExportLibrary;
use App\Domain\Contact\ContactImportLibrary;
use App\Domain\Contact\ContactLibrary;
use App\Domain\Contact\ContactMergeLibrary;
use App\Domain\Contact\Filters\ContactFilters;
use App\Http\Requests\Contacts\ContactRequest;
use App\Http\Requests\Contacts\ImportContactsRequest;
use App\Http\Requests\Contacts\OverrideRequest;
use App\Http\Requests\Contacts\UnarchivedContactRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;
use Illuminate\Support\Arr;
use Neomerx\JsonApi\Contracts\Encoder\Parameters\EncodingParametersInterface;

class ContactController extends JsonApiController
{
    use CreatesResponses;

    /**
     * @var ContactImportLibrary
     */
    private $contactImportLibrary;

    /**
     * @var ContactExportLibrary
     */
    private $contactExportLibrary;

    private $contactLibrary;

    private $contactMergeLibrary;

    public function __construct(ContactImportLibrary $contactImportLibrary,
                                ContactExportLibrary $contactExportLibrary,
                                ContactLibrary $contactLibrary,
                                ContactMergeLibrary $contactMergeLibrary)
    {
        $this->contactImportLibrary = $contactImportLibrary;
        $this->contactExportLibrary = $contactExportLibrary;
        $this->contactLibrary = $contactLibrary;
        $this->contactMergeLibrary = $contactMergeLibrary;
    }

    public function export(EncodingParametersInterface $request)
    {
        return $this->reply()->content(
            $this->contactExportLibrary->export(
                new ContactFilters($request->getFilteringParameters() ?? []),
                $request->getPaginationParameters() ?? []
            )
        );
    }

    public function mergeContacts(ContactRequest $request)
    {
        $model = $this->contactMergeLibrary->mergeContacts(
            $this->parseRequest($request->all())
        );

        return $this->reply()->created($model);
    }

    protected function parseRequest(array $document)
    {
        $documentRelationships = Arr::get($document, 'data.relationships', []);

        $relationships = [];

        if (isset($documentRelationships['master'])) {
            $relationships['master_id'] = Arr::get($documentRelationships, 'master.data.id');
        }

        if (isset($documentRelationships['slave'])) {
            $relationships['slave_id'] = Arr::get($documentRelationships, 'slave.data.id');
        }

        return $relationships;
    }

    public function searched($records, FetchResources $request)
    {
        $filters = $request->getEncodingParameters()->getFilteringParameters();
        if (isset($filters['scheduled_from']) && isset($filters['scheduled_to'])) {
            $meta = $this->contactLibrary->getContactMeta($filters);

            return $this->reply()->content($records, [], $meta);
        }

        return $records;
    }

    public function unarchivedContact($contact, UnarchivedContactRequest $request)
    {
        $email = Arr::get($request->all(), 'data.attributes.email');

        $model = $this->contactLibrary->unarchivedContact($contact, $email);

        return $this->reply()->created($model);
    }
}
