<?php

namespace App\Http\Controllers\Api;

use App\Domain\Bank\BankLibrary;
use App\Http\Requests\District\SaveDefaultPlpPlanRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class BankController extends JsonApiController
{
    use CreatesResponses;

    protected $BankLibrary;

    public function __construct(BankLibrary $BankLibrary)
    {
        $this->BankLibrary = $BankLibrary;
    }


    public function createBank(Request $request)
    {
          dd($request->all());
    }

    
}
