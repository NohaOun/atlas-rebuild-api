<?php

namespace App\Http\Controllers\Api;

use App\Domain\FileUpload\FileUploadLibrary;
use App\Domain\FileUpload\Factory\FromJwtTokenFactory;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Http\Request;

class FileUploadController extends Controller
{
    use CreatesResponses;

    const HEADER_TOKEN = 'X-FILE-UPLOAD-TOKEN';

    /**
     * @var FileUploadLibrary
     */
    private $fileUploadLibrary;

    public function __construct(FileUploadLibrary $fileUploadLibrary)
    {
        $this->fileUploadLibrary = $fileUploadLibrary;
    }

    public function createToken(Request $request)
    {
        $token = $this->fileUploadLibrary->getTokenFor($request->get('type'));

        return $this->reply()->content($token);
    }

    public function uploadTemporaryFile(FromJwtTokenFactory $tokenFactory, Request $request)
    {
        $tokenId = $request->header('X-FILE-UPLOAD-TOKEN');
        $token = $tokenFactory->make($tokenId);

        $file = $request->file('file');

        $temporaryFiles = $this->fileUploadLibrary->upload($token, [$file]);

        return $this->reply()->content($temporaryFiles);
    }
}
