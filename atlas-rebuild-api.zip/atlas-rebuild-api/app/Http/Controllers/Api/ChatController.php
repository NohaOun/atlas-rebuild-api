<?php

namespace App\Http\Controllers\Api;

use App\Domain\Chat\ChatLibrary;
use App\Domain\Chat\Exception\UnauthorizedActionException;
use App\Domain\Chat\Model\ChatMediaStatus;
use App\Domain\Chat\Model\ChatRoom;
use App\Domain\Chat\Model\Message;
use App\Domain\Chat\Model\RoomUser;
use App\Domain\Chat\Repository\ChatRoomRepository;
use App\Domain\District\Model\District;
use App\Domain\Student\Model\Student;
use App\Domain\User\Model\Permission;
use App\Domain\User\Model\User;
use App\Events\MessageFlagged;
use App\Events\MessageSent;
use App\Http\Controllers\Controller;
use App\Http\Resources\ChatMediaResource;
use Illuminate\Http\Request;
use \CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Support\Arr;
use Google\Cloud\Translate\V2\TranslateClient;
use Illuminate\Support\Carbon;

class ChatController extends Controller
{
    protected $chatLibrary;
    use CreatesResponses;

    public function __construct(ChatLibrary $chatLibrary)
    {
        $this->chatLibrary = $chatLibrary;
    }

    public function readMessages(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
        ]);
        $this->chatLibrary->readChatMessages(Arr::get($validated, 'data.attributes.room_id'));
        return $this->reply()->statusCode(200);
    }

    public function updateUserNickName(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
            'data.attributes.name' => 'required|string',
        ]);
        $this->chatLibrary->updateNickName(Arr::get($validated, 'data.attributes'), auth()->user()->id);
        return $this->reply()->statusCode(200);
    }

    public function translateMessage(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.message' => 'required|string',
            'data.attributes.lang' => 'required|string',
        ]);
        return $this->chatLibrary->translateMessage(Arr::get($validated, 'data.attributes'));
    }

    public function reassignGroupAdmin(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.user_id' => 'required|exists:users,id',
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $roomUser = RoomUser::query()->where('room_id', $input['room_id'])
            ->where('user_id', auth()->user()->id)->first();
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if (($roomUser->reassign_ability || $chatRoom->id === auth()->user()->id)
            && $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT']) {
            $chatRoom->update(['admin_id' => $input['user_id']]);
            return $chatRoom;
        }
        throw new UnauthorizedActionException();
    }

    public function memberViewStatus(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.user_id' => 'required',
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
            'data.attributes.user_type' => 'required|string|in:user,student',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if ($chatRoom->admin_id == auth()->user()->id && $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT']) {
            if ($input['user_type'] == RoomUser::$userTypes['USER'])
                $roomUser = RoomUser::query()
                    ->where('room_id', $input['room_id'])
                    ->where('user_type', '=', User::class)
                    ->where('user_id', $input['user_id'])->first();
            else
                $roomUser = RoomUser::query()
                    ->where('room_id', $input['room_id'])
                    ->where('user_type', '=', Student::class)
                    ->where('user_id', $input['user_id'])->first();
            $roomUser->update(['view_only' => true]);
            return $roomUser->refresh();
        }
        throw new UnauthorizedActionException();
    }

    public function memberChatAbility(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.user_id' => 'required|exists:users,id',
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if ($chatRoom->admin_id == auth()->user()->id && $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT']) {
            $roomUser = RoomUser::query()
                ->where('room_id', $input['room_id'])
                ->where('user_id', $input['user_id'])
                ->update(['view_only' => false]);
            return $roomUser->refresh();
        }
        throw new UnauthorizedActionException();
    }

    public function memberReassignAbility(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.user_id' => 'required|exists:users,id',
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if ($chatRoom->admin_id == auth()->user()->id && $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT']) {
            $roomUser = RoomUser::query()
                ->where('room_id', $input['room_id'])
                ->where('user_id', $input['user_id'])->first();
            $roomUser->update(['reassign_ability' => true]);
            return $roomUser->refresh();
        }
        throw new UnauthorizedActionException();
    }

    public function changeMessageFlag(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.message_id' => 'required|exists:messages,id',
            'data.attributes.flag' => 'required|string|in:red,yellow',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $message = Message::query()->find($input['message_id']);
        $chatRoom = ChatRoom::query()->find($message->room_id);
        if ($chatRoom->admin_id != auth()->user()->id)
            throw new UnauthorizedActionException();
        if ($message->flag != null) {
            $message->update(['flag' => $input['flag'], 'flag_created_at' => Carbon::now()]);
            event(new MessageFlagged($message, $chatRoom, auth()->user()));
            $chatRoomRepository = new ChatRoomRepository();
            $receivers = $chatRoomRepository->getReceivers(
                $message->room_id, auth()->user()->id);
            $messagesCount = Message::query()->where('room_id', $message->room_id)->count();
            foreach ($receivers as $receiver)
                broadcast(new MessageSent($message, $receiver, $messagesCount, 'new-flag'))->toOthers();
        }
        return $message->refresh();
    }

    public function addGroupMember(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
            'data.attributes.user_id' => 'required',
            'data.attributes.user_type' => 'required|string|in:user,student',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if ($chatRoom->admin_id != auth()->user()->id && $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT'])
            throw new UnauthorizedActionException();
        if ($input['user_type'] === RoomUser::$userTypes['USER']) {
            $user = User::query()->find($input['user_id']);
            $roomUser = RoomUser::query()->firstOrCreate(['room_id' => $input['room_id'],
                'user_id' => $input['user_id'], 'user_type' => User::class,
                'nick_name' => $user->first_name . " " . $user->last_name]);
        } else {
            $student = Student::query()->find($input['user_id']);
            $roomUser = RoomUser::query()->firstOrCreate(['room_id' => $input['room_id'],
                'user_id' => $input['user_id'], 'user_type' => Student::class,
                'nick_name' => $student->first_name . " " . $student->last_name]);
        }
        return $roomUser;
    }

    public function deleteGroupMember(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.id' => 'required|exists:room_users,id',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $roomUser = RoomUser::query()->find($input['id']);
        $chatRoom = ChatRoom::query()->find($roomUser->room_id);
        if ($chatRoom->admin_id == auth()->user()->id &&
            $chatRoom->room_type !== ChatRoom::$chatRoomType['CHAT']) {
            $roomUser->delete();
            return $this->reply()->statusCode(200);
        }
        throw new UnauthorizedActionException();
    }

    public function getMediaRequests($roomId)
    {
        $chatRoom = ChatRoom::query()->find($roomId);
        if ((!$chatRoom) || $chatRoom->admin_id != auth()->user()->id)
            throw new UnauthorizedActionException();
        $chatMediaStatus = ChatMediaStatus::query()->where('room_id', $chatRoom->id)
            ->where('status', ChatMediaStatus::MEDIA_STATUS['PENDING'])->get();
        return ChatMediaResource::collection($chatMediaStatus);
    }

    public function updateChatMediaRequestStatus(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.media_id' => 'required|exists:chat_media_statuses,id',
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
            'data.attributes.status' => 'required|in:accepted,rejected',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);
        if ((!$chatRoom) || $chatRoom->admin_id != auth()->user()->id)
            throw new UnauthorizedActionException();
        $chatMediaStatus = ChatMediaStatus::query()->find($input['media_id']);
        if (!$chatMediaStatus)
            throw new UnauthorizedActionException();
        $chatMediaStatus->update(['status', $input['status']]);
        return new ChatMediaResource($chatMediaStatus);
    }

    public function reassignSupportChat(Request $request)
    {
        $validated = $request->validate([
            'data.attributes.room_id' => 'required|exists:chat_rooms,id',
            'data.attributes.user_id' => 'required|exists:users,id',
        ]);
        $input = Arr::get($validated, 'data.attributes');
        $chatRoom = ChatRoom::query()->find($input['room_id']);

        if (!auth()->user()->can(Permission::PERMISSION_REASSIGN_SUPPORT_CHAT) ||
            $chatRoom->room_type !== ChatRoom::$chatRoomType['SUPPORT'])
            throw new UnauthorizedActionException();

        $user = User::query()->find($input['user_id']);
        $roomUser = RoomUser::query()->where('room_id', $input['room_id'])
            ->where('user_type', User::class)->first();
        if ($roomUser)
            $roomUser->update(['user_id' => $user->id]);
        else {
            RoomUser::query()->create([
                'user_id' => $user->id,
                'user_type' => User::class,
                'room_id' => $input['room_id']
            ]);
        }
        return $this->reply()->statusCode(200);
    }

    public function getSupportChats()
    {
        if (!auth()->user()->can(Permission::PERMISSION_REASSIGN_SUPPORT_CHAT))
            throw new UnauthorizedActionException();
        $chatRooms = ChatRoom::query()->where('room_type', ChatRoom::$chatRoomType['SUPPORT'])->get();
        return $this->reply()->content($chatRooms);
    }
}
