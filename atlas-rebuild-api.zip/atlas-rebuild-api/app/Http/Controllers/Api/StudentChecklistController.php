<?php


namespace App\Http\Controllers\Api;

use App\Domain\Checklist\StudentChecklistExportLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class StudentChecklistController extends JsonApiController
{
    use CreatesResponses;
  
    protected $studentChecklistExportLibrary;

    public function __construct(StudentChecklistExportLibrary $studentChecklistExportLibrary)
    {
        $this->studentChecklistExportLibrary = $studentChecklistExportLibrary;
    }

   
    public function exportChecklist(Request $request)
    {
        return $this->reply()->content($this->studentChecklistExportLibrary->export(Arr::get($request->all(), 'data.attributes.id')));
    }
}
