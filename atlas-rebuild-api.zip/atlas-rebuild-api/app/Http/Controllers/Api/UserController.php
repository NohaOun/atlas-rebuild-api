<?php

namespace App\Http\Controllers\Api;

use App\Domain\Auth\Exception\CurrentTenantIsNotDefinedException;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResource;
use Illuminate\Support\Facades\Auth;

class UserController extends JsonApiController
{
    public function me(FetchResource $request)
    {
        if (
            !Auth::user()->hasTenant() &&
            in_array('current_tenant', $request->getEncodingParameters()->getIncludePaths())
        ) {
            throw new CurrentTenantIsNotDefinedException();
        }

        $user = Auth::user();

        return $this->reply()->content($user);
    }
}
