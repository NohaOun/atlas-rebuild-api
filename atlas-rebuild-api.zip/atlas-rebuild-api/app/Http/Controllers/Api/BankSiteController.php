<?php

namespace App\Http\Controllers\Api;

use App\Domain\Bank\BankSiteLibrary;
use App\Http\Requests\District\SaveDefaultPlpPlanRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Request;

class BankSiteController extends JsonApiController
{
    use CreatesResponses;

    protected $BankSiteLibrary;

    public function __construct(BankSiteLibrary $BankSiteLibrary)
    {
        $this->BankSiteLibrary = $BankSiteLibrary;
    }

    public function saveDefaultPlpPlan($district, SaveDefaultPlpPlanRequest $request)
    {
        $attributes['content'] = Arr::get($request->all(), 'data.attributes.content');

        $defaultPlan = $this->planLibrary->saveDistrictDefaultPlan($district, $attributes);

        return $this->reply()->content($defaultPlan);
    }

    public function createBankSite(Request $request)
    {
            dd($request->all());
    }

    
}
