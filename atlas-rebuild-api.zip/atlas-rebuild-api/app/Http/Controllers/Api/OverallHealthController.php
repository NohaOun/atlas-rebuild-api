<?php

namespace App\Http\Controllers\Api;

use App\Domain\Student\Model\OverallHealth;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;
use App\Domain\Edmentum\OverAllHealthLibrary;
class OverallHealthController extends Controller
{
    use CreatesResponses;

    private $overAllHealthLibrary;

    public function __construct(
      OverAllHealthLibrary $overAllHealthLibrary
  	){
     	$this->overAllHealthLibrary = $overAllHealthLibrary;
	}

    public function index($student_id)
    {
        $model = $this->overAllHealthLibrary->fetchStudentData($student_id);
        return $this->reply()->created($model);
    }

}
