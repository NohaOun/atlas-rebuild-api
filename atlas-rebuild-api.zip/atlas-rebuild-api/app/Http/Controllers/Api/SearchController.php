<?php

namespace App\Http\Controllers\Api;

use App\Domain\Search\SearchLibrary;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    use CreatesResponses;

    /**
     * @var SearchLibrary
     */
    private $searchLibrary;

    public function __construct(SearchLibrary $searchLibrary)
    {
        $this->searchLibrary = $searchLibrary;
    }

    public function search(Request $request)
    {
        return $this->reply()->content(
            $this->searchLibrary->getSearchResults($request->get('filter')['q'])
        );
    }
}
