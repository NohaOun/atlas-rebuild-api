<?php

namespace App\Http\Controllers\Api;

use App\Domain\StudentAttendance\Filters\StudentAttendanceEntryFilters;
use App\Domain\StudentAttendance\StudentAttendanceLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;

class StudentAttendanceEntryController extends JsonApiController
{
    protected $studentAttendanceLibrary;

    public function __construct(StudentAttendanceLibrary $studentAttendanceLibrary)
    {
        $this->studentAttendanceLibrary = $studentAttendanceLibrary;
    }

    public function searched($records, FetchResources $request)
    {
        $filters = $request->getEncodingParameters()->getFilteringParameters();

        if(app()->has('showing-districts-ids-in-dashboard')) $filters['specific_district'] =  app('showing-districts-ids-in-dashboard');

        if (isset($filters['from']) && isset($filters['to'])) {
            $filters = new StudentAttendanceEntryFilters($filters);
            $meta = $this->studentAttendanceLibrary->getAttendanceMeta($records, $filters);

            return $this->reply()->content($records, [], $meta);
        }

        return $records;
    }
}
