<?php


namespace App\Http\Controllers\Api;


use App\Domain\Plp\PlanLibrary;
use App\Domain\Plp\StudentPlpExportLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class StudentPlpPlanController extends JsonApiController
{
    use CreatesResponses;

    protected $planLibrary;

    protected $studentPlpExportLibrary;

    public function __construct(PlanLibrary $planLibrary, StudentPlpExportLibrary $studentPlpExportLibrary)
    {
        $this->planLibrary = $planLibrary;
        $this->studentPlpExportLibrary = $studentPlpExportLibrary;
    }

    public function activeStudentPlan($studentPlpPlan)
    {
        return $this->reply()->content($this->planLibrary->activeStudentPlans($studentPlpPlan));
    }

    public function setTierStudentPlans($studentPlpPlan, Request $request)
    {
        return $this->reply()->content($this->planLibrary->setTierStudentPlans($studentPlpPlan, Arr::get($request->all(), 'data.attributes.override_tier_level')));
    }

    public function exportPlpPlan(Request $request)
    {
        return $this->reply()->content($this->studentPlpExportLibrary->export(Arr::get($request->all(), 'data.attributes.id')));
    }
}
