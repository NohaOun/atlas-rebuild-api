<?php

namespace App\Http\Controllers\Api;

use App\Domain\Business\BusinessImportLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class ImportedBusinessController extends JsonApiController
{
    use CreatesResponses;

    protected $businessImportLibrary;

    public function __construct(BusinessImportLibrary $businessImportLibrary)
    {
        $this->businessImportLibrary = $businessImportLibrary;
    }

    public function import(Request $request)
    {
        return $this->businessImportLibrary->acceptImport(Arr::get($request->all(), 'data.attributes.file'));
    }
}
