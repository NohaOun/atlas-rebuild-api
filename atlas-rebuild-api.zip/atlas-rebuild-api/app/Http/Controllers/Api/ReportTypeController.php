<?php

namespace App\Http\Controllers\Api;

use App\Domain\Report\ReportLibrary;
use App\Http\Controllers\Controller;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;

class ReportTypeController extends Controller
{
    use CreatesResponses;

    protected $reportLibrary;

    public function __construct(ReportLibrary $reportLibrary)
    {
        $this->reportLibrary = $reportLibrary;
    }

    public function index()
    {
        return $this->reply()->content(
            $this->reportLibrary->getReportTypes()
        );
    }
}
