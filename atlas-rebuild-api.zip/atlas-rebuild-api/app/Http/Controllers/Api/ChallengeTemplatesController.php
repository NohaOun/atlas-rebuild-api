<?php

namespace App\Http\Controllers\Api;

use App\Domain\Challenge\ChallengeLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;
use Illuminate\Http\Request;

class ChallengeTemplatesController extends JsonApiController
{  

    /**
     * @var LogLibrary
     */
    private $challengeLibrary;

    public function __construct(ChallengeLibrary $challengeLibrary)
    {
        $this->challengeLibrary = $challengeLibrary;
    }


    public function addToTenant($record)
    {	
        return $this->reply()->content(
            $this->challengeLibrary->addToTenant($record)
        );
    }                
}
