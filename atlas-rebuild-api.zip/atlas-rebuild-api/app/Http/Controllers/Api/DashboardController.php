<?php

namespace App\Http\Controllers\Api;

use App\Domain\DashBoard\DashboardLibrary;
use App\Domain\DashBoard\Model\TrackStatusChange;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepository;
use App\Domain\Phase\Repository\PhaseRepositoryInterface;
use App\Domain\Report\ReportGeneratorFactory;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    use CreatesResponses;

    protected $reportGeneratorFactory;
    private $dashboardLibrary;
    private $phaseRepo ;

    public function __construct(
        ReportGeneratorFactory $reportGeneratorFactory,
        DashboardLibrary $dashboardLibrary,
        PhaseRepositoryInterface $phaseRepo


    )
    {
        $this->reportGeneratorFactory = $reportGeneratorFactory;
        $this->dashboardLibrary = $dashboardLibrary;
        $this->phaseRepo = $phaseRepo;

    }

    public function index(FetchResources $request)
    {
        $filters = $request->getEncodingParameters()->getFilteringParameters();
        $district = (isset($filters['district'])) ? $filters['district'] : null;
        $model = $this->dashboardLibrary->getWidgetsData($district);
        $filters['scheduled_from'] = now()->startOfWeek(Carbon::SUNDAY)->startOfDay()->format('Y-m-d');
        $filters['scheduled_to'] = now()->endOfWeek(Carbon::SATURDAY)->endOfDay()->format('Y-m-d');
        $model->contacts_scheduled_to_register_this_week = $this->dashboardLibrary->getScheduledContactThisWeek($filters);


        return $this->reply()->created($model);
    }

    public function getCaseManagementTableData(FetchResources $request)
    {
        $filters = $request->getEncodingParameters()->getFilteringParameters();
        $page = $request->getEncodingParameters()->getPaginationParameters();

        $result = $this->dashboardLibrary->getCaseManagementTable($filters, $page);
        $meta = [];
        if (isset($result)) {
            $to = $result->currentPage() * $result->perPage();
            $from = $to - $result->perPage() + 1;
            $meta = [
                'page' => [
                    "current-page" => $result->currentPage(),
                    "per-page" => $result->perPage(),
                    "from" => $from,
                    "to" => $to,
                    "total" => $result->total(),
                    "last-page" => $result->lastPage()

                ]
            ];
        }

        return $this->reply()->content($result, [], $meta);
    }

    public function getDashboardPhasesStatues(FetchResources $request)
    {
        $filters = $request->getEncodingParameters()->getFilteringParameters();
        $PhaseData = $this->dashboardLibrary->getPhasesStatuses($filters);

        return $this->reply()->meta([
            'phase_data' => $PhaseData,
            "contact_count_stay_in_status_per_day" => $this->dashboardLibrary->getContactCountExited()
        ], 200);
    }

    public function trackStatusChanges()
    {
        $phaseStatus = [
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_REGISTRATION . ' ' . StatusRepositoryInterface::STATUS_KEY_INITIATED_FOLLOW_UP,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DENIED_BY_AA,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DECLINED_PROGRAM,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DENIED_BY_DISTRICT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_AGED_OUT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DECEASED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_ALREADY_GRADUATED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_FUTURE_RECRUITMENT_EFFORT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_INTERESTED_NOT_READY_TO_COMMIT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_CANNOT_CONTACT_NO_RESPONSE,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DO_NOT_CONTACT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_CANNOT_CONTACT_BAD_CONTACT_INFORMATION,
            PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_UNDERAGE,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_REGISTRATION . ' ' . StatusRepositoryInterface::STATUS_KEY_INITIATED_FOLLOW_UP,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DENIED_BY_AA,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DECLINED_PROGRAM,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DENIED_BY_DISTRICT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_AGED_OUT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DECEASED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_ALREADY_GRADUATED,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_FUTURE_RECRUITMENT_EFFORT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_INTERESTED_NOT_READY_TO_COMMIT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_CANNOT_CONTACT_NO_RESPONSE,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_DO_NOT_CONTACT,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_CANNOT_CONTACT_BAD_CONTACT_INFORMATION,
            PhaseKeyRepositoryInterface::PHASE_NAME_RE_ENGAGEMENT . ' ' . StatusRepositoryInterface::STATUS_KEY_NEW . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_CLOSE_LOST . ' ' . StatusRepositoryInterface::STATUS_KEY_UNDERAGE,
            PhaseKeyRepositoryInterface::PHASE_NAME_REGISTRATION . ' ' . StatusRepositoryInterface::STATUS_KEY_INITIATED_FOLLOW_UP . '->' . PhaseKeyRepositoryInterface::PHASE_NAME_ENROLLED_ORIENTATION . ' ' . StatusRepositoryInterface::STATUS_KEY_ACTIVE,

        ];


        $result = $this->dashboardLibrary->trackStatusChanges();
        $data = [];
        foreach ($phaseStatus as $key => $value) {
            $avg = 0;

            foreach ($result as $item) {

                if ($value == $item->prev_phase . ' ' . $item->prev_status . '->' . $item->new_phase . ' ' . $item->new_status) {
                    $avg = round($item->days / $item->member_count, 2);
                }

            }
            $data[] = $value . ' : ' . $avg;
        }

        return $this->reply()->created(new TrackStatusChange($data));

    }
}
