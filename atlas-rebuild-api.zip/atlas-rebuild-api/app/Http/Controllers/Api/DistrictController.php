<?php

namespace App\Http\Controllers\Api;

use App\Domain\Plp\PlanLibrary;
use App\Http\Requests\District\SaveDefaultPlpPlanRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use Illuminate\Support\Arr;

class DistrictController extends JsonApiController
{
    use CreatesResponses;

    protected $planLibrary;

    public function __construct(PlanLibrary $planLibrary)
    {
        $this->planLibrary = $planLibrary;
    }

    public function saveDefaultPlpPlan($district, SaveDefaultPlpPlanRequest $request)
    {
        $attributes['content'] = Arr::get($request->all(), 'data.attributes.content');

        $defaultPlan = $this->planLibrary->saveDistrictDefaultPlan($district, $attributes);

        return $this->reply()->content($defaultPlan);
    }
}
