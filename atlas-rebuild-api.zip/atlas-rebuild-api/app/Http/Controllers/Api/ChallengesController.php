<?php

namespace App\Http\Controllers\Api;

use App\Domain\Challenge\ChallengeLibrary;
use CloudCreativity\LaravelJsonApi\Http\Controllers\JsonApiController;
use CloudCreativity\LaravelJsonApi\Http\Requests\FetchResources;
use Illuminate\Http\Request;

class ChallengesController extends JsonApiController
{  

    /**
     * @var LogLibrary
     */
    private $challengeLibrary;

    public function __construct(ChallengeLibrary $challengeLibrary)
    {
        $this->challengeLibrary = $challengeLibrary;
    }


    public function addToTenant(Request $request)
    {	
    	$id = $request->id;
        return $this->reply()->content(
            $this->challengeLibrary->addToTenant($id)
        );
    }    
    public function activateChallenge($id){
    	return $this->reply()->content(
    		$this->challengeLibrary->activateChallenge($id)
    	);    	
    }   

    public function deActivateChallenge($id){
    	return $this->reply()->content(
    		$this->challengeLibrary->deActivateChallenge($id)
    	); 
    }             
}
