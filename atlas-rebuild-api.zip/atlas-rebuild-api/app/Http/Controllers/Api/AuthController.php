<?php

namespace App\Http\Controllers\Api;

use App\Domain\Auth\AuthLibrary;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\ChangePasswordRequest;
use App\Http\Requests\Auth\ForgotPasswordRequest;
use App\Http\Requests\Auth\ImpersonateRequest;
use App\Http\Requests\Auth\LoginRequest;
use App\Http\Requests\Auth\StudentLoginRequest;
use App\Http\Requests\Auth\SuperUserLoginRequest;
use CloudCreativity\LaravelJsonApi\Http\Controllers\CreatesResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    use CreatesResponses;

    /**
     * @var AuthLibrary
     */
    private $authLibrary;

    public function __construct(AuthLibrary $authLibrary)
    {
        $this->authLibrary = $authLibrary;
    }

    public function login(LoginRequest $request)
    {
        $input = $this->getLoginInput($request);

        return $this->reply()->created(
            $this->authLibrary->login($input['email'], $input['password'])
        );
    }

    public function superUserLogin(SuperUserLoginRequest $request)
    {
        $input = $this->getLoginInput($request);

        return $this->reply()->created(
            $this->authLibrary->loginSuperUser($input['email'], $input['password'])
        );
    }

    public function loginStudent(StudentLoginRequest $request)
    {
        $input = $this->getLoginInput($request);
        return $this->reply()->created(
            $this->authLibrary->loginStudent($input['email'], $input['password'])
        );
    }

    public function parentLogin(LoginRequest $request)
    {
        $input = $this->getLoginInput($request);
        return $this->reply()->created(
            $this->authLibrary->loginParent($input['email'], $input['password'])
        );
    }

    public function impersonate(ImpersonateRequest $request)
    {
        $user = $request->user('api_super_users');

        return $this->reply()->created(
            $this->authLibrary->impersonate(Arr::get($request->get('data'), 'attributes.user_id'), $user)
        );
    }

    protected function getLoginInput(Request $request)
    {
        return $request->get('data')['attributes'];
    }

    public function forgetPassword(Request $request)
    {
        return $this->reply()->content(
            $this->authLibrary->forgetPassword($this->getLoginInput($request))
        );
    }

    public function resetPassword(Request $request)
    {
        return $this->reply()->content($this->authLibrary->resetPassword($this->getLoginInput($request)));
    }

    public function changePassword(Request $request)
    {
        $input = $this->getLoginInput($request);
        $input['password'] = Hash::make($input['password']);
        return $this->reply()->content($this->authLibrary->changePassword($input));
    }

    public function superUserChangePassword(ChangePasswordRequest $request)
    {
        return $this->reply()->content($this->authLibrary->changePassword($this->getLoginInput($request)));
    }

    public function parentChangePassword(ChangePasswordRequest $request)
    {
        return $this->reply()->content($this->authLibrary->changePassword($this->getLoginInput($request)));
    }

    public function parentForgotPassword(ForgotPasswordRequest $request)
    {
        return $this->reply()->content($this->authLibrary->parentForgotPassword($this->getLoginInput($request)));
    }

    public function parentLogout(Request $request)
    {
        $this->guard()->logout();
    }
}
