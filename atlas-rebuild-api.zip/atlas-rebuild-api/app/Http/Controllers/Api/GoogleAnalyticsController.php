<?php


namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Spatie\Analytics\AnalyticsFacade as Analytics;
use Spatie\Analytics\Period;

class GoogleAnalyticsController extends Controller
{
    public function fetchMostVisitedPages(int $period = 30, int $maxResults = 10)
    {
        return Analytics::fetchMostVisitedPages(Period::days($period), $maxResults);
    }

    public function fetchTotalVisitorsAndPageViews(int $period = 30)
    {
        return Analytics::fetchTotalVisitorsAndPageViews(Period::days($period));
    }
}
