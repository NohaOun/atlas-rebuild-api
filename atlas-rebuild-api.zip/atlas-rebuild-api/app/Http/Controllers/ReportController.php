<?php

namespace App\Http\Controllers;

use App\Domain\Report\ReportLibrary;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class ReportController extends Controller
{
    private $reportLibrary;

    public function __construct(ReportLibrary $reportLibrary)
    {
        $this->reportLibrary = $reportLibrary;
    }

    public function download($reportId)
    {
        $report = $this->reportLibrary->getReport($reportId);

        if (!$report) {
            throw new NotFoundHttpException();
        }

        return Storage::disk('reports')->download($report->filename);
    }
}
