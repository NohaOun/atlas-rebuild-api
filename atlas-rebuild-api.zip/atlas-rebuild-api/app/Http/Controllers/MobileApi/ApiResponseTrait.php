<?php
namespace App\Http\Controllers\MobileApi;

trait ApiResponseTrait {

    public function apiResponse($data = [], $errors = [], $code=200, $flag=false)
    {
        $arr['status'] = empty($errors)? true : false;
        if(empty($errors)){
            $errors = (object) null;
        }
        $arr['errors'] = $errors;

        $arr['data'] = empty($data)? (($flag)? (object) null : $data) : $data;
        $arr['serverTime'] = [
            'timestamp' => time(),
            'formatted' => date('Y-m-d H:i:s', time()),
            'format' => 'yyyy-mm-dd hh:ii:ss',
            'timezone' => config('app.timezone')
        ];
        return response($arr, $code);
    }

    protected function formError($errors)
    {
        if (empty($errors)) return null;

        return ['failed' => $errors];
    }

    protected function isAssoc(array $arr)
    {
        if (array() === $arr) return false;
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}
