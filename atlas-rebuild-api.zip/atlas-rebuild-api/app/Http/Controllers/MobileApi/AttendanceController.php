<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\StudentAttendance\StudentAttendanceLibrary;
use App\Http\Resources\AttendanceResource;

class AttendanceController extends BaseController
{
    /**
     * @var StudentAttendanceLibrary
     */
    private $studentAttendanceLibrary;

    public function __construct(StudentAttendanceLibrary $studentAttendanceLibrary)
    {
        $this->studentAttendanceLibrary = $studentAttendanceLibrary;
    }

    public function index()
    {
        $attendance = $this->studentAttendanceLibrary->getAttendanceForMobileApi();

        return AttendanceResource::collection($attendance);
    }
}
