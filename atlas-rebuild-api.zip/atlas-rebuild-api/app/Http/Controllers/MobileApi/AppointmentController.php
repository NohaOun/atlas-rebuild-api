<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\AcademyClosure\Filters\AcademyClosureFilters;
use App\Domain\AcademyClosure\Repository\AcademyClosureRepository;
use App\Domain\Schedule\AppointmentCategoryLibrary;
use App\Domain\Schedule\Filters\AppointmentCategoryFilters;
use App\Domain\Schedule\Filters\StaffScheduleEntryFilters;
use App\Domain\Schedule\Filters\StudentScheduleEntryFilters;
use App\Domain\Schedule\Model\AppointmentCategory;
use App\Domain\Schedule\Model\StudentScheduleEntry;
use App\Domain\Schedule\Repository\StaffScheduleEntryRepository;
use App\Domain\Schedule\Repository\StudentScheduleEntryRepository;
use App\Domain\Schedule\StudentScheduleEntryLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Repository\UserRepository;
use App\Http\Resources\AppointmentCategoryResource;
use App\Http\Resources\ScheduleAssetsResource;
use App\Http\Resources\ScheduleInitResource;
use App\Http\Resources\ScheduleReasonResource;
use App\Http\Resources\ScheduleResource;
use App\Http\Resources\ScheduleTimesResource;
use App\Http\Resources\StaffResource;
use App\Http\Resources\StatusMessageResource;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Http\Resources\StudentScheduleResource;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;


class AppointmentController extends Controller
{
    //
    private $studentScheduleEntryLibrary;
    private $appointmentCategoryLibrary;
    private $academyClosureRepository;
    private $staffScheduleEntryRepository;
    private $userRepository;
    private $studentScheduleEntryRepository;

    public function __construct(StudentScheduleEntryLibrary $studentScheduleEntryLibrary,
        AppointmentCategoryLibrary $appointmentCategoryLibrary,
        AcademyClosureRepository $academyClosureRepository,
        StaffScheduleEntryRepository $staffScheduleEntryRepository,
        UserRepository $userRepository,
        StudentScheduleEntryRepository $studentScheduleEntryRepository
        )
    {
        $this->studentScheduleEntryLibrary = $studentScheduleEntryLibrary;
        $this->appointmentCategoryLibrary = $appointmentCategoryLibrary;
        $this->academyClosureRepository = $academyClosureRepository;
        $this->staffScheduleEntryRepository = $staffScheduleEntryRepository;
        $this->userRepository = $userRepository;
        $this->studentScheduleEntryRepository = $studentScheduleEntryRepository;
    }

    public function init()
    {
        return new ScheduleInitResource([
            'types' => [
                [
                    'id' => StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE,
                    'name' => 'On Site'
                ],
                [
                    'id' => StudentScheduleEntry::APPOINTMENT_TYPE_VIRTUAL,
                    'name' => 'Virtual'
                ]
            ],
            'reasons' => ScheduleReasonResource::collection(StudentScheduleEntry::getAvailableLookingFor())
        ]);
    }

    public function getStudentOf(Request $request){
        if(\Auth::guard('api_parents')->check()){
            $student_id = $request->headers->get('student-id');
            $parent = auth()->user();
            $student = $parent->students()->where('student_id', $student_id)->firstOrFail();
           
        }else{
            $student = auth()->user();
        }
        return $student;
    }

    public function schedule(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $newScheduleFlow = $student->site->district->use_new_schedule;
        return new ScheduleResource($newScheduleFlow? $this->getSchedules($student) : $this->getSchedulesOldWay());
    }

    protected function getSchedules(Student $student)
    {
        // Check If Parent Is logged in 
        // $student = $this->getStudentOf($request);
        $useNewFlow = (bool) $student->site->district->use_new_schedule;

        $site = $student->site;

        $startDate = Carbon::now()->format('m/d/Y');
        $endDate = Carbon::now()->addDays(7)->format('m/d/Y');

        $studentScheduleEnteries = $this->studentScheduleEntryLibrary->getStudentScheduleEntries(
            new StudentScheduleEntryFilters(
                [
                    'student' => $student->id,
                    'from-date' =>$startDate,
                    'to-date' => $endDate
                ])
            );

        $onSiteAppointmentsPerWeek = $studentScheduleEnteries->filter(function($item, $key){
                return $item->appointment_type == StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE;
            })->count();


        $schedules = [
            'remainingOnSiteAppointments' => (int) $site->gc_limit_onsite_appointments_per_week - $onSiteAppointmentsPerWeek,
            'useNewFlow' => $useNewFlow,
            'days' => []
        ];

        foreach($studentScheduleEnteries AS $scheduleRow) {
            $schedule['id'] = $scheduleRow->id;
            $schedule['name'] = Carbon::createFromFormat('Y-m-d', $scheduleRow->date)->format('D n/j');
            $schedule['from'] = Carbon::createFromFormat('H:i:s', $scheduleRow->from_time)->format('h:iA');
            $schedule['to'] = Carbon::createFromFormat('H:i:s', $scheduleRow->to_time)->format('h:iA');
            $schedule['location'] = Str::title($scheduleRow->appointment_type);
            $schedules['days'][]= $schedule;
        }

        return $schedules;
    }

    // Did not finished
    protected function getSchedulesOldWay()
    {
        $scheduleSetting = ScheduleSetting::query()->where('school_id', auth()->user()->school_id)->first();

        if (!$scheduleSetting) {
            $scheduleSetting = ScheduleSetting::query()->where('school_id', null)->first();
        }

        $studentSchedule = Schedule::query()
            ->where('student_id', auth()->id())
            ->where('week_start', '<=', now())
            ->orderBy('week_start', 'DESC')
            ->first();

        $weekStart = now()->startOfWeek();
        $addedDays = $scheduleSetting->schedule_day - 1;
        $deadline = $weekStart->addDays($addedDays)->endOfDay();
        if (!$deadline->isFuture()) {
            $deadline = $weekStart->addWeek()->addDays($addedDays);
        }
        $hours = now()->hoursUntil($deadline);
        $remainingDays = floor($hours->count() / 24);
        $remainingHours = $hours->count() % 24;

        $schedules = [
            'minimumHoursPerWeek' => $scheduleSetting->minimum_hours,
            'remainingDays' => $remainingDays,
            'remainingHours' => $remainingHours,
            'useNewFlow' => (bool) auth()->user()->school->district->use_new_schedule,
            'days' => []
        ];

        foreach (ScheduleSetting::DAYS as $i => $day) {
            $in = strtolower($day) . '_in';
            $out = strtolower($day) . '_out';
            if (!strtotime($scheduleSetting->getAttribute($in)) || !strtotime($scheduleSetting->getAttribute($out))) {
                continue;
            }
            $schedule = [
                'id' => $i + 1,
                'name' => $day,
                'minAvailableTime' => Carbon::createFromFormat('H:i:s', $scheduleSetting->getAttribute($in))->format('H:i'),
                'maxAvailableTime' => Carbon::createFromFormat('H:i:s', $scheduleSetting->getAttribute($out))->format('H:i'),
            ];

            if (
                $studentSchedule &&
                ($from = $studentSchedule->getAttribute($in)) &&
                ($to = $studentSchedule->getAttribute($out))
            ) {
                $schedule['isSelected'] = true;
                $schedule['from'] = Carbon::createFromFormat('H:i:s', $from)->format('H:i');
                $schedule['to'] = Carbon::createFromFormat('H:i:s', $to)->format('H:i');
                $schedule['isTransportation'] = (bool)$studentSchedule->getAttribute(strtolower($day) . '_transportation');
            } else {
                $schedule['isSelected'] = false;
            }

            $schedules['days'][] = $schedule;
        }

        return $schedules;
    }


    public function times(Request $request)
    {
        $validator = Validator::make(request()->all(), [
            'reason' => 'required',
            'type' => 'required|in:"'.StudentScheduleEntry::APPOINTMENT_TYPE_VIRTUAL.'", "'.StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE.'"',
            'staff' => 'required_if:reason,'.StudentScheduleEntry::LOOKING_FOR_MEET_WITH,
            'date' => ['bail', 'required_if:reason,'.StudentScheduleEntry::LOOKING_FOR_COME_IN_ON, 'date_format:"m/d/Y"', function($attribute, $value, $fail){
                if($value){
                    $obj = Carbon::createFromFormat('m/d/Y', $value)->startOfDay();
                    if(Carbon::tomorrow()->isAfter($obj) || Carbon::tomorrow()->addDays(6)->isBefore($obj)){
                        $fail('Invalid date');
                    }
                }
            }],
            'categories' => ['required', 'array', 'min:1', 'max:3', function($attribute, $value, $fail){
                if(!empty($value) && is_array($value)){
                    $cats = $this->appointmentCategoryLibrary->
                                getAppointmentCategoriesBuilder(new AppointmentCategoryFilters(['ids' => $value]))
                                    ->where(function($q){
                                        $q->where(function($qr){
                                            $qr->where('duration->type', AppointmentCategory::DURATION_TYPE_SET_TIME);
                                            $qr->whereBetween('duration->payload->date', [Carbon::tomorrow()->format('Y-m-d'), Carbon::now()->addDays(6)->format('Y-m-d')]);
                                        });

                                        $q->orWhere('duration->type', AppointmentCategory::DURATION_TYPE_RECURRING);
                                        $q->orWhere('duration->type', AppointmentCategory::DURATION_TYPE_IN_MINUTES);
                                    })
                                ->get();
                    // $cats = AppointmentCategory::whereIn('id', $value)
                    //     ->where(function($q){
                    //         $q->where(function($qr){
                    //             $qr->where('duration', AppointmentCategory::SET_TIME_DURATION);
                    //             $qr->whereBetween('date', [Carbon::tomorrow()->format('Y-m-d'), Carbon::now()->addDays(6)->format('Y-m-d')]);
                    //         });

                    //         $q->orWhere('duration', AppointmentCategory::RECURRING_DURATION);
                    //         $q->orWhere('duration', AppointmentCategory::IN_MINUTES_DURATION);
                    //     })
                    //     ->get();

                    //make sure the user selected categories in the current week
                    if(!$cats->count()){
                        $fail('invalid selected categories');
                    }

                }
            }]
        ], [
            'date.date_format' => 'The date ('.request('date').') doesn\'t match the format: MM/DD/YYYY'
        ]);

        if($validator->fails()){
            return (new StatusMessageResource($validator->errors()->first()))->response()->setStatusCode(400);
        }
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $site = $student->site;

        // $categories = AppointmentCategory::whereIn('id', request('categories'))->get();
        $categories = $this->appointmentCategoryLibrary->getAppointmentCategories(new AppointmentCategoryFilters(['ids' => request('categories')]));
        //sum categories of type in minutes duration minutes
        $minutes = $categories->filter(function($item, $key){
                return $item->duration == AppointmentCategory::DURATION_TYPE_IN_MINUTES;
            })
            ->sum('duration->payload->minutes');

        //get current week starting from today
        $start = Carbon::tomorrow();
        $end   = $start->copy()->addDays(6);

        //here we get all closures related to the data
        $closures = $this->weekClosures($site, $start, $end);

        //here we get all staff schedule related to the data
        $schedule = $this->weekSchedule($site, $start, $end);

        $data = new Collection();

        $filteredCats = $categories->filter(function($item, $key){
            return in_array($item->duration["type"], [AppointmentCategory::DURATION_TYPE_SET_TIME, AppointmentCategory::DURATION_TYPE_RECURRING]);
        });

        $activeDate = request('date', $this->get_date_of_categories($filteredCats));

        foreach($start->toPeriod($end, '1 day') as $day){
            $row = [
                'date' => $day->copy()->format('m/d/Y'),
                'month' => $day->copy()->format('M'),
                'day' => $day->copy()->format('l'),
                'numericDay' => $day->copy()->format('d'),
                'closed' => false, // this is the default value
                'active' => $day->copy()->format('m/d/Y') == $activeDate ? true : false,
                'times' => [] // this is the default value
            ];

            $isClosed = $this->isClosedAllDay($closures, $day);

            if($isClosed->count()){
                $row['closed'] = true;
                $data->add($row);
                continue;
            }

            $hasSchedule = $schedule->firstWhere('date', $day->copy()->format('Y-m-d'));

            if(!$hasSchedule){
                $data->add($row);
                continue;
            }

            //get selected categories min & max times
            $cats = $categories->filter(function($item, $key) use ($day){
                return (
                    ($item->duration == AppointmentCategory::DURATION_TYPE_SET_TIME && $item->date == $day->copy()->format('Y-m-d'))
                    || ($item->duration == AppointmentCategory::DURATION_TYPE_RECURRING && $item->day = Str::lower($day->copy()->format('l')))
                );
            });

            $min = $cats->min('start_time');
            $max = $cats->max('end_time');

            if($min && $max){
                $totalMinutes = $minutes + (Carbon::createFromFormat('Y-m-d H:i:s', $day->copy()->format('Y-m-d').' '.$min)->diffInMinutes(Carbon::createFromFormat('Y-m-d H:i:s', $day->copy()->format('Y-m-d').' '.$max)));
            }else{
                $totalMinutes = $minutes;
            }

            if(!$min){
                $min = $hasSchedule->from_time;
            }

            if(!$max){
                $max = $hasSchedule->to_time;
            }

            $startTime = Carbon::createFromFormat('Y-m-d H:i:s', $day->copy()->format('Y-m-d').' '.$min);
            $endTime = Carbon::createFromFormat('Y-m-d H:i:s', $day->copy()->format('Y-m-d').' '. $max);
            $times = [];
            foreach ($startTime->toPeriod($endTime, '15 minutes') AS $time){
                $from = $time->copy();
                $to = $time->copy()->addMinutes($totalMinutes);

                if($to->isAfter($endTime)){
                    break;
                }

                $isClosed = $this->isClosed($closures, $from, $to);

                if($isClosed->count()){
                    continue;
                }

                $times[] = [
                    'time' => $from->copy()->format('h:i'),
                    'meridian' => $from->copy()->format('A')
                ];
            }

            $row['times'] = $times;
            $data->add($row);
        }

        $activeRecord = $this->activeDay($data);

        $data = $data->map(function($item, $key){
            unset($item['active']);

            return $item;
        });

        if($activeRecord){
            unset($activeRecord['active']);
        }
        return new ScheduleTimesResource(['activeDay' => (object) $activeRecord, 'week' => $data]);
    }

    private function weekClosures($site, $start, $end)
    {
        $this->academyClosureRepository->getFilteredBuilder(new AcademyClosureFilters())
        ->whereHas('sites.district', function ($q) use($site){
            $q->where(function($q) use ($site) {
                $q->whereNull('district_id');
                $q->orWhere('district_id', 0);
                $q->orWhere('district_id', $site->district_id);
            });
        })
        ->whereHas('sites', function($q) use($site){
            $q->whereNull('site_id');
            $q->orWhere('site_id', 0);
            $q->orWhere('site_id', $site->id);
        })
        ->where(function($q){
            if(request('type') == StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE){
                $q->where('available_on_site', 1);
            }

            if(request('type') == StudentScheduleEntry::APPOINTMENT_TYPE_VIRTUAL){
                $q->where('available_virtually', 1);
            }
        })
        ->where(function($q) use ($start, $end){
            $q->where(function($qry) use ($start, $end){
                $qry->whereNull('end_date');
                $qry->whereBetween('start_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
            });

            $q->orWhere(function($qry) use ($start, $end){
                $qry->whereNotNull('end_date');
                $qry->where(function($qr) use ($start, $end){
                    $qr->whereBetween('start_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
                    $qr->orWhereBetween('end_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
                    $qr->orWhere(function($query) use ($start, $end){
                        $query->where('start_date', '<=', $start->copy()->format('Y-m-d'));
                        $query->where('end_date', '>=', $end->copy()->format('Y-m-d'));
                    });
                });
            });
        })
        ->get();
    }

    private function weekSchedule($site, $start, $end)
    {
        $StaffScheduleEntryFilters = new  StaffScheduleEntryFilters(
            ['appointment-categories' => request('categories'),
            'appointment-category-type' => request('type'),
            'from-date' => $start->copy()->format('m/d/Y'),
            'to-date' => $end->copy()->format('m/d/Y')
        ]);
        
        if(request('staff')){
            $StaffScheduleEntryFilters->add('staff', request('staff'));
        }

        return $this->staffScheduleEntryRepository->getStaffScheduleEntries($StaffScheduleEntryFilters);
    }


    private function get_date_of_categories($categories)
    {
        if($categories->count()){
            $record = $categories->filter(function($item, $key){ return $item->duration["type"] == AppointmentCategory::DURATION_TYPE_SET_TIME; });
            if(!$record->count()){
                $record = $categories->filter(function($item, $key){ return $item->duration["type"] == AppointmentCategory::DURATION_TYPE_RECURRING; });
                $day = $record->first()->day;
                $today = Str::lower(Carbon::now()->format('l'));
                if($day !== $today){
                    $date = Carbon::now()->next($day)->format('m/d/Y');
                }else{
                    $date = Carbon::now()->format('m/d/Y');
                }
            }else{
                $date = Carbon::createFromFormat('Y-m-d', $record->first()->date)->format('m/d/Y');
            }

            return $date;
        }

        return null;
    }

    private function isClosedAllDay($closures, $day)
    {
        if($closures)
            return $closures->filter(function($item, $key) use ($day){
                if($item->start_date == $day->copy()->format('Y-m-d') && $item->all_day){
                    return true;
                }

                if($item->all_day && !is_null($item->end_date)){
                    if($item->end_date == $day->copy()->format('Y-m-d')){
                        return true;
                    }

                    $start = Carbon::createFromFormat('Y-m-d', $item->blackout_date);
                    $end = Carbon::createFromFormat('Y-m-d', $item->end_date);

                    if($start->isBefore($day) && $end->isAfter($day)){
                        return true;
                    }
                }

                return false;
            });
        return new Collection();
    }

    private function activeDay($data)
    {
        $record = $data->filter(function($item, $key){
                return $item['active'];
            })
            ->first();

        if($record){
            return $record;
        }

        $record = $data->filter(function($item, $key){
                return !empty($item['times']);
            })
            ->first();

        if($record){
            return $record;
        }

        return $data->first();
    }

    public function saveGcSchedule()
    {
        $validator = Validator::make(request()->all(), [
            'staff' => 'required_if:reason,'.StudentScheduleEntry::LOOKING_FOR_MEET_WITH,
            'date' => 'required|date_format:"m/d/Y"',
            'time' => 'required|date_format:"h:iA"',
            'categories' => ['required', 'array', 'min:1', 'max:3'],
            'reason' => 'required',
            'type' => 'required|in:"'.StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE.'","'.StudentScheduleEntry::APPOINTMENT_TYPE_VIRTUAL.'"'
        ]);

        if($validator->fails()){
            return (new StatusMessageResource($validator->errors()->first()))->response()->setStatusCode(400);
        }

        $staff = request('staff', $this->getStaff());

        if(!$staff){
            return (new StatusMessageResource(__('No staff available')))->response()->setStatusCode(409);
        }

        $dateObj = Carbon::createFromFormat('m/d/Y', request('date'));
        
        $categories = $this->appointmentCategoryLibrary->
            getAppointmentCategoriesBuilder(new AppointmentCategoryFilters(
                ['ids' => request('categories'), 'active' => 1]
                ))
                ->where(function($q) use ($dateObj){
                    $q->where(function($qr) use ($dateObj){
                        $qr->where('duration->type', AppointmentCategory::DURATION_TYPE_SET_TIME);
                        $qr->where('duration->payload->date', $dateObj->copy()->format('Y-m-d'));
                    });
                    $q->orWhere(function($qry) use ($dateObj){
                        $qry->where('duration->type', AppointmentCategory::DURATION_TYPE_RECURRING);
                        $qry->where('duration->payload->day', Str::lower($dateObj->copy()->format('l')));
                    });

                    $q->orWhere('duration->type', AppointmentCategory::DURATION_TYPE_IN_MINUTES);
                })
                ->whereHas('staffScheduleEntries', function($q) use ($staff){
                    $q->whereHas('staffSchedule', function($q) use($staff){
                        $q->where('staff_id', $staff);
                        $q->where('staff_schedules.site_id', auth()->user()->site->id);
                    });
                    $time = Carbon::createFromFormat('h:iA', request('time'));
                    $q->where('from', '<=', $time->copy()->format('H:i:s'));
                    $q->where('to', '>=', $time->copy()->format('H:i:s'));
                })->get();

        if(!$categories->count()){
            return (new StatusMessageResource(__('Invalid categories selected')))->response()->setStatusCode(409);
        }

        $minutes = $categories->where('duration->type', AppointmentCategory::DURATION_TYPE_IN_MINUTES)->sum('duration->payload->minutes');

        $notInMinutes = $categories->filter(function($item, $key){
            return (
                $item->duration["type"] == AppointmentCategory::DURATION_TYPE_SET_TIME || $item->duration["type"] == AppointmentCategory::DURATION_TYPE_RECURRING
            );
        });

        $min = $notInMinutes->min('start_time');
        $max = $notInMinutes->max('end_time');

        if($min && $max){
            $minutes = $minutes + (Carbon::createFromFormat('Y-m-d H:i:s', $dateObj->format('Y-m-d').' '.$min)->diffInMinutes(Carbon::createFromFormat('Y-m-d H:i:s', $dateObj->format('Y-m-d').' '.$max)));
        }

        $timeObj = Carbon::createFromFormat( 'Y-m-d h:iA', $dateObj->format('Y-m-d').' '.request('time'));

        $this->studentScheduleEntryLibrary->getStudentScheduleEntriesBuilder(new StudentScheduleEntryFilters(
            [
             'student' => auth()->id(),
             'date' => Carbon::tomorrow()->format('m/d/Y'),
            ]
         ))->where(function($q) use ($timeObj, $minutes){
            $from = $timeObj->copy();
            $to = $timeObj->copy()->addMinutes($minutes);
            $q->whereBetween('from', [$from->copy()->format('H:i:s'), $to->copy()->format('H:i:s')]);
            $q->orWhereBetween('to', [$from->copy()->format('H:i:s'), $to->copy()->format('H:i:s')]);
            $q->orWhere(function ($qry) use ($from, $to){
                $qry->where('from', '<=', $from->copy()->format('H:i:s'))
                    ->where('to', '>=', $to->copy()->format('H:i:s'));
            });
        })->delete();

        $schedule = new StudentScheduleEntry();
        $schedule->student_id = auth()->id();
        $schedule->staff_id = $staff;
        // $schedule->school_id = auth()->user()->school_id;
        $schedule->looking_for = request('reason');
        $schedule->from = $timeObj->copy()->format('H:i:s');
        $schedule->to = $timeObj->copy()->addMinutes($minutes)->format('H:i:s');
        $schedule->date = $timeObj->copy()->format('Y-m-d');
        $schedule->appointment_type = request('type');
        $this->studentScheduleEntryRepository->saveStudentScheduleEntry($schedule);

        $schedule->appointmentCategories()->sync($categories->pluck('id')->all());
        
        $schedules = $this->getReminingSchedules();
        return [
            'schedules' => !empty($schedules) ? StudentScheduleResource::collection($schedules): null,
            'message' => 'Schedule has been saved successfully.'
        ];
    }

    public function cancelSchedule()
    {
        $student = auth()->user()->id;

        $schedule = $this->studentScheduleEntryLibrary->getStudentScheduleEntries(
                new StudentScheduleEntryFilters(['student' => $student->id, 'id' => request('id')]))->first();

        // if(!$schedule){
        //     return (new StatusMessageResource(__('Not Found Appointment')))->response()->setStatusCode(404);
        // }

        // $schedule->delete();
        $schedules = $this->getReminingSchedules();
        return [
            'schedules' => !empty($schedules) ? StudentScheduleResource::collection($schedules): null,
            'message' => 'Schedule has been canceled successful.'
        ];
    }

    public function schedule_assets()
    {
        $staff = [];
        $dates = [];
        $availableDates = [];
        $availableDays = [];
        $student = auth()->user();
        $site = $student->site;

        $start = Carbon::tomorrow();
        $end = $start->copy()->addDays(6);

        $allDayClosures = $this->closuresOfTypeAllDay($start, $end, $site);

        foreach($start->toPeriod($end, '1 day') AS $day){
            $closed = $allDayClosures->where('start_date', '<=', $day->copy()->format('Y-m-d'))
                ->where('end_date', '!=', null)
                ->where('end_date', '>=', $day->copy()->format('Y-m-d'))
                ->merge($allDayClosures->where('end_date', null)
                    ->where('start_date', $day->copy()->format('Y-m-d')));

            if(!$closed->count()){
                $availableDates[] = $day->copy()->format('Y-m-d');
                $availableDays[] = Str::lower($day->copy()->format('l'));
            }
        }
 
        $categoriesBuilder = $this->appointmentCategoryLibrary->
            getAppointmentCategoriesBuilder(new AppointmentCategoryFilters(['active' => 1, 'gcCanSelect' => 1]))
            ->where(function ($q) use ($site) {
                $q->where('has_all_sites', 1);
                $q->orWhereHas('sites', function ($q) use ($site) {
                    $q->where('sites.id', $site->id);
                });
            })->where(function($q) use ($availableDays, $availableDates){
                $q->where('duration->type', AppointmentCategory::DURATION_TYPE_IN_MINUTES);
                $q->orWhere(function($qr) use ($availableDates){
                    $qr->where('duration->type', AppointmentCategory::DURATION_TYPE_SET_TIME);
                    $qr->whereNotNull('duration->type->date');
                    $qr->whereIn('duration->type->date', $availableDates);
                });
                $q->orWhere(function($qr) use ($availableDays){
                    $qr->where('duration->type', AppointmentCategory::DURATION_TYPE_RECURRING);
                    $qr->whereNotNull('duration->type->day');
                    $qr->whereIn('duration->type->day', $availableDays);
                });
            });
            
            if(request('reason') == StudentScheduleEntry::LOOKING_FOR_MEET_WITH && !empty($availableDates)){
            $staff = $this->userRepository->
                getFilteredBuilder(new UserFilters(['active' => 1]))
                ->whereHas('tenantUser.districts', function($q) use ($site){
                    $q->where('districts.id', 0);
                    $q->orWhereNull('districts.id');
                    $q->orWhere('districts.id', $site->district_id);
                })
                ->whereHas('staffSchedule', function($q) use ($site, $availableDates){
                    $q->where('site_id', $site->id);
                    $q->whereHas('entries', function($q) use ( $availableDates){
                        $q->where('schedule_type', request('type'));
                        $q->whereIn('date', $availableDates);
                    });
                   
                })
                ->with(['staffSchedule' => function($q) use($site, $start, $end){
                    $q->where('site_id', $site->id);
                    $q->whereHas('entry', function($q) use ($start, $end){
                        $q->where('schedule_type', request('type'));
                        $q->whereIn('date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
                    });
                }])
                ->orderByRaw('CONCAT(first_name, " ", last_name) ASC')
                ->get();

            $categories = $categoriesBuilder->whereHas('staffScheduleEntries.staffSchedule', function($q) use ($staff){
                    if($staff->count()){
                        $q->whereIn('staff_id', $staff->pluck('id')->all());
                    }else{
                        $q->where('staff_schedules.id', null);
                    }
                })
                ->get();
                $staff = $staff->map(function($item, $key) use ($site, $categories){

                    $item->categories = $categories->filter(function($cat, $key) use ($item){
                        return $cat->staffScheduleEntries()
                            ->whereHas('staffSchedule', function($q, $item){
                                $q->where('staff_id', $item->id);
                            })->exist();
                    });

                    return new StaffResource($item);
                });
        }else{
            $categories = $categoriesBuilder->get();
        }

        if(request('reason') == StudentScheduleEntry::LOOKING_FOR_COME_IN_ON) {
            foreach ($start->toPeriod($end, '1 day') AS $day) {
                $filtered = $categories->filter(function ($category, $key) use ($day) {
                    return (
                        $category->duration['type'] == AppointmentCategory::DURATION_TYPE_IN_MINUTES
                        || ($category->duration['type'] == AppointmentCategory::DURATION_TYPE_SET_TIME && !is_null($category->duration['payload']['date']) && $category->duration['payload']['date'] == $day->copy()->format('Y-m-d'))
                        || ($category->duration['type'] == AppointmentCategory::DURATION_TYPE_RECURRING && !is_null($category->duration['payload']['day']) && $category->duration['payload']['day'] == Str::lower($day->copy()->format('l')))
                    );
                });
                $filtered = AppointmentCategory::all();

                $dates[] = [
                    'date' => $day->copy()->format('m/d/Y'),
                    'categories' => AppointmentCategoryResource::collection($filtered)
                ];
            }
        }

        if(!empty($categories) && $categories->count() && request('reason') == StudentScheduleEntry::LOOKING_FOR_WORK_ON){
            $categories = AppointmentCategoryResource::collection($categories);
        }else{
            $categories = [];
        }

        return new ScheduleAssetsResource(['staff' => $staff, 'dates' => $dates, 'categories' => $categories]);
    }

    private function closuresOfTypeAllDay($start, $end, $site)
    {
        return $this->academyClosureRepository->getFilteredBuilder(new AcademyClosureFilters(['all-day' => 1]))
                ->where(function($q) use ($start, $end){
                    $q->where(function($qry) use ($start, $end){
                        $qry->whereNull('end_date');
                        $qry->whereBetween('start_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
                    });
                    $q->orWhere(function($qry) use ($start, $end){
                        $qry->whereNotNull('end_date');
                        $qry->where(function($query) use ($start, $end){
                            $query->whereBetween('start_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);
                            $query->orWhereBetween('end_date', [$start->copy()->format('Y-m-d'), $end->copy()->format('Y-m-d')]);

                            $query->orWhere(function ($qr) use ($start, $end){
                                $qr->where('start_date', '<=', $start->copy()->format('Y-m-d'));
                                $qr->where('end_date', '>=', $end->copy()->format('Y-m-d'));
                            });
                        });
                    });
                })->whereHas('sites.district', function ($q) use($site){
                    $q->where(function($q) use ($site) {
                        $q->whereNull('district_id');
                        $q->orWhere('district_id', 0);
                        $q->orWhere('district_id', $site->district_id);
                    });
                })->whereHas('sites', function($q) use($site){
                    $q->whereNull('site_id');
                    $q->orWhere('site_id', 0);
                    $q->orWhere('site_id', $site->id);
                })
                ->where(function($q){
                    if(request('type') == StudentScheduleEntry::APPOINTMENT_TYPE_ON_SITE){
                        $q->where('available_on_site', 1);
                    }
        
                    if(request('type') == StudentScheduleEntry::APPOINTMENT_TYPE_VIRTUAL){
                        $q->where('available_virtually', 1);
                    }
                })->get();
    }

    private function getStaff()
    {
        $site = auth()->user()->site;
        $dateObj = Carbon::createFromFormat('m/d/Y', request('date'));
        $time = Carbon::createFromFormat('h:iA', request('time'))->format('H:i:s');
        $staff = $this->userRepository->
                getFilteredBuilder(new UserFilters(['active' => 1]))
                ->whereHas('tenantUser.districts', function($q) use ($site){
                    $q->where('districts.id', 0);
                    $q->orWhereNull('districts.id');
                    $q->orWhere('districts.id', $site->district_id);
                })
                ->whereHas('staffSchedule', function($q) use ($site, $dateObj, $time){
                    $q->where('site_id', $site->id);
                    $q->whereHas('entries', function($q) use ( $dateObj, $time){
                        $q->where('schedule_type', request('type'));
                        $q->where('date', $dateObj->format('Y-m-d'));
                        $q->where('from', '<=', $time);
                        $q->where('to', '>=', $time);
                        $q->whereHas('appointmentCategories', function($qry){
                            $qry->whereIn('appointment_category_staff_schedule_entry.appointment_category_id', request('categories'));
                        });
                    });
                   
                })
                ->orderByRaw('CONCAT(first_name, " ", last_name) ASC')
                ->first();
        return $staff? $staff->id : null;
    }

    public function getReminingSchedules()
    {
        $this->studentScheduleEntryLibrary->getStudentScheduleEntries(new StudentScheduleEntryFilters(
           [
            'student' => auth()->id(),
            'from-date' => Carbon::tomorrow()->format('m/d/Y'),
            'to-date' => Carbon::tomorrow()->addDays(6)->format('m/d/Y')
           ]
        ))->load(['staff', 'appointmentCategories']);
    }
}
