<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Voucher\Filters\VoucherFilters;
use App\Domain\Voucher\Model\Voucher;
use App\Domain\Voucher\Repository\VoucherRepository;
use App\Http\Controllers\MobileApi\BaseController;
use App\Http\Resources\VoucherResource;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Repository\StudentRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\UnauthorizedException;

class VoucherController extends BaseController
{

    private $voucherRepository;
    private $studentRepository;
   
    public function __construct(VoucherRepository $voucherRepository, 
        StudentRepository $studentRepository)
    {
        $this->voucherRepository = $voucherRepository;
        $this->studentRepository = $studentRepository;
    }

    public function index()
    {
        $student_id = auth()->id();
        $vouchers = $this->voucherRepository
        ->getVouchersBuilders(new VoucherFilters(['student' =>  $student_id]))->with('student')->latest()->paginate(500);
        return VoucherResource::collection($vouchers);
    }

    public function show($voucherId)
    {
        $voucher = $this->voucherRepository->getVoucher($voucherId)->load('student');

        return new VoucherResource($voucher);
    }

    public function proxyEmail(Request $request)
    {
        if ($request->get('password') != config('custom.proxy_email_password')) {
            throw new UnauthorizedException();
        }
        // $student = $this->studentRepository->
        //         getStudentFilter(
        //                 new StudentFilters(
        //                         ['rewards-email' => $request->get('payload')['email']]
        //                     )
        //                 );
        Log::emergency($request->get('payload'));
        Log::info($request->get('payload')['email']);
        $student = Student::where('rewards_email', $request->get('payload')['email'])->firstOrFail();
        if ($student) {
            $this->voucherRepository->saveVoucher(new Voucher([
                'student_id' => $student->id,
                'subject' => $request->get('payload')['subject'],
                'email_body' => $request->get('payload')['email_body']
            ]));
        }
        return json_encode(true);
    }
}