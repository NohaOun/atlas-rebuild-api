<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Redemption\Filters\RedemptionFilters;
use App\Domain\Redemption\Model\Redemption;
use App\Domain\Redemption\RedemptionLibrary;
use App\Domain\Student\Model\Student;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Http\Controllers\Controller;
use App\Http\Resources\RedemptionResource;
use Illuminate\Http\Request;
use App\Domain\Tango\TangoLibrary;
use Illuminate\Support\Arr;

class RedemptionController extends Controller
{
    use ApiResponseTrait;
    //
    private $redemptionLibrary;
    private $studentPointLibrary;

    function __construct(RedemptionLibrary $redemptionLibrary, StudentPointLibrary $studentPointLibrary)
    {
        $this->redemptionLibrary = $redemptionLibrary;
        $this->studentPointLibrary = $studentPointLibrary;
    }

    public function getStudentOf(Request $request){
        if(auth()->user() instanceof StudentParent){
            $student_id = $request->headers->get('student-id');
            $parent = auth()->user();
            $student = $parent->students()->where('student_id', $student_id)->firstOrFail();
           
        }else{
            $student = auth()->user();
        }
        return $student;
    }

    public function index(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $links = $this->redemptionLibrary->getRedemptions(new RedemptionFilters(["student" => $student->id, "status" , Redemption::STATUS_PENDING]));
        $this->redemptionLibrary->updateStatusToSeen($links);
        return RedemptionResource::collection($links);
    }

    public function store()
    {
        $student = auth()->user();
        $points = $student->availablePoints;

        if(! $points){
            return $this->apiResponse([], ['points' => "User doesn't have any points for redemption."], config('constants.response_codes.validation_error'), true);
        }
        if(!$student->can_redeem){
            return $this->apiResponse([], ['redeem' => "User is not allowed to redeem."], config('constants.response_codes.validation_error'), true);
        }

        if ($points > 50000) $points = 50000; 

        $factorRecord = $student->tenant->config["site_settings"]["points_to_dollars_factor"];
        $factor = $factorRecord ? floatval($factorRecord) : 1;
        $amount = $points / $factor;

        if (!$student->rewards_email) {
            $student->fill(['rewards_email' => $student->username . '@' . config('custom.web_app_domain')])->save();
        }
        $amount = round($amount,2);
        $response = (new TangoLibrary())->createOrder($student, $amount);
        $link = Arr::get($response, 'reward.credentials.Redemption Link');
        if($link){
            $record = $this->redemptionLibrary->createRedemption([
                'student_id' => auth()->id(),
                'link' => Arr::get($response, 'reward.credentials.Redemption Link'),
                'amount' => $amount,
                'points' => $points,
                'status' => Redemption::STATUS_NEW
            ]);
            return (new RedemptionResource($record))->additional([
                'message' => 'Reward link has been created successfully.'
            ]);
        }
        
        
    }
}
