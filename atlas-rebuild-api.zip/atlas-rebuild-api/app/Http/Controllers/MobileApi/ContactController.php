<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Business\Model\Business;
use App\Domain\Business\Filters\BusinessFilters;
use App\Domain\Business\Repository\BusinessRepository;
use App\Domain\Contact\Filters\ContactFilters;
use App\Domain\Contact\Model\Contact;
use App\Domain\Contact\Model\ContactsMapSessions;
use App\Domain\Contact\Repository\ContactRepository;
use App\Domain\District\Filters\DistrictFilters;
use App\Domain\District\Repository\DistrictRepository;
use App\Domain\Document\Filters\DocumentTypeFilters;
use App\Domain\Document\Repository\DocumentTypeRepository;
use App\Domain\Lookup\Library\HearAboutLibrary;
use App\Domain\Lookup\Library\PriorityLibrary;
use App\Domain\Lookup\Model\BusinessType;
use App\Domain\Phase\Filters\PhaseFilters;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepository;
use App\Domain\Status\Filters\StatusFilters;
use App\Domain\Status\Repository\StatusRepository;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Repository\UserRepository;
use App\Http\Resources\ContactResource;
use App\Http\Resources\DistrictResource;
use App\Http\Resources\PhaseStatusResource;
use App\Observers\ContactObserver;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Request as Input;
use Illuminate\Validation\Rule;
use stdClass;

class ContactController extends BaseController
{
    //
    use ApiResponseTrait, ValidationTrait;
    private $contactRepository;
    private $districtRepository;
    private $phaseRepository;
    private $priorityLibrary;
    private $userRepository;
    private $contactObserver;
    private $businessRepository;
    private $documentTypeRepository;
    
    public function __construct(ContactRepository $contactRepository, 
                PhaseRepository $phaseRepository,
                PriorityLibrary $priorityLibrary,
                UserRepository $userRepository,
                DistrictRepository $districtRepository,
                ContactObserver $contactObserver,
                BusinessRepository $businessRepository,
                DocumentTypeRepository $documentTypeRepository
                )
    {
        $this->contactRepository = $contactRepository;
        $this->districtRepository = $districtRepository;
        $this->phaseRepository = $phaseRepository;
        $this->priorityLibrary = $priorityLibrary;
        $this->userRepository = $userRepository;
        $this->contactObserver = $contactObserver;
        $this->businessRepository = $businessRepository;
        $this->documentTypeRepository = $documentTypeRepository;
    }

    public function create($id = null)
    {
        $contact = (object) null;
        if(!empty($id)){
            $contact = $this->contactRepository->getContact($id);
            if(!$contact){
                return $this->apiResponse([], ['failed' => 'can\'t find the contact you seek'], config('constants.response_codes.not_found'), true);
            }

            $contact = $this->formContactRowForEdit($contact);
        }
        $districts = $this->districtRepository->getDistricts(new DistrictFilters(['active' => true]))->load(['sites' => function($q) {
                $q->where('active', true);
                $q->orderBy('name', 'ASC');
                }] );
        $phases = $this->phaseRepository->getPhases(new PhaseFilters(["phase_type" => "Contact"]));
        $priorities = $this->priorityLibrary->getPriorities();
        
        $config["permission"] = 54; // Community Outreach Advocate
        $config["tenant_id"] = tenant()->id;

        $config2["permission"] = 66; //	Outreach Resource Advocate
        $config2["tenant_id"] = $config["tenant_id"];
       
        return $this->apiResponse([
            'districts' => DistrictResource::collection($districts),
            'phases' => $phases,
            'states' => config('states'),
            'HearAbout' => (new HearAboutLibrary())->getList(),
            'BusinessType' =>  (new BusinessType())->getValues(),
            'outreachResourceAdvocate' =>$this->userRepository->getUsers(new UserFilters( ["permission" => $config2])),
            'communityOutreachAdvocate' =>$this->userRepository->getUsers(new UserFilters( ["permission" => $config])),
            'priorities' => $priorities,
            'contact' => $contact
        ]);
    }

    public function store(Request $request)
    {
        $validator = $this->validator($request, $this->rules());

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }

        if(empty($request->lat) || empty($request->lng)){
            $mapLocation = $this->getContactLatLng($request);
            if(!$mapLocation['status']){
                return $this->apiResponse([], ['zip_code' => 'Invalid zip code and street address line 1'], config('constants.response_codes.server'), true);
            }
            $lat = $mapLocation['lat'];
            $lng = $mapLocation['lng'];
        }else{
            $lat = $request->lat;
            $lng = $request->lng;
        }

        $inputs = $this->getInputs($request->all());
        
        $inputs['referral_option'] = 'AA Staff';
        $inputs['lat'] = $lat;
        $inputs['lng'] = $lng;
        $inputs['enrollment_coach'] = auth()->user()->id;

        if($request->pin_type == 'business') {

            $business = $this->businessRepository->getBusinessByFilters(new BusinessFilters(
                    ['address' => $request->input('business.address'), 
                    'establishment' => $request->input('business.address')]));
            if ($business) {
                return $this->apiResponse([], ['failed' => 'The business is dupulicated'], config('constants.response_codes.validation_error'), true);
            }
        }

        DB::beginTransaction();
        try {
            $businessObj = [];
            if($request->pin_type == 'business'){
                $businessObj = new Business();
                $businessObj->business_name = $request->input('business.business_name');
                $businessObj->first_name = $request->input('business.first_name');
                $businessObj->last_name = $request->input('business.last_name');
                $businessObj->title = $request->input('business.title');
                $businessObj->address = $request->input('business.address');
                $businessObj->address_2 = $request->input('business.address_2');
                $businessObj->phone = $request->input('business.phone');
                $businessObj->phone_2 = $request->input('business.phone_2');
                $businessObj->email = $request->input('business.email');
                $businessObj->notes = $request->input('business.notes');
                $businessObj->city = $request->input('business.city');
                $businessObj->state = $request->input('business.state');
                $businessObj->zip_code = $request->input('business.zip_code');
                $businessObj->fax = $request->input('business.fax');
                $businessObj->lat = $request->input('business.lat');
                $businessObj->lng = $request->input('business.lng');
                $businessObj->community_outreach_advocate_id = $request->input('business.community_outreach_advocate_id');
                $businessObj->outreach_resource_advocate_id = $request->input('business.outreach_resource_advocate_id');
                $businessObj->gc_referral_source = $request->input('business.gc_referral_source');
                $businessObj->business_type = $request->input('business.business_type');
                $this->businessRepository->saveBusiness($businessObj);
                $inputs['business_id'] = $businessObj->id;
                DB::commit();
                $business = $businessObj->toArray();
                unset($business["tenant"]);
                return $this->apiResponse(['business' => $business]);
            }
            if(!empty($inputs["status"])){
                $statusRepository = new StatusRepository();
                if($status =  $statusRepository->getStatusByFilters(new StatusFilters(["status-name" => $inputs["status"], "phase-name" => $inputs["phase"]])))
                     $inputs["status_id"] = $status->id;
                 unset($inputs["status"]);
             }
            $exists = $this->getContact($inputs);
            $inputs['duplicate'] = $exists ? true : false;
            $inputs['duplicated_from'] = $exists ? $exists->id : null;
            $contact = new Contact($inputs);
            $this->contactRepository->saveContact($contact);
            if (
                $request->pin_type == 'contact' && 
                $contact->status->phase->name == PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT && 
                $contact->status->name == StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED
                ) {
                $this->contactObserver->createStudent($contact);
            }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            dd($e);
            return $this->apiResponse([], ['failed' => 'Something is wrong, please try again later'], config('constants.response_codes.server'), true);
        }
        return $this->apiResponse(['contact' => $this->formContactRow($contact, $businessObj)]);
    }

    public function update(Request $request, $id)
    {
        $validator = $this->validator($request, $this->rules(true));

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }

        // if(empty($request->countAsChange)){
        //     $countAsChange = false;
        // }else{
        //     $countAsChange = $request->countAsChange;
        // }

        $contact = Contact::find($id);
        if(!$contact){
            return $this->apiResponse([], ['failed' => 'Can\'t find the contact you seek'], config('constants.response_codes.not_found'), true);
        }

        if($request->pin_type == 'business') {

            $filters = ['address' => $request->input('business.address'), 
            'establishment' => $request->input('business.address')];
            if (!empty($contact->business_id)) {
                $filters[] = ['notId' => $contact->business_id];
            }
            $businessDuplicated = $this->businessRepository->getBusinessByFilters(new BusinessFilters($filters));
            if ($businessDuplicated) {
                return $this->apiResponse([], ['failed' => 'The business is dupulicated'], config('constants.response_codes.validation_error'), true);
            }
        }

        $originPhase = $contact->phase;
        $originStatus = $contact->status;

        $lat = null;
        $lng = null;

        if(($contact->street_address_1 != $request->street_address_1 || $contact->zip_code != $request->zip_code) && (empty($request->lat) || empty($request->lng))){
            // $response = $this->geocodeZipCode($request->zip_code);
            $mapLocation = $this->getContactLatLng($request);
            if(!$mapLocation['status']){
                return $this->apiResponse([], ['zip_code' => 'Invalid zip code and street address line 1'], config('constants.response_codes.server'), true);
            }

            $lat = $mapLocation['lat'];
            $lng = $mapLocation['lng'];
        }else{
            if(!empty($request->lat) && !empty($request->lng)) {
                $lat = $request->lat;
                $lng = $request->lng;
            }
        }

        $inputs = $this->getInputs($request->all());
        if(array_key_exists('lat', $inputs)){
            unset($inputs['lat']);
        }

        if(array_key_exists('lng', $inputs)){
            unset($inputs['lng']);
        }
        if($lat && $lng) {
            $inputs['lat'] = $lat;
            $inputs['lng'] = $lng;
        }

        if($request->pin_type == 'contact'){
            $inputs['business_id'] = null;
        }
        // if($countAsChange){
        //     $inputs['status_changes_number'] = (int) $contact->status_changes_number + 1;
        // }
        DB::beginTransaction();
        try {
            if(array_key_exists('enrollment_coach', $inputs)){
                unset($inputs['enrollment_coach']);
            }

            if(array_key_exists('status', $inputs)){
                unset($inputs['status']);
            }

            if(array_key_exists('phase', $inputs)){
                unset($inputs['phase']);
            }

            if(array_key_exists('scheduled_date', $inputs)){
                unset($inputs['scheduled_date']);
            }
            if(array_key_exists('wa_only_date', $inputs)){
                unset($inputs['wa_only_date']);
            }
            

            //            if(array_key_exists('priority', $inputs)){
            //                unset($inputs['priority']);
            //            }
            if(!empty($inputs["district"])){
                if($district = $this->districtRepository->getDistrictByFilters(new DistrictFilters(["name" => $inputs["district"]])))
                    $inputs["district_id"] = $district->id;
                unset($inputs["district"]);
            }
            $businessObj = [];
            if($request->pin_type == 'business'){
                $businessObj = $contact->business;
                if(!$businessObj){
                    $businessObj = new Business();
                }
                $businessObj->business_name = $request->input('business.business_name');
                $businessObj->first_name = $request->input('business.first_name');
                $businessObj->last_name = $request->input('business.last_name');
                $businessObj->title = $request->input('business.title');
                $businessObj->address = $request->input('business.address');
                $businessObj->address_2 = $request->input('business.address_2');
                $businessObj->phone = $request->input('business.phone');
                $businessObj->phone_2 = $request->input('business.phone_2');
                $businessObj->email = $request->input('business.email');
                $businessObj->notes = $request->input('business.notes');
                $businessObj->city = $request->input('business.city');
                $businessObj->state = $request->input('business.state');
                $businessObj->zip_code = $request->input('business.zip_code');
                $businessObj->fax = $request->input('business.fax');
                $businessObj->lat = $request->input('business.lat');
                $businessObj->lng = $request->input('business.lng');
                $businessObj->gc_referral_source = $request->input('business.gc_referral_source');
                $businessObj->business_type = $request->input('business.business_type');
                $this->businessRepository->saveBusiness($businessObj);
                $inputs['business_id'] = $businessObj->id;
                DB::commit();
                $business = $businessObj->toArray();
                unset($business["tenant"]);
                return $this->apiResponse(['business' => $business]);
            }
            $contact->fill($inputs)->save();
                    //    if ($request->pin_type == 'contact' &&
                    //        ($originPhase != $contact->phase || $originStatus != $contact->status) &&
                    //        ($contact->phase == Contact::PHASE_RECRUITMENT && $contact->status == Contact::STATUS_SCHEDULED)
                    //    ) {
                    //        $contact->addToStudents();
                    //    }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            dd($e);
            return $this->apiResponse([], ['failed' => 'Something is wrong, please try again later'], config('constants.response_codes.server'), true);
        }

        return $this->apiResponse(['contact' => $this->formContactRow($contact, $businessObj)]);
    }

    public function search(Request $request)
    {
        $validator = $this->validator($request, [
            'search' => 'required',
        ]);

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }

        $search = $request->search;
        if(!empty($request->places_session)){
            $sessionToken = $request->places_session;
        }else{
            $sessionToken = $this->gen_uuid();
        }

        $res = ['venues' => [], 'places' => [], 'places_session' => ""];

        $result = $this->googleAutoComplete($search, $sessionToken);
        if(!$result['status']){
            $errors = ['google_api_key' => [$result['result']]];
            return $this->apiResponse($res, $errors, config('constants.response_codes.server'), true);
        }

        $places = $result['result'];

        $contacts = $this->contactRepository->getContacts(new ContactFilters(["q" => $search]));
        $contacts = $contacts->splice(0, 5);//array_slice($contacts, 0, 5);
        $contacts = ContactResource::collection($contacts);

        $res = ['contacts' => $contacts, 'places' => $places, 'places_session' => $sessionToken];
        return $this->apiResponse($res);
    }

    public function map(Request $request)
    {

        $validator = $this->validator($request, [
            'lat' => 'required',
            'lng' => 'required',
            'zoomLevel' => 'required|numeric|max:20|min:0',
            'fromDate' => 'nullable|sometimes|required_with:toDate|date_format:Y-m-d',
            'toDate' => 'nullable|sometimes|required_with:fromDate|date_format:Y-m-d',
            'status' => 'nullable|sometimes|array',
            // 'serial' => 'required|string|max:191'
        ]);

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }

        if(empty($request->zoomLevel) && $request->zoomLevel != 0 && $request->zoomLevel != "0"){
            $radius = Contact::RADIUS;
        }else{
            $radius = $this->getRadiusFromZoomLevel($request->zoomLevel);
        }

        // $serial = $request->serial;
        $sessionID = $request->sessionId;
        $contact_fillter = new ContactFilters([
            "duplicate" => false, 
            // "community_outreach_advocate" => auth()->id(),
            "lat_is_not_null"=>null,
            "lng_is_not_null"=>null,
            "radians_calc" => ["lat" => $request->lat, "lng" => $request->lng, "radius" => $radius]
            ]);

        if(!empty($request->status)){
            $contact_fillter->add("status" , $request->status);
        }
       
        if(!empty($request->fromDate) && !empty($request->toDate)){
            $from  = Carbon::createFromFormat('Y-m-d', $request->fromDate)->format("m/d/Y");
            $toDate  = Carbon::createFromFormat('Y-m-d', $request->toDate)->format("m/d/Y");
            $contact_fillter->add("created_at_from" , $from);
            $contact_fillter->add("created_at_to" , $toDate);
        }

        $idsStr = '';
        // if(!empty($sessionID)){
        //     $sessionedIDs = ContactsMapSessions::where('serial', $serial)->where('session_id', $sessionID)->first();
        //     if($sessionedIDs){
        //         $idsStr = $sessionedIDs->contacts;
        //         if(!empty($idsStr)){
        //             $idsArr = explode(",", $idsStr);
        //             $contact_fillter->add("no_ids" , $idsArr);
        //         }
        //     }
        // }
        $contacts = $this->contactRepository->getContacts($contact_fillter);
        
        // if(!empty($sessionID)){
        //     if(!empty($contacts) && $contacts->count()){
        //         $retrievedIDs = $contacts->pluck('id')->all();
        //         $retrievedIDsStr = implode(",", $retrievedIDs);
        //         if(!empty($idsStr)){
        //             $retrievedIDsStr = $idsStr.','.$retrievedIDsStr;
        //             $sessionedIDs->contacts = $retrievedIDsStr;
        //             $sessionedIDs->save();
        //         }else{
        //             ContactsMapSessions::insert(['session_id' => $sessionID, 'serial' => $serial, 'contacts' => $retrievedIDsStr]);
        //         }
        //     }
        //     ContactsMapSessions::where('serial', $serial)->where('session_id', '!=', $sessionID)->delete();
        // }
        $phases = $this->phaseRepository->getPhases(new PhaseFilters(["phase_type" => "Contact"]))->load("statuses");
        $filteredResult = $this->mapContactsFilter($contacts);
        return $this->apiResponse([
            'statuesCounts' => $filteredResult['statuses'],
            'contacts' => $filteredResult['contacts'],
            'statuses' => PhaseStatusResource::collection($phases)
        ]);
    }

    public function gen_uuid() {
        return sprintf( '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            // 32 bits for "time_low"
            mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ),

            // 16 bits for "time_mid"
            mt_rand( 0, 0xffff ),

            // 16 bits for "time_hi_and_version",
            // four most significant bits holds version number 4
            mt_rand( 0, 0x0fff ) | 0x4000,

            // 16 bits, 8 bits for "clk_seq_hi_res",
            // 8 bits for "clk_seq_low",
            // two most significant bits holds zero and one for variant DCE1.1
            mt_rand( 0, 0x3fff ) | 0x8000,

            // 48 bits for "node"
            mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff ), mt_rand( 0, 0xffff )
        );
    }
    
    public function listView(Request $request)
    {
        $validator = $this->validator($request, [
            'lat' => 'required',
            'lng' => 'required',
            'fromDate' => 'nullable|sometimes|required_with:toDate|date_format:Y-m-d',
            'toDate' => 'nullable|sometimes|required_with:fromDate|date_format:Y-m-d',
            'status' => 'nullable|sometimes|array'
        ]);

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }

        $contact_fillter = new ContactFilters([
            "duplicate" => false, 
            "lat_is_not_null"=>null,
            "lng_is_not_null"=>null,
            "order_radians_calc" => ["lat" => $request->lat, "lng" => $request->lng]]);
      
        if(!empty($request->status)){
            $contact_fillter->add("status" , $request->status);
        }
       
        if(!empty($request->fromDate) && !empty($request->toDate)){
            $contact_fillter->add("created_at_from" , $request->fromDate);
            $contact_fillter->add("created_at_to" , $request->toDate);
        }

        $builder = Contact::where('duplicated', 0)
                ->whereNotNull('lat')
                ->whereNotNull('lng');
        if(auth()->user()->hasPermission(54)){
            $contact_fillter->add("community_outreach_advocate" , auth()->user()->id);
        }
        elseif(auth()->user()->hasPermission(66)){
            $contact_fillter->add("outreachResourceAdvocate" , auth()->user()->id);
        }
        
        $builder = Contact::query()->with('actionCountR');
        $contacts  = $contact_fillter->apply($builder)->paginate(40);

        $meta['currentPage'] = $contacts->currentPage();
        $meta['total'] = $contacts->total();
        $meta['count'] = $contacts->count();
        $meta['lastPage'] = $contacts->lastPage();
        $meta['hasMorePages'] = $contacts->hasMorePages();
        $links['nextPageUrl'] = $contacts->appends(Input::except('page'))->nextPageUrl();
        $links['prevPageUrl'] = $contacts->appends(Input::except('page'))->previousPageUrl();
        $filteredResult = $this->listContactsFilter($contacts);
        $phases = $this->phaseRepository->getPhases(new PhaseFilters(["phase_type" => "Contact"]))->load("statuses");

        return $this->apiResponse([
            'contacts' => $filteredResult,
            'statuses' =>PhaseStatusResource::collection($phases),
            'meta' => $meta, 'links' => $links
        ]);
    }

    protected function listContactsFilter($contacts)
    {
        $result = [];
        foreach($contacts AS $contact){
            $result[] = $this->formContactRow($contact, null);
        }

        return $result;
    }

    public function clearMapSession(Request $request)
    {
        $validator = $this->validator($request, [
            'serial' => 'required',
        ]);

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'));
        }

        ContactsMapSessions::where('serial', $request->serial)->delete();

        return $this->apiResponse();
    }

    protected function formContactRowForEdit($contact)
    {
        $pinColor = $contact->status->color?? '#31a1c0';
        return [
            'id' => $contact->id,
            'pin_type' => $contact->pin_type,
            'priority' => (int) $contact->priority,
            'statusChangesNumber' => $contact->status_changes_number ?? 0,
            'pinColor' => $pinColor,
            'business' => $contact->business_id ?
                [
                    'id' => $contact->business->id,
                    'business_name' => $contact->business->business_name,
                    'first_name' => $contact->business->first_name,
                    'last_name' => $contact->business->last_name,
                    'title' => $contact->business->title,
                    'address' => $contact->business->address,
                    'address_2' => $contact->business->address_2,
                    'phone' => $contact->business->phone,
                    'phone_2' => $contact->business->phone_2,
                    'city' => $contact->business->city,
                    'state' => $contact->business->state,
                    'zip_code' => $contact->business->zip_code,
                    'fax' => $contact->business->fax,
                    'lat' => $contact->business->lat,
                    'lng' => $contact->business->lng,
                    'outreachAdvocate' => $contact->business->outreachResourceAdvocate ?
                        [
                            'id' => $contact->business->outreachResourceAdvocate->id,
                            'first_name' => $contact->business->outreachResourceAdvocate->first_name,
                            'last_name' => $contact->business->outreachResourceAdvocate->last_name
                        ] : (object) null,
                    'enrollmentCoach' => $contact->business->communityOutreachAdvocate ?
                        [
                            'id' => $contact->business->communityOutreachAdvocate->id,
                            'first_name' => $contact->business->communityOutreachAdvocate->first_name,
                            'last_name' => $contact->business->communityOutreachAdvocate->last_name
                        ] : (object) null,
                        
                    'notes' => $contact->business->notes
                ] : (object) null,
            'overview' => [
                'firstName' => $contact->first_name,
                'middleName' => $contact->middle_name,
                'lastName' => $contact->last_name,
                'district' => optional($contact->district)->name,
                'site' => $contact->site ?
                    [
                        'id' => $contact->site->id,
                        'name' => $contact->site->name
                    ] : (object) null,
                'phase' => $contact->phase,
                'status' => $contact->status
            ],
            'contactInformation' => [
                'street1' => $contact->street_address_1,
                'street2' => $contact->street_address_2,
                'city' => $contact->city,
                'state' => $contact->state,
                'zipCode' => $contact->zip_code,
                'phone_1' => $contact->phone_1,
                'phone_2' => $contact->phone_2,
                'email' => $contact->email
            ],
            'eeoc' => [
                'DOB' => $contact->birthdate? $contact->birthdate->format('m/d/Y') : ''
            ],
            'pastSchoolAttended' => [
                'pastSchool' => $contact->past_school_attended,
                'withdrawalCode' => $contact->withdrawal_code,
                'withdrawalDate' => $contact->withdrawal_date
            ],
            'referrer' => [
                'referrer' => $contact->referrer,
                'referralOption' => $contact->referral_option,
                'referralOptionOther' => $contact->referral_option_other
            ],
            'staff' => [
                'outreachAdvocate' => optional($contact->business)->outreachResourceAdvocate ?
                    [
                        'id' => optional($contact->business)->outreachResourceAdvocate->id,
                        'name' => optional($contact->business)->outreachResourceAdvocate->full_name,
                    ] : (object) null,
                'enrollmentCoach' => optional($contact->business)->communityOutreachAdvocate ?
                    [
                        'id' => optional($contact->business)->communityOutreachAdvocate->id,
                        'name' => optional($contact->business)->communityOutreachAdvocate->full_name,
                    ] : (object) null,
            ],
            'notes' => $contact->notes,
            'updatedAt' => date('M d, Y \a\t h:i A', strtotime($contact->updated_at))
        ];
    }

    protected function getRadiusFromZoomLevel($level)
    {
        if($level <= 4){
            return 250 * 1.609344;
        }

        if($level >= 15){
            return 0.25 * 1.609344;
        }

        return ($this->zoomLevelScale()[(int) $level] * 1.609344);
    }

    protected function zoomLevelScale(){
        return [
            14 => 0.5,
            13 => 1,
            12 => 2.5,
            11 => 5,
            10 => 10,
            9 => 12.5,
            8 => 25,
            7 => 50,
            6 => 100,
            5 => 125
        ];
    }

    protected function mapContactsFilter($contacts, $flag = true)
    {
        $latLngs = [];
        $result = [];
        $counts = ['total' => 0];
        foreach($contacts AS $contact){
            $counts['total'] += 1;
            if(array_key_exists($contact->status->name, $counts)){
                $counts[$contact->status->name] += 1;
            }else{
                $counts[$contact->status->name] = 1;
            }
            $contactRow = $this->formContactRow($contact, null);
            $key = array_search($contact->lat.'-'.$contact->lng, $latLngs);
            if($key === false){
                array_push($latLngs, $contact->lat.'-'.$contact->lng);
                $result[] = [
                    'lat' => $contact->lat,
                    'lng' => $contact->lng,
                    'statusChangesNumber' => $contact->status_changes_number ?? 0,
                    'contactsCount' => 1,
                    'contacts' => [$contactRow]
                ];
            }else{
                $row = $result[$key];
                $row['statusChangesNumber'] = $row['statusChangesNumber'] + ($contact->status_changes_number ?? 0);
            $row['contactsCount'] = $row['contactsCount'] + 1;
                array_push($row['contacts'], $contactRow);
                $result[$key] = $row;
            }
        }

        $statuses = [];
        if($flag) {
            foreach ($counts AS $key => $value) {
                $statuses[] = [
                    'label' => $key,
                    'count' => $value
                ];
            }
        }
        return ['contacts' => $result, 'statuses' => $statuses];
    }

     protected function formContactRow($contact, $business)
    {
        $pinColor = $contact->status->color?? '#31a1c0';
        return [
            'id' => $contact->id,
            'pin_type' => $contact->pin_type,
            'priority' => (int) $contact->priority,
            'statusChangesNumber' => $contact->status_changes_number ?? 0,
            'pinColor' => $pinColor,
            'business' => $contact->business_id ?
                [
                    'id' => (empty($business))? $contact->business->id : $business->id,
                    'business_name' => (empty($business))? $contact->business->business_name : $business->business_name,
                ] : (object) null,
            'overview' => [
                'firstName' => $contact->first_name,
                'middleName' => $contact->middle_name,
                'lastName' => $contact->last_name,
                'district' => optional($contact->district)->name,
                'site' => $contact->site ?
                    [
                        'id' => $contact->site->id,
                        'name' => $contact->site->name
                    ] : (object) null,
                'phase' => $contact->phase,
                'status' => $contact->status
            ],
            'contactInformation' => [
                'street1' => $contact->street_address_1,
                'street2' => $contact->street_address_2,
                'city' => $contact->city,
                'state' => $contact->state,
                'zipCode' => $contact->zip_code,
                'phone_1' => $contact->phone_1,
                'phone_2' => $contact->phone_2,
                'email' => $contact->email
            ],
            'eeoc' => [
                'DOB' => $contact->birthdate? $contact->birthdate->format('m/d/Y') : ''
            ],
            'pastSchoolAttended' => [
                'pastSchool' => $contact->past_school_attended,
                'withdrawalCode' => $contact->withdrawal_code,
                'withdrawalDate' => $contact->withdrawal_date
            ],
            'referrer' => [
                'referrer' => $contact->referrer,
                'referralOption' => $contact->referral_option,
                'referralOptionOther' => $contact->referral_option_other
            ],
            'staff' =>  $contact->business_id?[
               'outreachAdvocate' => $contact->business->outreachResourceAdvocate ?
                    [
                        'id' => $contact->business->outreachResourceAdvocate->id,
                        'name' => $contact->business->outreachResourceAdvocate->full_name,
                    ] : (object) null,
                'enrollmentCoach' => $contact->business->communityOutreachAdvocate ?
                    [
                        'id' => $contact->business->communityOutreachAdvocate->id,
                        'name' => $contact->business->communityOutreachAdvocate->full_name,
                    ] : (object) null,
            ]: (object) null,
            'notes' => $contact->notes,
            'updatedAt' => date('M d, Y \a\t h:i A', strtotime($contact->updated_at))
        ];
    }


    public function getContact($row){
        return $this->contactRepository->getContactFilter(new ContactFilters([
            'firstName' => $row['first_name'],
            'lastName' => $row['last_name'],
            'birthdate' => Carbon::createFromFormat('m/d/Y', $row['birthdate'])->format('Y-m-d'),
            'district' =>  $row['district'],
            'tenant' => tenant()->id,
        ]));
    }
    protected function rules($isUpdate=false)
    {
        $rules = [
            'pin_type' => 'required|in:"contact","business"',
            'first_name' => 'required_if:pin_type,"contact"|string|max:255',
            'middle_name' => 'nullable|sometimes|string|max:255',
            'last_name' => 'required_if:pin_type,"contact"|string|max:255',
            'district' => 'required|numeric|exists:districts,id',
            'site_id' => 'nullable|sometimes|numeric|exists:sites,id',
            'referral_option' => 'nullable|sometimes|string|max:255',
            'referral_option_other' => 'nullable|sometimes|string|max:255',
            'referrer' => 'nullable|sometimes|string|max:255',
            'street_address_1' => 'required|string|max:255',
            'street_address_2' => 'nullable|sometimes|string|max:255',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'zip_code' => 'required|string|max:255',
            'phone_1' => 'required|string|max:255',
            'phone_2' => 'nullable|sometimes|string|max:255',
            'email' => 'nullable|sometimes|string|max:255',
            'birth_date' => 'nullable|sometimes|date_format:m/d/Y',
            'cohort_year' => 'nullable|sometimes|date_format:Y',
            'withdrawal_code' => 'nullable|sometimes|string|max:255',
            'withdrawal_date' => 'nullable|sometimes|date_format:m/d/Y',
            //'community_outreach_advocate' => 'nullable|sometimes|numeric|exists:users,id',
            'outreach_advocate' => 'nullable|sometimes|numeric|exists:users,id',
            'notes' => 'nullable|sometimes|string|max:65000',
            'business' => 'required_if:pin_type,"business"|array',
            'business.business_name' => 'required_if:pin_type,"business"|string|max:255',
            'business.first_name' => 'nullable|sometimes|string|max:255',
            'business.last_name' => 'nullable|sometimes|string|max:255',
            'business.city' => 'required_if:pin_type,"business"|string',
            'business.address' => 'required_if:pin_type,"business"|string|max:65000',
            'business.phone' => 'required_if:pin_type,"business"|string|max:191',
            'business.zip_code' => 'required_if:pin_type,"business"|string|max:191',
            'business.state' => 'required_if:pin_type,"business"|string|max:191',
            'business.gc_referral_source' => 'required_if:pin_type,"business"|boolean',
            'business.business_type' => ['required_if:pin_type,"business"',Rule::in((new BusinessType())->getValues())],
            'business.email' => 'nullable|sometimes|string|max:191',
            'business.outreach_resource_advocate' => 'nullable|sometimes|exists:users,id',
            'business.notes' => 'nullable|sometimes|string|max:65000',
            'priority' => 'required|in:0,1,2',
            'status' => 'required|string'
        ];

        if(!$isUpdate){
            $rules['scheduled_date'] = 'required_if:status,"Scheduled"|date_format:m/d/Y';
            $rules['scheduled_date'] = 'required_if:status,"Scheduled"|date_format:m/d/Y';
        }

        return $rules;
    }

    protected function getFillableFields()
    {
        return [
            'first_name', 'middle_name', 'last_name', 'birthdate', 'street_address_1', 'street_address_2', 'city', 'state', 'zip_code',
            'phone_1', 'phone_2', 'email', 'district', 'site_id', 'district_id', 'academy_id', 'cohort_year', 'grade_level', 'withdrawal_code',
            'withdrawal_date', 'status', 'phase','community_outreach_advocate_id', 'outreach_resource_advocate_id', 'notes','site_id',
            'scheduled_date','wa_only_date', 'phone_2_bad', 'phone_1_bad', 'county', 'do_not_contact', 'lat','lng','referral_option_id',
            'past_school_attended','referral_option','referred_by','hear_about', 'referral_option_other', 'referrer',  'pin_type', 'priority'
        ];
    }

    protected function getInputs($postData)
    {
        $fields = $this->getFillableFields();

        $dates = ['birth_date', 'withdrawal_date', 'scheduled_date','wa_only_date'];

        $inputs = [];

        foreach ($fields as $field) {
            $value = array_key_exists($field, $postData) ? $postData[$field] : null;
            $value = (is_string($value) && $value === '') ? null : $value;

            if ($value && in_array($field, $dates)) {
                try {
                    $date = Carbon::createFromFormat('m/d/Y', $value);
                    $value = $date->format('Y-m-d');
                } catch (\Exception $exception) {
                    $value = null;
                }
            }

            $inputs[$field] = $value;
        }
        return $inputs;
    }

    public function geocodeZipCode($zipCode)
    {
        try {
            $url = 'https://maps.googleapis.com/maps/api/geocode/json?components=country:US|postal_code:' . $zipCode . '&key=' . env('GOOGLE_KEY');
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $responseJson = curl_exec($ch);
            curl_close($ch);
            $response = json_decode($responseJson);

            if (empty($response->errorMessage)) {
                if ($response->status == 'ZERO_RESULTS' || empty($response->results)) {
                    return ['status' => false, 'result' => [], 'error' => 'ZERO RESULTS'];
                }

                return ['status' => true, 'result' => $response, 'error' => ''];
            }

            return ['status' => false, 'result' => [], 'error' => $response->errorMessage];
        } catch (\Exception $e) {
            return ['status' => false, 'result' => [], 'error' => $e->getMessage()];
        }
    }

    protected function getContactLatLng($request)
    {
        $fullAddress = $request->street_address_1 . ' ' . $request->street_address_2 . ' ' . $request->city . ' ' . $request->state . ' ' . $request->zip_code;
        $fullAddress = trim($fullAddress);
        $response = $this->geocodeByAddress($fullAddress);
        if(!$response['status']){
            $response =$this->geocodeZipCode($request->zip_code);
            if(!$response['status']){
                return ['status' => false, 'lat' => '', 'lng' => ''];
            }
        }

        $latLng = $response['result']->results[0]->geometry->location;

        return ['status' => true, 'lat' => $latLng->lat, 'lng' => $latLng->lng];
    }

    function geocodeByAddress($address)
    {
        $address = str_replace(' ' , '+', $address);
        try {
            $url = 'https://maps.googleapis.com/maps/api/geocode/json?address='.$address.'&components=country:US&key=' . env('GOOGLE_KEY');
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $responseJson = curl_exec($ch);
            curl_close($ch);
            $response = json_decode($responseJson);

            if (empty($response->errorMessage)) {
                if ($response->status == 'ZERO_RESULTS' || empty($response->results)) {
                    return ['status' => false, 'result' => [], 'error' => 'ZERO RESULTS'];
                }

                return ['status' => true, 'result' => $response, 'error' => ''];
            }

            return ['status' => false, 'result' => [], 'error' => $response->errorMessage];
        } catch (\Exception $e) {
            return ['status' => false, 'result' => [], 'error' => $e->getMessage()];
        }
    }

    public function googleAutoComplete($keyword, $sessionToken)
    {
        $keyword = str_replace(" ", "+", trim($keyword));

        $url = "https://maps.googleapis.com/maps/api/place/autocomplete/json?input=".$keyword."&key=".env('GOOGLE_KEY')."&sessiontoken=".$sessionToken."&types=geocode";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $responseJson = curl_exec($ch);
        curl_close($ch);

        $response = json_decode($responseJson);

        if(empty($response->errorMessage)){
            return ['status' => true, 'result' => $response];
        }

        return ['status' => false, 'result' => $response->errorMessage];
    }
}
