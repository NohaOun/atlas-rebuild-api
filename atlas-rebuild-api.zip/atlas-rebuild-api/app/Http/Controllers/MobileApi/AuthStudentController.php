<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Student\Model\Student;
use App\Http\Requests\SocialLoginRequest;
use App\Http\Resources\ForgotPasswordResource;
use App\Http\Resources\StatusMessageResource;
use App\Http\Resources\TokenResource;
use App\Http\Resources\UserResource;
use App\Models\StudentLogin;
use App\Models\StudentPasswordsQueue;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Laravel\Socialite\Facades\Socialite;

class AuthStudentController extends BaseController
{
    use ApiResponseTrait, ValidationTrait;

    public function login(Request $request)
    {
        $user = $this->getUser($request->get('username'), $this->getUsernameColumn($request->get('username')));

        if (!$user) {
            return (new StatusMessageResource(__('login_failed')))->response()->setStatusCode(401);
        }
        if (!$user || !$user->site || !$user->site->district || !$user->site->district->access_navigator) {
            return (new StatusMessageResource(__('login_failed')))->response()->setStatusCode(401);
        }

        if ($user) {
            if ($this->hasAccess($user)) {
                return $this->loggedUser($user);
            }
        }

        return (new StatusMessageResource(__('email_login_failed')))->response()->setStatusCode(401);
    }

    private function getUsernameColumn($value)
    {
        if (filter_var($value, FILTER_VALIDATE_EMAIL)) {
            return 'email';
        }

        return 'username';
    }

    public function socialLogin(Request $request)
    {
        $validator = $this->validator($request, [
            'type' => 'required|in:facebook,instagram,google,apple',
            'token' => 'required'
        ]);

        if (!empty($validator)) {
            return (new StatusMessageResource(__('Invalid Request')))->response()->setStatusCode(401);
        }

        try {
            $user = Socialite::driver(Str::lower($request->type))->userFromToken($request->token);
        } catch (\Exception $e) {
            return (new StatusMessageResource(__('invalid_user_token')))->response()->setStatusCode(401);
        }

        if (!$user->email) {
            return (new StatusMessageResource(__('social_missing_email')))->response()->setStatusCode(401);
        }

        $student = $this->getUser($user->email, 'email');

        if (!$student) {
            return (new StatusMessageResource(__('social_email_not_match')))->response()->setStatusCode(401);
        }

        if (!$student->site || !$student->site->district || !$student->site->district->access_navigator) {
            return (new StatusMessageResource(__('social_email_not_match')))->response()->setStatusCode(401);
        }

        if ($this->hasAccess($student)) {
            return $this->loggedUser($student);
        }

        return (new StatusMessageResource(__('social_email_not_match')))->response()->setStatusCode(401);

    }


    private function getUser($value, $col)
    {
        return Student::query()
            ->with('site.district')
            ->with(["status.phase" => function ($query) {
                $query->where('name', '!=', PhaseKeyRepositoryInterface::PHASE_NAME_WITHDRAWN)
                    ->where('name', '!=', PhaseKeyRepositoryInterface::PHASE_NAME_DUPLICATE);
            }])
            ->where($col, $value)
            ->first();
    }

    private function hasAccess($user)
    {
        $hasAccess = true;
        if (
            $user->status->phase->phase_key == PhaseKeyRepositoryInterface::PHASE_NAME_GRADUATE &&
            $user->graduation_date &&
            $user->graduation_date->addDays(30)->lt(now())
        ) {
            $hasAccess = false;
        }

        return $hasAccess;
    }

    private function loggedUser($user)
    {
        if (Hash::check(request('password'), $user->password)) {
            return new TokenResource([
                'token' => $user->createToken('students')->accessToken,
                'student' => $user
            ]);
        } else {
            return (new StatusMessageResource(__('email_login_failed')))->response()->setStatusCode(403);
        }

        // if(Auth::guard('student')->attempt(['email' => $user->username, 'password' => $user->password]))
        // {
        //     dd("sa");
        //     return redirect()->intended(route('admin.dashboard'));
        // }

        // dd(auth()->user()->username);
        // $token = Auth::guard('api')->attempt([]); // auth()->login($user);

        //save student login
        // StudentLogin::insert([
        //     'student_id' => $user->id
        // ]);

        // $user->last_login = Carbon::now()->format('Y-m-d H:i:s');
        // $user->save();
        // return new TokenResource([
        //     'token' => $token,
        //     'student' => $user
        // ]);
    }

    public function forgotPassword()
    {
        $student = Student::where('email', request('email'))->with(["status.phase" => function ($query) {
            $query->where('name', '!=', PhaseKeyRepositoryInterface::PHASE_NAME_WITHDRAWN)
                ->where('name', '!=', PhaseKeyRepositoryInterface::PHASE_NAME_DUPLICATE);
        }])->first();

        if (!$student) {
            return (new StatusMessageResource(__('There is no account with this email. Please contact your GCA for help.')))->response()->setStatusCode(404);
        }


        $pass = Str::random(8);

        $token = Str::random(20);

        StudentPasswordsQueue::insert([
            'student_id' => $student->id,
            'email' => request('email'),
            'password' => $pass,
            'token' => $token,
            'status' => 'sent'
        ]);

        $url = '<a href="' . route('students.reset.password.get', $token) . '">here</a>';
        $message = 'Frogot your GC Navigator login password?, please click ' . $url . ' now to reset your password.';
        sendEmail($student->email, 'GC Navigator forgot password.', $message);

        return new ForgotPasswordResource(__('An email has been sent to you with instructions on how to reset your password.'));
    }

    public function recruitmentLogin(Request $request)
    {

        $validator = $this->validator($request, [
            'email' => 'required',
            'password' => 'required'
        ]);

        if (!empty($validator)) {
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }
        $user = User::where('email', $request->email)
            ->where('active', 1)
            // ->where('compass_mobile', 1)
            ->first();

        if (!$user) {
            return $this->apiResponse([], ['email' => __('Incorrect email address')], config('constants.response_codes.unAuthorized'), true);
        }
        if (!$user->isCompassMobile() && !$user->isEnrollmentCoach() && !$user->isOutreachAdvocate()) {
            return $this->apiResponse([], ['email' => __('Incorrect email address')], config('constants.response_codes.unAuthorized'), true);
        }

        if ($this->hasher($request->password, $user->salt) != $user->password) {
            return $this->apiResponse([], ['password' => __('Incorrect password')], config('constants.response_codes.unAuthorized'), true);
        }

        if (empty($user->api_token)) {
            $token = Str::random(60);
            $user->api_token = $token;
            $user->save();
        }

        return $this->apiResponse(new UserResource($user), [], config('constants.response_codes.ok'), 1);
    }

    protected function hasher($password, $salt)
    {
        $result = base64_encode(hash('md5', $password . $salt));
        $result = substr($result, 5, -5);
        return strrev($result);
    }
}

