<?php

namespace App\Http\Controllers\MobileApi;

use Illuminate\Routing\Controller;
use App\Http\Controllers\MobileApi\ApiResponseTrait;
abstract class BaseController extends Controller
{
    use ApiResponseTrait;
}
