<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentParent;
use App\Domain\Student\Model\StudentProfileUpdate;
use App\Domain\Student\Repository\StudentProfileUpdateRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Http\Controllers\Controller;
use App\Http\Requests\Student\UpdateProfileRequest;
use App\Http\Resources\ProfileResource;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;

class ProfileController extends Controller
{
    use ApiResponseTrait;
    public function me(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $rankingList = StudentPointLibrary::getRankingList();
        $student->ranking = Arr::get($rankingList, $student->id);

        return new ProfileResource($student);
    }


    public function getStudentOf(Request $request){
        if(auth()->user() instanceof StudentParent){
            $student_id = $request->headers->get('student-id');
            $parent = auth()->user();
            $student = $parent->students()->where('student_id', $student_id)->firstOrFail();
           
        }else{
            $student = auth()->user();
        }
        return $student;
    }
    
    public function update(UpdateProfileRequest $request){
        $student = auth()->user();

        $newFields = $request->all();
        foreach($this->column_mapping() As $newColumn => $oldColumn){
                if(isset($newFields[$oldColumn]))
                $newFields[$newColumn] = $newFields[$oldColumn];
                unset($newFields[$oldColumn]);
        }
        $student->fill($newFields);
        if(sizeof($newFields) > 0 ){
            $this->studentProfileUpdateRepository = new StudentProfileUpdateRepository();

           $newUpdate = new StudentProfileUpdate();
           $newUpdate->student_id = $student->id;
           $newUpdate->changes = json_encode($newFields);
           $this->studentProfileUpdateRepository->saveStudentProfileUpdates($newUpdate);
        }
        return $this->apiResponse(['message'=>'Your update will be reviewed soon!'], [], 200, true);
    }

    protected function column_mapping(){
        return [
            'street_address' => "address",
            'zip_code' => "zipcode",
            'phone_1' => "phone",
            'phone_1_type' => "phone_type",
            'phone_2' => "phone_secondary",
            'phone_2_type' => "phone_secondary_type"
        ];
     }
}
