<?php
namespace App\Http\Controllers\MobileApi;

use Illuminate\Support\Facades\Validator;

trait ValidationTrait {

	public function validator($request, $rules)
	{
		$validator = Validator::make($request->all(), $rules);
		if($validator->fails()){
			return $validator->errors()->getMessages();
		}

		return [];
	}
}