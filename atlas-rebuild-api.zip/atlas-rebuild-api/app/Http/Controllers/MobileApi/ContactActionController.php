<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Contact\Filters\ContactActionFilters;
use App\Domain\Contact\Model\Contact;
use App\Domain\Contact\Model\ContactAction;
use App\Domain\Contact\Repository\ActionContactRepository;
use App\Domain\Contact\Repository\CategoryContactRepository;
use App\Domain\Contact\Repository\ContactActionRepository;
use App\Domain\Contact\Repository\ContactRepository;
use App\Domain\Lookup\Library\PriorityLibrary;
use App\Domain\Note\Notifications\Contact\ContactNoteTodoCreated;
use App\Domain\Phase\Filters\PhaseFilters;
use App\Domain\Phase\Repository\PhaseKeyRepositoryInterface;
use App\Domain\Phase\Repository\PhaseRepository;
use App\Domain\Status\Filters\StatusFilters;
use App\Domain\Status\Repository\StatusRepository;
use App\Domain\Status\Repository\StatusRepositoryInterface;
use App\Domain\User\Filters\UserFilters;
use App\Domain\User\Repository\UserRepository;
use App\Http\Resources\ActionContactsResource;
use App\Http\Resources\AssignedUserResource;
use App\Http\Resources\CategoryContactsResource;
use App\Http\Resources\ContactActionResource;
use App\Http\Resources\PhaseLabelResource;
use App\Observers\ContactObserver;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use App\Domain\Note\Notifications\Contact\NoteCreated as ContactNoteCreated;
use Illuminate\Support\Facades\Notification;
use stdClass;

class ContactActionController extends BaseController
{
    //
    use ApiResponseTrait, ValidationTrait;
    private $contactRepository;
    private $contactActionRepository;
    private $phaseRepository;
    private $priorityLibrary;
    private $userRepository;
    private $contactObserver;
    public function __construct(ContactRepository $contactRepository,
                PhaseRepository $phaseRepository,
                PriorityLibrary $priorityLibrary,
                UserRepository $userRepository,
                ContactActionRepository $contactActionRepository,
                ContactObserver $contactObserver
                )
    {
        $this->contactRepository = $contactRepository;
        $this->contactActionRepository = $contactActionRepository;
        $this->phaseRepository = $phaseRepository;
        $this->priorityLibrary = $priorityLibrary;
        $this->userRepository = $userRepository;
        $this->contactObserver = $contactObserver;
    }

    public function actionLogList($id)
    {
        $actions = $this->contactActionRepository->getContactActions(new ContactActionFilters(["contact" => $id]))
        ->load(["userAction","assignee", "action", "category", "creator"]);
        $actions = $actions->splice(0, 3);
        // $actions = ContactAction::where('contact_id', $id)
        // ->with(["userAction","assignee", "action", "category", "creator"])->orderBy('id', 'DESC')->limit(3)->get();
        return $this->apiResponse(['actions->' => ContactActionResource::collection($actions)]);
    }

    public function actionLogForm($id)
    {
        $filters = new Collection();
        $filters->put(
            'permission-group', ['group' => 'Atlas GC Profile', 
            'tenant_id' =>  tenant()->id,
            'active' => true]
        );
        $users = $this->userRepository->
            getUsers(new UserFilters($filters)); // Mew Work Permission::CAN_MANAGE_CONTACTS
        $usersArray = [];
        foreach($users as $user){
            $usersArray[] = $user->full_name;
        }
        $users =  $usersArray;
        // $users = User::whereIn(  'user_group',
        // Permission::CAN_MANAGE_CONTACTS)->
        // selectRaw('CONCAT(first_name, " ", last_name) AS full_name')
        // ->pluck('full_name')->all();

        $phases = $this->phaseRepository->getPhases(new PhaseFilters(["Phase-type" => 'contact']))->load("statuses");;

        $priorities = Contact::getPriorities();
        $actionContactRepository = new ActionContactRepository();
        $categoryContactRepository = new CategoryContactRepository();
        $actions =    $actionContactRepository->getActionContacts();
        $categories = $categoryContactRepository->getCategoryContacts();

        $currentUser = auth()->user()->id ?? null;

        // Need Work
        $districts =  auth()->user()->district_id ?? false;
        if(!$districts || empty($districts)){
            $districts = [];
        }else{
            $districts = json_decode($districts, true);
            if(in_array(0, $districts) || in_array('0', $districts)){
                $districts = [];
            }
        }
        $districtsCond = '';
        if(!empty($districts)){
            $districtsCond = " AND (";
            $or = '';
            foreach($districts AS $row){
                $districtsCond .= $or." district_id LIKE '%\"".$row."\"%' ";
                $or = "OR";
            }
            $districtsCond .= " OR district_id IS NULL OR district_id = '[\"0\"]')";
        }
        $asigneedUsers = $this->userRepository->getUsers(new UserFilters(['where-not-in' => array($currentUser), 'active' => true]));
        // $asigneedUsers = User::active()->whereRaw("id != ".$currentUser.$districtsCond)->get(); //Assign To users list

        return $this->apiResponse([
            'users' => $users,
            'phases' => PhaseLabelResource::collection($phases),
            'priorities' => $priorities, 'categories' => CategoryContactsResource::collection($categories),
            'asigneedUsers' => AssignedUserResource::collection($asigneedUsers), 'actions' => ActionContactsResource::collection($actions)]);
    }

    public function saveActionLog(Request $request, $id){
        $validator = $this->validator($request, [
            'action_cat_id' => 'required',
            'phase' => 'required',
            'status' => 'required',
            'scheduled_date' => 'required_if:status,"Scheduled"|date_format:m/d/Y',
            'wa_only_date' => 'required_if:status,"WA ONLY - HB 1418"|date_format:m/d/Y',
            'priority' => 'required|in:0,1,2',
            'notes' => 'nullable|sometimes',
            'mentions' => 'nullable|sometimes|array',
            'assigned_to' => 'required'
        ]);

        if(!empty($validator)){
            return $this->apiResponse([], $validator, config('constants.response_codes.validation_error'), true);
        }
        $contact = $this->contactRepository->getContact($id);
        if(!$contact){
            return $this->apiResponse([], ['failed' => 'Can\'t find the contact you seek'], config('constants.response_codes.not_found'), true);
        }
        $request->assigned_to = (isset($request->assigned_to) &&
        $request->assigned_to == 'self')? auth()->user()->id :
            (!empty($request->assigned_to)? $request->assigned_to : 'null');

        if(isset($request->assigned_to) && $request->assigned_to != 'self' && !empty($request->assigned_to)){
        $request->user_time_zone = $this->userRepository->getUserById($request->assigned_to)->timezone->id;
        }else{
            $request->user_time_zone = auth()->user()->timezone->id;

        }
        $request->due_date = (isset($request->due_date) && !empty($request->due_date))? date('Y-m-d', strtotime($request->due_date)) : 'null';
        // $request->due_date_time = (isset($request->due_date) && !empty($request->due_date))?
        //         convertUTC(date('Y-m-d', strtotime($request->due_date)),'Y-m-d H:i:s',
        //         $request->user_time_zone):null;
        $request->status_note = ($request->follow_up == 'completed')? 'completed' : 'pending';
        $request->action_type = ($request->follow_up == 'completed')? 'completed' : 'pending';

        $result = $this->saveAction($request,$contact);
        $action = $result['action'];

        if(!$result['status'] || !$result['action']){
            return $this->apiResponse([], ['failed' => 'Failed to add the action, please try again later'], config('constants.response_codes.server'), true);
        }

        if($request->follow_up == 'to do'){
            $action->assignee->notify(new ContactNoteTodoCreated($action));
        }

        $usersMentioned = $this->userRepository->getUsersById($result['mentions']);
        $action = $action->fresh();
        $action->usersMentioned = $usersMentioned->pluck("full_name")->toArray();
        if(count($usersMentioned)){
            $object = new stdClass();
            $user = auth()->user();
            $object->contact_id = $contact->id;
            $object->full_name = $user->full_name;
            $object->email = $user->email;
            $object->category = $contact->category->name?? "Cannot get the category";
            $object->note_id = $action->id;
            $object->note = $action->note;
            $object->contact_full_name = $action->contact->full_name;
            Notification::send($usersMentioned, new ContactNoteCreated($object));
            // foreach($usersMentioned as $user){
            // $this->auditEmail($user->email, $subject, $message,pathinfo(__FILE__, PATHINFO_BASENAME));
            // }
        }
        return $this->apiResponse(['action' => new ContactActionResource($action)]);
    }

    // ID Of Contact Action
    public function UpdateAction(Request $request, $id=null)
    {
        $contact_action = $this->contactActionRepository->getContactAction($id);
        if(!$contact_action ){
            return $this->apiResponse([],["error" => "Not Found"],404);
        }
        $note_readable = $this->NoteTostring($request->note);
        $contact_action->following_note = $note_readable;;
        $contact_action->action_type = $request->action;
        $contact_action->following_date = Carbon::createFromFormat('m/d/Y', $request->date)->format('Y-m-d');
        $contact_action->follower_id = auth()->user()->id;
        $this->contactActionRepository->saveContactAction($contact_action);
        $contact = $contact_action->contact;
        /**/
        $usersMentioned = [];
        if (!empty($request->mentions)) {
            $usersMentioned = $this->userRepository->getUsersById($request->mentions);
            $object = new stdClass();
            $object->contact_id = $contact_action->contact_id;
            $user = auth()->user();
            $object->full_name = $user->full_name;
            $object->email = $user->email;
            $object->category = $contact->category->name?? "Cannot get the category";
            $object->note_id = $contact_action->id;
            $object->note = $note_readable;
            $object->contact_full_name = $contact_action->contact->full_name;
            Notification::send($usersMentioned, new ContactNoteCreated($object));
            // foreach($usersMentioned as $user){
            // $this->auditEmail($user->email, $subject, $message,pathinfo(__FILE__, PATHINFO_BASENAME));
            // }
        }
        $contact_action->usersMentioned = $usersMentioned->pluck("full_name")->toArray();

        return $this->apiResponse(['action' => new ContactActionResource($contact_action)]);
    }

    protected function auditEmail($to,$subject,$message,$file){
        AuditEmail::insert([
            'user_id' => auth()->user()->id,
            'datetime_change' => date('Y-m-d H:i:s'),
            'user_ip' => $_SERVER['REMOTE_ADDR'],
            'script' => $file ,
            'to' => $to,
            'from' => env('EMAIL_NOREPLY', 'noreply@'.env('WEB_APP_DOMAIN')),
            'subject' => $subject,
            'contents' => $message,
        ]);
    }

    public function saveAction($request, $contact)
    {
        $mentions = [];
        DB::beginTransaction();
        try {

            if($request->status == StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED){
                $scheduled_date = Carbon::createFromFormat('m/d/Y', $request->scheduled_date);
                $scheduled_date = $scheduled_date->format('Y-m-d');
                $contact->scheduled_date = $scheduled_date;
            }
            if($request->status == StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED &&
                $contact->status->name == StatusRepositoryInterface::STATUS_KEY_WA_ONLY_HB1418 &&
                !empty($request->wa_only_date)){
                $wa_only_date = Carbon::createFromFormat('m/d/Y', $request->wa_only_date);
                $wa_only_date = $wa_only_date->format('Y-m-d');
                $contact->wa_only_date = $wa_only_date;
            }
            if($contact->status->phase->name != $request->phase || $contact->status->name != $request->status || $contact->priority != $request->priority ){
                if(!$contact->business_id) {
                    if (
                        ($contact->status->phase->name != $request->phase || $contact->status->name != $request->status) &&
                        ($request->phase == PhaseKeyRepositoryInterface::PHASE_NAME_RECRUITMENT && $request->status == StatusRepositoryInterface::STATUS_KEY_APPOINTMENT_SCHEDULED)
                    ) {
                        $this->contactObserver->createStudent($contact);
                    }
                }
                if(!empty($request->status)){
                    $statusRepository = new StatusRepository();
                    if($status =  $statusRepository->getStatusByFilters(new StatusFilters(["status-name" => $request->status, "phase-name" => $request->phase])))
                        $contact->status_id = $status->id;
                 }
                // $contact->phase = $request->phase;
                // $contact->status = $request->status;
                $contact->priority = $request->priority;
                // $contact->status_changes_number = (int)$contact->status_changes_number + 1;
                $contact->save();
            }
            $inputs = $request->all();
            foreach($this->column_mapping() As $oldColumn => $newColumn){
                if(isset($inputs[$oldColumn]))
                    $inputs[$newColumn] = $inputs[$oldColumn];
                unset($inputs[$oldColumn]);
            }
            $inputs["note"] = $this->NoteTostring($inputs["note"]);
            $inputs["assignee_id"] = $request->assigned_to;
            $inputs["contact_id"] = $contact->id;
            $inputs["status_id"] = $contact->status_id;
            $inputs["creator_id"] = auth()->user()->id;
            $inputs["scheduled_date"] = Carbon::createFromFormat('m/d/Y', $request->scheduled_date);
            if(!empty($request->mentions)){
                $inputs["mentions"] = $request->mentions;
            }
            $action =new ContactAction($inputs);
            $this->contactActionRepository->saveContactAction($action);
            $mentions = $request->mentions;
            // if(!empty($mentions)){
            //     $districtLog = [];
            //     foreach($mentions AS $mention){
            //         $districtLog[] = new DistrictEmailLog([
            //             'contact_id' => $action->contact_id,
            //             'email_id' => $mention->id,
            //             'date_sent' => Carbon::now()->format('Y-m-d H:i:s'),
            //             'user_edited' => auth()->user()->id
            //         ]);
            //     }

            //     if(!empty($districtLog)){
            //         $action->districtEmailLogs()->saveMany($districtLog);
            //     }
            // }
            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
            dd($e);
            return ['action' => null, 'status' => false, 'mentions' => []];
        }

        return ['action' => $action, 'status' => true, 'mentions' => $mentions];
    }

    // protected function getMentionedUsers($mentions)
    // {
    //     return User::whereIn(DB::raw('CONCAT(first_name, " ", last_name)'), $mentions)->get();
    // }

    public function addToDistrictLog($action, $mentionsIds){
        foreach($mentionsIds as $mentionedID){
            $districtEmailLog = new DistrictEmailLog();
            $districtEmailLog->retention_id = $action->id;
            $districtEmailLog->contact_id = $action->contact_id;
            $districtEmailLog->email_id = $mentionedID;
            $districtEmailLog->date_sent = Carbon::now()->format('Y-m-d H:i:s');
            $districtEmailLog->user_edited = auth()->user()->id;
            $districtEmailLog->save();
        }
    }

    public function NoteTostring($note){
        $notes = [];
        $names = [];
        // Get all inside [[ ]] as Json string
        preg_match_all('/(?<=\[\[)(.*)(?=\]\])/siU', $note, $output, PREG_PATTERN_ORDER);
        // Convert Json object to php object and fill my needed arrays
        foreach ($output[0] as $key => $jsonObject) {
            $notes[$key] = json_decode($jsonObject);
            $names[$key] = $notes[$key]->value;
        }
        $note = preg_replace_array('/(?<=\[\[)(.*)(?=\]\])/siU',$names,$note);
        // delete [[ and ]]
        //$note = preg_replace('/(\[\[|\]\])*/','',$note);
        return $note;
    }

    protected function column_mapping(){
        return [
            "action" => "contact_action_id",
            "action_cat_id" => "contact_category_id",
            "status_note" => "following_note",
            "assigned_to" => "assignee_id",
            "notes" => "note"
       ];
     }
}
