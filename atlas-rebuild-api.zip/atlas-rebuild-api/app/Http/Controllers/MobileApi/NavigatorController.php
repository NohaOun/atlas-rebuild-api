<?php

namespace App\Http\Controllers\MobileApi;

use App\Domain\Challenge\ChallengeLibrary;
use App\Domain\Contact\ContactLibrary;
use App\Domain\Edmentum\CoursewareAuditLiberary;
use App\Domain\Edmentum\Model\Activity;
use App\Domain\Edmentum\Model\ActivityLearner;
use App\Domain\Edmentum\Model\ClassLearner;
use App\Domain\Edmentum\Model\EdmentumCoursewareAudit;
use App\Domain\Lookup\Model\PhoneType;
use App\Domain\Plp\PlanLibrary;
use App\Domain\Student\Filters\StudentFilters;
use App\Domain\Student\Model\Student;
use App\Domain\Student\Model\StudentParent;
use App\Domain\Student\Repository\StudentRepository;
use App\Domain\StudentAttendance\Filters\StudentAttendanceEntryFilters;
use App\Domain\StudentAttendance\StudentAttendanceLibrary;
use App\Domain\StudentPoint\Filters\StudentPointFilters;
use App\Domain\StudentPoint\Repository\StudentPointRepository;
use App\Domain\StudentPoint\StudentPointLibrary;
use App\Http\Controllers\Controller;
use App\Http\Resources\AttendanceResource;
use App\Http\Resources\ChallengesResource;
use App\Http\Resources\CourseworkResource;
use App\Http\Resources\GraduationResource;
use App\Http\Resources\GroupChatReceiversResource;
use App\Http\Resources\HomeResource;
use App\Http\Resources\LeaderboardResource;
use App\Http\Resources\StatusMessageResource;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;

class NavigatorController extends Controller
{
    //
    use ApiResponseTrait;

    private $studentPointRepository;
    private $planLibrary;
    private $contactLibrary;
    private $studentAttendanceLibrary;
    public function __construct(
        StudentPointRepository $studentPointRepository,
        ContactLibrary $contactLibrary,
        PlanLibrary $planLibrary,
        ChallengeLibrary $challengeLibrary,
        StudentAttendanceLibrary $studentAttendanceLibrary
    )
    {
        $this->studentPointRepository = $studentPointRepository;
        $this->contactLibrary = $contactLibrary;
        $this->planLibrary = $planLibrary;
        $this->challengeLibrary = $challengeLibrary;
        $this->studentAttendanceLibrary = $studentAttendanceLibrary;
    }

    public function getStudentOf(Request $request){
        if(auth()->user() instanceof StudentParent){
            $student_id = $request->headers->get('student-id');
            $parent = auth()->user();
            $student = $parent->students()->where('student_id', $student_id)->firstOrFail();

        }else{
            $student = auth()->user();
        }
        return $student;
    }
    public function home(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $current_plan = $student->activePlpPlan;
        if($current_plan){
            $plan_credits =  $current_plan->content["total_diploma_credit"];
            $earnedCredits = $current_plan->content["total_credit"];
            $toGoal = round(($earnedCredits / $plan_credits) * 100) . '%';
        }else{
           $toGoal = '0%';
        }

        $attendance = ceil($this->studentAttendanceLibrary->getOverallAttendanceForAsPercentage(new StudentAttendanceEntryFilters(["studentId" => $student->id])) * 100) . '%';

        $lastCourseDetails = $this->lastCourseDetails($request);
        if( $lastCourseDetails){
           $coursework = floor($lastCourseDetails->percentage_complete) .'%';
        }else{
            $coursework = '0%';
        }

        return new HomeResource(compact('attendance', 'coursework', 'toGoal'));
    }


    public function leaderboard()
    {
        ini_set('memory_limit', '-1');
        $students = StudentPointLibrary::getRankingList();

        $students->map(function ($student, $key) {
            $student->ranking = ++$key;
        });

        return LeaderboardResource::collection($students);
    }

    public function graduation(Request $request)
    {
        // Check If Parent Is logged in
        $student = $this->getStudentOf($request);
        $current_plan = $student->activePlpPlan; //$this->planLibrary->getActiveStudentPlan($student->id);
        if (!$current_plan){
            $all_plans = $this->planLibrary->getStudentPlans($student->id)->toArray();
            if(!empty($all_plans)){
                foreach ($all_plans as $plan) {
                    $current_plan = $plan;
                    break;
                }
            }else if(!$current_plan){
                $data['credits'] = '';
                $data['toGoal'] = '';
                $data['courses'] = [];
                return new GraduationResource($data);
            }
        }
           $plan_credits = $current_plan["content"]["total_diploma_credit"];
        $earnedCredits = 0;
        $data['courses'] = [];
        foreach ($current_plan["content"]["groups"] as $group) {
            $courseList = [];
            $courseList['name'] = $group["group"]["name"]?? null;
            $courseList['total_credit'] = $group["group"]["min_credit"]?? null;
            $courseList['completed_credit'] = 0;
            foreach ($group["courses"] as $key => $course) {
                $earnedCredits += $course["earned_credit"]?? 0;
                $courseList['completed_credit'] += $course["earned_credit"] ?? 0;
            }
            $data['courses'][] =  $courseList;
        }

        $earnedCredits = $current_plan->content["total_credit"];
        $data['credits'] = round($earnedCredits). '/' . $plan_credits;
        $data['toGoal'] = round(($earnedCredits / $plan_credits) * 100) . '%';

        return new GraduationResource($data);
    }


    public function getStatesAndPhoneTypes(){
        return ['states'=> config('states'),
                'phone_types'=>(new PhoneType())->getValues()];
    }

    public function updateDeviceToken(Request $request)
    {
        auth()->user()->fill(['device_token' => $request->get('device_token')])->save();

        return new StatusMessageResource(__('Device token has been saved successfully.'));
    }

    public function coursework(Request $request)
    {
        $lastCourseDetails = $this->lastCourseDetails($request);
        if ($lastCourseDetails) {
            $coursework = floor(100 - $lastCourseDetails->percentage_complete) . '%';
        } else {
            $coursework = "0%";
        }
        $currentCourse = [
            'name' => $lastCourseDetails->className ?? null,
            'grade' => ($lastCourseDetails->percentage_complete ?? null) . '%',
        ];

        return new CourseworkResource(compact('coursework', 'currentCourse'));
    }

    public function lastCourseDetails(Request $request){

        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        if(config('custom.challenges_attendance_method') == 'EDMENTUM'){
            return $student->edmentumCoursewareAuditsLatest;
        }else{
            return null;
        //    return auth()->user()->progress()->orderBy('id', 'DESC')->first();
        }
    }

    public function emptyObject(){
        $lastCourse = new \stdClass();
        $lastCourse->percent_by_count = 0;
        $lastCourse->name = null;

        return $lastCourse;
    }


    public function ReferralFriend(Request $request){
        $validator = Validator::make(request()->all(), [
            'state' => 'required,string',
            'first_name' => 'required,string',
            'last_name' => 'required,string',
            'phone' => 'required, numeric, digits:10',
            'address' => 'required,string',
            'city' => 'required,string',
        ]);
        $student = auth()->user();
        $inputs = ["attributes"];
        $inputs["attributes"] = $request->only(['state', 'first_name', 'last_name', 'phone_1', 'street_address_1', 'city']);
        $inputs['relationships'] = [];
        $inputs['attributes']['district'] = optional($student->site)->district_id;
        $inputs['attributes']['status_id'] = 50; // ToDo: Should be replaced based on phase/status key
        $inputs["attributes"]["referrer"] = $student->referral_code;
        $inputs["attributes"]["tenant_id"] = $student->tenant->id;
        $inputs["attributes"]["referred_by"] = $student->referral_code;
        $inputs["attributes"]["hear_about"] = "Family/Friend";

        $this->contactLibrary->CreateContactFromReferralFriend($inputs);

        return new StatusMessageResource(__('Referral Friend Created Successfully.'));
    }


    public function challenges(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $studentPoints =  $student->availablePoints;

        $activeChallenges = $this->challengeLibrary->getStandardChallenges()->pluck('name');

        $factorRecord = $student->tenant->config["site_settings"]["points_to_dollars_factor"];
        $factor = $factorRecord ? floatval($factorRecord) : 1;
        $amount = round(intval($studentPoints) / $factor,2);


        return new ChallengesResource(compact('studentPoints', 'activeChallenges', 'amount'));
    }

    public function attendance(Request $request)
    {
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $recentAttendance = $this->studentAttendanceLibrary->getLatestByLimitStudentAttendance($student->id, 3)->pluck('check_in')->map(function ($date) {
            return $date->format('Y-m-d');
        });

        //Same as home for attendance (weekly).
        $attendance =$this->studentAttendanceLibrary->getOverallAttendanceFor(new StudentAttendanceEntryFilters(["studentId" => $student->id]));

        $toGoal = ceil($this->studentAttendanceLibrary->getOverallAttendanceForAsPercentage(new StudentAttendanceEntryFilters(["studentId" => $student->id])) * 100) . '%';

        return new AttendanceResource(compact('recentAttendance', 'toGoal', 'attendance'));
    }

      /**
     * @API Return the Badges Of current logged User
     * @return Array of Objects Containt name , image
     * @return {
     *      name : '',
     *      image : '',
     *  }
     */
    public function getRewardsBadges(Request $request){

        // Get All Badges For this Student
        // Make it distinct Becuase user can Gain Multiple of Badges
        // Check If Parent Is logged in 
        $student = $this->getStudentOf($request);
        $badges =  $student->badges()->distinct()->with('media')->get();
        $array = [];
        foreach ($badges as $key => $badge) {
            $image = $badge->getFirstMedia('image');
            // retrive them and Convert it to array to send it
            $array[$key] = [
                'name' => $badge->name,
                'status' => $badge->status,
                'image' => $image ? $image->getFullUrl() : null
            ];
        }
        return $array;
    }

    public function getCustomFields(){
        return $this->apiResponse(tenant()->config["fields"] );
    }
}
