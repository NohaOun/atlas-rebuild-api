<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Storage;

class NoteController extends Controller
{
    public function download()
    {
        return Storage::disk('public')->download('notes/notes-template.csv');
    }
}
