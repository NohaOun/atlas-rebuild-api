<?php

namespace App\Http\Controllers;

use App\Domain\Student\GeneratePDFLibrary;
use Illuminate\Support\Facades\Storage;

class PDFController extends Controller
{
    private $generatePdfLibrary;

    public function __construct(GeneratePDFLibrary $generatePdfLibrary)
    {
        $this->generatePdfLibrary = $generatePdfLibrary;
    }

    public function download()
    {

        return Storage::download('public/pdf/pdf_file.pdf');
    }
    
     public function userDownload()
    {

        return Storage::download('public/pdf/pdf_file_user.pdf');
    }
}