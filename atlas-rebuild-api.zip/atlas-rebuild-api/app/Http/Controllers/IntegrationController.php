<?php

namespace App\Http\Controllers;

use App\Domain\CallLog\Provider\Zoom\Manager;
use App\Domain\Tenancy\TenantLibrary;
use Illuminate\Http\Request;

class IntegrationController extends Controller
{
    /**
     * @var Manager
     */
    private $zoomManager;

    /**
     * @var TenantLibrary
     */
    private $tenantLibrary;

    public function __construct(Manager $zoomManager, TenantLibrary $tenantLibrary)
    {
        $this->zoomManager = $zoomManager;
        $this->tenantLibrary = $tenantLibrary;
    }

    public function zoomRedirect(Request $request)
    {
        $tenant = $this->tenantLibrary->getTenant($request->get('tenant'));

        $url = $this->zoomManager->setTenant($tenant)->getAuthRedirectUrl();

        return redirect($url);
    }

    public function zoomCallback($tenantId, Request $request)
    {
        $code = $request->query('code');
        $tenant = $this->tenantLibrary->getTenant($tenantId);

        $this->zoomManager->setTenant($tenant)->authenticate($code);

        return redirect()->to(
            sprintf('%s/dashboard?integration=zoom&status=success', config('app.web_app_url'))
        );
    }
}
