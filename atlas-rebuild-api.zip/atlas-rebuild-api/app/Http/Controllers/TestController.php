<?php


namespace App\Http\Controllers;


use App\Domain\Zoom\ZoomService;
use Illuminate\Http\Request;
use Pusher\Pusher;

class TestController extends Controller
{
    private $zoomService;

    public function __construct(ZoomService $zoomService)
    {
        return $this->zoomService = $zoomService;
    }

    public function test()
    {
        return $this->zoomService->fetchData();
    }

    public function zoomCallback(Request $request)
    {
        $request = $request->all();
        return $request['code'];
    }

    public function authPusher(Request $request)
    {
        $pusher = new Pusher(
            config('broadcasting.connections.pusher.key'),
            config('broadcasting.connections.pusher.secret'),
            config('broadcasting.connections.pusher.app_id')
        );

        return $pusher->socket_auth($request->channel_name, $request->socket_id);
    }
}
